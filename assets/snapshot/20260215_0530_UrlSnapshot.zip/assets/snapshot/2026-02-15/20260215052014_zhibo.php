虎牙网页,#genre#
虎牙放映厅(网页),video://https://www.huya.com/11602077
刘德华(网页),video://https://www.huya.com/11342424
许冠英(网页),video://https://www.huya.com/11601972
李连杰(网页),video://https://www.huya.com/11342390
甄子丹(网页),video://https://www.huya.com/11352935
周润发(网页),video://https://www.huya.com/11342387
周星星(网页),video://https://www.huya.com/11336587
洪金宝(网页),video://https://www.huya.com/11279251
梁家辉(网页),video://https://www.huya.com/11342429
洪金宝(网页),video://https://www.huya.com/11279251
五福星(网页),video://https://www.huya.com/11282233
古天乐(网页),video://https://www.huya.com/11602041
邱淑贞(网页),video://https://www.huya.com/11352949
周海媚(网页),video://https://www.huya.com/11279247
星爷(网页),video://https://www.huya.com/11342412
英叔(网页),video://https://www.huya.com/11342421
成龙(网页),video://https://www.huya.com/11342386
王晶(网页),video://https://www.huya.com/11602058
沈腾(网页),video://https://www.huya.com/11601968
黄渤(网页),video://https://www.huya.com/11352876
吴京(网页),video://https://www.huya.com/11602041
强森(网页),video://https://www.huya.com/21059581
玄幻(网页),video://https://www.huya.com/11342414
喜剧(网页),video://https://www.huya.com/11352877
港片(网页),video://https://www.huya.com/11602043
国产(网页),video://https://www.huya.com/11352973
漫威(网页),video://https://www.huya.com/11602034
宇宙(网页),video://https://www.huya.com/11342428
怪兽(网页),video://https://www.huya.com/21059577
武侠(网页),video://https://www.huya.com/11342427
警匪(网页),video://https://www.huya.com/11352886
罪犯(网页),video://https://www.huya.com/11352962
枪战(网页),video://https://www.huya.com/21059579
盗墓(网页),video://https://www.huya.com/21059552
海盗(网页),video://https://www.huya.com/21059595
推荐(网页),video://https://www.huya.com/11602041
救援(网页),video://https://www.huya.com/21059594
热血(网页),video://https://www.huya.com/11352934
谍战(网页),video://https://www.huya.com/21059585
战争(网页),video://https://www.huya.com/21059592
小鬼头(网页),video://https://www.huya.com/11352963
陈翔六点半(网页),video://https://www.huya.com/11274154
喜剧专场(网页),video://https://www.huya.com/11602044
高分动作(网页),video://https://www.huya.com/11352884
不挤影院(网页),video://https://www.huya.com/11352897
黑帮斗争(网页),video://https://www.huya.com/11342419
嫣然影厅(网页),video://https://www.huya.com/11601977
女神系列(网页),video://https://www.huya.com/11336571
经典女神(网页),video://https://www.huya.com/11352909
许氏三杰(网页),video://https://www.huya.com/11602033
经典港片(网页),video://https://www.huya.com/11352965
镖行天下(网页),video://https://www.huya.com/11352969
蘑菇影厅(网页),video://https://www.huya.com/11601981
搞笑恐怖(网页),video://https://www.huya.com/11601960
死神来了(网页),video://https://www.huya.com/11352903
超异能族(网页),video://https://www.huya.com/21059586
古墓系列(网页),video://https://www.huya.com/11352913
动作电影(网页),video://https://www.huya.com/11602077
搞笑喜剧(网页),video://https://www.huya.com/11342423
欢笑影院(网页),video://https://www.huya.com/11352894
国产悬疑(网页),video://https://www.huya.com/11342395
快意江湖(网页),video://https://www.huya.com/11342435
喜乐影院(网页),video://https://www.huya.com/21059580
怪兽系列(网页),video://https://www.huya.com/21059554
杰森·斯坦森(网页),video://https://www.huya.com/21059588
1寻秦记(网页),video://https://www.huya.com/29465848
1寻秦记(网页),video://https://www.huya.com/29633850
2西游记2(网页),video://https://www.huya.com/29465859
3扫黄先锋(网页),video://https://www.huya.com/29465855
4楚汉骄雄(网页),video://https://www.huya.com/29465854
5陀枪师姐(网页),video://https://www.huya.com/29465857
6法证先锋4(网页),video://https://www.huya.com/29465861
7刑事侦缉档案(网页),video://https://www.huya.com/29465856
8笑看风云(网页),video://https://www.huya.com/29465858
9大唐双龙传(网页),video://https://www.huya.com/29465850
10洗冤录(网页),video://https://www.huya.com/29465851
11金枝欲孽(网页),video://https://www.huya.com/29465847
12野蛮奶奶大战戈师奶(网页),video://https://www.huya.com/23863796
13创世纪(网页),video://https://www.huya.com/29465852
14封神榜(网页),video://https://www.huya.com/29465849
15神雕侠侣(网页),video://https://www.huya.com/30454429
16妙手仁心(网页),video://https://www.huya.com/29465853
17活佛济公3(网页),video://https://www.huya.com/23903123
倚天屠龙记(网页),video://https://www.huya.com/27834853
鹿鼎记98(网页),video://https://www.huya.com/26355806
小李飞刀(网页),video://https://www.huya.com/11342417
水月洞天(网页),video://https://www.huya.com/21059567
绝代双娇(网页),video://https://www.huya.com/29465867
风云雄霸天下(网页),video://https://www.huya.com/21059612
如懿传(网页),video://https://www.huya.com/29465868
芈月传(网页),video://https://www.huya.com/11352975
延禧攻略(网页),video://https://www.huya.com/26355864
王子变青蛙(网页),video://https://www.huya.com/11601964
永夜星河(网页),video://https://www.huya.com/23734169
玫瑰的故事(网页),video://https://www.huya.com/23865142
漫长的季节(网页),video://https://www.huya.com/11342393
梦华录(网页),video://https://www.huya.com/11336590
乌龙院闯情关(网页),video://https://www.huya.com/26355767
新楚留香(网页),video://https://www.huya.com/26355848
新楚留香(网页),video://https://www.huya.com/23863804
无心法师(网页),video://https://www.huya.com/30080233
征服(网页),video://https://www.huya.com/30311494
蜡笔小新(网页),video://https://www.huya.com/30299353
海绵宝宝(网页),video://https://www.huya.com/11352919
龙珠(网页),video://https://www.huya.com/10279885
叮当全集剧集(网页),video://https://www.huya.com/11601963
樱桃小丸子剧(网页),video://https://www.huya.com/11342394
猫和老鼠剧集(网页),video://https://www.huya.com/11352879
鬼吹灯之精绝古城(网页),video://https://www.huya.com/11352871
鬼吹灯之怒晴湘西(网页),video://https://www.huya.com/11602075
鬼吹灯之龙岭迷窟(网页),video://https://www.huya.com/29465863
鬼吹灯之云南虫谷(网页),video://https://www.huya.com/11352898
JJ斗地主(网页),video://https://www.huya.com/14079954
亮剑(网页),video://https://www.huya.com/30080238
民兵葛二蛋(网页),video://https://www.huya.com/11602072
我的团长我的团(网页),video://https://www.huya.com/11352910
铁道游击队(网页),video://https://www.huya.com/11352936
铁梨花(网页),video://https://www.huya.com/11352912
康熙微服私访记(网页),video://https://www.huya.com/11342418
御赐小仵作(网页),video://https://www.huya.com/11352948
新水浒传(网页),video://https://www.huya.com/11342384
开端(网页),video://https://www.huya.com/11342397
神探狄仁杰(网页),video://https://www.huya.com/11352958
三国演义（94版）(网页),video://https://www.huya.com/11602081
新三国演义(网页),video://https://www.huya.com/11352944
问心(网页),video://https://www.huya.com/11352890
家有儿女(网页),video://https://www.huya.com/29774370
全职高手(网页),video://https://www.huya.com/11352901
炊事班的故事3(网页),video://https://www.huya.com/19524135
医馆笑传(网页),video://https://www.huya.com/11352891
杨光的快乐生活(网页),video://https://www.huya.com/11602085
陈情令(网页),video://https://www.huya.com/29465862
神医喜来乐(网页),video://https://www.huya.com/11601978
大宋提刑官(网页),video://https://www.huya.com/26355856
鹊刀门传奇(网页),video://https://www.huya.com/29805872
白鹿原(网页),video://https://www.huya.com/11342416
长相思(网页),video://https://www.huya.com/11336593
你是我的荣耀(网页),video://https://www.huya.com/11352920
一代枭雄(网页),video://https://www.huya.com/11342398
庆余年(网页),video://https://www.huya.com/11352960
铁齿铜牙纪晓岚(网页),video://https://www.huya.com/11342396
镖行天下(网页),video://https://www.huya.com/11352969
雪中悍刀行(网页),video://https://www.huya.com/11336592
星汉灿烂·月生沧海(网页),video://https://www.huya.com/11336591
将夜(网页),video://https://www.huya.com/11352885
父母爱情(网页),video://https://www.huya.com/11602071
大染坊(网页),video://https://www.huya.com/11602086
地下交通站(网页),video://https://www.huya.com/11342433
邻里一家亲(网页),video://https://www.huya.com/11342426
剧集_雍正王朝(网页),video://https://www.huya.com/11342439
剧集_士兵突击(网页),video://https://www.huya.com/11342430
剧集_爱情公寓(网页),video://https://www.huya.com/11336726
电视剧场一(网页),video://https://www.huya.com/29465862
电视剧场二(网页),video://https://www.huya.com/11336591
电视剧场三(网页),video://https://www.huya.com/21059563
电视剧场四(网页),video://https://www.huya.com/26355783
电视剧场五(网页),video://https://www.huya.com/11352912
电视剧场六(网页),video://https://www.huya.com/11352936
电视剧场七(网页),video://https://www.huya.com/21059630
电视剧场八(网页),video://https://www.huya.com/26355775
电视剧场九(网页),video://https://www.huya.com/21059594
电视剧场十(网页),video://https://www.huya.com/11336592
电视剧场十一(网页),video://https://www.huya.com/11602088




体育咪咕,#genre#
五星体育,http://43.251.226.89:9003/live/a9fc6080659aa5463f2f60e92e0328e8?token=8520
睛彩竞技,http://43.251.226.89:9003/TVOD/3000000020000011528.m3u8?token=8520
睛彩篮球,http://43.251.226.89:9003/TVOD/3000000020000011529.m3u8?token=8520
睛彩青少,http://43.251.226.89:9003/TVOD/3000000020000011525.m3u8?token=8520
咪咕视频-1,http://43.251.226.89:9003/TVOD/3000000001000005308.m3u8?token=8520
咪咕视频-2,http://43.251.226.89:9003/TVOD/3000000001000005969.m3u8?token=8520
咪咕视频-3,http://43.251.226.89:9003/TVOD/3000000001000007218.m3u8?token=8520
咪咕视频-4,http://43.251.226.89:9003/TVOD/3000000001000008001.m3u8?token=8520
咪咕视频-5,http://43.251.226.89:9003/TVOD/3000000001000008176.m3u8?token=8520
咪咕视频-6,http://43.251.226.89:9003/TVOD/3000000001000008379.m3u8?token=8520
咪咕视频-7,http://43.251.226.89:9003/TVOD/3000000001000010129.m3u8?token=8520
咪咕视频-8,http://43.251.226.89:9003/TVOD/3000000001000010948.m3u8?token=8520
咪咕视频-9,http://43.251.226.89:9003/TVOD/3000000001000028638.m3u8?token=8520
咪咕视频-10,http://43.251.226.89:9003/TVOD/3000000001000031494.m3u8?token=8520
咪咕视频-11,http://43.251.226.89:9003/TVOD/3000000010000005837.m3u8?token=8520
咪咕视频-12,http://43.251.226.89:9003/TVOD/3000000020000011518.m3u8?token=8520
咪咕视频-13,http://43.251.226.89:9003/TVOD/3000000020000011519.m3u8?token=8520
咪咕视频-14,http://43.251.226.89:9003/TVOD/3000000020000011520.m3u8?token=8520
咪咕视频-15,http://43.251.226.89:9003/TVOD/3000000020000011521.m3u8?token=8520
咪咕视频-16,http://43.251.226.89:9003/TVOD/3000000020000011522.m3u8?token=8520
咪咕视频-24,http://43.251.226.89:9003/TVOD/3000000010000000097.m3u8?token=8520
咪咕视频-25,http://43.251.226.89:9003/TVOD/3000000010000002019.m3u8?token=8520
咪咕视频-26,http://43.251.226.89:9003/TVOD/3000000010000002809.m3u8?token=8520
咪咕视频-27,http://43.251.226.89:9003/TVOD/3000000010000003915.m3u8?token=8520
咪咕视频-28,http://43.251.226.89:9003/TVOD/3000000010000004193.m3u8?token=8520
咪咕视频-29,http://43.251.226.89:9003/TVOD/3000000010000006077.m3u8?token=8520
咪咕视频-30,http://43.251.226.89:9003/TVOD/3000000010000006658.m3u8?token=8520
咪咕视频-31,http://43.251.226.89:9003/TVOD/3000000010000009788.m3u8?token=8520
咪咕视频-32,http://43.251.226.89:9003/TVOD/3000000010000010833.m3u8?token=8520
咪咕视频-33,http://43.251.226.89:9003/TVOD/3000000010000011297.m3u8?token=8520
咪咕视频-34,http://43.251.226.89:9003/TVOD/3000000010000011518.m3u8?token=8520
咪咕视频-35,http://43.251.226.89:9003/TVOD/3000000010000012558.m3u8?token=8520
咪咕视频-36,http://43.251.226.89:9003/TVOD/3000000010000012616.m3u8?token=8520
咪咕视频-37,http://43.251.226.89:9003/TVOD/3000000010000015470.m3u8?token=8520
咪咕视频-38,http://43.251.226.89:9003/TVOD/3000000010000015560.m3u8?token=8520
咪咕视频-39,http://43.251.226.89:9003/TVOD/3000000010000017678.m3u8?token=8520
咪咕视频-40,http://43.251.226.89:9003/TVOD/3000000010000019839.m3u8?token=8520
咪咕视频-41,http://43.251.226.89:9003/TVOD/3000000010000021904.m3u8?token=8520
咪咕视频-42,http://43.251.226.89:9003/TVOD/3000000010000023434.m3u8?token=8520
咪咕视频-43,http://43.251.226.89:9003/TVOD/3000000010000025380.m3u8?token=8520
咪咕视频-44,http://43.251.226.89:9003/TVOD/3000000010000027691.m3u8?token=8520
咪咕视频-45,http://43.251.226.89:9003/TVOD/3000000010000031669.m3u8?token=8520

跨年晚会,#genre#
浙江卫视2026跨年晚会,https://v.lzcdn28.com/20251231/6723_40011122/2000k/hls/mixed.m3u8
浙江卫视2026跨年晚会,https://vip.dytt-cine.com/20260101/66144_d85193a6/3000k/hls/mixed.m3u8
浙江卫视2026跨年晚会,https://s1.fengbao9.com/video/2026zhejiangweishikuanianwanhui/bf2f88013abd/index.m3u8
浙江卫视2026跨年晚会,https://v13.fentvoss.com/yyv13/202601/01/kB2jZuxXVd22/video/2000k_1080/hls/index.m3u8
湖南卫视芒果TV2026跨年演唱会,https://v.lzcdn28.com/20251231/6726_2ae6ea86/index.m3u8
江西卫视2026年跨年晚会,https://v.lzcdn28.com/20251231/6724_31feda67/index.m3u8
广东卫视大湾区2026年跨年歌会,https://v.lzcdn28.com/20251231/6721_34626e17/index.m3u8
北京卫视2026跨年晚会,https://s1.fengbao9.com/video/2026beijingweishikuanianwanhui/31f6e72b396c/index.m3u8
北京卫视2026跨年晚会,https://v.lzcdn28.com/20251231/6722_e3285cba/index.m3u8
东方卫视2026跨年晚会,https://v.lzcdn28.com/20251231/6725_c0168672/2000k/hls/mixed.m3u8
东方卫视2026跨年晚会,https://vip.dytt-cine.com/20260101/66146_f191860c/3000k/hls/mixed.m3u8
江苏卫视2026跨年晚会,https://s1.fengbao9.com/video/2026jiangsuweishikuanianwanhui/0afce1f74b3c/index.m3u8
江苏卫视2026跨年晚会,https://v.lzcdn28.com/20251231/6720_34bbc160/index.m3u8
东方卫视2025跨年晚会,https://svipsvip.ffzyread1.com/20250101/34719_f2a81b73/2000k/hls/mixed.m3u8
江苏卫视2025跨年晚会,https://svipsvip.ffzyread1.com/20250101/34720_0d5e4b60/2000k/hls/mixed.m3u8
浙江卫视2025跨年晚会,https://svipsvip.ffzyread1.com/20250101/34721_0289fc9e/2000k/hls/mixed.m3u8
北京卫视2025跨年晚会,https://svipsvip.ffzyread1.com/20250101/34722_cbaafc6f/2000k/hls/mixed.m3u8

北京卫视4K,http://139.ye23.vip/dl/btv2502.php?id=bjws4
东方卫视4K,http://bp-resource-dfl.bestv.cn/148/3/video.m3u8
湖南卫视4K,http://hlsal-ldvt.qing.mgtv.com/nn_live/nn_x64/dWlwPTEyNy4wLjAuMSZ1aWQ9cWluZy1jbXMmbm5fdGltZXpvbmU9OCZjZG5leF9pZD1hbF9obHNfbGR2dCZ1dWlkPTliODY4NmU5ZTM2YzYwMmMmZT02OTE0NjA0JnY9MSZpZD1ITldTWkdTVCZzPTcwN2RiYTc2YzJjNmJmMTQ4MmUyZGYzOWU2NWM3YWFi/HNWSZGST.m3u8
浙江卫视4K,https://play-qukan.cztv.com/live/1758879019692345.m3u8


【直播】启航2026——中央广播电视总台跨年晚会,https://hls.liveshow.bdstatic.com/live/stream_bduid_4174276634_10960253162-L1.m3u8
【直播】梦圆东方・2026东方卫视跨年盛典,https://hls.liveshow.bdstatic.com/live/stream_bduid_138424090_10961625017-L1.m3u8
【直播】哈尔滨冰雪大世界跨年演唱会,https://hls.liveshow.bdstatic.com/live/stream_bduid_5044039763_10962537740-L1.m3u8
【直播】跨年夜玩点新的！非遗国潮跨年狂欢夜来啦,https://hls.liveshow.bdstatic.com/live/stream_bduid_1047707389_10963256619-L1.m3u8
【直播】直播丨2025跨年夜科学沙龙：科学家陪你品小吃 畅聊全球科技前沿,https://hls.liveshow.bdstatic.com/live/stream_bduid_1096736198_10962965847-L1.m3u8
【直播】浙江卫视跨年晚会，一起告别2025奔赴2026,https://hls.liveshow.bdstatic.com/live/stream_bduid_12449324_10962876068-L1.m3u8
【直播】《踏上新征程-更好2026BRTV跨年之夜》,https://hls.liveshow.bdstatic.com/live/stream_bduid_2628045633_10960275350-L1.m3u8
【直播】更好2026江苏卫视跨年演唱会,https://hls.liveshow.bdstatic.com/live/stream_bduid_3417409170_10962718832-L1.m3u8



█████████████████████████████████████████████

█████████████████████████████████████████████


█████████████████████████████████████████████
新闻频道,#genre#
█████████████████████████████████████████████
CCTV1,http://39.152.103.17:8089/tsfile/live/1000_1.m3u8
CCTV4,http://39.152.103.17:8089/tsfile/live/1003_1.m3u8
CCTV13,http://39.152.103.17:8089/tsfile/live/1012_1.m3u8

CCTV1,http://202.168.168.50:5000/tsfile/live/1000_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV1,http://222.135.142.75:3283/tsfile/live/0001_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV4,http://223.75.148.190:9910/tsfile/live/0004_2.m3u8?key=txiptv&playlive=0&authid=0
CCTV4,http://202.168.168.50:5000/tsfile/live/1003_1.m3u8?key=txiptv&playlive=1&authid=0

CCTV13,http://223.75.148.190:9910/tsfile/live/0013_1.m3u8?key=txiptv&playlive=0&authid=0
CCTV13,http://202.168.168.50:5000/tsfile/live/1012_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV13,http://61.156.228.12:8154/tsfile/live/0013_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV13,http://222.169.85.8:9901/tsfile/live/0013_1.m3u8?key=txiptv&playlive=1&authid=0

CCTV1,http://php.jdshipin.com:8880/TVOD/iptv.php?id=rthk33$订阅源
CCTV1,http://106.53.99.30/tv/20250717.php?id=0001

CCTV4,https://stream1.freetv.fun/7d105b2bd6766ad7d984e03690fa58db14153c30af9569da0346c26f2b82d5ed.m3u8

凤凰中文,http://php.jdshipin.com/TVOD/iptv.php?id=fhzw
凤凰资讯,http://php.jdshipin.com/TVOD/iptv.php?id=fhzx
凤凰香港,http://php.jdshipin.com/TVOD/iptv.php?id=fhhk
凤凰中文,http://php.jdshipin.com:8880/smt.php?id=phoenixtv_hd
凤凰资讯,http://php.jdshipin.com:8880/smt.php?id=phoenixinfo_hd
凤凰香港,http://php.jdshipin.com:8880/smt.php?id=hkphoenix_twn
凤凰中文,https://smt.1678520.xyz/smt3.2.1.php?id=phoenixtv_hd
凤凰资讯,https://smt.1678520.xyz/smt3.2.1.php?id=phoenixinfo_hd
凤凰香港,https://smt.1678520.xyz/smt3.2.1.php?id=hkphoenix_twn

凤凰中文,http://t.061899.xyz/tl/js/js.php?id=fhwszwt
凤凰资讯,http://t.061899.xyz/tl/js/js.php?id=fhwszxt
凤凰香港,http://t.061899.xyz/tl/js/js.php?id=fhwsxgt

凤凰中文,http://58.19.180.108:9981/stream/channelid/1749482778?profile=pass
凤凰资讯,http://58.19.180.108:9981/stream/channelid/708272803?profile=pass

凤凰资讯,http://uo202.1985001.xyz:66/rtp/239.93.0.118:2191
凤凰中文,http://222.212.84.190:54123/udp/239.93.1.9:2192

凤凰中文,http://zqh2333.top:2222/rtp/239.93.24.9:2192
凤凰中文,http://203.205.191.53/qctv.fengshows.cn/live/0701pcc72.flv
凤凰资讯,http://zqh2333.top:2222/rtp/239.93.24.4:2191


凤凰中文,http://api.mg.itv888.cn:8080/hls/2f80047f91e/index.m3u8
凤凰资讯,http://api.mg.itv888.cn:8080/hls/11ef1dc70d8/index.m3u8
凤凰香港,http://api.mg.itv888.cn:8080/hls/e9660dce9a6/index.m3u8
凤凰中文,http://58.19.180.108:9981/stream/channelid/1749482778?profile=pass
凤凰资讯,http://58.19.180.108:9981/stream/channelid/708272803?profile=pass

凤凰中文,http://vallest.uk/livehttpplay?channel_id=30014
凤凰资讯,http://vallest.uk/livehttpplay?channel_id=30015
凤凰香港,http://vallest.uk/livehttpplay?channel_id=30016

中天新闻,https://live.catvod.com/live.php?id=ctinews
中天新闻,http://rihou.cc:555/tv/[SZ]中天新闻
中天新闻,http://rihou.cc:555/tv/[Bx]中天新闻

HOY76,http://hls.168.us.kg/u/76/master.m3u8
HOY77,http://hls.168.us.kg/u/77/master.m3u8
HOY78,http://hls.168.us.kg/u/78/master.m3u8
HOY78,http://hls.168.us.kg/u/78/master.m3u8
翡翠台,http://hls.168.us.kg/u/81/master.m3u8
TVB Plus,http://hls.168.us.kg/u/82/master.m3u8
无线新闻台,http://hls.168.us.kg/u/83/master.m3u8
明珠台,http://hls.168.us.kg/u/84/master.m3u8
Now新聞台,http://hls.168.us.kg/u/332/master.m3u8
ViuTVsix,http://hls.168.us.kg/u/96/master.m3u8
ViuTV,http://hls.168.us.kg/u/99/master.m3u8
Now華劇台,http://hls.168.us.kg/u/105/master.m3u8
熊貓TV,http://hls.168.us.kg/u/200/master.m3u8
Now直播台,http://hls.168.us.kg/u/331/master.m3u8
Now新聞台,http://hls.168.us.kg/u/332/master.m3u8
Now財經台,http://hls.168.us.kg/u/333/master.m3u8
Now Sports 精選,http://hls.168.us.kg/u/630/master.m3u8

Now新闻,http://iptv.4666888.xyz/iptv2A.php?id=NOW新闻
Now新闻,http://cdn.163189.xyz/163189/now
动作片,https://mfzb.wsmywlkj.top/live/xgzb-ss01.m3u8
凤凰中文,https://cdn6.101.qzz.io/163189/fhzw
凤凰资讯,https://cdn6.101.qzz.io/163189/fhzx
凤凰香港,https://cdn6.101.qzz.io/163189/fhhk
无线新闻,https://cdn6.101.qzz.io/163189/wxxw
无线翡翠,https://cdn6.101.qzz.io/163189/fct
无线翡翠,https://mytv.cdn.loc.cc/o12.php?id=fct
TVB明珠,https://mytv.cdn.loc.cc/o12.php?id=mzt
无线星河,https://cdn6.101.qzz.io/163189/tvbxh


TVB翡翠,http://iptv.4666888.xyz/iptv2A.php?id=TVB翡翠
TVB明珠,http://iptv.4666888.xyz/iptv2A.php?id=TVB明珠
TVBPLUS,http://iptv.4666888.xyz/iptv2A.php?id=TVBPLUS
NOW新闻,http://iptv.4666888.xyz/iptv2A.php?id=NOW新闻
VIUTV,http://iptv.4666888.xyz/iptv2A.php?id=VIUTV
TVB千禧经典,http://iptv.4666888.xyz/iptv2A.php?id=TVB千禧经典
TVB1,http://iptv.4666888.xyz/iptv2A.php?id=TVB1
TVBJ1,http://iptv.4666888.xyz/iptv2A.php?id=TVBJ1
星空卫视,http://iptv.4666888.xyz/iptv2A.php?id=星空卫视
重温经典,http://iptv.4666888.xyz/iptv2A.php?id=重温经典
八度空间,http://iptv.4666888.xyz/iptv2A.php?id=八度空间
综艺玩很大,http://iptv.4666888.xyz/iptv2A.php?id=综艺玩很大
爱奇艺,http://iptv.4666888.xyz/iptv2A.php?id=爱奇艺
TVBS台剧,http://iptv.4666888.xyz/iptv2A.php?id=TVBS台剧
纬来戏剧,http://iptv.4666888.xyz/iptv2A.php?id=纬来戏剧


凤凰中文,http://t.061899.xyz/tl/js/js.php?id=fhwszwt
凤凰资讯,http://t.061899.xyz/tl/js/js.php?id=fhwszxt
凤凰香港,http://t.061899.xyz/tl/js/js.php?id=fhwsxgt
TVB翡翠台,http://t.061899.xyz/tl/js/js.php?id=tvbfct
TVB无线新闻台,http://t.061899.xyz/tl/js/js.php?id=tvbwxxwt

CCTV-1,video://https://jzb5kqln.huajiaedu.com/tvs

凤凰资讯HD,http://222.212.84.190:54123/udp/239.93.1.4:2191
凤凰资讯HD,http://61.184.46.85:85/tsfile/live/1030_1.m3u8?key=txiptv&playlive=1&authid=0
凤凰资讯,https://4k.11cn.dpdns.org/28.m3u8
凤凰资讯,http://j.s.bkpcp.top/js/fhzx
凤凰资讯,http://m.061899.xyz/mg/fhzx
凤凰资讯,http://139.196.228.200:5678/公众号搞机大师/fhx.php?id=info
凤凰资讯,http://203.205.191.53/qctv.fengshows.cn/live/0701pin72.m3u8
凤凰资讯,http://218.104.239.114:9901/tsfile/live/1012_1.m3u8?key=txiptv$tsfil
凤凰资讯,http://203.205.191.53/qctv.fengshows.cn/live/0701pin72.m3u8
凤凰资讯,https://stream1.freetv.fun/55317db1dd958d493bc8a11eed6f260f7c0903ab196dbbb4b5bf379800ba397f.m3u8
凤凰资讯,https://stream1.freetv.fun/320c213f4bb29b607f6c659b2a94918fc7f922c996ede3738fdff2ab9bd90217.ctv
凤凰资讯,https://cdn9.163189.xyz/smt3.1.1.php?id=phoenixinfo_hd
凤凰资讯,http://php.jdshipin.com:8880/smt.php?id=phoenixinfo_hd

凤凰中文HD,http://222.212.84.190:54123/udp/239.93.1.9:2192
凤凰中文HD,http://116.77.33.98:44330/tsfile/live/1011_1.m3u8?key=txiptv&playlive=0&authid=0
凤凰中文HD,http://171.213.202.212:19999/udp/239.93.0.162:2192
凤凰中文HD,http://61.184.46.85:85/tsfile/live/1029_1.m3u8?key=txiptv&playlive=1&authid=0
凤凰中文,https://4k.11cn.dpdns.org/27.m3u8
凤凰中文,http://203.205.191.53/qctv.fengshows.cn/live/0701pcc72.m3u8
凤凰中文,http://j.s.bkpcp.top/js/fhzw
凤凰中文,http://api.mg.itv888.cn:8080/hls/2f80047f91e/index.m3u8
凤凰中文,http://m.061899.xyz/mg/fhzw
凤凰中文,http://203.205.191.53/qctv.fengshows.cn/live/0701pcc72.m3u8
凤凰中文,https://cdn9.163189.xyz/smt3.1.1.php?id=phoenixtv_hd
凤凰中文,http://php.jdshipin.com:8880/smt.php?id=phoenixtv_hd 
凤凰香港,https://4k.11cn.dpdns.org/29.m3u8
凤凰香港,http://stream-ali1.csslcloud.net/live/uEACKo2YT4ZTiHBMNM2g49d00j924NASwca4Glm436hsAvKE1L.flv
凤凰香港,http://203.205.191.53/qctv.fengshows.cn/live/0701phk72.m3u8
凤凰香港,http://qwt.zhibotv.top:2016/全网通.php?id=凤凰香港台
凤凰香港,http://cdn.jdshipin.com/jisu.php?id=fhxg
凤凰香港,https://cdn8.163189.xyz/live/fhhk/stream.m3u8
凤凰香港,http://139.196.228.200:5678/公众号搞机大师/fhx.php?id=hk
凤凰香港,http://156.238.253.62:5555/tvbox/公众号好享生活小助手/fenghuangxiu22.php?id=hk
凤凰香港,http://203.205.191.53/qctv.fengshows.cn/live/0701phk72.m3u8
凤凰香港,http://bx.757888.xyz/mytv/mytvts1.1.php?id=null-7
凤凰香港,http://weixin.qq.home.kg/smtv.php?id=hkphoenix_twm
凤凰香港,https://live.sxrtv.com/iptv/fhhk.flv
凤凰香港,http://j.s.bkpcp.top/js/fhxg
凤凰香港,http://bx.757888.xyz/api.php?id=fhhk
凤凰香港,http://push-rtmp-hs-spe-f5.douyincdn.com/live/awei_fhxg.flv
凤凰香港,http://api.mg.itv888.cn:8080/hls/e9660dce9a6/index.m3u8
凤凰香港,http://m.061899.xyz/mg/fhhk
凤凰香港,http://j.s.bkpcp.top/js/fhhk
凤凰香港,http://api.mg.itv888.cn:8080/hls/e9660dce9a6/index.m3u8
凤凰香港,http://iptv.4666888.xyz/iptv.php?id=20062
凤凰香港,http://iptv.4666888.xyz/iptv.php?id=20065
凤凰香港,https://migu.188766.xyz/?migutoken=cbf8f4f16f7ccdc07d7ccd8f9b012692&id=fhhk&pp=1
凤凰香港,http://m.061899.xyz/mg/fhhk
凤凰香港,https://cdn9.163189.xyz/smt3.1.1.php?id=hkphoenix_twn
凤凰香港,http://php.jdshipin.com:8880/smt.php?id=hkphoenix_twn

翡翠台4K(多音轨字幕),https://o11.163189.xyz/stream/tvb/fct4k/
翡翠台(多音轨字幕),https://o11.163189.xyz/stream/tvb/fct/
TVB PLUS(多音轨字幕),https://o11.163189.xyz/stream/tvb/tvbp/
明珠台(多音轨字幕),https://o11.163189.xyz/stream/tvb/mzt/
华丽翡翠台(多音轨字幕),https://o11.163189.xyz/stream/live/hlt/
华丽翡翠台(新加坡),https://o11.163189.xyz/stream/live/jade/
Astro AOD(多音轨字幕),https://o11.163189.xyz/stream/live/aod/
Astro AEC(多音轨字幕),https://o11.163189.xyz/stream/live/aec/
Astro QJ(多音轨字幕),https://o11.163189.xyz/stream/live/qj/
TVB星河(多音轨字幕),https://o11.163189.xyz/stream/live/tvbxh/
爱奇艺,https://o11.163189.xyz/stream/live/iqiyi/
千禧经典台,https://o11.163189.xyz/stream/live/tvbc/


█████████████
===========,https://vd2.bdstatic.com/mda-mjshcpd847mhnjgj/sc/cae_h264/1635337200637124885/mda-mjshcpd847mhnjgj.mp4
█████████████

TANG,https://ntd02.akamaized.net/HD-NY/tracks-v3a1/mono.m3u8


央卫组播,#genre#
CCTV1,http://222.214.208.34:59901/tsfile/live/0001_1.m3u8
CCTV1,http://111.23.208.105:9908/tsfile/live/0001_1.m3u8
CCTV1,http://39.152.103.17:8089/tsfile/live/1000_1.m3u8
CCTV1,http://183.57.249.112:8183/tsfile/live/0001_1.m3u8
CCTV1,http://218.17.33.178:53290/tsfile/live/1001_1.m3u8
CCTV1,http://202.168.168.50:5000/tsfile/live/1000_1.m3u8
CCTV2,http://222.214.208.34:59901/tsfile/live/0002_1.m3u8
CCTV2,http://111.23.208.105:9908/tsfile/live/0002_1.m3u8
CCTV2,http://39.152.103.17:8089/tsfile/live/1001_1.m3u8
CCTV2,http://183.57.249.112:8183/tsfile/live/0002_1.m3u8
CCTV2,http://218.17.33.178:53290/tsfile/live/1002_1.m3u8
CCTV2,http://202.168.168.50:5000/tsfile/live/1001_1.m3u8
CCTV3,http://111.23.208.105:9908/tsfile/live/0003_1.m3u8
CCTV3,http://39.152.103.17:8089/tsfile/live/1002_1.m3u8
CCTV3,http://183.57.249.112:8183/tsfile/live/0003_1.m3u8
CCTV3,http://218.17.33.178:53290/tsfile/live/1003_1.m3u8
CCTV3,http://202.168.168.50:5000/tsfile/live/1002_1.m3u8
CCTV4,http://222.214.208.34:59901/tsfile/live/0004_1.m3u8
CCTV4,http://111.23.208.105:9908/tsfile/live/0004_1.m3u8
CCTV4,http://39.152.103.17:8089/tsfile/live/1003_1.m3u8
CCTV4,http://183.57.249.112:8183/tsfile/live/0004_1.m3u8
CCTV4,http://218.17.33.178:53290/tsfile/live/1004_1.m3u8
CCTV4,http://202.168.168.50:5000/tsfile/live/1003_1.m3u8
CCTV5,http://111.23.208.105:9908/tsfile/live/0005_1.m3u8
CCTV5,http://39.152.103.17:8089/tsfile/live/1004_1.m3u8
CCTV5,http://183.57.249.112:8183/tsfile/live/0005_1.m3u8
CCTV5,http://218.17.33.178:53290/tsfile/live/1017_1.m3u8
CCTV5,http://202.168.168.50:5000/tsfile/live/1004_1.m3u8
CCTV5+,http://222.214.208.34:59901/tsfile/live/0016_1.m3u8
CCTV5+,http://111.23.208.105:9908/tsfile/live/1015_1.m3u8
CCTV5+,http://39.152.103.17:8089/tsfile/live/1090_1.m3u8
CCTV5+,http://218.17.33.178:53290/tsfile/live/1005_1.m3u8
CCTV6,http://111.23.208.105:9908/tsfile/live/0006_2.m3u8
CCTV6,http://39.152.103.17:8089/tsfile/live/1005_1.m3u8
CCTV6,http://183.57.249.112:8183/tsfile/live/0006_1.m3u8
CCTV6,http://218.17.33.178:53290/tsfile/live/1006_1.m3u8
CCTV6,http://202.168.168.50:5000/tsfile/live/1005_1.m3u8
CCTV7,http://222.214.208.34:59901/tsfile/live/0007_1.m3u8
CCTV7,http://111.23.208.105:9908/tsfile/live/0007_2.m3u8
CCTV7,http://39.152.103.17:8089/tsfile/live/1006_1.m3u8
CCTV7,http://183.57.249.112:8183/tsfile/live/0007_1.m3u8
CCTV7,http://202.168.168.50:5000/tsfile/live/1006_1.m3u8
CCTV8,http://222.214.208.34:59901/tsfile/live/0008_1.m3u8
CCTV8,http://111.23.208.105:9908/tsfile/live/0008_2.m3u8
CCTV8,http://39.152.103.17:8089/tsfile/live/1007_1.m3u8
CCTV8,http://183.57.249.112:8183/tsfile/live/0008_1.m3u8
CCTV8,http://218.17.33.178:53290/tsfile/live/1008_1.m3u8
CCTV8,http://202.168.168.50:5000/tsfile/live/1007_1.m3u8
CCTV9,http://222.214.208.34:59901/tsfile/live/0009_1.m3u8
CCTV9,http://111.23.208.105:9908/tsfile/live/0009_2.m3u8
CCTV9,http://39.152.103.17:8089/tsfile/live/1008_1.m3u8
CCTV9,http://183.57.249.112:8183/tsfile/live/0009_1.m3u8
CCTV9,http://218.17.33.178:53290/tsfile/live/1009_1.m3u8
CCTV9,http://202.168.168.50:5000/tsfile/live/1008_1.m3u8
CCTV10,http://222.214.208.34:59901/tsfile/live/0010_1.m3u8
CCTV10,http://111.23.208.105:9908/tsfile/live/0010_2.m3u8
CCTV10,http://39.152.103.17:8089/tsfile/live/1009_1.m3u8
CCTV10,http://183.57.249.112:8183/tsfile/live/0010_1.m3u8
CCTV10,http://218.17.33.178:53290/tsfile/live/1010_1.m3u8
CCTV10,http://202.168.168.50:5000/tsfile/live/1009_1.m3u8
CCTV11,http://222.214.208.34:59901/tsfile/live/0011_1.m3u8
CCTV11,http://111.23.208.105:9908/tsfile/live/0011_2.m3u8
CCTV11,http://39.152.103.17:8089/tsfile/live/1010_1.m3u8
CCTV11,http://202.168.168.50:5000/tsfile/live/1010_1.m3u8
CCTV12,http://222.214.208.34:59901/tsfile/live/0012_1.m3u8
CCTV12,http://111.23.208.105:9908/tsfile/live/0012_2.m3u8
CCTV12,http://39.152.103.17:8089/tsfile/live/1011_1.m3u8
CCTV12,http://183.57.249.112:8183/tsfile/live/0012_1.m3u8
CCTV12,http://218.17.33.178:53290/tsfile/live/1012_1.m3u8
CCTV12,http://202.168.168.50:5000/tsfile/live/1011_1.m3u8
CCTV13,http://222.214.208.34:59901/tsfile/live/0013_1.m3u8
CCTV13,http://111.23.208.105:9908/tsfile/live/0013_1.m3u8
CCTV13,http://39.152.103.17:8089/tsfile/live/1012_1.m3u8
CCTV13,http://183.57.249.112:8183/tsfile/live/0013_1.m3u8
CCTV13,http://202.168.168.50:5000/tsfile/live/1012_1.m3u8
CCTV14,http://222.214.208.34:59901/tsfile/live/0014_1.m3u8
CCTV14,http://111.23.208.105:9908/tsfile/live/0014_1.m3u8
CCTV14,http://39.152.103.17:8089/tsfile/live/1013_1.m3u8
CCTV14,http://183.57.249.112:8183/tsfile/live/0014_1.m3u8
CCTV14,http://202.168.168.50:5000/tsfile/live/1013_1.m3u8
CCTV15,http://222.214.208.34:59901/tsfile/live/0015_1.m3u8
CCTV15,http://111.23.208.105:9908/tsfile/live/0015_2.m3u8
CCTV15,http://39.152.103.17:8089/tsfile/live/1014_1.m3u8
CCTV15,http://183.57.249.112:8183/tsfile/live/0015_1.m3u8
CCTV15,http://202.168.168.50:5000/tsfile/live/1014_1.m3u8
CCTV16,http://59.32.97.221:9999/tsfile/live/1008_1.m3u8
CCTV16,http://202.168.168.50:5000/tsfile/live/1015_1.m3u8
CCTV16,http://39.152.103.17:8089/tsfile/live/1015_1.m3u8
CCTV16,http://39.152.103.17:8089/tsfile/live/1073_1.m3u8
CCTV17,http://111.23.208.105:9908/tsfile/live/0019_1.m3u8
CCTV17,http://39.152.103.17:8089/tsfile/live/1016_1.m3u8
CCTV17,http://183.57.249.112:8183/tsfile/live/0016_1.m3u8
CCTV17,http://202.168.168.50:5000/tsfile/live/1016_1.m3u8
浙江卫视4K,https://play-qukan.cztv.com/live/1758879019692345.m3u8
深圳卫视4K,http://jiangxun.sendsmtp.com:40222/udp/239.81.0.254:4056
北京卫视4K,http://jiangxun.sendsmtp.com:40222/udp/239.81.0.226:4056
广东卫视4K,http://jiangxun.sendsmtp.com:40222/udp/239.81.0.252:4056
华数4K,http://jiangxun.sendsmtp.com:40222/udp/239.81.0.123:4056
湖南卫视,http://222.214.208.34:59901/tsfile/live/0128_1.m3u8
湖南卫视,http://111.23.208.105:9908/tsfile/live/1059_1.m3u8
湖南卫视,http://39.152.103.17:8089/tsfile/live/1040_1.m3u8
湖南卫视,http://183.57.249.112:8183/tsfile/live/1007_1.m3u8
湖南卫视,http://218.17.33.178:53290/tsfile/live/0128_1.m3u8
湖南卫视,http://202.168.168.50:5000/tsfile/live/1021_1.m3u8
浙江卫视,http://222.214.208.34:59901/tsfile/live/0124_1.m3u8
浙江卫视,http://111.23.208.105:9908/tsfile/live/1023_1.m3u8
浙江卫视,http://39.152.103.17:8089/tsfile/live/1037_1.m3u8
浙江卫视,http://183.57.249.112:8183/tsfile/live/1008_1.m3u8
浙江卫视,http://218.17.33.178:53290/tsfile/live/0124_1.m3u8
浙江卫视,http://202.168.168.50:5000/tsfile/live/1022_1.m3u8
浙江卫视,http://59.32.97.221:9999/tsfile/live/1035_1.m3u8
江苏卫视,http://222.214.208.34:59901/tsfile/live/0127_1.m3u8
江苏卫视,http://111.23.208.105:9908/tsfile/live/1022_1.m3u8
江苏卫视,http://39.152.103.17:8089/tsfile/live/1038_1.m3u8
江苏卫视,http://183.57.249.112:8183/tsfile/live/1009_1.m3u8
江苏卫视,http://202.168.168.50:5000/tsfile/live/1023_1.m3u8
东方卫视,http://222.214.208.34:59901/tsfile/live/0107_1.m3u8
东方卫视,http://111.23.208.105:9908/tsfile/live/1019_1.m3u8
东方卫视,http://39.152.103.17:8089/tsfile/live/1036_1.m3u8
东方卫视,http://183.57.249.112:8183/tsfile/live/1010_1.m3u8
东方卫视,http://202.168.168.50:5000/tsfile/live/1019_1.m3u8
东方卫视,http://59.32.97.221:9999/tsfile/live/1037_1.m3u8
北京卫视,http://222.214.208.34:59901/tsfile/live/0122_1.m3u8
北京卫视,http://111.23.208.105:9908/tsfile/live/1025_1.m3u8
北京卫视,http://39.152.103.17:8089/tsfile/live/1034_1.m3u8
北京卫视,http://202.168.168.50:5000/tsfile/live/1020_1.m3u8
北京卫视,http://59.32.97.221:9999/tsfile/live/1039_1.m3u8
东南卫视,http://222.214.208.34:59901/tsfile/live/0137_1.m3u8
东南卫视,http://111.23.208.105:9908/tsfile/live/1029_1.m3u8
东南卫视,http://39.152.103.17:8089/tsfile/live/1081_1.m3u8
东南卫视,http://202.168.168.50:5000/tsfile/live/1035_1.m3u8
东南卫视,http://59.32.97.221:9999/tsfile/live/1050_1.m3u8
云南卫视,http://111.23.208.105:9908/tsfile/live/0119_1.m3u8
云南卫视,http://39.152.103.17:8089/tsfile/live/1083_1.m3u8
吉林卫视,http://111.23.208.105:9908/tsfile/live/1039_1.m3u8
吉林卫视,http://39.152.103.17:8089/tsfile/live/1047_1.m3u8
吉林卫视,http://202.168.168.50:5000/tsfile/live/1037_1.m3u8
吉林卫视,http://59.32.97.221:9999/tsfile/live/1051_1.m3u8
四川卫视,http://222.214.208.34:59901/tsfile/live/0017_1.m3u8
四川卫视,http://111.23.208.105:9908/tsfile/live/1033_1.m3u8
四川卫视,http://39.152.103.17:8089/tsfile/live/1044_1.m3u8
四川卫视,http://218.17.33.178:53290/tsfile/live/0123_1.m3u8
四川卫视,http://202.168.168.50:5000/tsfile/live/1031_1.m3u8
四川卫视,http://59.32.97.221:9999/tsfile/live/1047_1.m3u8
四川经济,http://222.214.208.34:59901/tsfile/live/0018_1.m3u8
天津卫视,http://222.214.208.34:59901/tsfile/live/0135_1.m3u8
天津卫视,http://111.23.208.105:9908/tsfile/live/1026_1.m3u8
天津卫视,http://39.152.103.17:8089/tsfile/live/1035_1.m3u8
天津卫视,http://202.168.168.50:5000/tsfile/live/1025_1.m3u8
天津卫视,http://59.32.97.221:9999/tsfile/live/1040_1.m3u8
宁夏卫视,http://111.23.208.105:9908/tsfile/live/0112_1.m3u8
宁夏卫视,http://39.152.103.17:8089/tsfile/live/1086_1.m3u8
安徽卫视,http://222.214.208.34:59901/tsfile/live/0130_1.m3u8
安徽卫视,http://111.23.208.105:9908/tsfile/live/1024_1.m3u8
安徽卫视,http://39.152.103.17:8089/tsfile/live/1039_1.m3u8
安徽卫视,http://202.168.168.50:5000/tsfile/live/1028_1.m3u8
安徽卫视,http://59.32.97.221:9999/tsfile/live/1038_1.m3u8
山东卫视,http://222.214.208.34:59901/tsfile/live/0131_1.m3u8
山东卫视,http://111.23.208.105:9908/tsfile/live/1032_1.m3u8
山东卫视,http://183.57.249.112:8183/tsfile/live/0139_1.m3u8
山东卫视,http://39.152.103.17:8089/tsfile/live/1018_1.m3u8
山东卫视,http://218.17.33.178:53290/tsfile/live/0131_1.m3u8
山东卫视,http://202.168.168.50:5000/tsfile/live/1026_1.m3u8
山东卫视,http://59.32.97.221:9999/tsfile/live/1041_1.m3u8
广东卫视,http://222.214.208.34:59901/tsfile/live/0125_1.m3u8
广东卫视,http://111.23.208.105:9908/tsfile/live/1031_1.m3u8
广东卫视,http://39.152.103.17:8089/tsfile/live/1042_1.m3u8
广东卫视,http://183.57.249.112:8183/tsfile/live/0125_1.m3u8
广东卫视,http://218.17.33.178:53290/tsfile/live/0125_1.m3u8
广东卫视,http://202.168.168.50:5000/tsfile/live/1017_1.m3u8
广西卫视,http://111.23.208.105:9908/tsfile/live/0113_1.m3u8
广西卫视,http://39.152.103.17:8089/tsfile/live/1077_1.m3u8
广西卫视,http://202.168.168.50:5000/tsfile/live/1038_1.m3u8
江西卫视,http://222.214.208.34:59901/tsfile/live/0138_1.m3u8
江西卫视,http://111.23.208.105:9908/tsfile/live/1027_1.m3u8
江西卫视,http://39.152.103.17:8089/tsfile/live/1078_1.m3u8
江西卫视,http://218.17.33.178:53290/tsfile/live/0138_1.m3u8
江西卫视,http://202.168.168.50:5000/tsfile/live/1034_1.m3u8
江西卫视,http://59.32.97.221:9999/tsfile/live/1042_1.m3u8
河北卫视,http://111.23.208.105:9908/tsfile/live/1038_1.m3u8
河北卫视,http://39.152.103.17:8089/tsfile/live/1079_1.m3u8
河北卫视,http://202.168.168.50:5000/tsfile/live/1033_1.m3u8
河北卫视,http://59.32.97.221:9999/tsfile/live/1049_1.m3u8
河南卫视,http://111.23.208.105:9908/tsfile/live/1035_1.m3u8
河南卫视,http://39.152.103.17:8089/tsfile/live/1080_1.m3u8
河南卫视,http://202.168.168.50:5000/tsfile/live/1036_1.m3u8
海南卫视,http://111.23.208.105:9908/tsfile/live/1030_1.m3u8
海南卫视,http://39.152.103.17:8089/tsfile/live/1046_1.m3u8
深圳卫视,http://222.214.208.34:59901/tsfile/live/0126_1.m3u8
深圳卫视,http://111.23.208.105:9908/tsfile/live/1020_1.m3u8
深圳卫视,http://39.152.103.17:8089/tsfile/live/1049_1.m3u8
深圳卫视,http://202.168.168.50:5000/tsfile/live/1018_1.m3u8
深圳卫视,http://59.32.97.221:9999/tsfile/live/1043_1.m3u8
湖北卫视,http://222.214.208.34:59901/tsfile/live/0132_1.m3u8
湖北卫视,http://111.23.208.105:9908/tsfile/live/1021_1.m3u8
湖北卫视,http://39.152.103.17:8089/tsfile/live/1043_1.m3u8
湖北卫视,http://183.57.249.112:8183/tsfile/live/0132_1.m3u8
湖北卫视,http://218.17.33.178:53290/tsfile/live/0132_1.m3u8
湖北卫视,http://202.168.168.50:5000/tsfile/live/1027_1.m3u8
贵州卫视,http://222.214.208.34:59901/tsfile/live/0120_1.m3u8
贵州卫视,http://111.23.208.105:9908/tsfile/live/1037_1.m3u8
贵州卫视,http://39.152.103.17:8089/tsfile/live/1041_1.m3u8
贵州卫视,http://202.168.168.50:5000/tsfile/live/1030_1.m3u8
贵州卫视,http://59.32.97.221:9999/tsfile/live/1046_1.m3u8
辽宁卫视,http://111.23.208.105:9908/tsfile/live/1028_1.m3u8
辽宁卫视,http://39.152.103.17:8089/tsfile/live/1024_1.m3u8
辽宁卫视,http://218.17.33.178:53290/tsfile/live/0121_1.m3u8
辽宁卫视,http://202.168.168.50:5000/tsfile/live/1029_1.m3u8
辽宁卫视,http://59.32.97.221:9999/tsfile/live/1044_1.m3u8
重庆卫视,http://222.214.208.34:59901/tsfile/live/0142_1.m3u8
重庆卫视,http://111.23.208.105:9908/tsfile/live/1034_1.m3u8
重庆卫视,http://39.152.103.17:8089/tsfile/live/1048_1.m3u8
重庆卫视,http://183.57.249.112:8183/tsfile/live/0142_1.m3u8
重庆卫视,http://202.168.168.50:5000/tsfile/live/1032_1.m3u8
重庆卫视,http://59.32.97.221:9999/tsfile/live/1048_1.m3u8
甘肃卫视,http://111.23.208.105:9908/tsfile/live/1040_1.m3u8
甘肃卫视,http://218.17.33.178:53290/tsfile/live/0141_1.m3u8
甘肃卫视,http://202.168.168.50:5000/tsfile/live/1041_1.m3u8
陕西卫视,http://111.23.208.105:9908/tsfile/live/0136_1.m3u8
陕西卫视,http://202.168.168.50:5000/tsfile/live/1040_1.m3u8
青海卫视,http://111.23.208.105:9908/tsfile/live/0140_1.m3u8
新疆卫视,http://111.23.208.105:9908/tsfile/live/0110_1.m3u8
新疆卫视,http://39.152.103.17:8089/tsfile/live/1087_1.m3u8
黑龙江卫视,http://111.23.208.105:9908/tsfile/live/1036_1.m3u8
黑龙江卫视,http://39.152.103.17:8089/tsfile/live/1055_1.m3u8
黑龙江卫视,http://202.168.168.50:5000/tsfile/live/1024_1.m3u8
黑龙江卫视,http://59.32.97.221:9999/tsfile/live/1045_1.m3u8


央卫秒播,#genre#
CCTV1,http://39.152.103.17:8089/tsfile/live/1000_1.m3u8
CCTV1,http://222.214.208.34:59901/tsfile/live/0001_1.m3u8
CCTV1,http://111.23.208.105:9908/tsfile/live/0001_1.m3u8
CCTV1,http://183.57.249.112:8183/tsfile/live/0001_1.m3u8
CCTV1,http://218.17.33.178:53290/tsfile/live/1001_1.m3u8
CCTV1,http://202.168.168.50:5000/tsfile/live/1000_1.m3u8
CCTV2,http://39.152.103.17:8089/tsfile/live/1001_1.m3u8
CCTV2,http://222.214.208.34:59901/tsfile/live/0002_1.m3u8
CCTV2,http://111.23.208.105:9908/tsfile/live/0002_1.m3u8
CCTV2,http://183.57.249.112:8183/tsfile/live/0002_1.m3u8
CCTV2,http://218.17.33.178:53290/tsfile/live/1002_1.m3u8
CCTV2,http://202.168.168.50:5000/tsfile/live/1001_1.m3u8
CCTV3,http://39.152.103.17:8089/tsfile/live/1002_1.m3u8
CCTV3,http://111.23.208.105:9908/tsfile/live/0003_1.m3u8
CCTV3,http://183.57.249.112:8183/tsfile/live/0003_1.m3u8
CCTV3,http://218.17.33.178:53290/tsfile/live/1003_1.m3u8
CCTV3,http://202.168.168.50:5000/tsfile/live/1002_1.m3u8
CCTV4,http://39.152.103.17:8089/tsfile/live/1003_1.m3u8
CCTV4,http://222.214.208.34:59901/tsfile/live/0004_1.m3u8
CCTV4,http://111.23.208.105:9908/tsfile/live/0004_1.m3u8
CCTV4,http://183.57.249.112:8183/tsfile/live/0004_1.m3u8
CCTV4,http://218.17.33.178:53290/tsfile/live/1004_1.m3u8
CCTV4,http://202.168.168.50:5000/tsfile/live/1003_1.m3u8
CCTV5,http://39.152.103.17:8089/tsfile/live/1004_1.m3u8
CCTV5,http://111.23.208.105:9908/tsfile/live/0005_1.m3u8
CCTV5,http://183.57.249.112:8183/tsfile/live/0005_1.m3u8
CCTV5,http://218.17.33.178:53290/tsfile/live/1017_1.m3u8
CCTV5,http://202.168.168.50:5000/tsfile/live/1004_1.m3u8
CCTV5+,http://39.152.103.17:8089/tsfile/live/1090_1.m3u8
CCTV5+,http://222.214.208.34:59901/tsfile/live/0016_1.m3u8
CCTV5+,http://111.23.208.105:9908/tsfile/live/1015_1.m3u8
CCTV5+,http://218.17.33.178:53290/tsfile/live/1005_1.m3u8
CCTV6,http://111.23.208.105:9908/tsfile/live/0006_2.m3u8
CCTV6,http://39.152.103.17:8089/tsfile/live/1005_1.m3u8
CCTV6,http://183.57.249.112:8183/tsfile/live/0006_1.m3u8
CCTV6,http://218.17.33.178:53290/tsfile/live/1006_1.m3u8
CCTV6,http://202.168.168.50:5000/tsfile/live/1005_1.m3u8
CCTV7,http://222.214.208.34:59901/tsfile/live/0007_1.m3u8
CCTV7,http://111.23.208.105:9908/tsfile/live/0007_2.m3u8
CCTV7,http://39.152.103.17:8089/tsfile/live/1006_1.m3u8
CCTV7,http://183.57.249.112:8183/tsfile/live/0007_1.m3u8
CCTV7,http://202.168.168.50:5000/tsfile/live/1006_1.m3u8
CCTV8,http://222.214.208.34:59901/tsfile/live/0008_1.m3u8
CCTV8,http://111.23.208.105:9908/tsfile/live/0008_2.m3u8
CCTV8,http://39.152.103.17:8089/tsfile/live/1007_1.m3u8
CCTV8,http://183.57.249.112:8183/tsfile/live/0008_1.m3u8
CCTV8,http://218.17.33.178:53290/tsfile/live/1008_1.m3u8
CCTV8,http://202.168.168.50:5000/tsfile/live/1007_1.m3u8
CCTV9,http://222.214.208.34:59901/tsfile/live/0009_1.m3u8
CCTV9,http://111.23.208.105:9908/tsfile/live/0009_2.m3u8
CCTV9,http://39.152.103.17:8089/tsfile/live/1008_1.m3u8
CCTV9,http://183.57.249.112:8183/tsfile/live/0009_1.m3u8
CCTV9,http://218.17.33.178:53290/tsfile/live/1009_1.m3u8
CCTV9,http://202.168.168.50:5000/tsfile/live/1008_1.m3u8
CCTV10,http://222.214.208.34:59901/tsfile/live/0010_1.m3u8
CCTV10,http://111.23.208.105:9908/tsfile/live/0010_2.m3u8
CCTV10,http://39.152.103.17:8089/tsfile/live/1009_1.m3u8
CCTV10,http://183.57.249.112:8183/tsfile/live/0010_1.m3u8
CCTV10,http://218.17.33.178:53290/tsfile/live/1010_1.m3u8
CCTV10,http://202.168.168.50:5000/tsfile/live/1009_1.m3u8
CCTV11,http://222.214.208.34:59901/tsfile/live/0011_1.m3u8
CCTV11,http://111.23.208.105:9908/tsfile/live/0011_2.m3u8
CCTV11,http://39.152.103.17:8089/tsfile/live/1010_1.m3u8
CCTV11,http://202.168.168.50:5000/tsfile/live/1010_1.m3u8
CCTV12,http://222.214.208.34:59901/tsfile/live/0012_1.m3u8
CCTV12,http://111.23.208.105:9908/tsfile/live/0012_2.m3u8
CCTV12,http://39.152.103.17:8089/tsfile/live/1011_1.m3u8
CCTV12,http://183.57.249.112:8183/tsfile/live/0012_1.m3u8
CCTV12,http://218.17.33.178:53290/tsfile/live/1012_1.m3u8
CCTV12,http://202.168.168.50:5000/tsfile/live/1011_1.m3u8
CCTV13,http://39.152.103.17:8089/tsfile/live/1012_1.m3u8
CCTV13,http://222.214.208.34:59901/tsfile/live/0013_1.m3u8
CCTV13,http://111.23.208.105:9908/tsfile/live/0013_1.m3u8
CCTV13,http://183.57.249.112:8183/tsfile/live/0013_1.m3u8
CCTV13,http://202.168.168.50:5000/tsfile/live/1012_1.m3u8
CCTV14,http://222.214.208.34:59901/tsfile/live/0014_1.m3u8
CCTV14,http://111.23.208.105:9908/tsfile/live/0014_1.m3u8
CCTV14,http://39.152.103.17:8089/tsfile/live/1013_1.m3u8
CCTV14,http://183.57.249.112:8183/tsfile/live/0014_1.m3u8
CCTV14,http://202.168.168.50:5000/tsfile/live/1013_1.m3u8
CCTV15,http://222.214.208.34:59901/tsfile/live/0015_1.m3u8
CCTV15,http://111.23.208.105:9908/tsfile/live/0015_2.m3u8
CCTV15,http://39.152.103.17:8089/tsfile/live/1014_1.m3u8
CCTV15,http://183.57.249.112:8183/tsfile/live/0015_1.m3u8
CCTV15,http://202.168.168.50:5000/tsfile/live/1014_1.m3u8
CCTV16,http://59.32.97.221:9999/tsfile/live/1008_1.m3u8
CCTV16,http://202.168.168.50:5000/tsfile/live/1015_1.m3u8
CCTV16,http://39.152.103.17:8089/tsfile/live/1015_1.m3u8
CCTV16,http://39.152.103.17:8089/tsfile/live/1073_1.m3u8
CCTV17,http://111.23.208.105:9908/tsfile/live/0019_1.m3u8
CCTV17,http://39.152.103.17:8089/tsfile/live/1016_1.m3u8
CCTV17,http://183.57.249.112:8183/tsfile/live/0016_1.m3u8
CCTV17,http://202.168.168.50:5000/tsfile/live/1016_1.m3u8
浙江卫视4K,https://play-qukan.cztv.com/live/1758879019692345.m3u8
深圳卫视4K,http://jiangxun.sendsmtp.com:40222/udp/239.81.0.254:4056
北京卫视4K,http://jiangxun.sendsmtp.com:40222/udp/239.81.0.226:4056
广东卫视4K,http://jiangxun.sendsmtp.com:40222/udp/239.81.0.252:4056
华数4K,http://jiangxun.sendsmtp.com:40222/udp/239.81.0.123:4056
湖南卫视,http://222.214.208.34:59901/tsfile/live/0128_1.m3u8
湖南卫视,http://111.23.208.105:9908/tsfile/live/1059_1.m3u8
湖南卫视,http://39.152.103.17:8089/tsfile/live/1040_1.m3u8
湖南卫视,http://183.57.249.112:8183/tsfile/live/1007_1.m3u8
湖南卫视,http://218.17.33.178:53290/tsfile/live/0128_1.m3u8
湖南卫视,http://202.168.168.50:5000/tsfile/live/1021_1.m3u8
浙江卫视,http://222.214.208.34:59901/tsfile/live/0124_1.m3u8
浙江卫视,http://111.23.208.105:9908/tsfile/live/1023_1.m3u8
浙江卫视,http://39.152.103.17:8089/tsfile/live/1037_1.m3u8
浙江卫视,http://183.57.249.112:8183/tsfile/live/1008_1.m3u8
浙江卫视,http://218.17.33.178:53290/tsfile/live/0124_1.m3u8
浙江卫视,http://202.168.168.50:5000/tsfile/live/1022_1.m3u8
浙江卫视,http://59.32.97.221:9999/tsfile/live/1035_1.m3u8
江苏卫视,http://222.214.208.34:59901/tsfile/live/0127_1.m3u8
江苏卫视,http://111.23.208.105:9908/tsfile/live/1022_1.m3u8
江苏卫视,http://39.152.103.17:8089/tsfile/live/1038_1.m3u8
江苏卫视,http://183.57.249.112:8183/tsfile/live/1009_1.m3u8
江苏卫视,http://202.168.168.50:5000/tsfile/live/1023_1.m3u8
东方卫视,http://222.214.208.34:59901/tsfile/live/0107_1.m3u8
东方卫视,http://111.23.208.105:9908/tsfile/live/1019_1.m3u8
东方卫视,http://39.152.103.17:8089/tsfile/live/1036_1.m3u8
东方卫视,http://183.57.249.112:8183/tsfile/live/1010_1.m3u8
东方卫视,http://202.168.168.50:5000/tsfile/live/1019_1.m3u8
东方卫视,http://59.32.97.221:9999/tsfile/live/1037_1.m3u8
北京卫视,http://222.214.208.34:59901/tsfile/live/0122_1.m3u8
北京卫视,http://111.23.208.105:9908/tsfile/live/1025_1.m3u8
北京卫视,http://39.152.103.17:8089/tsfile/live/1034_1.m3u8
北京卫视,http://202.168.168.50:5000/tsfile/live/1020_1.m3u8
北京卫视,http://59.32.97.221:9999/tsfile/live/1039_1.m3u8
东南卫视,http://222.214.208.34:59901/tsfile/live/0137_1.m3u8
东南卫视,http://111.23.208.105:9908/tsfile/live/1029_1.m3u8
东南卫视,http://39.152.103.17:8089/tsfile/live/1081_1.m3u8
东南卫视,http://202.168.168.50:5000/tsfile/live/1035_1.m3u8
东南卫视,http://59.32.97.221:9999/tsfile/live/1050_1.m3u8
云南卫视,http://111.23.208.105:9908/tsfile/live/0119_1.m3u8
云南卫视,http://39.152.103.17:8089/tsfile/live/1083_1.m3u8
吉林卫视,http://111.23.208.105:9908/tsfile/live/1039_1.m3u8
吉林卫视,http://39.152.103.17:8089/tsfile/live/1047_1.m3u8
吉林卫视,http://202.168.168.50:5000/tsfile/live/1037_1.m3u8
吉林卫视,http://59.32.97.221:9999/tsfile/live/1051_1.m3u8
四川卫视,http://222.214.208.34:59901/tsfile/live/0017_1.m3u8
四川卫视,http://111.23.208.105:9908/tsfile/live/1033_1.m3u8
四川卫视,http://39.152.103.17:8089/tsfile/live/1044_1.m3u8
四川卫视,http://218.17.33.178:53290/tsfile/live/0123_1.m3u8
四川卫视,http://202.168.168.50:5000/tsfile/live/1031_1.m3u8
四川卫视,http://59.32.97.221:9999/tsfile/live/1047_1.m3u8
四川经济,http://222.214.208.34:59901/tsfile/live/0018_1.m3u8
天津卫视,http://222.214.208.34:59901/tsfile/live/0135_1.m3u8
天津卫视,http://111.23.208.105:9908/tsfile/live/1026_1.m3u8
天津卫视,http://39.152.103.17:8089/tsfile/live/1035_1.m3u8
天津卫视,http://202.168.168.50:5000/tsfile/live/1025_1.m3u8
天津卫视,http://59.32.97.221:9999/tsfile/live/1040_1.m3u8
宁夏卫视,http://111.23.208.105:9908/tsfile/live/0112_1.m3u8
宁夏卫视,http://39.152.103.17:8089/tsfile/live/1086_1.m3u8
安徽卫视,http://222.214.208.34:59901/tsfile/live/0130_1.m3u8
安徽卫视,http://111.23.208.105:9908/tsfile/live/1024_1.m3u8
安徽卫视,http://39.152.103.17:8089/tsfile/live/1039_1.m3u8
安徽卫视,http://202.168.168.50:5000/tsfile/live/1028_1.m3u8
安徽卫视,http://59.32.97.221:9999/tsfile/live/1038_1.m3u8
山东卫视,http://222.214.208.34:59901/tsfile/live/0131_1.m3u8
山东卫视,http://111.23.208.105:9908/tsfile/live/1032_1.m3u8
山东卫视,http://183.57.249.112:8183/tsfile/live/0139_1.m3u8
山东卫视,http://39.152.103.17:8089/tsfile/live/1018_1.m3u8
山东卫视,http://218.17.33.178:53290/tsfile/live/0131_1.m3u8
山东卫视,http://202.168.168.50:5000/tsfile/live/1026_1.m3u8
山东卫视,http://59.32.97.221:9999/tsfile/live/1041_1.m3u8
广东卫视,http://222.214.208.34:59901/tsfile/live/0125_1.m3u8
广东卫视,http://111.23.208.105:9908/tsfile/live/1031_1.m3u8
广东卫视,http://39.152.103.17:8089/tsfile/live/1042_1.m3u8
广东卫视,http://183.57.249.112:8183/tsfile/live/0125_1.m3u8
广东卫视,http://218.17.33.178:53290/tsfile/live/0125_1.m3u8
广东卫视,http://202.168.168.50:5000/tsfile/live/1017_1.m3u8
广西卫视,http://111.23.208.105:9908/tsfile/live/0113_1.m3u8
广西卫视,http://39.152.103.17:8089/tsfile/live/1077_1.m3u8
广西卫视,http://202.168.168.50:5000/tsfile/live/1038_1.m3u8
江西卫视,http://222.214.208.34:59901/tsfile/live/0138_1.m3u8
江西卫视,http://111.23.208.105:9908/tsfile/live/1027_1.m3u8
江西卫视,http://39.152.103.17:8089/tsfile/live/1078_1.m3u8
江西卫视,http://218.17.33.178:53290/tsfile/live/0138_1.m3u8
江西卫视,http://202.168.168.50:5000/tsfile/live/1034_1.m3u8
江西卫视,http://59.32.97.221:9999/tsfile/live/1042_1.m3u8
河北卫视,http://111.23.208.105:9908/tsfile/live/1038_1.m3u8
河北卫视,http://39.152.103.17:8089/tsfile/live/1079_1.m3u8
河北卫视,http://202.168.168.50:5000/tsfile/live/1033_1.m3u8
河北卫视,http://59.32.97.221:9999/tsfile/live/1049_1.m3u8
河南卫视,http://111.23.208.105:9908/tsfile/live/1035_1.m3u8
河南卫视,http://39.152.103.17:8089/tsfile/live/1080_1.m3u8
河南卫视,http://202.168.168.50:5000/tsfile/live/1036_1.m3u8
海南卫视,http://111.23.208.105:9908/tsfile/live/1030_1.m3u8
海南卫视,http://39.152.103.17:8089/tsfile/live/1046_1.m3u8
深圳卫视,http://222.214.208.34:59901/tsfile/live/0126_1.m3u8
深圳卫视,http://111.23.208.105:9908/tsfile/live/1020_1.m3u8
深圳卫视,http://39.152.103.17:8089/tsfile/live/1049_1.m3u8
深圳卫视,http://202.168.168.50:5000/tsfile/live/1018_1.m3u8
深圳卫视,http://59.32.97.221:9999/tsfile/live/1043_1.m3u8
湖北卫视,http://222.214.208.34:59901/tsfile/live/0132_1.m3u8
湖北卫视,http://111.23.208.105:9908/tsfile/live/1021_1.m3u8
湖北卫视,http://39.152.103.17:8089/tsfile/live/1043_1.m3u8
湖北卫视,http://183.57.249.112:8183/tsfile/live/0132_1.m3u8
湖北卫视,http://218.17.33.178:53290/tsfile/live/0132_1.m3u8
湖北卫视,http://202.168.168.50:5000/tsfile/live/1027_1.m3u8
贵州卫视,http://222.214.208.34:59901/tsfile/live/0120_1.m3u8
贵州卫视,http://111.23.208.105:9908/tsfile/live/1037_1.m3u8
贵州卫视,http://39.152.103.17:8089/tsfile/live/1041_1.m3u8
贵州卫视,http://202.168.168.50:5000/tsfile/live/1030_1.m3u8
贵州卫视,http://59.32.97.221:9999/tsfile/live/1046_1.m3u8
辽宁卫视,http://111.23.208.105:9908/tsfile/live/1028_1.m3u8
辽宁卫视,http://39.152.103.17:8089/tsfile/live/1024_1.m3u8
辽宁卫视,http://218.17.33.178:53290/tsfile/live/0121_1.m3u8
辽宁卫视,http://202.168.168.50:5000/tsfile/live/1029_1.m3u8
辽宁卫视,http://59.32.97.221:9999/tsfile/live/1044_1.m3u8
重庆卫视,http://222.214.208.34:59901/tsfile/live/0142_1.m3u8
重庆卫视,http://111.23.208.105:9908/tsfile/live/1034_1.m3u8
重庆卫视,http://39.152.103.17:8089/tsfile/live/1048_1.m3u8
重庆卫视,http://183.57.249.112:8183/tsfile/live/0142_1.m3u8
重庆卫视,http://202.168.168.50:5000/tsfile/live/1032_1.m3u8
重庆卫视,http://59.32.97.221:9999/tsfile/live/1048_1.m3u8
甘肃卫视,http://111.23.208.105:9908/tsfile/live/1040_1.m3u8
甘肃卫视,http://218.17.33.178:53290/tsfile/live/0141_1.m3u8
甘肃卫视,http://202.168.168.50:5000/tsfile/live/1041_1.m3u8
陕西卫视,http://111.23.208.105:9908/tsfile/live/0136_1.m3u8
陕西卫视,http://202.168.168.50:5000/tsfile/live/1040_1.m3u8
青海卫视,http://111.23.208.105:9908/tsfile/live/0140_1.m3u8
新疆卫视,http://111.23.208.105:9908/tsfile/live/0110_1.m3u8
新疆卫视,http://39.152.103.17:8089/tsfile/live/1087_1.m3u8
黑龙江卫视,http://111.23.208.105:9908/tsfile/live/1036_1.m3u8
黑龙江卫视,http://39.152.103.17:8089/tsfile/live/1055_1.m3u8
黑龙江卫视,http://202.168.168.50:5000/tsfile/live/1024_1.m3u8
黑龙江卫视,http://59.32.97.221:9999/tsfile/live/1045_1.m3u8

蜀小果
CCTV1,http://iptv.666230.xyz/iptv/sxg.php/CCTV-1H265_4000
CCTV2,http://iptv.666230.xyz/iptv/sxg.php/CCTV-2H265_4000
CCTV3,http://iptv.666230.xyz/iptv/sxg.php/CCTV-3H265_4000
CCTV4,http://iptv.666230.xyz/iptv/sxg.php/CCTV-4H265_4000
CCTV4K,http://iptv.666230.xyz/iptv/sxg.php/ys4Kcq_2000
CCTV5,http://iptv.666230.xyz/iptv/sxg.php/CCTV-5H265_4000
CCTV5+,http://iptv.666230.xyz/iptv/sxg.php/CCTV-5plusH265_4000
CCTV6,http://iptv.666230.xyz/iptv/sxg.php/CCTV-6H265_4000
CCTV7,http://iptv.666230.xyz/iptv/sxg.php/CCTV-7H265_4000
CCTV8,http://iptv.666230.xyz/iptv/sxg.php/CCTV-8H265_4000
CCTV9,http://iptv.666230.xyz/iptv/sxg.php/CCTV-9H265_4000
CCTV10,http://iptv.666230.xyz/iptv/sxg.php/CCTV-10H265_4000
CCTV11,http://iptv.666230.xyz/iptv/sxg.php/CCTV-11-H265_4000
CCTV12,http://iptv.666230.xyz/iptv/sxg.php/CCTV-12H265_4000
CCTV13,http://iptv.666230.xyz/iptv/sxg.php/CCTV-xw_4000
CCTV14,http://iptv.666230.xyz/iptv/sxg.php/CCTV-14H265_4000
CCTV15,http://iptv.666230.xyz/iptv/sxg.php/CCTV-15-yyH265_4000
CCTV16,http://iptv.666230.xyz/iptv/sxg.php/CCTV-16_4000
CCTV16-4k,http://iptv.666230.xyz/iptv/sxg.php/CCTV-16-4K_8000
CCTV17,http://iptv.666230.xyz/iptv/sxg.php/CCTV-17_4000
CGTN,http://iptv.666230.xyz/iptv/sxg.php/CGTN_4000
CGTN西语,http://iptv.666230.xyz/iptv/sxg.php/xbyy_2000
CGTN法语,http://iptv.666230.xyz/iptv/sxg.php/fy_2000
CGTN俄语,http://iptv.666230.xyz/iptv/sxg.php/ey_2000
北京卫视,http://iptv.666230.xyz/iptv/sxg.php/bjwsH265_4000
东方卫视,http://iptv.666230.xyz/iptv/sxg.php/dfwsH265_4000
天津卫视,http://iptv.666230.xyz/iptv/sxg.php/tjwsH265_4000
重庆卫视,http://iptv.666230.xyz/iptv/sxg.php/cqwsH265_4000
黑龙江卫视,http://iptv.666230.xyz/iptv/sxg.php/hljwsH265_4000
吉林卫视,http://iptv.666230.xyz/iptv/sxg.php/jlwsH265_4000
辽宁卫视,http://iptv.666230.xyz/iptv/sxg.php/lnwsHDH264_4000
内蒙古卫视,http://iptv.666230.xyz/iptv/sxg.php/nmgws_4000
甘肃卫视,http://iptv.666230.xyz/iptv/sxg.php/gsws_4000
青海卫视,http://iptv.666230.xyz/iptv/sxg.php/qhwsH264_2000
陕西卫视,http://iptv.666230.xyz/iptv/sxg.php/sxws_4000
山西卫视,http://iptv.666230.xyz/iptv/sxg.php/sxws42_4000
山东卫视,http://iptv.666230.xyz/iptv/sxg.php/sdwsH265_4000
安徽卫视,http://iptv.666230.xyz/iptv/sxg.php/ahwsH265_4000
河南卫视,http://iptv.666230.xyz/iptv/sxg.php/hnws35_4000
湖北卫视,http://iptv.666230.xyz/iptv/sxg.php/hbwsH265_4000
湖南卫视,http://iptv.666230.xyz/iptv/sxg.php/hnwsH265_4000
江西卫视,http://iptv.666230.xyz/iptv/sxg.php/jxwsH265_4000
江苏卫视,http://iptv.666230.xyz/iptv/sxg.php/jswsH265_4000
浙江卫视,http://iptv.666230.xyz/iptv/sxg.php/zjwsH265_4000
东南卫视,http://iptv.666230.xyz/iptv/sxg.php/dnwsfjwsH265_4000
广东卫视,http://iptv.666230.xyz/iptv/sxg.php/gdwsH265_4000
深圳卫视,http://iptv.666230.xyz/iptv/sxg.php/szwsH265_4000
广西卫视,http://iptv.666230.xyz/iptv/sxg.php/gxws_4000
云南卫视,http://iptv.666230.xyz/iptv/sxg.php/ynws_4000
贵州卫视,http://iptv.666230.xyz/iptv/sxg.php/gzwsH265_4000
四川卫视,http://iptv.666230.xyz/iptv/sxg.php/scwsH265_4000
康巴卫视,http://iptv.666230.xyz/iptv/sxg.php/kbwsH264_2000
新疆卫视,http://iptv.666230.xyz/iptv/sxg.php/xjws_4000
兵团卫视,http://iptv.666230.xyz/iptv/sxg.php/btws_4000
西藏卫视,http://iptv.666230.xyz/iptv/sxg.php/xzwsH264_2000
海南卫视,http://iptv.666230.xyz/iptv/sxg.php/hnws_4000
卡酷少儿,http://iptv.666230.xyz/iptv/sxg.php/kkkt_4000
金鹰卡通,http://iptv.666230.xyz/iptv/sxg.php/jykt_2000
嘉佳卡通,http://iptv.666230.xyz/iptv/sxg.php/jjkt_2000
成都少儿,http://iptv.666230.xyz/iptv/sxg.php/CDTV-6_2000
四川经济,http://iptv.666230.xyz/iptv/sxg.php/SCTV-2-H265_4000
四川文化,http://iptv.666230.xyz/iptv/sxg.php/SCTV-3-H265_4000
四川新闻,http://iptv.666230.xyz/iptv/sxg.php/SCTV-4H265_4000
四川影视,http://iptv.666230.xyz/iptv/sxg.php/SCTV-5-scysH265_4000
四川科教,http://iptv.666230.xyz/iptv/sxg.php/SCTV-ggSCTV-8_4000
四川乡村,http://iptv.666230.xyz/iptv/sxg.php/SCTV-kjSCTV-9-_4000
峨嵋电影,http://iptv.666230.xyz/iptv/sxg.php/emdygqH265_4000
峨眉电影4K,http://iptv.666230.xyz/iptv/sxg.php/emdy4k_8000
成都新闻,http://iptv.666230.xyz/iptv/sxg.php/CDTV-1_4000
成都经济,http://iptv.666230.xyz/iptv/sxg.php/CDTV-2_4000
成都都市,http://iptv.666230.xyz/iptv/sxg.php/CDTV-3_4000
成都影视,http://iptv.666230.xyz/iptv/sxg.php/CDTV-4_4000
成都公共,http://iptv.666230.xyz/iptv/sxg.php/CDTV-5_4000
成都购物,http://iptv.666230.xyz/iptv/sxg.php/mrgw_4000
成都高新,http://iptv.666230.xyz/iptv/sxg.php/cdgxdstgq_2000
CHC影迷电影,http://iptv.666230.xyz/iptv/sxg.php/lnwsCHC-HDH265_4000
CHC动作电影,http://iptv.666230.xyz/iptv/sxg.php/wqCHCdzdyH265_4000
CHC家庭影院,http://iptv.666230.xyz/iptv/sxg.php/jbtygqCHCjtyyH265_4000
中央新影-老故事,http://iptv.666230.xyz/iptv/sxg.php/lgs_2000
中央新影-中学生,http://iptv.666230.xyz/iptv/sxg.php/zxs_4000
中央新影-发现之旅,http://iptv.666230.xyz/iptv/sxg.php/fxzl_2000
书画频道,http://iptv.666230.xyz/iptv/sxg.php/sh_4000
中国天气,http://iptv.666230.xyz/iptv/sxg.php/zgqx_4000
重温经典,http://iptv.666230.xyz/iptv/sxg.php/CWJD_4000
CETV1,http://iptv.666230.xyz/iptv/sxg.php/CETV-1H264_4000
CETV2,http://iptv.666230.xyz/iptv/sxg.php/CETV-2_4000
CETV4,http://iptv.666230.xyz/iptv/sxg.php/CETV-4H264_2000
四海钓鱼,http://iptv.666230.xyz/iptv/sxg.php/shdy_4000
车迷,http://iptv.666230.xyz/iptv/sxg.php/cmpdH264_2000
证劵服务,http://iptv.666230.xyz/iptv/sxg.php/jz_2000
聚鲨环球精选,http://iptv.666230.xyz/iptv/sxg.php/hqgw_4000
动漫秀场,http://iptv.666230.xyz/iptv/sxg.php/yybb-dmxc-H265_4000
都市剧场,http://iptv.666230.xyz/iptv/sxg.php/yxfydsjcHDH265_4000
法治天地,http://iptv.666230.xyz/iptv/sxg.php/fztx_4000
欢笑剧场,http://iptv.666230.xyz/iptv/sxg.php/hxjc-4k_8000
乐游,http://iptv.666230.xyz/iptv/sxg.php/qjs-HDH265_4000
魅力足球,http://iptv.666230.xyz/iptv/sxg.php/mlyy_4000
生活时尚,http://iptv.666230.xyz/iptv/sxg.php/shssH265_4000
新视觉,http://iptv.666230.xyz/iptv/sxg.php/ycxsjH265_4000
汽摩,http://iptv.666230.xyz/iptv/sxg.php/qmpdH264_2000
家有购物,http://iptv.666230.xyz/iptv/sxg.php/jygw_4000
家庭理财,http://iptv.666230.xyz/iptv/sxg.php/jtlc_4000
优购物,http://iptv.666230.xyz/iptv/sxg.php/ygw_4000
凤凰中文,http://iptv.666230.xyz/iptv/sxg.php/test1_4000
凤凰资讯,http://iptv.666230.xyz/iptv/sxg.php/test2_4000
梨园频道,http://iptv.666230.xyz/iptv/sxg.php/ly_4000
武术世界,http://iptv.666230.xyz/iptv/sxg.php/wssj_4000
文物宝库,http://iptv.666230.xyz/iptv/sxg.php/wwbk_4000
茶频道,http://iptv.666230.xyz/iptv/sxg.php/cpd_4000
金鹰纪实,http://iptv.666230.xyz/iptv/sxg.php/jyjsHDH265_4000
北京纪实科教,http://iptv.666230.xyz/iptv/sxg.php/bjjs_2000
快乐垂钓,http://iptv.666230.xyz/iptv/sxg.php/fyzqklcdHDH265_4000
先锋乒羽,http://iptv.666230.xyz/iptv/sxg.php/xfpy_4000
财富天下,http://iptv.666230.xyz/iptv/sxg.php/cftx_4000
天元围棋,http://iptv.666230.xyz/iptv/sxg.php/tywq_2000
精品导视,http://iptv.666230.xyz/iptv/sxg.php/jpdsH265_4000
精品导视2,http://iptv.666230.xyz/iptv/sxg.php/jpdsgq-hkkp_4000
川网导视,http://iptv.666230.xyz/iptv/sxg.php/cwdsHDH264_4000
东方财经,http://iptv.666230.xyz/iptv/sxg.php/dfcj_4000
山东教育,http://iptv.666230.xyz/iptv/sxg.php/sdjy_4000
青羊电视,http://iptv.666230.xyz/iptv/sxg.php/qyzh_4000
央广购物,http://iptv.666230.xyz/iptv/sxg.php/yggw_2000
崇州,http://iptv.666230.xyz/iptv/sxg.php/czyt_4000
大邑,http://iptv.666230.xyz/iptv/sxg.php/dyytH265_4000
都江堰综合,http://iptv.666230.xyz/iptv/sxg.php/djyzh_4000
金牛综合,http://iptv.666230.xyz/iptv/sxg.php/jnyx_2000
金堂,http://iptv.666230.xyz/iptv/sxg.php/jtzhpd_2000
简阳新闻,http://iptv.666230.xyz/iptv/sxg.php/jyxwzh_2000
龙泉新闻,http://iptv.666230.xyz/iptv/sxg.php/lqxw_2000
郫都新闻,http://iptv.666230.xyz/iptv/sxg.php/pxds1_2000
蒲江综合,http://iptv.666230.xyz/iptv/sxg.php/pjxw_4000
彭州综合,http://iptv.666230.xyz/iptv/sxg.php/pzxwzh_2000
青白江综合,http://iptv.666230.xyz/iptv/sxg.php/qbjxwzh_2000
邛崃综合,http://iptv.666230.xyz/iptv/sxg.php/qlds1t_2000
双流综合,http://iptv.666230.xyz/iptv/sxg.php/slgq_2000
温江新闻,http://iptv.666230.xyz/iptv/sxg.php/wjytH264_2000
新都综合,http://iptv.666230.xyz/iptv/sxg.php/xdzhpd_2000
新津综合,http://iptv.666230.xyz/iptv/sxg.php/xjzh_4000
绵阳新闻,http://iptv.666230.xyz/iptv/sxg.php/myytH265_4000
绵阳科技,http://iptv.666230.xyz/iptv/sxg.php/myetH265_4000
安州综合,http://iptv.666230.xyz/iptv/sxg.php/azgq_2000
北川综合,http://iptv.666230.xyz/iptv/sxg.php/bcxwHD_2000
涪城综合,http://iptv.666230.xyz/iptv/sxg.php/fcgq_2000
江油综合,http://iptv.666230.xyz/iptv/sxg.php/jyxwHD_2000
平武综合,http://iptv.666230.xyz/iptv/sxg.php/pwgq_4000
盐亭综合,http://iptv.666230.xyz/iptv/sxg.php/ytzh_2000
梓潼综合,http://iptv.666230.xyz/iptv/sxg.php/ztgq_2000
攀枝花新闻,http://iptv.666230.xyz/iptv/sxg.php/pzhytH265_4000
攀枝花文旅,http://iptv.666230.xyz/iptv/sxg.php/pzhggpd_2000
攀钢新闻,http://iptv.666230.xyz/iptv/sxg.php/pgxwzh_2000
米易综合,http://iptv.666230.xyz/iptv/sxg.php/myxwzh_2000
盐边综合,http://iptv.666230.xyz/iptv/sxg.php/ybtgq_2000
仁和新闻,http://iptv.666230.xyz/iptv/sxg.php/rhxwH264_2000
广元综合,http://iptv.666230.xyz/iptv/sxg.php/gyzhH265_4000
广元文化生活,http://iptv.666230.xyz/iptv/sxg.php/gyggH265_4000
朝天综合,http://iptv.666230.xyz/iptv/sxg.php/ctxwzh_2000
苍溪综合,http://iptv.666230.xyz/iptv/sxg.php/cxxwgqH265_4000
剑阁综合,http://iptv.666230.xyz/iptv/sxg.php/jgxwzhH265_4000
利州综合,http://iptv.666230.xyz/iptv/sxg.php/lzxwzh_2000
青川综合,http://iptv.666230.xyz/iptv/sxg.php/qcxwzhH265_4000
旺苍新闻,http://iptv.666230.xyz/iptv/sxg.php/wcxwzhH265_4000
昭化综合,http://iptv.666230.xyz/iptv/sxg.php/zhxwzh_2000
古蔺新闻,http://iptv.666230.xyz/iptv/sxg.php/glxwzhgq_2000
合江新闻,http://iptv.666230.xyz/iptv/sxg.php/hjxw_2000
泸县综合,http://iptv.666230.xyz/iptv/sxg.php/lxxwzh_2000
纳溪,http://iptv.666230.xyz/iptv/sxg.php/nxxw_2000
叙永综合,http://iptv.666230.xyz/iptv/sxg.php/xyxw_2000
德阳新闻,http://iptv.666230.xyz/iptv/sxg.php/dyxwgq-HD-_2000
德阳文旅,http://iptv.666230.xyz/iptv/sxg.php/dygggq-HD-_2000
广汉综合,http://iptv.666230.xyz/iptv/sxg.php/ghxwzh_2000
旌阳综合,http://iptv.666230.xyz/iptv/sxg.php/jyxwgq-HD-_2000
罗江综合,http://iptv.666230.xyz/iptv/sxg.php/ljxwzh_2000
绵竹综合,http://iptv.666230.xyz/iptv/sxg.php/mzxwzh_2000
中江新闻,http://iptv.666230.xyz/iptv/sxg.php/zjxwzh_2000
宜宾新闻,http://iptv.666230.xyz/iptv/sxg.php/ybytH264_2000
宜宾公共,http://iptv.666230.xyz/iptv/sxg.php/ybetH264_2000
宜宾导视,http://iptv.666230.xyz/iptv/sxg.php/ybds_2000
珙县新闻,http://iptv.666230.xyz/iptv/sxg.php/gxzh_2000
江安综合,http://iptv.666230.xyz/iptv/sxg.php/jat_2000
南溪综合,http://iptv.666230.xyz/iptv/sxg.php/nxt_2000
屏山新闻,http://iptv.666230.xyz/iptv/sxg.php/psxwzh_2000
兴文综合,http://iptv.666230.xyz/iptv/sxg.php/xwt_2000
叙州新闻,http://iptv.666230.xyz/iptv/sxg.php/ybx_2000
筠连新闻,http://iptv.666230.xyz/iptv/sxg.php/ylyt_2000
长宁综合,http://iptv.666230.xyz/iptv/sxg.php/znzh_2000
宁新综合,http://iptv.666230.xyz/iptv/sxg.php/snxwzhHDH265_4000
遂宁文化,http://iptv.666230.xyz/iptv/sxg.php/sngggq_2000
安居综合,http://iptv.666230.xyz/iptv/sxg.php/ajxw_2000
大英新闻,http://iptv.666230.xyz/iptv/sxg.php/dyxwzhH265_4000
蓬溪新闻,http://iptv.666230.xyz/iptv/sxg.php/pxxw_2000
乐山新闻,http://iptv.666230.xyz/iptv/sxg.php/lsxwzh_4000
乐山文旅,http://iptv.666230.xyz/iptv/sxg.php/lsggpd_4000
峨边综合,http://iptv.666230.xyz/iptv/sxg.php/ebdst_2000
夹江新闻,http://iptv.666230.xyz/iptv/sxg.php/jjxw_2000
金口河综合,http://iptv.666230.xyz/iptv/sxg.php/jkhdst_2000
井研新闻,http://iptv.666230.xyz/iptv/sxg.php/jyxwzh162_2000
马边综合,http://iptv.666230.xyz/iptv/sxg.php/mbxwzh_2000
沐川综合,http://iptv.666230.xyz/iptv/sxg.php/mcxw_2000
犍为新闻,http://iptv.666230.xyz/iptv/sxg.php/qwxwzh_2000
沙湾融媒,http://iptv.666230.xyz/iptv/sxg.php/swxwzh_2000
五通桥综合,http://iptv.666230.xyz/iptv/sxg.php/wtqxwzh_2000
内江综合,http://iptv.666230.xyz/iptv/sxg.php/njzh_4000
内江公共,http://iptv.666230.xyz/iptv/sxg.php/njgg_4000
东兴综合,http://iptv.666230.xyz/iptv/sxg.php/dxxwzh_4000
隆昌综合,http://iptv.666230.xyz/iptv/sxg.php/lcxw_2000
资中综合,http://iptv.666230.xyz/iptv/sxg.php/zzzh_2000
南充综合,http://iptv.666230.xyz/iptv/sxg.php/ncxwzh_2000
南充科教,http://iptv.666230.xyz/iptv/sxg.php/nckj_4000
阆中综合,http://iptv.666230.xyz/iptv/sxg.php/lzxw_2000
南部综合,http://iptv.666230.xyz/iptv/sxg.php/nbxw_2000
蓬安综合,http://iptv.666230.xyz/iptv/sxg.php/pazh_2000
西充新闻,http://iptv.666230.xyz/iptv/sxg.php/xczh_2000
仪陇新闻,http://iptv.666230.xyz/iptv/sxg.php/ylxw_2000
营山综合,http://iptv.666230.xyz/iptv/sxg.php/ysxw_2000
达州新闻,http://iptv.666230.xyz/iptv/sxg.php/dzxwzh_2000
达州文化,http://iptv.666230.xyz/iptv/sxg.php/dzgg_2000
达州导视,http://iptv.666230.xyz/iptv/sxg.php/dzds_2000
达川新闻,http://iptv.666230.xyz/iptv/sxg.php/dcxwzh_2000
大竹新闻,http://iptv.666230.xyz/iptv/sxg.php/dzxwzh137_2000
开江新闻,http://iptv.666230.xyz/iptv/sxg.php/kjxwzh_2000
渠县新闻,http://iptv.666230.xyz/iptv/sxg.php/qxxwzh_2000
通川综合,http://iptv.666230.xyz/iptv/sxg.php/xcxwzhH264_2000
万源综合,http://iptv.666230.xyz/iptv/sxg.php/wyxwzh_2000
宣汉新闻,http://iptv.666230.xyz/iptv/sxg.php/xhxwzh_2000
雅安新闻,http://iptv.666230.xyz/iptv/sxg.php/yazh_2000
雅安公共,http://iptv.666230.xyz/iptv/sxg.php/yagg_2000
雅安雨城,http://iptv.666230.xyz/iptv/sxg.php/ycpd_2000
宝兴综合,http://iptv.666230.xyz/iptv/sxg.php/bxdst_2000
汉源新闻,http://iptv.666230.xyz/iptv/sxg.php/hyxwzh_2000
芦山新闻,http://iptv.666230.xyz/iptv/sxg.php/lszh_2000
名山综合,http://iptv.666230.xyz/iptv/sxg.php/msdstH265_2000
石棉综合,http://iptv.666230.xyz/iptv/sxg.php/smxwzh_2000
天全新闻,http://iptv.666230.xyz/iptv/sxg.php/tqzh_2000
荥经综合,http://iptv.666230.xyz/iptv/sxg.php/xjdst_2000
广安公共,http://iptv.666230.xyz/iptv/sxg.php/gagg_2000
广安区综合,http://iptv.666230.xyz/iptv/sxg.php/gaqxw_2000
华蓥综合,http://iptv.666230.xyz/iptv/sxg.php/hyxw_2000
邻水综合,http://iptv.666230.xyz/iptv/sxg.php/lsxw_2000
前锋综合,http://iptv.666230.xyz/iptv/sxg.php/qfxw_2000
武胜综合,http://iptv.666230.xyz/iptv/sxg.php/wsxw_2000
岳池综合,http://iptv.666230.xyz/iptv/sxg.php/ycxw_2000
巴中综合,http://iptv.666230.xyz/iptv/sxg.php/bzytH265_4000
巴中文旅,http://iptv.666230.xyz/iptv/sxg.php/bzetH264_2000
巴州电视,http://iptv.666230.xyz/iptv/sxg.php/bzxw_4000
恩阳新闻,http://iptv.666230.xyz/iptv/sxg.php/eyxw_2000
南江综合,http://iptv.666230.xyz/iptv/sxg.php/njxw_2000
平昌综合,http://iptv.666230.xyz/iptv/sxg.php/pcxw_2000
通江综合,http://iptv.666230.xyz/iptv/sxg.php/tjxwH265_4000
眉山综合,http://iptv.666230.xyz/iptv/sxg.php/msxwzhgq_2000
眉山文旅乡村,http://iptv.666230.xyz/iptv/sxg.php/msgg_2000
丹棱新闻,http://iptv.666230.xyz/iptv/sxg.php/dlxwzhH265_4000
洪雅新闻,http://iptv.666230.xyz/iptv/sxg.php/hyzh_2000
彭山综合,http://iptv.666230.xyz/iptv/sxg.php/pszh_2000
青神综合,http://iptv.666230.xyz/iptv/sxg.php/qszh_2000
仁寿综合,http://iptv.666230.xyz/iptv/sxg.php/msrszh_2000
凉山新闻,http://iptv.666230.xyz/iptv/sxg.php/lsxwHDH265_4000
凉山彝语,http://iptv.666230.xyz/iptv/sxg.php/yyzh_2000
德昌综合,http://iptv.666230.xyz/iptv/sxg.php/dcxw_4000
会理新闻,http://iptv.666230.xyz/iptv/sxg.php/hlyt_4000
木里综合,http://iptv.666230.xyz/iptv/sxg.php/mltHD_4000
冕宁综合,http://iptv.666230.xyz/iptv/sxg.php/mnxw_2000
宁南综合,http://iptv.666230.xyz/iptv/sxg.php/nnt_4000
普格新闻,http://iptv.666230.xyz/iptv/sxg.php/pgt_4000
西昌综合,http://iptv.666230.xyz/iptv/sxg.php/xctHD_2000
喜德综合,http://iptv.666230.xyz/iptv/sxg.php/xdxw_4000
越西综合,http://iptv.666230.xyz/iptv/sxg.php/yxt_4000
资阳新闻,http://iptv.666230.xyz/iptv/sxg.php/zyxwzh_2000
雁江综合,http://iptv.666230.xyz/iptv/sxg.php/yjxw_2000
安岳新闻,http://iptv.666230.xyz/iptv/sxg.php/ayxwzh_4000
乐至综合,http://iptv.666230.xyz/iptv/sxg.php/lezhixwzh_4000
自贡新闻,http://iptv.666230.xyz/iptv/sxg.php/zgxw_4000
自贡文化生活,http://iptv.666230.xyz/iptv/sxg.php/zggg_4000
富顺综合,http://iptv.666230.xyz/iptv/sxg.php/fszh_2000
荣县综合,http://iptv.666230.xyz/iptv/sxg.php/rxzh_2000
甘孜新闻,http://iptv.666230.xyz/iptv/sxg.php/gzxwzh_2000
泸定综合,http://iptv.666230.xyz/iptv/sxg.php/ldxw_4000
康定综合,http://iptv.666230.xyz/iptv/sxg.php/gzkdxwzh_2000
黑水新闻,http://iptv.666230.xyz/iptv/sxg.php/hsxwzhpdH264_2000
马尔康新闻,http://iptv.666230.xyz/iptv/sxg.php/mekxwzhpd_2000
松潘新闻,http://iptv.666230.xyz/iptv/sxg.php/spxwzhpdH264_2000
三台一套,http://iptv.666230.xyz/iptv/sxg.php/stxwHD_2000
高县一套,http://iptv.666230.xyz/iptv/sxg.php/gxt_2000
峨眉山综合,http://iptv.666230.xyz/iptv/sxg.php/emsxw_2000


CCTV1,http://202.168.168.50:5000/tsfile/live/1000_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV1,http://222.135.142.75:3283/tsfile/live/0001_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV2,http://222.169.85.8:9901/tsfile/live/0002_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV3,http://163.142.186.48:9901/tsfile/live/1003_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV3,http://202.168.168.50:5000/tsfile/live/1002_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV3,http://163.142.186.57:9901/tsfile/live/1003_1.m3u8?key=txiptv&playlive=1&authid=0# S3 |0 h$ V% \. i5 i* W
CCTV3,http://163.142.186.56:9901/tsfile/live/1003_1.m3u8?key=txiptv&playlive=1&authid=06 l8 ?5 k6 j* y5 B0 j
CCTV3,http://222.169.85.8:9901/tsfile/live/0003_1.m3u8?key=txiptv&playlive=1&authid=0$ ^. P, g" n& f3 k2 j0 S
CCTV3,http://223.75.148.190:9910/tsfile/live/0003_2.m3u8?key=txiptv&playlive=0&authid=0" r, W9 `( d/ l% r3 q
CCTV3,http://119.125.104.133:9901/tsfile/live/1022_1.m3u8?key=txiptv&playlive=1&authid=0! b6 s5 z- \" i: `% o. j; T
CCTV3,http://221.13.235.210:9901/tsfile/live/0003_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV4,http://202.168.168.50:5000/tsfile/live/1003_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV4,http://223.75.148.190:9910/tsfile/live/0004_2.m3u8?key=txiptv&playlive=0&authid=0
CCTV4,http://110.72.65.118:8181/tsfile/live/0004_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV4,http://110.72.67.190:8181/tsfile/live/0004_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV4,http://182.91.124.60:8801/tsfile/live/1040_1.m3u8?key=txiptv&playlive=0&authid=0
CCTV4,http://61.156.228.12:8154/tsfile/live/0004_1.m3u8?key=txiptv&playlive=1&authid=0  \, V# o; Q  a6 `& s0 R
CCTV4,http://218.94.31.154:1111/tsfile/live/0004_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV5,http://223.75.148.190:9910/tsfile/live/0005_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV5,http://61.156.228.12:8154/tsfile/live/0005_1.m3u8?key=txiptv&playlive=1&authid=0! i, G! ^2 Q% K1 R" x( Y+ e
CCTV5,http://222.169.85.8:9901/tsfile/live/0005_1.m3u8?key=txiptv&playlive=1&authid=0' V9 ^! v& }1 C- l# n- d
CCTV5,http://119.125.104.133:9901/tsfile/live/1024_1.m3u8?key=txiptv&playlive=1&authid=0- m& q, M0 R7 g; Q% C' K7 }+ {
CCTV5,http://221.13.235.210:9901/tsfile/live/0005_1.m3u8?key=txiptv&playlive=1&authid=07 o+ y! w" u7 m# a8 u/ o* l
CCTV6,http://163.142.186.56:9901/tsfile/live/1006_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV6,http://111.8.242.142:9999/tsfile/live/1024_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV6,http://163.142.186.57:9901/tsfile/live/1006_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV6,http://163.142.186.49:9901/tsfile/live/1006_1.m3u8?key=txiptv&playlive=1&authid=0/ F: V1 a& i8 ^" u& R* l% Y/ w9 l
CCTV6,http://163.142.186.48:9901/tsfile/live/1006_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV6,http://202.168.168.50:5000/tsfile/live/1005_1.m3u8?key=txiptv&playlive=1&authid=0/ k+ X3 |( ?1 I8 O+ R+ R1 T
CCTV6,http://223.75.148.190:9910/tsfile/live/0006_1.m3u8?key=txiptv&playlive=0&authid=0; v- u8 r* V0 O% s
CCTV6,http://119.125.104.133:9901/tsfile/live/1026_1.m3u8?key=txiptv&playlive=1&authid=05 c7 `/ D- l; P, f7 H! i7 H- |  Y
CCTV7,http://202.168.168.50:5000/tsfile/live/1006_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV7,http://110.72.65.118:8181/tsfile/live/0007_1.m3u8?key=txiptv&playlive=1&authid=0  ?  C$ n$ H$ k6 ?" Q$ f
CCTV7,http://119.125.104.133:9901/tsfile/live/1027_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV8,http://163.142.186.57:9901/tsfile/live/1008_1.m3u8?key=txiptv&playlive=1&authid=0" K2 F. \$ L. k
CCTV8,http://202.168.168.50:5000/tsfile/live/1007_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV8,http://163.142.186.56:9901/tsfile/live/1008_1.m3u8?key=txiptv&playlive=1&authid=0% S- b5 d# D0 e% A. r
CCTV8,http://222.223.84.112:9901/tsfile/live/0008_1.m3u8?key=txiptv&playlive=1&authid=08 z' B! l" S2 B- }
CCTV8,http://163.142.186.48:9901/tsfile/live/1008_1.m3u8?key=txiptv&playlive=1&authid=0. }+ c* {, w% Z# D
CCTV8,http://163.142.186.49:9901/tsfile/live/1008_1.m3u8?key=txiptv&playlive=1&authid=06 R, k4 [, [/ p/ ?- j) S6 `0 l
CCTV8,http://61.156.228.12:8154/tsfile/live/0008_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV8,http://119.125.104.133:9901/tsfile/live/1028_1.m3u8?key=txiptv&playlive=1&authid=0  A/ t  Z, y: ?+ Y  p
CCTV9,http://202.168.168.50:5000/tsfile/live/1008_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV10,http://202.168.168.50:5000/tsfile/live/1009_1.m3u8?key=txiptv&playlive=1&authid=08 o- o! X$ d7 h5 {% l  `5 g6 u
CCTV10,http://119.125.104.133:9901/tsfile/live/1030_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV11,http://223.75.148.190:9910/tsfile/live/0011_1.m3u8?key=txiptv&playlive=0&authid=0
CCTV11,http://202.168.168.50:5000/tsfile/live/1010_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV11,http://182.91.124.60:8801/tsfile/live/1047_1.m3u8?key=txiptv&playlive=0&authid=0
CCTV11,http://222.169.85.8:9901/tsfile/live/0011_1.m3u8?key=txiptv&playlive=1&authid=0) R) p2 R/ I" G1 |3 j: g, b5 Q
CCTV11,http://61.156.228.12:8154/tsfile/live/0011_1.m3u8?key=txiptv&playlive=1&authid=04 Q& \6 D$ {( e. O9 O$ j) ^
CCTV11,http://218.94.31.154:1111/tsfile/live/0011_1.m3u8?key=txiptv&playlive=1&authid=09 S, h% q& o% h/ \, Q& {) H
CCTV12,http://202.168.168.50:5000/tsfile/live/1011_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV12,http://110.72.67.190:8181/tsfile/live/0012_1.m3u8?key=txiptv&playlive=1&authid=0/ _& h6 o3 ?0 p( j+ ]7 {, G: X4 v9 w5 @
CCTV12,http://110.72.65.118:8181/tsfile/live/0012_1.m3u8?key=txiptv&playlive=1&authid=0; ?& k) K+ N) t  J' W; x
CCTV12,http://61.156.228.12:8154/tsfile/live/0012_1.m3u8?key=txiptv&playlive=1&authid=08 O+ p8 |/ c: a0 \
CCTV12,http://119.125.104.133:9901/tsfile/live/1032_1.m3u8?key=txiptv&playlive=1&authid=0% j" m3 t, B5 ^) f4 w6 q) N* g; R
CCTV13,http://202.168.168.50:5000/tsfile/live/1012_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV13,http://61.156.228.12:8154/tsfile/live/0013_1.m3u8?key=txiptv&playlive=1&authid=0; n1 H# E) w$ Z) v! r" i
CCTV13,http://223.75.148.190:9910/tsfile/live/0013_1.m3u8?key=txiptv&playlive=0&authid=0
CCTV13,http://222.169.85.8:9901/tsfile/live/0013_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV13,http://221.13.235.210:9901/tsfile/live/0013_1.m3u8?key=txiptv&playlive=1&authid=09 a! z* A# M, u- i0 o0 n* W
CCTV13,http://110.72.65.118:8181/tsfile/live/0013_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV13,http://182.91.124.60:8801/tsfile/live/1049_1.m3u8?key=txiptv&playlive=0&authid=0
CCTV13,http://218.94.31.154:1111/tsfile/live/0013_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV13,http://110.72.67.190:8181/tsfile/live/0013_1.m3u8?key=txiptv&playlive=1&authid=0: a7 |& [5 m2 D7 [
CCTV14,http://202.168.168.50:5000/tsfile/live/1013_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV14,http://222.169.85.8:9901/tsfile/live/0014_1.m3u8?key=txiptv&playlive=1&authid=02 p8 z, q) u3 V5 A9 o; y; I
CCTV14,http://119.125.104.133:9901/tsfile/live/1034_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV14,http://110.72.65.118:8181/tsfile/live/0014_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV15,http://223.75.148.190:9910/tsfile/live/0015_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV15,http://202.168.168.50:5000/tsfile/live/1014_1.m3u8?key=txiptv&playlive=1&authid=0' F# `% Z0 x3 S% f
CCTV15,http://110.72.67.190:8181/tsfile/live/0015_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV15,http://110.72.65.118:8181/tsfile/live/0015_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV15,http://182.91.124.60:8801/tsfile/live/1051_1.m3u8?key=txiptv&playlive=0&authid=0
CCTV15,http://222.135.142.75:3283/tsfile/live/0015_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV15,http://61.156.228.12:8154/tsfile/live/0015_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV15,http://218.94.31.154:1111/tsfile/live/0015_1.m3u8?key=txiptv&playlive=1&authid=0) @# o+ V* S% e1 E6 e: }$ H( J& l
CCTV16,http://202.168.168.50:5000/tsfile/live/1015_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV16奥利匹克,http://163.142.186.48:9901/tsfile/live/1016_1.m3u8?key=txiptv&playlive=1&authid=0$ L* N3 m/ E) ^+ Q1 X7 y' G/ C
CCTV16奥利匹克,http://163.142.186.57:9901/tsfile/live/1016_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV16奥利匹克,http://163.142.186.49:9901/tsfile/live/1016_1.m3u8?key=txiptv&playlive=1&authid=0' f8 y* u6 ]7 h1 N4 }8 t8 Q
CCTV17,http://61.156.228.12:8154/tsfile/live/0019_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV17,http://202.168.168.50:5000/tsfile/live/1016_1.m3u8?key=txiptv&playlive=1&authid=0+ T6 V- ?' p. E' ]( }
CCTV17,http://110.72.67.190:8181/tsfile/live/0019_1.m3u8?key=txiptv&playlive=1&authid=02 A  g6 r* K6 y2 Y% [; G) i
CCTV17,http://110.72.65.118:8181/tsfile/live/0019_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV17,http://222.169.85.8:9901/tsfile/live/0007_1.m3u8?key=txiptv&playlive=1&authid=0

CCTV1,http://58.19.180.108:9981/stream/channelid/1198995092?profile=pass
CCTV2,http://58.19.180.108:9981/stream/channelid/980211261?profile=pass
CCTV3,http://58.19.180.108:9981/stream/channelid/188040143?profile=pass
CCTV4,http://58.19.180.108:9981/stream/channelid/1411564127?profile=pass
CCTV5,http://58.19.180.108:9981/stream/channelid/908622330?profile=pass
CCTV5+,http://58.19.180.108:9981/stream/channelid/1400754434?profile=pass
CCTV6,http://58.19.180.108:9981/stream/channelid/115694977?profile=pass
CCTV7,http://58.19.180.108:9981/stream/channelid/499001205?profile=pass
CCTV8,http://58.19.180.108:9981/stream/channelid/1123874386?profile=pass
CCTV9,http://58.19.180.108:9981/stream/channelid/1681394297?profile=pass
CCTV10,http://58.19.180.108:9981/stream/channelid/197590532?profile=pass
CCTV11,http://58.19.180.108:9981/stream/channelid/550290687?profile=pass
CCTV12,http://58.19.180.108:9981/stream/channelid/857624678?profile=pass
CCTV13,http://58.19.180.108:9981/stream/channelid/876545399?profile=pass
CCTV14,http://58.19.180.108:9981/stream/channelid/446310281?profile=pass

江苏卫视,http://202.168.168.50:5000/tsfile/live/1023_1.m3u8?key=txiptv&playlive=1&authid=0
江苏卫视,http://110.181.239.144:9901/tsfile/live/1001_1.m3u8?key=txiptv&playlive=1&authid=0( A0 P% X! {  B+ B3 J. M. N  k
江苏卫视,http://110.181.238.142:9901/tsfile/live/1001_1.m3u8?key=txiptv&playlive=1&authid=0$ L7 l5 t6 I* {2 Z" I
江苏卫视,http://223.75.148.190:9910/tsfile/live/0127_1.m3u8?key=txiptv&playlive=1&authid=0
江苏卫视,http://221.13.235.210:9901/tsfile/live/0127_1.m3u8?key=txiptv&playlive=1&authid=0
江苏卫视,http://163.142.186.56:9901/tsfile/live/1022_1.m3u8?key=txiptv&playlive=1&authid=0
江苏卫视,http://163.142.186.57:9901/tsfile/live/1022_1.m3u8?key=txiptv&playlive=1&authid=0& T# F, h% x! f7 K
江苏卫视,http://163.142.186.49:9901/tsfile/live/1022_1.m3u8?key=txiptv&playlive=1&authid=0
江苏卫视,http://110.72.65.118:8181/tsfile/live/0127_1.m3u8?key=txiptv&playlive=1&authid=0
江苏卫视,http://119.125.104.133:9901/tsfile/live/1050_1.m3u8?key=txiptv&playlive=1&authid=0* w6 e  e6 ~& _, s
浙江卫视,http://202.168.168.50:5000/tsfile/live/1022_1.m3u8?key=txiptv&playlive=1&authid=0
浙江卫视,http://110.181.239.150:9901/tsfile/live/1003_1.m3u8?key=txiptv&playlive=1&authid=0# N( d, B$ c$ M
浙江卫视,http://110.181.239.203:9901/tsfile/live/1003_1.m3u8?key=txiptv&playlive=1&authid=04 _- A$ Y9 K& u& u9 F2 `9 O: V
浙江卫视,http://110.181.238.174:9901/tsfile/live/1003_1.m3u8?key=txiptv&playlive=1&authid=0
浙江卫视,http://110.181.239.144:9901/tsfile/live/1003_1.m3u8?key=txiptv&playlive=1&authid=09 ^! b9 U4 x. R! B& M
浙江卫视,http://221.13.235.210:9901/tsfile/live/0124_1.m3u8?key=txiptv&playlive=1&authid=0
浙江卫视,http://110.72.65.118:8181/tsfile/live/0124_2.m3u8?key=txiptv&playlive=1&authid=02 Q% j2 G& _8 z6 J
浙江卫视,http://110.72.67.190:8181/tsfile/live/0124_2.m3u8?key=txiptv&playlive=1&authid=0
浙江卫视,http://223.75.148.190:9910/tsfile/live/0124_2.m3u8?key=txiptv&playlive=0&authid=0) [* u8 m0 s. P! C
浙江卫视,http://119.125.104.133:9901/tsfile/live/1049_1.m3u8?key=txiptv&playlive=1&authid=0* S- x# @1 o9 C7 L" y' Q
北京卫视,http://202.168.168.50:5000/tsfile/live/1020_1.m3u8?key=txiptv&playlive=1&authid=0
北京卫视,http://110.181.239.150:9901/tsfile/live/1002_1.m3u8?key=txiptv&playlive=1&authid=0
北京卫视,http://110.181.238.174:9901/tsfile/live/1002_1.m3u8?key=txiptv&playlive=1&authid=0
北京卫视,http://110.181.239.144:9901/tsfile/live/1002_1.m3u8?key=txiptv&playlive=1&authid=0
北京卫视,http://222.223.84.112:9901/tsfile/live/0122_1.m3u8?key=txiptv&playlive=1&authid=0
北京卫视,http://110.72.67.190:8181/tsfile/live/0122_1.m3u8?key=txiptv&playlive=1&authid=0
北京卫视,http://221.13.235.210:9901/tsfile/live/0122_1.m3u8?key=txiptv&playlive=1&authid=0: C6 E4 i5 h: L# Q# H; z
北京卫视,http://119.125.104.133:9901/tsfile/live/1055_1.m3u8?key=txiptv&playlive=1&authid=0
北京卫视,http://110.72.65.118:8181/tsfile/live/0122_1.m3u8?key=txiptv&playlive=1&authid=0
北京卫视,http://223.75.148.190:9910/tsfile/live/0122_2.m3u8?key=txiptv&playlive=0&authid=0
湖南卫视,http://202.168.168.50:5000/tsfile/live/1021_1.m3u8?key=txiptv&playlive=1&authid=0
湖南卫视,http://110.181.239.150:9901/tsfile/live/1007_1.m3u8?key=txiptv&playlive=1&authid=0% T3 B! H) K2 y* l, p
湖南卫视,http://110.181.239.144:9901/tsfile/live/1007_1.m3u8?key=txiptv&playlive=1&authid=0
湖南卫视,http://223.75.148.190:9910/tsfile/live/0128_2.m3u8?key=txiptv&playlive=0&authid=0
湖南卫视,http://163.142.186.48:9901/tsfile/live/1020_1.m3u8?key=txiptv&playlive=1&authid=0
湖南卫视,http://163.142.186.56:9901/tsfile/live/1020_1.m3u8?key=txiptv&playlive=1&authid=0
湖南卫视,http://163.142.186.57:9901/tsfile/live/1020_1.m3u8?key=txiptv&playlive=1&authid=0
湖南卫视,http://110.72.67.190:8181/tsfile/live/0128_1.m3u8?key=txiptv&playlive=1&authid=0
湖南卫视,http://111.8.242.142:9999/tsfile/live/1009_1.m3u8?key=txiptv&playlive=1&authid=0+ _7 Y, p! j* `6 G1 @/ m& i
湖南卫视,http://119.125.104.133:9901/tsfile/live/1048_1.m3u8?key=txiptv&playlive=1&authid=0
东南卫视,http://202.168.168.50:5000/tsfile/live/1035_1.m3u8?key=txiptv&playlive=1&authid=0. S; e) q+ G$ q+ d" E5 L3 s1 U
东南卫视,http://110.72.67.190:8181/tsfile/live/0137_1.m3u8?key=txiptv&playlive=1&authid=09 |# Z; o! W) n3 H* X
东南卫视,http://110.72.65.118:8181/tsfile/live/0137_1.m3u8?key=txiptv&playlive=1&authid=0$ R7 g/ D& A8 t' H7 D$ c. S
东南卫视,http://182.91.124.60:8801/tsfile/live/1080_1.m3u8?key=txiptv&playlive=0&authid=0
东南卫视,http://218.94.31.154:1111/tsfile/live/0137_1.m3u8?key=txiptv&playlive=1&authid=0
东方卫视,http://202.168.168.50:5000/tsfile/live/1019_1.m3u8?key=txiptv&playlive=1&authid=00
东方卫视,http://110.181.238.174:9901/tsfile/live/1000_1.m3u8?key=txiptv&playlive=1&authid=0$ |& ^& y3 N2 d2 d1 j7 ?! E' |% `
东方卫视,http://110.181.238.142:9901/tsfile/live/1000_1.m3u8?key=txiptv&playlive=1&authid=0: E' F4 Z; \+ ?* k1 w% E0 e* ?
东方卫视,http://110.181.239.150:9901/tsfile/live/1000_1.m3u8?key=txiptv&playlive=1&authid=0+ _# A4 z- |9 E8 C/ T3 k
东方卫视,http://110.181.239.217:9901/tsfile/live/1000_1.m3u8?key=txiptv&playlive=1&authid=04 G4 E4 R' ^8 e7 h: K/ F( V
东方卫视,http://222.223.84.112:9901/tsfile/live/0107_1.m3u8?key=txiptv&playlive=1&authid=0
东方卫视,http://221.13.235.210:9901/tsfile/live/0107_1.m3u8?key=txiptv&playlive=1&authid=01 j9 H; l0 G# C2 u0 w
东方卫视,http://110.72.65.118:8181/tsfile/live/0107_1.m3u8?key=txiptv&playlive=1&authid=0
东方卫视,http://110.72.67.190:8181/tsfile/live/0107_1.m3u8?key=txiptv&playlive=1&authid=0
东方卫视,http://119.125.104.133:9901/tsfile/live/1051_1.m3u8?key=txiptv&playlive=1&authid=0
深圳卫视,http://202.168.168.50:5000/tsfile/live/1018_1.m3u8?key=txiptv&playlive=1&authid=0
深圳卫视,http://223.75.148.190:9910/tsfile/live/0126_1.m3u8?key=txiptv&playlive=0&authid=0
深圳卫视,http://110.72.65.118:8181/tsfile/live/0126_1.m3u8?key=txiptv&playlive=1&authid=0, k( G1 L/ m0 ^1 W3 ]# @
深圳卫视,http://110.72.67.190:8181/tsfile/live/0126_1.m3u8?key=txiptv&playlive=1&authid=0* a' C: N. _. I7 f+ b% l/ {  X4 x
深圳卫视,http://182.91.124.60:8801/tsfile/live/1059_1.m3u8?key=txiptv&playlive=0&authid=0) X1 {% w4 G/ E* \$ ~. G7 ^7 f4 A
深圳卫视,http://116.179.187.230:888/tsfile/live/0126_1.m3u8?key=txiptv&playlive=1&authid=0
深圳卫视,http://222.169.85.8:9901/tsfile/live/0126_1.m3u8?key=txiptv&playlive=1&authid=0
深圳卫视,http://119.125.104.133:9901/tsfile/live/1059_1.m3u8?key=txiptv&playlive=1&authid=0
深圳卫视,http://218.94.31.154:1111/tsfile/live/0126_1.m3u8?key=txiptv&playlive=1&authid=0
湖北卫视,http://202.168.168.50:5000/tsfile/live/1027_1.m3u8?key=txiptv&playlive=1&authid=0
湖北卫视,http://110.181.239.217:9901/tsfile/live/1010_1.m3u8?key=txiptv&playlive=1&authid=01 b7 i8 X: x: O. O
湖北卫视,http://110.181.239.150:9901/tsfile/live/1010_1.m3u8?key=txiptv&playlive=1&authid=0* x, g4 `0 E/ T! }  y- @5 ^
湖北卫视,http://110.181.239.144:9901/tsfile/live/1010_1.m3u8?key=txiptv&playlive=1&authid=07 D) G. _$ q1 m5 A* \: p: B$ b, J
湖北卫视,http://110.181.238.142:9901/tsfile/live/1010_1.m3u8?key=txiptv&playlive=1&authid=0
湖北卫视,http://110.181.239.203:9901/tsfile/live/1010_1.m3u8?key=txiptv&playlive=1&authid=0
湖北卫视,http://110.72.65.118:8181/tsfile/live/0132_1.m3u8?key=txiptv&playlive=1&authid=0
湖北卫视,http://110.72.67.190:8181/tsfile/live/0132_1.m3u8?key=txiptv&playlive=1&authid=0
湖北卫视,http://182.91.124.60:8801/tsfile/live/1061_1.m3u8?key=txiptv&playlive=0&authid=0
湖北卫视,http://119.125.104.133:9901/tsfile/live/1060_1.m3u8?key=txiptv&playlive=1&authid=09 Q3 Y6 U! A+ a" U, R6 r7 f
云南卫视,http://218.94.31.154:1111/tsfile/live/0119_1.m3u8?key=txiptv&playlive=1&authid=0/ W+ A- U! Y6 {/ @9 W& s
云南卫视,http://58.245.255.38:9999/tsfile/live/0119_2.m3u8?key=txiptv&playlive=1&authid=0
吉林卫视,http://202.168.168.50:5000/tsfile/live/1037_1.m3u8?key=txiptv&playlive=1&authid=0
吉林卫视,http://222.223.84.112:9901/tsfile/live/0116_1.m3u8?key=txiptv&playlive=1&authid=07 m8 H9 e/ H" L2 }2 i$ M
吉林卫视,http://223.75.148.190:9910/tsfile/live/0107_1.m3u8?key=txiptv&playlive=1&authid=0$ ~9 e" p# M+ [* n' c( k/ n
吉林卫视,http://116.179.187.230:888/tsfile/live/0116_1.m3u8?key=txiptv&playlive=1&authid=0
吉林卫视,http://61.156.228.12:8154/tsfile/live/0116_1.m3u8?key=txiptv&playlive=1&authid=0
吉林卫视,http://119.125.104.133:9901/tsfile/live/1071_1.m3u8?key=txiptv&playlive=1&authid=0
吉林卫视,http://218.94.31.154:1111/tsfile/live/0116_1.m3u8?key=txiptv&playlive=1&authid=0" _$ M  |, _9 N
四川卫视,http://202.168.168.50:5000/tsfile/live/1031_1.m3u8?key=txiptv&playlive=1&authid=0
四川卫视,http://222.169.85.8:9901/tsfile/live/0123_1.m3u8?key=txiptv&playlive=1&authid=03 M% w/ u  {/ ~1 E3 z: z
四川卫视,http://61.156.228.12:8154/tsfile/live/0123_1.m3u8?key=txiptv&playlive=1&authid=0
四川卫视,http://110.72.67.190:8181/tsfile/live/0123_1.m3u8?key=txiptv&playlive=1&authid=0
四川卫视,http://110.72.65.118:8181/tsfile/live/0123_1.m3u8?key=txiptv&playlive=1&authid=0
四川卫视,http://182.91.124.60:8801/tsfile/live/1025_1.m3u8?key=txiptv&playlive=0&authid=0
四川卫视,http://116.179.187.230:888/tsfile/live/0123_1.m3u8?key=txiptv&playlive=1&authid=0
四川卫视,http://218.94.31.154:1111/tsfile/live/0123_1.m3u8?key=txiptv&playlive=1&authid=0
四川卫视,http://119.125.104.133:9901/tsfile/live/1063_1.m3u8?key=txiptv&playlive=1&authid=0
天津卫视,http://202.168.168.50:5000/tsfile/live/1025_1.m3u8?key=txiptv&playlive=1&authid=0
天津卫视,http://110.181.239.217:9901/tsfile/live/1009_1.m3u8?key=txiptv&playlive=1&authid=0
天津卫视,http://110.181.239.144:9901/tsfile/live/1009_1.m3u8?key=txiptv&playlive=1&authid=0
天津卫视,http://110.181.239.150:9901/tsfile/live/1009_1.m3u8?key=txiptv&playlive=1&authid=0
天津卫视,http://110.181.238.174:9901/tsfile/live/1009_1.m3u8?key=txiptv&playlive=1&authid=0
天津卫视,http://222.223.84.112:9901/tsfile/live/0135_1.m3u8?key=txiptv&playlive=1&authid=0
天津卫视,http://110.72.65.118:8181/tsfile/live/0135_1.m3u8?key=txiptv&playlive=1&authid=0
天津卫视,http://61.156.228.12:8154/tsfile/live/0135_1.m3u8?key=txiptv&playlive=1&authid=0
天津卫视,http://222.169.85.8:9901/tsfile/live/0135_1.m3u8?key=txiptv&playlive=1&authid=0
天津卫视,http://119.125.104.133:9901/tsfile/live/1056_1.m3u8?key=txiptv&playlive=1&authid=0
宁夏卫视,http://116.179.187.230:888/tsfile/live/0112_1.m3u8?key=txiptv&playlive=1&authid=0
安徽卫视,http://202.168.168.50:5000/tsfile/live/1028_1.m3u8?key=txiptv&playlive=1&authid=0
安徽卫视,http://110.181.239.203:9901/tsfile/live/1005_1.m3u8?key=txiptv&playlive=1&authid=0
安徽卫视,http://110.181.239.217:9901/tsfile/live/1005_1.m3u8?key=txiptv&playlive=1&authid=0
安徽卫视,http://110.181.239.2:9901/tsfile/live/1005_1.m3u8?key=txiptv&playlive=1&authid=0
安徽卫视,http://110.181.239.144:9901/tsfile/live/1005_1.m3u8?key=txiptv&playlive=1&authid=0
安徽卫视,http://110.181.238.142:9901/tsfile/live/1005_1.m3u8?key=txiptv&playlive=1&authid=0
安徽卫视,http://110.181.239.150:9901/tsfile/live/1005_1.m3u8?key=txiptv&playlive=1&authid=0
安徽卫视,http://221.13.235.210:9901/tsfile/live/0130_1.m3u8?key=txiptv&playlive=1&authid=0
安徽卫视,http://116.179.187.230:888/tsfile/live/0130_1.m3u8?key=txiptv&playlive=1&authid=0
安徽卫视,http://119.125.104.133:9901/tsfile/live/1065_1.m3u8?key=txiptv&playlive=1&authid=0
山东卫视,http://202.168.168.50:5000/tsfile/live/1026_1.m3u8?key=txiptv&playlive=1&authid=0
山东卫视,http://110.181.238.174:9901/tsfile/live/1006_1.m3u8?key=txiptv&playlive=1&authid=0
山东卫视,http://110.181.239.217:9901/tsfile/live/1006_1.m3u8?key=txiptv&playlive=1&authid=0
山东卫视,http://110.181.239.203:9901/tsfile/live/1006_1.m3u8?key=txiptv&playlive=1&authid=0
山东卫视,http://110.181.239.144:9901/tsfile/live/1006_1.m3u8?key=txiptv&playlive=1&authid=0
山东卫视,http://110.72.67.190:8181/tsfile/live/0131_2.m3u8?key=txiptv&playlive=1&authid=0
山东卫视,http://110.72.65.118:8181/tsfile/live/0131_2.m3u8?key=txiptv&playlive=1&authid=0
山东卫视,http://222.169.85.8:9901/tsfile/live/0131_1.m3u8?key=txiptv&playlive=1&authid=0
山东卫视,http://61.156.228.12:8154/tsfile/live/0131_1.m3u8?key=txiptv&playlive=1&authid=03 w' G' Z. \. _1 {
山东卫视,http://119.125.104.133:9901/tsfile/live/1057_1.m3u8?key=txiptv&playlive=1&authid=0: @+ ~% x$ A/ z( b9 b+ o
广东卫视,http://202.168.168.50:5000/tsfile/live/1017_1.m3u8?key=txiptv&playlive=1&authid=0
广东卫视,http://110.181.239.217:9901/tsfile/live/1008_1.m3u8?key=txiptv&playlive=1&authid=0/ l) d, K, D2 _) _0 Y7 r0 y
广东卫视,http://110.181.239.150:9901/tsfile/live/1008_1.m3u8?key=txiptv&playlive=1&authid=0( t; @, T1 K7 N4 s- q5 I3 W
广东卫视,http://110.181.239.2:9901/tsfile/live/1008_1.m3u8?key=txiptv&playlive=1&authid=0& C' Q8 u7 l; e7 k) r
广东卫视,http://110.181.239.203:9901/tsfile/live/1008_1.m3u8?key=txiptv&playlive=1&authid=0
广东卫视,http://61.156.228.12:8154/tsfile/live/0125_1.m3u8?key=txiptv&playlive=1&authid=0
广东卫视,http://110.72.65.118:8181/tsfile/live/0125_1.m3u8?key=txiptv&playlive=1&authid=09 y% k, m) x' \7 z
广东卫视,http://110.72.67.190:8181/tsfile/live/0125_1.m3u8?key=txiptv&playlive=1&authid=0. \& b# b5 O2 a1 ~6 p
广东卫视,http://182.91.124.60:8801/tsfile/live/1006_1.m3u8?key=txiptv&playlive=0&authid=0
广东卫视,http://119.125.104.133:9901/tsfile/live/1010_1.m3u8?key=txiptv&playlive=1&authid=0
广西卫视,http://202.168.168.50:5000/tsfile/live/1038_1.m3u8?key=txiptv&playlive=1&authid=0
广西卫视,http://222.169.85.8:9901/tsfile/live/0113_1.m3u8?key=txiptv&playlive=1&authid=09 O; S8 ?8 P6 \. |- R
广西卫视,http://182.91.124.60:8801/tsfile/live/1004_1.m3u8?key=txiptv&playlive=0&authid=0: z$ |2 b8 W+ c% ^8 c
广西卫视,http://119.125.104.133:9901/tsfile/live/1074_1.m3u8?key=txiptv&playlive=1&authid=0
广西卫视,http://218.94.31.154:1111/tsfile/live/0113_1.m3u8?key=txiptv&playlive=1&authid=0' ]8 a) p8 N6 s6 \
新疆卫视,http://116.179.187.230:888/tsfile/live/0110_1.m3u8?key=txiptv&playlive=1&authid=0
新疆卫视,http://42.225.117.174:11199/tsfile/live/0110_1.m3u8?key=txiptv&playlive=1&authid=09 H1 S. y* `3 v0 F2 ~; V
旅游卫视,http://110.72.67.190:8181/tsfile/live/0114_1.m3u8?key=txiptv&playlive=1&authid=0
旅游卫视,http://218.94.31.154:1111/tsfile/live/0114_1.m3u8?key=txiptv&playlive=1&authid=0& m* @- r" H; e9 e6 z& W
旅游卫视,http://110.72.65.118:8181/tsfile/live/0114_1.m3u8?key=txiptv&playlive=1&authid=0
江西卫视,http://202.168.168.50:5000/tsfile/live/1034_1.m3u8?key=txiptv&playlive=1&authid=0
江西卫视,http://218.94.31.154:1111/tsfile/live/0138_1.m3u8?key=txiptv&playlive=1&authid=0) ]8 g* ^/ o9 ?0 q
江西卫视,http://182.91.124.60:8801/tsfile/live/1062_1.m3u8?key=txiptv&playlive=0&authid=02 B5 a5 J! K5 }$ n
江西卫视,http://116.179.187.230:888/tsfile/live/0138_1.m3u8?key=txiptv&playlive=1&authid=0; \4 F4 i8 K  R- x8 V
江西卫视,http://222.169.85.8:9901/tsfile/live/0138_1.m3u8?key=txiptv&playlive=1&authid=0
江西卫视,http://119.125.104.133:9901/tsfile/live/1058_1.m3u8?key=txiptv&playlive=1&authid=0
江西卫视,http://118.248.167.154:8088/tsfile/live/0131_1.m3u8?key=txiptv&playlive=1&authid=02 H' }4 \+ ~: O. u+ e7 P
河北卫视,http://202.168.168.50:5000/tsfile/live/1033_1.m3u8?key=txiptv&playlive=1&authid=0
河北卫视,http://222.223.84.112:9901/tsfile/live/0117_1.m3u8?key=txiptv&playlive=1&authid=0
河北卫视,http://110.72.65.118:8181/tsfile/live/0117_1.m3u8?key=txiptv&playlive=1&authid=0
河北卫视,http://61.156.228.12:8154/tsfile/live/0117_1.m3u8?key=txiptv&playlive=1&authid=0
河北卫视,http://116.179.187.230:888/tsfile/live/0117_1.m3u8?key=txiptv&playlive=1&authid=00 b' h( p- T( R, C' Z
河北卫视,http://182.91.124.60:8801/tsfile/live/1066_1.m3u8?key=txiptv&playlive=0&authid=0/ w2 P7 v. Y) J4 g2 H
河北卫视,http://119.125.104.133:9901/tsfile/live/1069_1.m3u8?key=txiptv&playlive=1&authid=0
河北卫视,http://218.94.31.154:1111/tsfile/live/0117_1.m3u8?key=txiptv&playlive=1&authid=0
河南卫视,http://202.168.168.50:5000/tsfile/live/1036_1.m3u8?key=txiptv&playlive=1&authid=0
河南卫视,http://221.13.235.210:9901/tsfile/live/0139_1.m3u8?key=txiptv&playlive=1&authid=0
河南卫视,http://61.156.228.12:8154/tsfile/live/0139_1.m3u8?key=txiptv&playlive=1&authid=0
河南卫视,http://116.179.187.230:888/tsfile/live/0139_1.m3u8?key=txiptv&playlive=1&authid=05 g1 Z, X2 Y' H, I* `6 W
河南卫视,http://218.94.31.154:1111/tsfile/live/0139_1.m3u8?key=txiptv&playlive=1&authid=0
河南卫视,http://222.169.85.8:9901/tsfile/live/0139_1.m3u8?key=txiptv&playlive=1&authid=0
海南卫视,http://163.142.186.48:9901/tsfile/live/1027_1.m3u8?key=txiptv&playlive=1&authid=0  B  \8 }1 i- G
海南卫视,http://163.142.186.56:9901/tsfile/live/1027_1.m3u8?key=txiptv&playlive=1&authid=0$ X3 ?( j" \. C, X7 W- z* g% x) Y
海南卫视,http://163.142.186.57:9901/tsfile/live/1027_1.m3u8?key=txiptv&playlive=1&authid=0/ }* ?" v* f% C4 g' {
海南卫视,http://163.142.186.49:9901/tsfile/live/1027_1.m3u8?key=txiptv&playlive=1&authid=05 e7 Y' b( C! R, k
甘肃卫视,http://202.168.168.50:5000/tsfile/live/1041_1.m3u8?key=txiptv&playlive=1&authid=0
甘肃卫视,http://182.91.124.60:8801/tsfile/live/1016_1.m3u8?key=txiptv&playlive=0&authid=01 B  o# @* T$ n$ A+ t4 W' Z
甘肃卫视,http://116.179.187.230:888/tsfile/live/0141_1.m3u8?key=txiptv&playlive=1&authid=0
三沙卫视,http://202.168.168.50:5000/tsfile/live/1039_1.m3u8?key=txiptv&playlive=1&authid=0# E2 j5 A" p7 }+ M1 q/ g# r* G



CCTV1综合,http://110.177.144.66:9003/hls/1/index.m3u8
CCTV2财经,http://110.177.144.66:9003/hls/2/index.m3u8
CCTV3综艺,http://110.177.144.66:9003/hls/3/index.m3u8
CCTV4中文国际,http://110.177.144.66:9003/hls/4/index.m3u8
CCTV5体育,http://110.177.144.66:9003/hls/5/index.m3u8
CCTV6电影,http://110.177.144.66:9003/hls/7/index.m3u8
CCTV7国防军事,http://110.177.144.66:9003/hls/8/index.m3u8
CCTV8电视剧,http://110.177.144.66:9003/hls/9/index.m3u8
CCTV9纪录,http://110.177.144.66:9003/hls/10/index.m3u8
CCTV10科教,http://110.177.144.66:9003/hls/11/index.m3u8
CCTV11戏曲,http://110.177.144.66:9003/hls/12/index.m3u8
CCTV12社会与法,http://110.177.144.66:9003/hls/13/index.m3u8
CCTV13新闻,http://110.177.144.66:9003/hls/14/index.m3u8
CCTV14少儿,http://110.177.144.66:9003/hls/15/index.m3u8
CCTV15音乐,http://110.177.144.66:9003/hls/16/index.m3u8
CCTV16奥林匹克,http://110.177.144.66:9003/hls/17/index.m3u8
CCTV17农业农村,http://110.177.144.66:9003/hls/18/index.m3u8



CHC家庭影院,http://58.19.180.108:9981/stream/channelid/2141017443?profile=pass
CHC影迷电影,http://58.19.180.108:9981/stream/channelid/473633391?profile=pass
CHC动作电影,http://58.19.180.108:9981/stream/channelid/1782708396?profile=pass

CHC影迷电影,http://182.32.204.243:1015/tsfile/live/1005_1.m3u8?key=txiptv
CHC动作电影,http://182.32.204.243:1015/tsfile/live/1114_1.m3u8?key=txiptv
CHC动作电影,http://223.167.74.193:4022/rtp/239.45.0.41:5140
CHC家庭影院,http://223.167.74.193:4022/rtp/239.45.0.40:5140
CHC影迷电影,http://223.167.74.193:4022/rtp/239.45.0.42:5140
CHC影迷电影,http://36.135.118.195:85/tsfile/live/1020_1.m3u8?key=txiptv&playlive=1&authid=0
CHC动作电影,http://36.135.118.195:85/tsfile/live/1019_1.m3u8?key=txiptv&playlive=1&authid=0
CHC家庭影院,http://36.135.118.195:85/tsfile/live/1021_1.m3u8?key=txiptv&playlive=1&authid=0
CHC影迷电影,http://117.141.162.238:8181/tsfile/live/0006_1.m3u8
CHC动作电影,http://117.141.162.238:8181/tsfile/live/1121_1.m3u8
CHC家庭影院,http://117.141.162.238:8181/tsfile/live/1110_1.m3u8
CHC动作电影,http://111.162.205.19:8686/rtp/225.1.1.215:5002
CHC影迷电影,http://111.162.205.19:8686/rtp/225.1.1.214:5002
CHC家庭影院,http://111.162.205.19:8686/rtp/225.1.1.213:5002
CHC影迷电影,http://58.19.180.108:9981/stream/channelid/473633391?profile=pass
CHC动作电影,http://58.19.180.108:9981/stream/channelid/1782708396?profile=pass
CHC家庭影院,http://58.19.180.108:9981/stream/channelid/2141017443?profile=pass
CHC动作电影,http://58.245.255.38:9999/tsfile/live/1014_1.m3u8?key=txiptv&playlive=1&authid=0
CHC影迷电影,http://58.245.255.38:9999/tsfile/live/1015_1.m3u8?key=txiptv&playlive=1&authid=0
CHC家庭影院,http://58.245.255.38:9999/tsfile/live/1016_1.m3u8?key=txiptv&playlive=1&authid=0
CHC家庭影院,https://migu.188766.xyz/?migutoken=ac8ce3f4e16467ad78a7e0eb5d165bed&id=CHC%E5%AE%B6%E5%BA%AD%E5%BD%B1%E9%99%A2&type=yy
CHC动作电影,https://migu.188766.xyz/?migutoken=15b62d4eb926bfe288d8c474470e61d5&id=CHC%E5%8A%A8%E4%BD%9C%E7%94%B5%E5%BD%B1&type=yy
CHC影迷电影,https://migu.188766.xyz/?migutoken=0bebe24cb9d8d7d34a2edc058f2551bc&id=CHC%E5%BD%B1%E8%BF%B7%E7%94%B5%E5%BD%B1&type=yy
CHC影迷电影,http://m.061899.xyz/mg/ymdy
CHC动作电影,http://m.061899.xyz/mg/dzdy
CHC家庭影院,http://m.061899.xyz/mg/jtyy
CHC影迷电影,http://113.195.172.192:808/hls/110/index.m3u8
CHC动作电影,http://113.195.172.192:808/hls/112/index.m3u8
CHC家庭影院,http://113.195.172.192:808/hls/111/index.m3u8
CHC家庭影院,http://cdn6.bkpcp.top/tl/tuiliu.php?id=jtyy
CHC动作电影,http://cdn6.bkpcp.top/tl/tuiliu.php?id=dzdy
CHC影迷电影,http://cdn6.bkpcp.top/tl/tuiliu.php?id=ymdy
CHC动作电影,http://www.520345.xyz:8188/rtp/239.69.1.242:11094
CHC家庭影院,http://www.520345.xyz:8188/rtp/239.69.1.243:11100

流畅
CCTV1,http://ygbh.site/php/bfgd.php?id=488
CCTV1,http://ygbh.site/php/bfgd.php?id=201
CCTV1,http://ygbh.site/php/bfgd.php?id=484
CCTV1,http://ygbh.site/php/bfgd.php?id=489
CCTV2,http://ygbh.site/php/bfgd.php?id=061
CCTV3,http://ygbh.site/php/bfgd.php?id=062
CCTV4,http://ygbh.site/php/bfgd.php?id=063
CCTV5,http://ygbh.site/php/bfgd.php?id=064
CCTV5+,http://ygbh.site/php/bfgd.php?id=246
CCTV6,http://ygbh.site/php/bfgd.php?id=065
CCTV7,http://ygbh.site/php/bfgd.php?id=127
CCTV8,http://ygbh.site/php/bfgd.php?id=066
CCTV9,http://ygbh.site/php/bfgd.php?id=128
CCTV10,http://ygbh.site/php/bfgd.php?id=129
CCTV11,http://ygbh.site/php/bfgd.php?id=130
CCTV12,http://ygbh.site/php/bfgd.php?id=131
CCTV13,http://ygbh.site/php/bfgd.php?id=067
CCTV14,http://ygbh.site/php/bfgd.php?id=132
CCTV15,http://ygbh.site/php/bfgd.php?id=133
CCTV17,http://ygbh.site/php/bfgd.php?id=204
CETV1,http://ygbh.site/php/bfgd.php?id=135
CETV2,http://ygbh.site/php/bfgd.php?id=492
CGTN,http://ygbh.site/php/bfgd.php?id=134
CGTN,http://ygbh.site/php/bfgd.php?id=305
CGTN阿拉伯语,http://ygbh.site/php/bfgd.php?id=308
CGTN俄语,http://ygbh.site/php/bfgd.php?id=309
CGTN法语,http://ygbh.site/php/bfgd.php?id=307
CGTN西班牙语,http://ygbh.site/php/bfgd.php?id=306

北京卫视,http://ygbh.site/php/bfgd.php?id=083
本溪综合,http://ygbh.site/php/bfgd.php?id=312
兵团卫视,http://ygbh.site/php/bfgd.php?id=124
财富天下,http://ygbh.site/php/bfgd.php?id=231
茶频道,http://ygbh.site/php/bfgd.php?id=181
朝阳新闻综合,http://ygbh.site/php/bfgd.php?id=282
车迷频道,http://ygbh.site/php/bfgd.php?id=146
重庆汽摩,http://ygbh.site/php/bfgd.php?id=168
重庆卫视,http://ygbh.site/php/bfgd.php?id=107
大连新闻综合,http://ygbh.site/php/bfgd.php?id=273
丹东新闻综合,http://ygbh.site/php/bfgd.php?id=276
电视指南,http://ygbh.site/php/bfgd.php?id=164
电子体育,http://ygbh.site/php/bfgd.php?id=143
东方卫视,http://ygbh.site/php/bfgd.php?id=093
东南卫视,http://ygbh.site/php/bfgd.php?id=483
儿童动漫,http://ygbh.site/php/bfgd.php?id=293
发现之旅,http://ygbh.site/php/bfgd.php?id=151
法治天地,http://ygbh.site/php/bfgd.php?id=162
抚顺综合,http://ygbh.site/php/bfgd.php?id=275
阜新综合,http://ygbh.site/php/bfgd.php?id=279
甘肃卫视,http://ygbh.site/php/bfgd.php?id=119
广东卫视,http://ygbh.site/php/bfgd.php?id=092
广西卫视,http://ygbh.site/php/bfgd.php?id=116
贵州卫视,http://ygbh.site/php/bfgd.php?id=101
国学频道,http://ygbh.site/php/bfgd.php?id=169
海南卫视,http://ygbh.site/php/bfgd.php?id=473
河北卫视,http://ygbh.site/php/bfgd.php?id=108
河南卫视,http://ygbh.site/php/bfgd.php?id=339
河南卫视,http://ygbh.site/php/bfgd.php?id=104
黑龙江卫视,http://ygbh.site/php/bfgd.php?id=095
湖北卫视,http://ygbh.site/php/bfgd.php?id=102
湖南卫视,http://ygbh.site/php/bfgd.php?id=086
葫芦岛新闻综合,http://ygbh.site/php/bfgd.php?id=284
环球旅游,http://ygbh.site/php/bfgd.php?id=147
绘画,http://ygbh.site/php/bfgd.php?id=297
吉林卫视,http://ygbh.site/php/bfgd.php?id=097
纪录片,http://ygbh.site/php/bfgd.php?id=295
家庭剧场,http://ygbh.site/php/bfgd.php?id=290
家庭理财,http://ygbh.site/php/bfgd.php?id=139
家庭影院,http://ygbh.site/php/bfgd.php?id=289
家政,http://ygbh.site/php/bfgd.php?id=167
江苏卫视,http://ygbh.site/php/bfgd.php?id=085
江西卫视,http://ygbh.site/php/bfgd.php?id=098
金鹰卡通,http://ygbh.site/php/bfgd.php?id=105
锦州新闻综合,http://ygbh.site/php/bfgd.php?id=277
老故事,http://ygbh.site/php/bfgd.php?id=166
连山区综合,http://ygbh.site/php/bfgd.php?id=491
辽宁北方,http://ygbh.site/php/bfgd.php?id=071
辽宁都市,http://ygbh.site/php/bfgd.php?id=610
辽宁公共,http://ygbh.site/php/bfgd.php?id=077
辽宁公共,http://ygbh.site/php/bfgd.php?id=481
辽宁教育青少,http://ygbh.site/php/bfgd.php?id=075
辽宁经济,http://ygbh.site/php/bfgd.php?id=480
辽宁经济,http://ygbh.site/php/bfgd.php?id=076
辽宁生活,http://ygbh.site/php/bfgd.php?id=073
辽宁体育,http://ygbh.site/php/bfgd.php?id=611
辽宁卫视,http://ygbh.site/php/bfgd.php?id=058
辽宁新动漫,http://ygbh.site/php/bfgd.php?id=140
辽宁影视剧,http://ygbh.site/php/bfgd.php?id=070
辽阳新闻综合,http://ygbh.site/php/bfgd.php?id=280
龙港区综合,http://ygbh.site/php/bfgd.php?id=490
内蒙古卫视,http://ygbh.site/php/bfgd.php?id=110
宁夏卫视,http://ygbh.site/php/bfgd.php?id=118
农林卫视,http://ygbh.site/php/bfgd.php?id=122
盘锦新闻综合,http://ygbh.site/php/bfgd.php?id=283
青海卫视,http://ygbh.site/php/bfgd.php?id=111
求索地理,http://ygbh.site/php/bfgd.php?id=286
求索动物,http://ygbh.site/php/bfgd.php?id=287
求索生活,http://ygbh.site/php/bfgd.php?id=288
山东教育卫视,http://ygbh.site/php/bfgd.php?id=112
山东卫视,http://ygbh.site/php/bfgd.php?id=099
山西卫视,http://ygbh.site/php/bfgd.php?id=109
陕西卫视,http://ygbh.site/php/bfgd.php?id=512
陕西卫视,http://ygbh.site/php/bfgd.php?id=114
社区老年教育课堂,http://ygbh.site/php/bfgd.php?id=615
摄影频道,http://ygbh.site/php/bfgd.php?id=222
深圳卫视,http://ygbh.site/php/bfgd.php?id=100
沈阳新闻综合,http://ygbh.site/php/bfgd.php?id=059
生态环境,http://ygbh.site/php/bfgd.php?id=149
世界地理,http://ygbh.site/php/bfgd.php?id=177
收藏天下,http://ygbh.site/php/bfgd.php?id=155
书画,http://ygbh.site/php/bfgd.php?id=180
四川卫视,http://ygbh.site/php/bfgd.php?id=103
天津卫视,http://ygbh.site/php/bfgd.php?id=084
天元围棋,http://ygbh.site/php/bfgd.php?id=633
天元围棋,http://ygbh.site/php/bfgd.php?id=144
铁岭新闻综合,http://ygbh.site/php/bfgd.php?id=281
外国影院,http://ygbh.site/php/bfgd.php?id=291
网络棋牌,http://ygbh.site/php/bfgd.php?id=141
午夜影院,http://ygbh.site/php/bfgd.php?id=294
西藏卫视,http://ygbh.site/php/bfgd.php?id=121
先锋乒羽,http://ygbh.site/php/bfgd.php?id=349
新疆卫视,http://ygbh.site/php/bfgd.php?id=150
延边卫视,http://ygbh.site/php/bfgd.php?id=117
营口新闻综合,http://ygbh.site/php/bfgd.php?id=278
优优宝贝,http://ygbh.site/php/bfgd.php?id=153
游戏竞技,http://ygbh.site/php/bfgd.php?id=296
游戏竞技,http://ygbh.site/php/bfgd.php?id=142
云南卫视,http://ygbh.site/php/bfgd.php?id=482
云南卫视,http://ygbh.site/php/bfgd.php?id=115
浙江卫视,http://ygbh.site/php/bfgd.php?id=094
中国天气,http://ygbh.site/php/bfgd.php?id=160
中华特产,http://ygbh.site/php/bfgd.php?id=158
重温经典,http://ygbh.site/php/bfgd.php?id=636
综艺,http://ygbh.site/php/bfgd.php?id=292

3D影院,http://ygbh.site/php/bfgd.php?id=298
安徽卫视,http://ygbh.site/php/bfgd.php?id=096
鞍山新闻综合,http://ygbh.site/php/bfgd.php?id=274
百姓健康,http://ygbh.site/php/bfgd.php?id=219
北方导视,http://ygbh.site/php/bfgd.php?id=187
北京纪实科教,http://ygbh.site/php/bfgd.php?id=113
北京卡酷少儿,http://ygbh.site/php/bfgd.php?id=106
浙江卫视,https://ali-m-l.cztv.com/channels/lantian/channel001/1080p.m3u8


CCTV1综合高清,http://39.77.165.202:85/tsfile/live/0002_2.m3u8?key=txiptv&playlive=1&authid=0
CCTV2财经高清,http://39.77.165.202:85/tsfile/live/0002_3.m3u8?key=txiptv&playlive=1&authid=0
CCTV3综艺,http://39.77.165.202:85/tsfile/live/0002_4.m3u8?key=txiptv&playlive=1&authid=0
CCTV4中文国际,http://39.77.165.202:85/tsfile/live/0002_5.m3u8?key=txiptv&playlive=1&authid=0
CCTV5体育,http://39.77.165.202:85/tsfile/live/0002_6.m3u8?key=txiptv&playlive=1&authid=0
CCTV5+体育赛事,http://39.77.165.202:85/tsfile/live/0005_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV6电影,http://39.77.165.202:85/tsfile/live/0002_7.m3u8?key=txiptv&playlive=1&authid=0
CCTV7军事 农业,http://39.77.165.202:85/tsfile/live/0002_8.m3u8?key=txiptv&playlive=1&authid=0
CCTV8电视剧,http://39.77.165.202:85/tsfile/live/0002_9.m3u8?key=txiptv&playlive=1&authid=0
CCTV9记录,http://39.77.165.202:85/tsfile/live/0002_10.m3u8?key=txiptv&playlive=1&authid=0
CCTV10科教,http://39.77.165.202:85/tsfile/live/0002_11.m3u8?key=txiptv&playlive=1&authid=0
CCTV11戏曲,http://39.77.165.202:85/tsfile/live/0002_12.m3u8?key=txiptv&playlive=1&authid=0
CCTV12社会与法,http://39.77.165.202:85/tsfile/live/0002_13.m3u8?key=txiptv&playlive=1&authid=0
CCTV13新闻,http://39.77.165.202:85/tsfile/live/0002_14.m3u8?key=txiptv&playlive=1&authid=0
CCTV14少儿,http://39.77.165.202:85/tsfile/live/0002_15.m3u8?key=txiptv&playlive=1&authid=0
CCTV15音乐,http://39.77.165.202:85/tsfile/live/0002_16.m3u8?key=txiptv&playlive=1&authid=0
QTV-1,http://39.77.165.202:85/tsfile/live/1000_1.m3u8?key=txiptv&playlive=1&authid=0
QTV-6,http://39.77.165.202:85/tsfile/live/0002_1.m3u8?key=txiptv&playlive=1&authid=0
QTV-3,http://39.77.165.202:85/tsfile/live/1002_1.m3u8?key=txiptv&playlive=1&authid=0
QTV-4,http://39.77.165.202:85/tsfile/live/1004_1.m3u8?key=txiptv&playlive=1&authid=0
河南卫视,http://39.77.165.202:85/tsfile/live/0139_1.m3u8?key=txiptv&playlive=1&authid=0
山东卫视,http://39.77.165.202:85/tsfile/live/0002_17.m3u8?key=txiptv&playlive=1&authid=0
湖南卫视高清,http://39.77.165.202:85/tsfile/live/0002_18.m3u8?key=txiptv&playlive=1&authid=0
浙江卫视高清,http://39.77.165.202:85/tsfile/live/0002_19.m3u8?key=txiptv&playlive=1&authid=0
东方卫视高清,http://39.77.165.202:85/tsfile/live/0002_20.m3u8?key=txiptv&playlive=1&authid=0
江苏卫视高清,http://39.77.165.202:85/tsfile/live/0002_21.m3u8?key=txiptv&playlive=1&authid=0
北京卫视高清,http://39.77.165.202:85/tsfile/live/0002_22.m3u8?key=txiptv&playlive=1&authid=0
安徽卫视高清,http://39.77.165.202:85/tsfile/live/0002_23.m3u8?key=txiptv&playlive=1&authid=0
深圳卫视高清,http://39.77.165.202:85/tsfile/live/0002_24.m3u8?key=txiptv&playlive=1&authid=0
湖北卫视高清,http://39.77.165.202:85/tsfile/live/0002_25.m3u8?key=txiptv&playlive=1&authid=0
广东卫视高清,http://39.77.165.202:85/tsfile/live/0002_26.m3u8?key=txiptv&playlive=1&authid=0
辽宁卫视高清,http://39.77.165.202:85/tsfile/live/0002_27.m3u8?key=txiptv&playlive=1&authid=0
黑龙江卫视高清,http://39.77.165.202:85/tsfile/live/0002_28.m3u8?key=txiptv&playlive=1&authid=0
江西卫视,http://39.77.165.202:85/tsfile/live/0002_29.m3u8?key=txiptv&playlive=1&authid=0
重庆卫视,http://39.77.165.202:85/tsfile/live/0002_30.m3u8?key=txiptv&playlive=1&authid=0
东南卫视,http://39.77.165.202:85/tsfile/live/0002_31.m3u8?key=txiptv&playlive=1&authid=0
四川卫视,http://39.77.165.202:85/tsfile/live/0002_32.m3u8?key=txiptv&playlive=1&authid=0
贵州卫视,http://39.77.165.202:85/tsfile/live/0002_33.m3u8?key=txiptv&playlive=1&authid=0
山西卫视,http://39.77.165.202:85/tsfile/live/0002_34.m3u8?key=txiptv&playlive=1&authid=0
陕西卫视,http://39.77.165.202:85/tsfile/live/0002_35.m3u8?key=txiptv&playlive=1&authid=0
旅游卫视,http://39.77.165.202:85/tsfile/live/0002_36.m3u8?key=txiptv&playlive=1&authid=0
吉林卫视,http://39.77.165.202:85/tsfile/live/0002_37.m3u8?key=txiptv&playlive=1&authid=0
甘肃卫视,http://39.77.165.202:85/tsfile/live/0002_38.m3u8?key=txiptv&playlive=1&authid=0
宁夏卫视,http://39.77.165.202:85/tsfile/live/0002_39.m3u8?key=txiptv&playlive=1&authid=0
青海卫视,http://39.77.165.202:85/tsfile/live/0002_40.m3u8?key=txiptv&playlive=1&authid=0
西藏卫视,http://39.77.165.202:85/tsfile/live/0002_41.m3u8?key=txiptv&playlive=1&authid=0
新疆卫视,http://39.77.165.202:85/tsfile/live/0002_42.m3u8?key=txiptv&playlive=1&authid=0
内蒙古卫视,http://39.77.165.202:85/tsfile/live/0002_43.m3u8?key=txiptv&playlive=1&authid=0
兵团卫视,http://39.77.165.202:85/tsfile/live/0002_44.m3u8?key=txiptv&playlive=1&authid=0
农林卫视,http://39.77.165.202:85/tsfile/live/0002_45.m3u8?key=txiptv&playlive=1&authid=0
CETV1中国教育1,http://39.77.165.202:85/tsfile/live/0002_46.m3u8?key=txiptv&playlive=1&authid=0
BTVKAKU少儿卡酷动画,http://39.77.165.202:85/tsfile/live/0002_47.m3u8?key=txiptv&playlive=1&authid=0
炫动卡通,http://39.77.165.202:85/tsfile/live/0002_48.m3u8?key=txiptv&playlive=1&authid=0
山东综艺,http://39.77.165.202:85/tsfile/live/0002_49.m3u8?key=txiptv&playlive=1&authid=0
山东教育,http://39.77.165.202:85/tsfile/live/0002_50.m3u8?key=txiptv&playlive=1&authid=0
CETV2,http://39.77.165.202:85/tsfile/live/0002_51.m3u8?key=txiptv&playlive=1&authid=0
山东居家购物,http://39.77.165.202:85/tsfile/live/0002_52.m3u8?key=txiptv&playlive=1&authid=0
山东新闻,http://39.77.165.202:85/tsfile/live/0002_53.m3u8?key=txiptv&playlive=1&authid=0
山东少儿,http://39.77.165.202:85/tsfile/live/0002_54.m3u8?key=txiptv&playlive=1&authid=0
山东农科,http://39.77.165.202:85/tsfile/live/0002_55.m3u8?key=txiptv&playlive=1&authid=0
山东卫视,http://39.77.165.202:85/tsfile/live/0002_56.m3u8?key=txiptv&playlive=1&authid=0
东南卫视,http://39.77.165.202:85/tsfile/live/0002_57.m3u8?key=txiptv&playlive=1&authid=0
浙江卫视,http://39.77.165.202:85/tsfile/live/0002_58.m3u8?key=txiptv&playlive=1&authid=0
东方卫视,http://39.77.165.202:85/tsfile/live/0002_59.m3u8?key=txiptv&playlive=1&authid=0
三沙卫视,http://39.77.165.202:85/tsfile/live/0002_60.m3u8?key=txiptv&playlive=1&authid=0
BTV北京卫视,http://39.77.165.202:85/tsfile/live/0002_61.m3u8?key=txiptv&playlive=1&authid=0
安徽卫视,http://39.77.165.202:85/tsfile/live/0002_62.m3u8?key=txiptv&playlive=1&authid=0
发现之旅,http://39.77.165.202:85/tsfile/live/0002_63.m3u8?key=txiptv&playlive=1&authid=0
天津卫视,http://39.77.165.202:85/tsfile/live/0002_64.m3u8?key=txiptv&playlive=1&authid=0
湖北卫视,http://39.77.165.202:85/tsfile/live/0002_65.m3u8?key=txiptv&playlive=1&authid=0
中学生,http://39.77.165.202:85/tsfile/live/0002_66.m3u8?key=txiptv&playlive=1&authid=0
辽宁卫视,http://39.77.165.202:85/tsfile/live/0002_67.m3u8?key=txiptv&playlive=1&authid=0
CHC动作电影,http://39.77.165.202:85/tsfile/live/0002_68.m3u8?key=txiptv&playlive=1&authid=0
海看教育,http://39.77.165.202:85/tsfile/live/0002_69.m3u8?key=txiptv&playlive=1&authid=0
海看演艺,http://39.77.165.202:85/tsfile/live/0002_70.m3u8?key=txiptv&playlive=1&authid=0

CCTV-1综合,http://112.6.239.227:8207/hls/1/index.m3u8
CCTV-2财经,http://112.6.239.227:8207/hls/2/index.m3u8
CCTV-3综艺,http://112.6.239.227:8207/hls/3/index.m3u8
CCTV-4中文国际,http://112.6.239.227:8207/hls/4/index.m3u8
CCTV-5体育,http://112.6.239.227:8207/hls/5/index.m3u8
CCTV-5+体育赛事,http://112.6.239.227:8207/hls/6/index.m3u8
CCTV-6电影,http://112.6.239.227:8207/hls/7/index.m3u8
CCTV-7国防军事,http://112.6.239.227:8207/hls/8/index.m3u8
CCTV-8电视剧,http://112.6.239.227:8207/hls/9/index.m3u8
CCTV-9记录,http://112.6.239.227:8207/hls/10/index.m3u8
CCTV-10科教,http://112.6.239.227:8207/hls/11/index.m3u8
CCTV-11戏曲,http://112.6.239.227:8207/hls/12/index.m3u8
CCTV-12社会与法,http://112.6.239.227:8207/hls/13/index.m3u8
CCTV-13新闻,http://112.6.239.227:8207/hls/14/index.m3u8
山东卫视,http://112.6.239.227:8207/hls/15/index.m3u8
浙江卫视,http://112.6.239.227:8207/hls/16/index.m3u8
厦门卫视,http://112.6.239.227:8207/hls/17/index.m3u8
天津卫视,http://112.6.239.227:8207/hls/18/index.m3u8
安徽卫视,http://112.6.239.227:8207/hls/19/index.m3u8
深圳卫视,http://112.6.239.227:8207/hls/20/index.m3u8
深圳卫视,http://112.6.239.227:8207/hls/21/index.m3u8
广东卫视,http://112.6.239.227:8207/hls/22/index.m3u8
东南卫视,http://112.6.239.227:8207/hls/23/index.m3u8
海南卫视,http://112.6.239.227:8207/hls/24/index.m3u8
湖北卫视,http://112.6.239.227:8207/hls/25/index.m3u8
山西卫视,http://112.6.239.227:8207/hls/26/index.m3u8
四川卫视,http://112.6.239.227:8207/hls/27/index.m3u8
河北卫视,http://112.6.239.227:8207/hls/28/index.m3u8
江西卫视.http://112.6.239.227:8207/hls/29/index.m3u8
吉林卫视,http://112.6.239.227:8207/hls/30/index.m3u8
河南卫视,http://112.6.239.227:8207/hls/31/index.m3u8
广西卫视,http://112.6.239.227:8207/hls/32/index.m3u8



█████████████████████████████████████████████
港澳频道,#genre#
█████████████████████████████████████████████

凤凰中文,http://php.jdshipin.com/TVOD/iptv.php?id=fhzw
凤凰资讯,http://php.jdshipin.com/TVOD/iptv.php?id=fhzx
凤凰香港,http://php.jdshipin.com/TVOD/iptv.php?id=fhhk
凤凰中文,http://php.jdshipin.com:8880/smt.php?id=phoenixtv_hd
凤凰资讯,http://php.jdshipin.com:8880/smt.php?id=phoenixinfo_hd
凤凰香港,http://php.jdshipin.com:8880/smt.php?id=hkphoenix_twn
凤凰中文,https://smt.1678520.xyz/smt3.2.1.php?id=phoenixtv_hd
凤凰资讯,https://smt.1678520.xyz/smt3.2.1.php?id=phoenixinfo_hd
凤凰香港,https://smt.1678520.xyz/smt3.2.1.php?id=hkphoenix_twn

美亚电影,http://php.jdshipin.com:8880/smt.php?id=meiyamovie_twn
美亚电影,https://smt.1678520.xyz/smt3.2.1.php?id=meiyamovie_twn
美亚电影,https://cdn9.163189.xyz/smt3.1.1.php?id=meiyamovie_twn
美亚电影,https://cdn9.163189.xyz/smt1.1.php?id=meiyamovie_twn


tvbS新闻,http://rihou.cc:555/tv/[FY]tvbS新闻
tvbS新闻,http://rihou.cc:555/tv/[ST]tvbS新闻
tvbs闽南,http://rihou.cc:555/tv/[Hk]tvbs闽南
tvbs闽南,http://rihou.cc:555/tv/[ST]tvbS闽南
凤凰中文,http://rihou.cc:555/tv/[Pd]凤凰中文
凤凰资讯,http://rihou.cc:555/tv/[Pd]凤凰资讯
凤凰资讯,http://rihou.cc:555/tv/[Bx]凤凰资讯
凤凰香港,http://rihou.cc:555/tv/[Pd]凤凰香港
凤凰香港,http://rihou.cc:555/tv/[Bx]凤凰香港

Plus综合,http://rihou.cc:555/tv/PdlPlus综合
凤凰中文,http://rihou.cc:555/tv/Pdl凤凰中文
凤凰资讯,http://rihou.cc:555/tv/Pdl凤凰资讯
凤凰香港,http://rihou.cc:555/tv/Pdl凤凰香港
有线综合,http://rihou.cc:555/tv/Pdl有线综合
无线新闻,http://rihou.cc:555/tv/Pdl无线新闻
无线翡翠,http://rihou.cc:555/tv/Pdl无线翡翠
无线翡翠4Ktv,http://rihou.cc:555/tv/Pdl无线翡4K
无线明珠,http://rihou.cc:555/tv/Pdl无线明珠
无线星河,http://rihou.cc:555/tv/Pdl无线星河
无线功夫,http://rihou.cc:555/tv/Pdl无线功夫
澳视澳门,http://rihou.cc:555/tv/Pdl澳视澳门
澳视卫星,http://rihou.cc:555/tv/Pdl澳视卫星
澳门体育,http://rihou.cc:555/tv/Pdl澳门体育
澳门综艺,http://rihou.cc:555/tv/Pdl澳门综艺
澳门莲花,http://rihou.cc:555/tv/Pdl澳门莲花
央视综合,http://rihou.cc:555/tv/Pdl央视综合
CHU综合,http://rihou.cc:555/tv/PdlCHU综合
CH5综合,http://rihou.cc:555/tv/PdlCH5综合
CH8综合,http://rihou.cc:555/tv/PdlCH8综合
八度空间,http://rihou.cc:555/tv/Pdl八度空间

星空http://iptv.huuc.edu.cn/player.html?channel=startv
邵氏喜剧,http://38.75.136.137:98/gslb/dsdqpub/lbssxj.m3u8?auth=testpub
邵氏武侠,http://38.75.136.137:98/gslb/dsdqpub/lbsswx.m3u8?auth=testpub
邵氏电影,http://38.75.136.137:98/gslb/dsdqpub/lbssdy.m3u8?auth=testpub


风云


有线新闻,http://kkk.888.3116598.xyz/api.php?n=HKTV&id=DZm4pU&tk=g1eaDlmNASwC
有线新闻,http://feng163.com:8003/bysid/78.m3u8
有线新闻,http://beishan008.asuscomm.com:8891/bysid/78.m3u8
有线新闻,video://http://99754106633f94d350db34d548d6091a.everydaytv.top/play-2-9-0.html
有线新闻,video://http://99754106633f94d350db34d548d6091a.everydaytv.top/play-2-7-0.html
无线新闻,http://erp.giihgtidg.com:8080/live/wxxw01.m3u8
Now新闻,http://iptv.4666888.xyz/iptv2A.php?id=NOW新闻
有线综合,http://php.jdshipin.com/PLTV/iptv.php?id=hoytv2
无线翡翠,http://erp.giihgtidg.com:8080/live/jade01.m3u8
无线翡翠,http://iptv.4666888.xyz/iptv2A.php?id=TVB翡翠
无线明珠,http://iptv.4666888.xyz/iptv2A.php?id=TVB明珠
无线千禧,http://iptv.4666888.xyz/iptv2A.php?id=TVB千禧经典
无线一台,http://iptv.4666888.xyz/iptv2A.php?id=TVB1
无线综台,http://iptv.4666888.xyz/iptv2A.php?id=TVBJ1
VIUTV,http://iptv.4666888.xyz/iptv2A.php?id=VIUTV
tvbs台剧,http://iptv.4666888.xyz/iptv2A.php?id=TVBS台剧
三立都会,http://iptv.4666888.xyz/iptv2A.php?id=综艺玩很大
纬来戏剧,http://iptv.4666888.xyz/iptv2A.php?id=纬来戏剧
星空卫视,http://iptv.4666888.xyz/iptv2A.php?id=星空卫视
重温经典,http://iptv.4666888.xyz/iptv2A.php?id=重温经典
八度空间,http://iptv.4666888.xyz/iptv2A.php?id=八度空间
爱奇艺,http://iptv.4666888.xyz/iptv2A.php?id=爱奇艺

凤凰中文,http://play-ali.cloudvdn.com/live/00987tp3309.flv
凤凰资讯,http://play-ali.cloudvdn.com/live/00987tp0032.flv
凤凰香港,http://play-ali.cloudvdn.com/live/00987tp0033.flv
无线翡翠,http://play-ali.cloudvdn.com/live/00987tp0031.flv



Plus综合频粤,http://php.jdshipin.com:8880/smt.php?id=j2_twn
凤凰中文频国,http://php.jdshipin.com:8880/smt.php?id=phoenixtv_hd
凤凰资讯频国,http://php.jdshipin.com:8880/smt.php?id=phoenixinfo_hd
凤凰香港频国,http://php.jdshipin.com:8880/smt.php?id=hkphoenix_twn
无线新闻频粤,http://php.jdshipin.com:8880/smt.php?id=inews_twn
无线翡翠频粤,http://php.jdshipin.com:8880/smt.php?id=jade_twn
无线华丽频国,http://php.jdshipin.com:8880/smt.php?id=Tvbjade
无线明珠频英,http://php.jdshipin.com:8880/smt.php?id=pearl_twn
无线星河频国,http://php.jdshipin.com:8880/smt.php?id=Xinhe
无线娱乐频粤,http://php.jdshipin.com:8880/smt.php?id=Tvbentertainment
无线千禧频粤,http://php.jdshipin.com:8880/smt.php?id=Tvbclassic
RTHK-31频粤,http://php.jdshipin.com:8880/smt.php?id=rhk31_twn
RTHK-32频粤,http://php.jdshipin.com:8880/smt.php?id=rhk32_twn
VIUTV'频道粤,http://php.jdshipin.com:8880/smt.php?id=viu1_twn
VIUTV'频道英,http://php.jdshipin.com:8880/smt.php?id=viusix_twn
美亚电影频国,http://php.jdshipin.com:8880/smt.php?id=meiyamovie_twn
天映频道频国,http://php.jdshipin.com:8880/smt.php?id=Celestial
天映经典频粤,http://php.jdshipin.com:8880/smt.php?id=Celestial2
Astr'爱奇频国,http://php.jdshipin.com:8880/smt.php?id=Qiyi
AstrQJ国频国,http://php.jdshipin.com:8880/smt.php?id=Quanjia
Astr-AoD频国,http://php.jdshipin.com:8880/smt.php?id=Aodhd
Astr-AeC频国,http://php.jdshipin.com:8880/smt.php?id=AEC
Astr'欢喜频国,http://php.jdshipin.com:8880/smt.php?id=Huahee

Plus综合频粤,https://smt.1678520.xyz/smt3.2.1.php?id=j2_twn
凤凰中文频国,https://smt.1678520.xyz/smt3.2.1.php?id=phoenixtv_hd
凤凰资讯频国,https://smt.1678520.xyz/smt3.2.1.php?id=phoenixinfo_hd
凤凰香港频国,https://smt.1678520.xyz/smt3.2.1.php?id=hkphoenix_twn
无线新闻频粤,https://smt.1678520.xyz/smt3.2.1.php?id=inews_twn
无线翡翠频粤,https://smt.1678520.xyz/smt3.2.1.php?id=jade_twn
无线华丽频国,https://smt.1678520.xyz/smt3.2.1.php?id=Tvbjade
无线明珠频英,https://smt.1678520.xyz/smt3.2.1.php?id=pearl_twn
无线星河频国,https://smt.1678520.xyz/smt3.2.1.php?id=Xinhe
无线娱乐频粤,https://smt.1678520.xyz/smt3.2.1.php?id=Tvbentertainment
无线千禧频粤,https://smt.1678520.xyz/smt3.2.1.php?id=Tvbclassic
RTHK-31频粤,https://smt.1678520.xyz/smt3.2.1.php?id=rhk31_twn
RTHK-32频粤,https://smt.1678520.xyz/smt3.2.1.php?id=rhk32_twn
VIUTV'频道粤,https://smt.1678520.xyz/smt3.2.1.php?id=viu1_twn
VIUTV'频道英,https://smt.1678520.xyz/smt3.2.1.php?id=viusix_twn
美亚电影频国,https://smt.1678520.xyz/smt3.2.1.php?id=meiyamovie_twn
天映频道频国,https://smt.1678520.xyz/smt3.2.1.php?id=Celestial
天映经典频粤,https://smt.1678520.xyz/smt3.2.1.php?id=Celestial2
Astr'爱奇频国,https://smt.1678520.xyz/smt3.2.1.php?id=Qiyi
AstrQJ国频国,https://smt.1678520.xyz/smt3.2.1.php?id=Quanjia
Astr-AoD频国,https://smt.1678520.xyz/smt3.2.1.php?id=Aodhd
Astr-AeC频国,https://smt.1678520.xyz/smt3.2.1.php?id=AEC
Astr'欢喜频国,https://smt.1678520.xyz/smt3.2.1.php?id=Huahee
Plus综合频粤,https://cdn9.163189.xyz/smt3.1.1.php?id=j2_twn
凤凰中文频国,https://cdn9.163189.xyz/smt3.1.1.php?id=phoenixtv_hd
凤凰资讯频国,https://cdn9.163189.xyz/smt3.1.1.php?id=phoenixinfo_hd
凤凰香港频国,https://cdn9.163189.xyz/smt3.1.1.php?id=hkphoenix_twn
无线新闻频粤,https://cdn9.163189.xyz/smt3.1.1.php?id=inews_twn
无线翡翠频粤,https://cdn9.163189.xyz/smt3.1.1.php?id=jade_twn
无线华丽频国,https://cdn9.163189.xyz/smt3.1.1.php?id=Tvbjade
无线明珠频英,https://cdn9.163189.xyz/smt3.1.1.php?id=pearl_twn
无线星河频国,https://cdn9.163189.xyz/smt3.1.1.php?id=Xinhe
无线娱乐频粤,https://cdn9.163189.xyz/smt3.1.1.php?id=Tvbentertainment
无线千禧频粤,https://cdn9.163189.xyz/smt3.1.1.php?id=Tvbclassic
RTHK-31频粤,https://cdn9.163189.xyz/smt3.1.1.php?id=rhk31_twn
RTHK-32频粤,https://cdn9.163189.xyz/smt3.1.1.php?id=rhk32_twn
VIUTV'频道粤,https://cdn9.163189.xyz/smt3.1.1.php?id=viu1_twn
VIUTV'频道英,https://cdn9.163189.xyz/smt3.1.1.php?id=viusix_twn
美亚电影频国,https://cdn9.163189.xyz/smt3.1.1.php?id=meiyamovie_twn
天映频道频国,https://cdn9.163189.xyz/smt3.1.1.php?id=Celestial
天映经典频粤,https://cdn9.163189.xyz/smt3.1.1.php?id=Celestial2
Astr'爱奇频国,https://cdn9.163189.xyz/smt3.1.1.php?id=Qiyi
AstrQJ国频国,https://cdn9.163189.xyz/smt3.1.1.php?id=Quanjia
Astr-AoD频国,https://cdn9.163189.xyz/smt3.1.1.php?id=Aodhd
Astr-AeC频国,https://cdn9.163189.xyz/smt3.1.1.php?id=AEC
Astr'欢喜频国,https://cdn9.163189.xyz/smt3.1.1.php?id=Huahee
Plus综合频粤,https://cdn9.163189.xyz/smt1.1.php?id=j2_twn
凤凰中文频国,https://cdn9.163189.xyz/smt1.1.php?id=phoenixtv_hd
凤凰资讯频国,https://cdn9.163189.xyz/smt1.1.php?id=phoenixinfo_hd
凤凰香港频国,https://cdn9.163189.xyz/smt1.1.php?id=hkphoenix_twn
无线新闻频粤,https://cdn9.163189.xyz/smt1.1.php?id=inews_twn
无线翡翠频粤,https://cdn9.163189.xyz/smt1.1.php?id=jade_twn
无线华丽频国,https://cdn9.163189.xyz/smt1.1.php?id=Tvbjade
无线明珠频英,https://cdn9.163189.xyz/smt1.1.php?id=pearl_twn
无线星河频国,https://cdn9.163189.xyz/smt1.1.php?id=Xinhe
无线娱乐频粤,https://cdn9.163189.xyz/smt1.1.php?id=Tvbentertainment
无线千禧频粤,https://cdn9.163189.xyz/smt1.1.php?id=Tvbclassic
RTHK-31频粤,https://cdn9.163189.xyz/smt1.1.php?id=rhk31_twn
RTHK-32频粤,https://cdn9.163189.xyz/smt1.1.php?id=rhk32_twn
VIUTV'频道粤,https://cdn9.163189.xyz/smt1.1.php?id=viu1_twn
VIUTV'频道英,https://cdn9.163189.xyz/smt1.1.php?id=viusix_twn
美亚电影频国,https://cdn9.163189.xyz/smt1.1.php?id=meiyamovie_twn
天映频道频国,https://cdn9.163189.xyz/smt1.1.php?id=Celestial
天映经典频粤,https://cdn9.163189.xyz/smt1.1.php?id=Celestial2
Astr'爱奇频国,https://cdn9.163189.xyz/smt1.1.php?id=Qiyi
AstrQJ国频国,https://cdn9.163189.xyz/smt1.1.php?id=Quanjia
Astr-AoD频国,https://cdn9.163189.xyz/smt1.1.php?id=Aodhd
Astr-AeC频国,https://cdn9.163189.xyz/smt1.1.php?id=AEC
Astr'欢喜频国,https://cdn9.163189.xyz/smt1.1.php?id=Huahee

特区酒店
凤凰中文,http://php.jdshipin.com/PLTV/iptv.php?id=fhzw
凤凰资讯,http://php.jdshipin.com/PLTV/iptv.php?id=fhzx
凤凰香港,http://php.jdshipin.com/PLTV/iptv.php?id=fhhk
有线综合粤,http://php.jdshipin.com/PLTV/iptv.php?id=hoytv2
有线综合国,http://php.jdshipin.com/PLTV/iptv.php?id=hoytv
无线新闻,http://php.jdshipin.com/PLTV/iptv.php?id=wxxwt
无线翡翠4k,http://php.jdshipin.com/PLTV/iptv.php?id=fct4
无线翡翠,http://php.jdshipin.com/PLTV/iptv.php?id=fct3
无线翡翠,http://php.jdshipin.com/PLTV/iptv.php?id=fct2
无线翡翠,http://php.jdshipin.com/PLTV/iptv.php?id=fct
无线华丽国,http://php.jdshipin.com/PLTV/iptv.php?id=huali
无线明珠粤,http://php.jdshipin.com/PLTV/iptv.php?id=mzt2
无线明珠,http://php.jdshipin.com/PLTV/iptv.php?id=mzt
无线娱乐,http://php.jdshipin.com/PLTV/iptv.php?id=tvbylxw
无线星河,http://php.jdshipin.com/PLTV/iptv.php?id=tvbxh
无线星河,http://php.jdshipin.com/PLTV/iptv.php?id=xinghe
无线功夫,http://php.jdshipin.com/PLTV/iptv.php?id=yzwx
无线千禧,http://php.jdshipin.com/PLTV/iptv.php?id=tvbc
美亚电影,http://php.jdshipin.com/PLTV/iptv.php?id=meiya
VIUTV粤,http://php.jdshipin.com/PLTV/iptv.php?id=viutv2
RTHK-31,http://php.jdshipin.com/PLTV/iptv.php?id=rthk31
RTHK-32,http://php.jdshipin.com/PLTV/iptv.php?id=rthk32
Astroaod,http://php.jdshipin.com/PLTV/iptv.php?id=aod
澳门Mac,http://php.jdshipin.com/PLTV/iptv.php?id=as
澳视澳门,http://php.jdshipin.com/PLTV/iptv.php?id=asam
重温经典,http://php.jdshipin.com/PLTV/iptv.php?id=cwjd

凤凰中文,http://r.jdshipin.com/cCCzW
凤凰资讯,http://r.jdshipin.com/0Rp07
凤凰香港,http://r.jdshipin.com/yDoTN
无线新闻, http://erp.giihgtidg.com:8080/live/wxxw01.m3u8
无线新闻,http://r.jdshipin.com/CkuBd
娱乐新闻,http://php.jdshipin.com/TVOD/iptv.php?id=tvbylxw
TVB Plus,http://r.jdshipin.com/ndGgS
TVB星河,http://php.jdshipin.com/TVOD/iptv.php?id=xinghe
TVB星河,http://r.jdshipin.com/Voac4
翡翠台,http://erp.giihgtidg.com:8080/live/jade01.m3u8
翡翠台,https://cdn6.163189.xyz/163189/fct4k
翡翠台,https://mytv.cdn.loc.cc/o12.php?id=fct
翡翠台,http://r.jdshipin.com/62WM7
明珠台,https://mytv.cdn.loc.cc/o12.php?id=mzt
明珠台,http://r.jdshipin.com/ZQ4kN
凤凰电影,http://iot-mqqt.111yao.cn:8080/live/diyp_fhdy.m3u8
Astro AOD,http://php.jdshipin.com/TVOD/iptv.php?id=aod
Astro AEC,http://php.jdshipin.com/smt.php?id=AEC
Astro QJ,http://php.jdshipin.com/smt.php?id=Quanjia
Astro 欢喜台,http://php.jdshipin.com/smt.php?id=Huahee
星空卫视,http://iot-mqqt.111yao.cn:8080/live/diyp_xingkong.m3u8
亚洲卫视,https://p2hs.vzan.com/slowlive/821481626725612419/live.m3u8
亚洲武侠,http://php.jdshipin.com/TVOD/iptv.php?id=yzwx

番薯111,http://61.216.67.119:1935/TWHG/E1/chunklist_w7058102.m3u8
番薯111,http://61.216.67.119:1935/TWHG/E1/chunklist_w7058102.m3u8?blog.ntnas.top
番薯111,http://61.216.67.119:1935/TWHG/E1/chunklist_w705811302.m3u8

美亚电影台,http://php.jdshipin.com/TVOD/iptv.php?id=meiya
美亚电影台,http://php.jdshipin.com:8880/smt.php?id=meiyamovie_twn
澳门莲花,http://live-hls.macaulotustv.com/lotustv/macaulotustv.m3u8
澳门莲花,http://1033946631.cloudvdn.com/a.m3u8?domain=live-hdl.macaulotustv.com&player=1&streamid=lotustv:lotustv/macaulotustv&v3=1
澳视澳门,http://r.jdshipin.com/n2YZI
澳视澳门,https://get.2sb.org/https://globallive.tdm.com.mo/ch1/ch1.live/playlist.m3u8
澳视葡文,https://get.2sb.org/https://globallive.tdm.com.mo/ch2/ch2.live/chunklist_w1226640182.m3u8
澳门资讯,https://get.2sb.org/https://globallive.tdm.com.mo/ch5/info_ch5.live/playlist.m3u8
澳门体育,https://get.2sb.org/https://globallive.tdm.com.mo/ch4/sport_ch4.live/playlist.m3u8
澳门综艺,https://get.2sb.org/https://globallive.tdm.com.mo/ch6/hd_ch6.live/playlist.m3u8
澳门Macau,https://get.2sb.org/https://globallive.tdm.com.mo/ch3/ch3.live/chunklist_w2074018415.m3u8
澳门综合,https://get.2sb.org/https://globallive.tdm.com.mo/cgtn/cgtn71/chunklist_w1346605470.m3u8
C+,http://ottproxy2.ist.ooo/livehls/MOB-U1-NO/01.m3u8
天映频道,http://php.jdshipin.com/smt.php?id=Celestial
天映经典,http://php.jdshipin.com/smt.php?id=Celestial2
CH5,http://cdn6.163189.xyz/163189/ch5
CH8,http://cdn6.163189.xyz/163189/ch8
CHU,http://cdn6.163189.xyz/163189/chu
MoMoTV,rtmp://f13h.mine.nu/sat/tv761
重温经典,http://8.138.7.223/tv/cwjd.php
八度空间,http://cdn6.163189.xyz/163189/8tv
唯心电视,http://mobile.ccdntech.com/transcoder/_definst_/vod164_Live/live/playlist.m3u8
中旺电视,http://38.64.72.148:80/hls/modn/list/4010/chunklist1.m3u8
生命电影,http://61.216.67.119:1935/lifetv/lifetv.stream/manifest.m3u8
环球电视台,http://utv1.hqtvzb.com:9999/hls/world.m3u8
香港环球卫视,https://play.xghqws.cn/yunqing888/yunqing888.m3u8?auth_key=1731294000-0-0-0942b140da60167a47c1f2d685f702b2&rts_degrade=on



凤凰中文,http://php.jdshipin.com/TVOD/iptv.php?id=fhzw
凤凰资讯,http://php.jdshipin.com/TVOD/iptv.php?id=fhzx
凤凰中文,http://php.jdshipin.com/TVOD/iptv.php?id=fhzw
凤凰中文,http://php.jdshipin.com:8880/smt.php?id=phoenixtv_hd
凤凰资讯,http://php.jdshipin.com:8880/smt.php?id=phoenixinfo_hd
凤凰香港,http://php.jdshipin.com:8880/smt.php?id=hkphoenix_twn
凤凰中文,http://t.061899.xyz/tl/js/js.php?id=fhwszwt
凤凰资讯,http://t.061899.xyz/tl/js/js.php?id=fhwszxt
凤凰香港,http://t.061899.xyz/tl/js/js.php?id=fhwsxgt

凤凰中文,http://zqh2333.top:2222/rtp/239.93.24.9:2192
凤凰中文,http://203.205.191.53/qctv.fengshows.cn/live/0701pcc72.flv
凤凰资讯,http://zqh2333.top:2222/rtp/239.93.24.4:2191
凤凰资讯,http://203.205.191.53/qctv.fengshows.cn/live/0701pin72.flv
凤凰香港,http://php.jdshipin.com:8880/smt.php?id=hkphoenix_twn
凤凰资讯,http://203.205.191.53/qctv.fengshows.cn/live/0701pin72.flv
凤凰中文,http://203.205.191.53/qctv.fengshows.cn/live/0701pcc72.m3u8
凤凰中文,http://php.jdshipin.com/TVOD/iptv.php?id=fhzw2

无线新闻,http://t.061899.xyz/tl/js/js.php?id=tvbwxxwt
无线新闻,http://t.061899.xyz/tl/168.php?id=wxxwt
无线翡翠,http://t.061899.xyz/tl/js/js.php?id=tvbfct
无线翡翠,http://t.061899.xyz/tl/168.php?id=fct

无线翡翠,http://php.jdshipin.com:8880/TVOD/iptv.php?id=fct
无线华丽,http://php.jdshipin.com:8880/TVOD/iptv.php?id=huali


翡翠台,http://erp.giihgtidg.com:8080/live/jade01.m3u8
翡翠台,https://cdn.163189.xyz/live/fct4k/stream.m3u8
翡翠台,http://cdn9.163189.xyz/smt1.1.php?id=jade_twn
翡翠台,https://smt.1789.dpdns.org/smt3.2.1.php?id=Tvbjade
台湾台,https://bcovlive-a.akamaihd.net/rce33d845cb9e42dfa302c7ac345f7858/ap-northeast-1/6282251407001/playlist.m3u8
环球电视,http://utv1.hqtvzb.com:9999/hls/world.m3u8
亚洲卫视,https://p2hs.vzan.com/slowlive/821481626725612419/live.m3u8
香港卫视,http://zhibo.hkstv.tv/livestream/mutfysrq.flv
星空卫视,http://iot-mqqt.111yao.cn:8080/live/diyp_xingkong.m3u8

凤凰电影,http://iot-mqqt.111yao.cn:8080/live/diyp_fhdy.m3u8
无线新闻,http://erp.giihgtidg.com:8080/live/wxxw01.m3u8?hls_ctx=5l3k567n
翡翠台,http://erp.giihgtidg.com:8080/live/jade01.m3u8?hls_ctx=a08bsf11
香港31台,http://php.jdshipin.com/TVOD/iptv.php?id=rthk31
香港32台,http://php.jdshipin.com/TVOD/iptv.php?id=rthk32
香港33台,http://php.jdshipin.com/TVOD/iptv.php?id=rthk33
HOY77,http://php.jdshipin.com/TVOD/iptv.php?id=hoytv2
无线新闻,http://hdtvtw.com/hstvs.php?pid=3
无线新闻,http://erp.giihgtidg.com:8080/live/wxxw01.m3u8

华丽翡翠,http://php.jdshipin.com/TVOD/iptv.php?id=huali
TVB星河,http://cdn9.163189.xyz/smt1.1.php?id=Xinhe

无线功夫,http://php.jdshipin.com/PLTV/iptv.php?id=yzwx
千禧经典,http://cdn9.163189.xyz/smt1.1.php?id=Tvbclassic
千禧经典,http://php.jdshipin.com:8880/smt.php?id=Tvbclassic
无线华丽,http://php.jdshipin.com/TVOD/iptv.php?id=huali
无线华丽,http://php.jdshipin.com/smt.php?id=Tvbjade
娱乐新闻,http://php.jdshipin.com/smt.php?id=Tvbentertainment
澳視澳門,https://149.102.97.122/ch1/ch1.live/playlist.m3u8
澳視葡文,https://149.102.97.122/ch2/ch2.live/playlist.m3u8
澳門資訊,https://149.102.97.122/ch5/info_ch5.live/playlist.m3u8
澳門綜藝,https://149.102.97.122/ch6/hd_ch6.live/playlist.m3u8
澳門體育,https://149.102.97.122/ch4/sport_ch4.live/playlist.m3u8
澳视澳门,https://cdn.163189.xyz/live/asam/stream.m3u8
澳门卫星,https://cdn.163189.xyz/live/as/stream.m3u8
澳門莲花,http://1033946631.cloudvdn.com/a.m3u8?domain=live-hdl.macaulotustv.com&player=1&streamid=lotustv:lotustv/macaulotustv&v3=1
澳門莲花,http://2028496195.cloudvdn.com/a.m3u8?domain=live-hls.macaulotustv.com&player=UuYAANXkTFhf1EYY&secondToken=secondToken%3AaeH9bajglaAWNijdz3YrvgSYrwU&streamid=lotustv%3Alotustv%2Fmacaulotustv&v3=1
澳門莲花,http://live-hls.macaulotustv.com/lotustv/macaulotustv.m3u8

重温经典,http://php.jdshipin.com/TVOD/iptv.php?id=cwjd
淘电影,http://ydl.yueyaoxian.top:8686/rtp/239.3.1.250:8001

人间卫视,http://61.216.67.119:1935/bltvhd/bltv1/chunklist_w1266569526.m3u8
小公视台,https://stream1.freetv.fun/f415852174b30f1fc43d85ce4bf9347586de6f2d688ba1fe1a4095a9db20dcdd.m3u8

人间卫视,https://5ddce30eb4b55.streamlock.net:443/bltvhd/bltv1/chunklist.m3u8
番薯111,http://61.216.67.119:1935/TWHG/E1/chunklist_w7058102.m3u8

HOY77,http://php.jdshipin.com/PLTV/iptv.php?id=hoytv2
HOY76,http://bziyunshao.synology.me:8891/bysid/76
HOY77,http://php.jdshipin.com/TVOD/iptv.php?id=hoytv2
HOY77,http://php.jdshipin.com/PLTV/iptv.php?id=hoytv2
HOY77,http://beishan008.asuscomm.com:8891/bysid/77.m3u8
HOY77,http://bziyunshao.synology.me:8891/bysid/77
HOY78,http://bziyunshao.synology.me:8891/bysid/78
HOY78,https://gdfire2.67890123.cn:8088/live/hoy7801.m3u8
HOY76,http://bziyunshao.synology.me:8891/bysid/76
HOY78,http://bziyunshao.synology.me:8891/bysid/78
HOY77,http://bziyunshao.synology.me:8891/bysid/77


特区粤央
Plus综合,http://vallest.uk/livehttpplay?channel_id=30023
Plus综合,http://vallest.uk/livehttpplay?channel_id=20122
凤凰中文,http://vallest.uk/livehttpplay?channel_id=30014
凤凰中文,http://vallest.uk/livehttpplay?channel_id=20065
凤凰资讯,http://vallest.uk/livehttpplay?channel_id=30015
凤凰资讯,http://vallest.uk/livehttpplay?channel_id=20066
凤凰香港,http://vallest.uk/livehttpplay?channel_id=20067
凤凰香港,http://vallest.uk/livehttpplay?channel_id=30016
有线综合,http://vallest.uk/livehttpplay?channel_id=20152
无线新闻,http://vallest.uk/livehttpplay?channel_id=30024
无线翡翠,http://vallest.uk/livehttpplay?channel_id=20124
无线明珠,http://vallest.uk/livehttpplay?channel_id=30026
无线明珠,http://vallest.uk/livehttpplay?channel_id=20125
VIUTV粤,http://vallest.uk/livehttpplay?channel_id=30032
VIUTV粤,http://vallest.uk/livehttpplay?channel_id=20131
VIUTV英,http://vallest.uk/livehttpplay?channel_id=30033
VIUTV英,http://vallest.uk/livehttpplay?channel_id=20132
RTHK-31,http://vallest.uk/livehttpplay?channel_id=30066
RTHK-32,http://vallest.uk/livehttpplay?channel_id=30067
RTHK-32,http://vallest.uk/livehttpplay?channel_id=20203
RTHK-32,http://vallest.uk/livehttpplay?channel_id=30028
广东珠江,http://vallest.uk/livehttpplay?channel_id=20144
广东体育,http://vallest.uk/livehttpplay?channel_id=12028
广东体育,http://vallest.uk/livehttpplay?channel_id=20130
广东体育,http://vallest.uk/livehttpplay?channel_id=30031
广东戏曲,http://vallest.uk/livehttpplay?channel_id=20142
CCTV-05,http://vallest.uk/livehttpplay?channel_id=10107
CCTV-05,http://vallest.uk/livehttpplay?channel_id=20005
CCTV-05,http://vallest.uk/livehttpplay?channel_id=30003
CCTV-5+,http://vallest.uk/livehttpplay?channel_id=20006
CCTV-5+,http://vallest.uk/livehttpplay?channel_id=30004
CCTV-07,http://vallest.uk/livehttpplay?channel_id=20008
CCTV-15,http://vallest.uk/livehttpplay?channel_id=20016
CCTV-16,http://vallest.uk/livehttpplay?channel_id=20039
CCTV-4k,http://vallest.uk/livehttpplay?channel_id=30029
江苏卫视,http://vallest.uk/livehttpplay?channel_id=20326
深圳卫视,http://vallest.uk/livehttpplay?channel_id=20025
广东卫视,http://vallest.uk/livehttpplay?channel_id=20024
天津卫视,http://vallest.uk/livehttpplay?channel_id=20042
辽宁卫视,http://vallest.uk/livehttpplay?channel_id=20320
四川卫视,http://vallest.uk/livehttpplay?channel_id=20038
重庆卫视,http://vallest.uk/livehttpplay?channel_id=20040
湖北卫视,http://vallest.uk/livehttpplay?channel_id=20022
广西卫视,http://vallest.uk/livehttpplay?channel_id=20323
黑龙江视,http://vallest.uk/livehttpplay?channel_id=20321

特区酒店
Plus综合,http://php.jdshipin.com/PLTV/iptv.php?id=tvbp
Plus综合,http://php.jdshipin.com/PLTV/iptv.php?id=j2
TVBJ1美,http://php.jdshipin.com/PLTV/iptv.php?id=j1
TVBJ1标,http://php.jdshipin.com/PLTV/iptv.php?id=tvbj1
凤凰中文,http://php.jdshipin.com/PLTV/iptv.php?id=fhzw
凤凰资讯,http://php.jdshipin.com/PLTV/iptv.php?id=fhzx
凤凰香港,http://php.jdshipin.com/PLTV/iptv.php?id=fhhk
有线综合粤,http://php.jdshipin.com/PLTV/iptv.php?id=hoytv2
有线综合,http://php.jdshipin.com/PLTV/iptv.php?id=hoytv
无线新闻,http://php.jdshipin.com/PLTV/iptv.php?id=wxxwt
无线翡翠4k,http://php.jdshipin.com/PLTV/iptv.php?id=fct4
无线翡翠,http://php.jdshipin.com/PLTV/iptv.php?id=fct3
无线翡翠,http://php.jdshipin.com/PLTV/iptv.php?id=fct2
无线翡翠,http://php.jdshipin.com/PLTV/iptv.php?id=fct
无线华丽,http://php.jdshipin.com/PLTV/iptv.php?id=huali
无线明珠,http://php.jdshipin.com/PLTV/iptv.php?id=mzt2
无线明珠,http://php.jdshipin.com/PLTV/iptv.php?id=mzt
无线娱乐,http://php.jdshipin.com/PLTV/iptv.php?id=tvbylxw
无线星河,http://php.jdshipin.com/PLTV/iptv.php?id=tvbxh
无线星河,http://php.jdshipin.com/PLTV/iptv.php?id=xinghe
无线功夫,http://php.jdshipin.com/PLTV/iptv.php?id=yzwx
无线千禧,http://php.jdshipin.com/PLTV/iptv.php?id=tvbc
美亚电影,http://php.jdshipin.com/PLTV/iptv.php?id=meiya
VIUTV粤,http://php.jdshipin.com/PLTV/iptv.php?id=viutv2
RTHK-31,http://php.jdshipin.com/PLTV/iptv.php?id=rthk31
RTHK-32,http://php.jdshipin.com/PLTV/iptv.php?id=rthk32
Astroaod,http://php.jdshipin.com/PLTV/iptv.php?id=aod
澳门Mac,http://php.jdshipin.com/PLTV/iptv.php?id=as
澳视澳门,http://php.jdshipin.com/PLTV/iptv.php?id=asam
重温经典,http://php.jdshipin.com/PLTV/iptv.php?id=cwjd




特区地波
Plus综合,http://beishan008.asuscomm.com:8890/bysid/82.m3u8
有线新闻,http://feng163.com:8003/bysid/78.m3u8
有线新闻,http://beishan008.asuscomm.com:8891/bysid/78.m3u8
无线新闻,http://beishan008.asuscomm.com:8890/bysid/83.m3u8
无线翡翠,http://beishan008.asuscomm.com:8889/bysid/1.m3u8
无线明珠,http://beishan008.asuscomm.com:8890/bysid/2.m3u8
有线赛讯,http://beishan008.asuscomm.com:8891/bysid/76.m3u8
有线综讯,http://beishan008.asuscomm.com:8891/bysid/77.m3u8
ViuTv_粤,http://beishan008.asuscomm.com:8889/bysid/99.m3u8
ViuTv_英,http://beishan008.asuscomm.com:8889/bysid/96.m3u8
RTHK-31,http://beishan008.asuscomm.com:8892/bysid/31.m3u8
RTHK-32,http://beishan008.asuscomm.com:8892/bysid/32.m3u8
RTHK-33,http://beishan008.asuscomm.com:8892/bysid/33.m3u8
RTHK-34,http://beishan008.asuscomm.com:8892/bysid/34.m3u8


待测频道,#genre#


港澳代理,#genre#

珠江卫视,http://iptv.4666888.xyz/iptv2A.php?id=19
明珠台,http://iptv.4666888.xyz/iptv2A.php?id=29
美亚电影,http://iptv.4666888.xyz/iptv2A.php?id=30
有线新闻,http://iptv.4666888.xyz/iptv2A.php?id=31
翡翠台,http://iptv.4666888.xyz/iptv2A.php?id=34
龙华电影,http://iptv.4666888.xyz/iptv2A.php?id=45


凤凰中文,http://cdn6.163189.xyz/163189/fhzw
凤凰资讯,http://cdn6.163189.xyz/163189/fhzx
凤凰香港,http://cdn6.163189.xyz/163189/fhhk


澳亚卫视,http://cdn9.163189.xyz/live/as/stream.m3u8
莲花卫视,http://live-hls.macaulotustv.com/lotustv/macaulotustv.m3u8
无线新闻,http://cdn9.163189.xyz/smt1.1.php?id=inews_twn

翡翠台,http://cdn9.163189.xyz/smt1.1.php?id=jade_twn

华丽翡翠,http://cdn9.163189.xyz/smt1.1.php?id=Tvbjade
明珠台,http://cdn9.163189.xyz/smt1.1.php?id=pearl_twn
TVBJ1,http://cdn3.163189.xyz/live/j1/stream.m3u8

千禧经典,http://cdn9.163189.xyz/smt3.1.1.php?id=Tvbclassic

龙华电影,https://cdn8.163189.xyz/live/lhdy/stream.m3u8
龙华洋片,https://cdn8.163189.xyz/live/lhyp/stream.m3u8
龙华经典,https://cdn8.163189.xyz/live/lhjd/stream.m3u8
龙华卡通,https://cdn8.163189.xyz/live/lhkt/stream.m3u8
龙华偶像,https://cdn8.163189.xyz/live/lhox/stream.m3u8
龙华日韩,https://cdn8.163189.xyz/live/lhrh/stream.m3u8
龙华戏剧,https://cdn8.163189.xyz/live/lhxj/stream.m3u8
靖天电影,http://live4play.uk/livehttpplay?channel_id=12037
港台电视31,https://cdn5.163189.xyz/live/rthk31/stream.m3u8
港台电视32,https://cdn5.163189.xyz/live/rthk32/stream.m3u8
HOY78,http://cdn.163189.xyz/live/hoy/stream.m3u8
ASTRO AOD,http://cdn9.163189.xyz/smt1.1.php?id=Aodhd

翡翠台,http://cdn6.163189.xyz/163189/fct4k

八度空间,https://cdn6.163189.xyz/163189/8tv
CH5,https://cdn6.163189.xyz/163189/ch5
CH8,https://cdn6.163189.xyz/163189/ch8
CHU,https://cdn6.163189.xyz/163189/chu

NOW NEWS,http://cdn.163189.xyz/163189/now
澳视卫星,https://cdn6.163189.xyz/163189/as
澳视澳门,https://cdn6.163189.xyz/163189/asam
澳门体育,http://cdn6.163189.xyz/163189/amty
澳门综艺,http://cdn6.163189.xyz/163189/amzy



█████████████████████████████████████████████
湾湾频道,#genre#
█████████████████████████████████████████████

中天新闻,https://live.catvod.com/live.php?id=ctinews
中天新闻,http://rihou.cc:555/tv/[SZ]中天新闻
中天新闻,http://rihou.cc:555/tv/[Bx]中天新闻

SMT-台湾
台视 HD,https://smart.946985.filegear-sg.me/smart.php?id=ttv_taiwan&token=tvbjack
台视新闻,https://smart.946985.filegear-sg.me/smart.php?id=ttvnews_twn&token=tvbjack
台视综合,https://smart.946985.filegear-sg.me/smart.php?id=ttvzhonghe&token=tvbjack
中视 HD,https://smart.946985.filegear-sg.me/smart.php?id=zhongshihd_twn&token=tvbjack
中视新闻,https://smart.946985.filegear-sg.me/smart.php?id=zhongshinews_twn&token=tvbjack
中视经典,https://smart.946985.filegear-sg.me/smart.php?id=zhongshi_twn&token=tvbjack
华视 HD,https://smart.946985.filegear-sg.me/smart.php?id=ctshd_twn&token=tvbjack
公视 HD,https://smart.946985.filegear-sg.me/smart.php?id=ctv_taiwan&token=tvbjack
公视台语台,https://smart.946985.filegear-sg.me/smart.php?id=ctv2_twn&token=tvbjack
三立台湾台,https://smart.946985.filegear-sg.me/smart.php?id=sanlitaiwan&token=tvbjack
三立都会台,https://smart.946985.filegear-sg.me/smart.php?id=sanlidouhui&token=tvbjack
三立综合台,https://smart.946985.filegear-sg.me/smart.php?id=sanlizhonghe&token=tvbjack
三立戏剧台,https://smart.946985.filegear-sg.me/smart.php?id=sanlixiju_twn&token=tvbjack
东森新闻台,https://smart.946985.filegear-sg.me/smart.php?id=ettvnews&token=tvbjack
东森财经新闻台,https://smart.946985.filegear-sg.me/smart.php?id=ettvcaijing_twn&token=tvbjack
东森综合台,https://smart.946985.filegear-sg.me/smart.php?id=ettvzhonghe&token=tvbjack
东森戏剧台,https://smart.946985.filegear-sg.me/smart.php?id=ettvdrama&token=tvbjack
东森电影台,https://smart.946985.filegear-sg.me/smart.php?id=ettvmovie&token=tvbjack
东森洋片台,https://smart.946985.filegear-sg.me/smart.php?id=ettvwestern&token=tvbjack
东森幼幼台,https://smart.946985.filegear-sg.me/smart.php?id=yoyo_twn&token=tvbjack
东森超视,https://smart.946985.filegear-sg.me/smart.php?id=ettvsuper&token=tvbjack
TVBS HD,https://smart.946985.filegear-sg.me/smart.php?id=tvbs&token=tvbjack
TVBS 新闻台,https://smart.946985.filegear-sg.me/smart.php?id=tvbs_n&token=tvbjack
TVBS 欢乐台,https://smart.946985.filegear-sg.me/smart.php?id=tvbshuanle_twn&token=tvbjack
民视 HD,https://smart.946985.filegear-sg.me/smart.php?id=ftvhd_taiwan&token=tvbjack
民视新闻台,https://smart.946985.filegear-sg.me/smart.php?id=ftvnew_taiwan&token=tvbjack
民视台湾台,https://smart.946985.filegear-sg.me/smart.php?id=ftvtaiwan_twn&token=tvbjack
中天综合,https://smart.946985.filegear-sg.me/smart.php?id=ctizhonghe&token=tvbjack
中天娱乐,https://smart.946985.filegear-sg.me/smart.php?id=ctient&token=tvbjack
中天亚洲,https://smart.946985.filegear-sg.me/smart.php?id=ctiasia_twn&token=tvbjack
中天新闻,https://smart.946985.filegear-sg.me/smart.php?id=ctinews&token=tvbjack
寰宇新闻台,https://smart.946985.filegear-sg.me/smart.php?id=huanyuxinwen_twn&token=tvbjack
寰宇财经台,https://smart.946985.filegear-sg.me/smart.php?id=huanyutaiwan_twn&token=tvbjack
八大第一台,https://smart.946985.filegear-sg.me/smart.php?id=badafirst&token=tvbjack
八大综合台,https://smart.946985.filegear-sg.me/smart.php?id=badazhonghe&token=tvbjack
八大戏剧台,https://smart.946985.filegear-sg.me/smart.php?id=badadrama&token=tvbjack
八大娱乐台,https://smart.946985.filegear-sg.me/smart.php?id=badaentertain&token=tvbjack
纬来体育,https://smart.946985.filegear-sg.me/smart.php?id=videolandsport&token=tvbjack
纬来精彩,https://smart.946985.filegear-sg.me/smart.php?id=videolandspecial_twn&token=tvbjack
纬来日本,https://smart.946985.filegear-sg.me/smart.php?id=videolandjapan&token=tvbjack
纬来电影,https://smart.946985.filegear-sg.me/smart.php?id=videolandmovie&token=tvbjack
纬来综合,https://smart.946985.filegear-sg.me/smart.php?id=videolandzonghe&token=tvbjack
纬来育乐,https://smart.946985.filegear-sg.me/smart.php?id=videolandyule&token=tvbjack
爱尔达综合台,https://smart.946985.filegear-sg.me/smart.php?id=eltazonghe_twn&token=tvbjack
爱尔达影剧台,https://smart.946985.filegear-sg.me/smart.php?id=eltayingju_twn&token=tvbjack
爱尔达体育1台,https://smart.946985.filegear-sg.me/smart.php?id=eltasport_twn&token=tvbjack
爱尔达体育2台,https://smart.946985.filegear-sg.me/smart.php?id=eltasport2_twn&token=tvbjack
爱尔达体育3台,https://smart.946985.filegear-sg.me/smart.php?id=eltasport3_twn&token=tvbjack
爱尔达体育4台,https://smart.946985.filegear-sg.me/smart.php?id=eltasports4_twn&token=tvbjack
非凡新闻,https://smart.946985.filegear-sg.me/smart.php?id=feifannews_twn&token=tvbjack
年代新闻,https://smart.946985.filegear-sg.me/smart.php?id=niandainews_twn&token=tvbjack
龙华戏剧,https://smart.946985.filegear-sg.me/smart.php?id=lunghuaxiju_twn&token=tvbjack
龙华偶像,https://smart.946985.filegear-sg.me/smart.php?id=lunghuaidol_twn&token=tvbjack
龙华电影,https://smart.946985.filegear-sg.me/smart.php?id=xingwei_movie&token=tvbjack
龙华洋片,https://smart.946985.filegear-sg.me/smart.php?id=lunghuawestern_twn&token=tvbjack
龙华经典,https://smart.946985.filegear-sg.me/smart.php?id=lunghuajingdian_twn&token=tvbjack
靖天国际,https://smart.946985.filegear-sg.me/smart.php?id=jingtianintl_twn&token=tvbjack
靖天卡通,https://smart.946985.filegear-sg.me/smart.php?id=jingtiancartoon_twn&token=tvbjack
大愛電視,https://smart.946985.filegear-sg.me/smart.php?id=daai_twn&token=tvbjack
大愛二台,https://smart.946985.filegear-sg.me/smart.php?id=daai2_twn&token=tvbjack
EYE 旅游台,https://smart.946985.filegear-sg.me/smart.php?id=eyetvtravel_twn&token=tvbjack
EYE 戏剧台,https://smart.946985.filegear-sg.me/smart.php?id=eyetvxiju_twn&token=tvbjack
亚洲美食,https://smart.946985.filegear-sg.me/smart.php?id=afc_twn&token=tvbjack
美食星球,https://smart.946985.filegear-sg.me/smart.php?id=foodplanet_twn&token=tvbjack
TLC旅遊生活,https://smart.946985.filegear-sg.me/smart.php?id=tlc_twn&token=tvbjack
亚洲旅游台,https://smart.946985.filegear-sg.me/smart.php?id=asiatravel_twn&token=tvbjack
Arirang,https://smart.946985.filegear-sg.me/smart.php?id=arirang_twn&token=tvbjack
AXN Taiwan,https://smart.946985.filegear-sg.me/smart.php?id=axn_twn&token=tvbjack
MTV Live,https://smart.946985.filegear-sg.me/smart.php?id=mtvhd_twn&token=tvbjack
HBO_HD,https://smart.946985.filegear-sg.me/smart.php?id=hbohd_twn&token=tvbjack
HBO_HITS,https://smart.946985.filegear-sg.me/smart.php?id=hbohit_twn&token=tvbjack
CINEMAX,https://smart.946985.filegear-sg.me/smart.php?id=cinemax_twn&token=tvbjack
好萊塢電影台,https://smart.946985.filegear-sg.me/smart.php?id=hollywoodmovies_twn&token=tvbjack
卫视电影台,https://smart.946985.filegear-sg.me/smart.php?id=weishimovie_twn&token=tvbjack
龙祥时代,https://smart.946985.filegear-sg.me/smart.php?id=lungxiangtime_twn&token=tvbjack
美亚电影,https://smart.946985.filegear-sg.me/smart.php?id=meiyamovie_twn&token=tvbjack
華藝綜合,https://smart.946985.filegear-sg.me/smart.php?id=weishichinese_twn&token=tvbjack
博斯运动一台,https://smart.946985.filegear-sg.me/smart.php?id=bosisport1_twn&token=tvbjack
博斯运动二台,https://smart.946985.filegear-sg.me/smart.php?id=bosisport2_twn&token=tvbjack
博斯高球一台,https://smart.946985.filegear-sg.me/smart.php?id=bosigolf1_twn&token=tvbjack
博斯高球二台,https://smart.946985.filegear-sg.me/smart.php?id=bosigolf2_twn&token=tvbjack
博斯网球台,https://smart.946985.filegear-sg.me/smart.php?id=bositennis_twn&token=tvbjack
博斯无限台,https://smart.946985.filegear-sg.me/smart.php?id=bosiunlimited_twn&token=tvbjack
好消息 2,https://smart.946985.filegear-sg.me/smart.php?id=good2_twn&token=tvbjack

PopC,mitv://starvod.xyz:19806/688bba7c000da6943214e2280ad91465.ts
私人影院,mitv://starvod.xyz:19806/74567d46c9a54cb8aab7bb35b7446cf2.ts
星空衛視,mitv://starvod.xyz:19806/913e258484624493a5a6d960500b30cc.ts
天映經典,mitv://starvod.xyz:19806/4eebafee9ada46c9b959fe48a6baf682.ts
美亞電影台HD,mitv://starvod.xyz:19806/f9cdad09f3cc47bc83ba1d94167ebe64.ts
龍華電影,mitv://starvod.xyz:19806/574ee66b78d44e6e81450ae523041523.ts
靖天映畫,mitv://starvod.xyz:19806/9c504d3521e4481088a8a6c54fbac3d3.ts
靖天電影台,mitv://starvod.xyz:19806/7a72ea8d27d64fb9aae835c30af3b1cc.ts
壹電視電影台,mitv://starvod.xyz:19806/599f2aabecde4ed4b5fff257c229f986.ts
采昌影劇台,mitv://starvod.xyz:19806/33264996f0c14a369140623dca66da43.ts
影迷數位電影台,mitv://starvod.xyz:19806/37350129294343bcb28f6494c7ce4c07.ts
Thrill,mitv://starvod.xyz:19806/68679be10008a36ea4fd4b2b3b26291d.ts
城市電視,mitv://starvod.xyz:19806/2b3efa01d8bf4c7fbbef69911802df3f.ts
新時代1(東部),mitv://starvod.xyz:19806/e485c2b5af154a638d9d54d10dcb73d9.ts
新時代1(西部),mitv://starvod.xyz:19806/2c381681bcfd4ecdb2e52ece5014d6e8.ts
新時代2,mitv://starvod.xyz:19806/dd3cb3133b9d4ab38fb4b2c321a727a2.ts
千禧經典台,mitv://starvod.xyz:19806/8cf149d3490640d298e3bce48cd0e8ae.ts
TVB娛樂新聞台,mitv://starvod.xyz:19806/c6994957df9e4488bfb1c462db442f61.ts
TVB星河,mitv://starvod.xyz:19806/52d013423e304854a4980bd64c0015ae.ts
HKC 18,mitv://starvod.xyz:19806/72740144b3744949b05bd0220bd4c231.ts
now新聞台,mitv://starvod.xyz:19806/d0ba9cc570654f6d958809d4c3f8931d.ts
無綫新聞台,mitv://starvod.xyz:19806/557d5098116e4e1f9b14008ed764cc71.ts
黃金翡翠台,mitv://starvod.xyz:19806/d6964956395e43d1a62e6166706f7fcf.ts
生活台,mitv://starvod.xyz:19806/f4650e7cb54645f79ea52469b84ef3c4.ts
SUPER Kids,mitv://starvod.xyz:19806/631732f5fa894772aec8ee750359e455.ts
粵語片台,mitv://starvod.xyz:19806/04fd1cf947634341813b484f497ecbbc.ts
亞洲劇台,mitv://starvod.xyz:19806/4eab17c6f15b475696bcb51b61233345.ts
功夫台,mitv://starvod.xyz:19806/6043814031384523bc272f4f87aeb298.ts
戲曲台,mitv://starvod.xyz:19806/38b743244a7b4812a4e54b0d32910647.ts
18台,mitv://starvod.xyz:19806/ad27c96a4bca4e61be7b4b2ba07368fc.ts
澳門蓮花,mitv://starvod.xyz:19806/68679bdf00060084a4fd42af6a261d1a.ts
愛奇藝,mitv://starvod.xyz:19806/1cd1505d309948e596459856926cda41.ts
八度空間,mitv://starvod.xyz:19806/ae2ec19c582f4a07baa35b40f91b4239.ts
三立戲劇台,mitv://starvod.xyz:19806/eb30a7e16f1841c6900b45c8be342071.ts
龍華戲劇,mitv://starvod.xyz:19806/6a6681f04fcc4478886cded08a10c658.ts
愛爾達影劇台,mitv://starvod.xyz:19806/0ae8227ad4ca480499bdd9280ca57f7f.ts
靖洋戲劇台,mitv://147.135.39.171:9906/6867a22a000b7799949ca28717b451f5.ts
亞洲劇台,mitv://starvod.xyz:19806/4eab17c6f15b475696bcb51b61233345.ts
寰宇新聞台灣台,mitv://starvod.xyz:19806/afe7794ac5bf40ba96830dd97318be8c.ts
民視第一台,mitv://starvod.xyz:19806/6a62462b09e141a289c6882ef0ae3d6d.ts
民視台灣台,mitv://starvod.xyz:19806/0ad1202aa2fe4fb4872479db5e384e46.ts
中視菁采台,mitv://147.135.39.171:9906/6867a07b0000813094960c2053bb31ec.ts
三立綜合台,mitv://147.135.39.171:9906/6869374a000888579acb331f46c77c60.ts
靖天資訊台,mitv://starvod.xyz:19806/db9b03374399434da716bae0cd93f784.ts
靖天綜合台,mitv://starvod.xyz:19806/75b3e6bac51d4f08ba7ed008892ad6c2.ts
KLT-靖天國際台,mitv://starvod.xyz:19806/f349833dddb5488ab2ce1175246557c1.ts
靖天育樂台,mitv://starvod.xyz:19806/9dfcf4658000439aadcf1feb841a8887.ts
Smart知識台,mitv://starvod.xyz:19806/91503615eaa2416b929e56f178be5100.ts
中視經典台,mitv://starvod.xyz:19806/c523db6b2af648daa7c4c6bc2b8b4fa0.ts
TVBS精采台,mitv://starvod.xyz:19806/e9b905add7be4a3abd0a1993053ab547.ts
壹電視綜合,mitv://147.135.39.171:9906/685f810d000eeaf174db4a19563a6520.ts
緯來精采,mitv://147.135.39.171:9906/68693691000447559ac85f5e03845769.ts
八大優頻道,mitv://147.135.39.171:9906/686141c600004a257bb419081c1d2844.ts
三立戲劇台,mitv://starvod.xyz:19806/eb30a7e16f1841c6900b45c8be342071.ts
龍華戲劇,mitv://starvod.xyz:19806/6a6681f04fcc4478886cded08a10c658.ts
龍華偶像,mitv://starvod.xyz:19806/b3c35c2e01d44a31b17efef0af0ebc64.ts
愛爾達影劇台,mitv://starvod.xyz:19806/0ae8227ad4ca480499bdd9280ca57f7f.ts
靖天戲劇台,mitv://starvod.xyz:19806/840e84aa0a114e108edcaf6137177c4a.ts
靖洋戲劇台,mitv://147.135.39.171:9906/6867a22a000b7799949ca28717b451f5.ts
EYE TV戲劇台,mitv://starvod.xyz:19806/5756cf2acc364bd5ab062db33ddfad4b.ts
靖天日本台,mitv://starvod.xyz:19806/17ccd24c94514b0d928a3abd047add40.ts
台視財經台,mitv://starvod.xyz:19806/0817341552e94d809c49a1a48598b8f1.ts
台視綜合台,mitv://starvod.xyz:19806/c37a6ec58dd140ccab0e25b94849ee06.ts
中天亞洲台,mitv://starvod.xyz:19806/cd11642fed21436aae33a4a2ad34d222.ts
TVBS亞洲,mitv://starvod.xyz:19806/62e69ecfa7ad4edfa092d
美亚电影,https://smt.1678520.xyz/smt3.2.1.php?id=meiyamovie_twn
天映频道,https://smt.1678520.xyz/smt3.2.1.php?id=Celestial
天映经典,https://smt.1678520.xyz/smt3.2.1.php?id=Celestial2

闽南频波
东森新闻,http://211.72.174.95:8138/0.ts
民视新闻,http://211.72.174.95:8117/0.ts
中视HD,http://211.72.174.95:8113/0.ts
华视HD,http://211.72.174.95:8114/0.ts
公视,http://211.72.174.95:8116/0.ts
民视,http://211.72.174.95:8115/0.ts
台视HD,http://211.72.174.95:8112/0.ts

Now新闻,P2p://starvod.xyz:19806/d0ba9cc570654f6d958809d4c3f8931d.ts
无线新闻,P2p://starvod.xyz:19806/557d5098116e4e1f9b14008ed764cc71.ts
无线生活,P2p://starvod.xyz:19806/f4650e7cb54645f79ea52469b84ef3c4.ts
无线娱乐,P2p://starvod.xyz:19806/c6994957df9e4488bfb1c462db442f61.ts
无线星河,P2p://starvod.xyz:19806/52d013423e304854a4980bd64c0015ae.ts
无线千禧,P2p://starvod.xyz:19806/8cf149d3490640d298e3bce48cd0e8ae.ts
无线功夫,P2p://starvod.xyz:19806/6043814031384523bc272f4f87aeb298.ts
无线粤片,P2p://starvod.xyz:19806/04fd1cf947634341813b484f497ecbbc.ts
无线戏曲,P2p://starvod.xyz:19806/38b743244a7b4812a4e54b0d32910647.ts
无线亚剧,P2p://starvod.xyz:19806/4eab17c6f15b475696bcb51b61233345.ts
无线少儿,P2p://starvod.xyz:19806/631732f5fa894772aec8ee750359e455.ts
黄金翡翠,P2p://starvod.xyz:19806/d6964956395e43d1a62e6166706f7fcf.ts
无线赛马,P2p://starvod.xyz:19806/ad27c96a4bca4e61be7b4b2ba07368fc.ts
有线赛马,P2p://starvod.xyz:19806/72740144b3744949b05bd0220bd4c231.ts
澳门莲花,P2p://starvod.xyz:19806/68679bdf00060084a4fd42af6a261d1a.ts
星空卫视,P2p://starvod.xyz:19806/913e258484624493a5a6d960500b30cc.ts
天映经典,P2p://starvod.xyz:19806/4eebafee9ada46c9b959fe48a6baf682.ts
pₒₚc电影,P2p://starvod.xyz:19806/688bba7c000da6943214e2280ad91465.ts
美亚电影,P2p://starvod.xyz:19806/f9cdad09f3cc47bc83ba1d94167ebe64.ts
龙华电影,P2p://starvod.xyz:19806/574ee66b78d44e6e81450ae523041523.ts
私人影院,P2p://starvod.xyz:19806/74567d46c9a54cb8aab7bb35b7446cf2.ts
爱奇艺综,P2p://starvod.xyz:19806/1cd1505d309948e596459856926cda41.ts
八度空间,P2p://starvod.xyz:19806/ae2ec19c582f4a07baa35b40f91b4239.ts
Ftv_城市,P2p://starvod.xyz:19806/2b3efa01d8bf4c7fbbef69911802df3f.ts
Ftv1时代中文,P2p://starvod.xyz:19806/e485c2b5af154a638d9d54d10dcb73d9.ts
Ftv1时代英文,P2p://starvod.xyz:19806/2c381681bcfd4ecdb2e52ece5014d6e8.ts
Ftv2时代,P2p://starvod.xyz:19806/dd3cb3133b9d4ab38fb4b2c321a727a2.ts
thrill电影,P2p://starvod.xyz:19806/68679be10008a36ea4fd4b2b3b26291d.ts
壹电影视,P2p://starvod.xyz:19806/599f2aabecde4ed4b5fff257c229f986.ts
数位电影,P2p://starvod.xyz:19806/37350129294343bcb28f6494c7ce4c07.ts
靖天电影,P2p://starvod.xyz:19806/7a72ea8d27d64fb9aae835c30af3b1cc.ts
靖天映画,P2p://starvod.xyz:19806/9c504d3521e4481088a8a6c54fbac3d3.ts
采昌影剧,P2p://starvod.xyz:19806/33264996f0c14a369140623dca66da43.ts
三立戏剧,P2p://starvod.xyz:19806/eb30a7e16f1841c6900b45c8be342071.ts

人间卫视,http://61.216.67.119:1935/bltvhd/bltv1/chunklist_w1266569526.m3u8
人间卫视,https://5ddce30eb4b55.streamlock.net/bltvhd/bltv1/chunklist_w511254805.m3u8
人间卫视,http://61.216.67.119:1935/bltvhd/bltv1/chunklist_w1266569526.m3u8
人间卫视,https://5ddce30eb4b55.streamlock.net/bltvhd/bltv1/chunklist_w511254805.m3u8

民视,rtmp://f13h.mine.nu/sat/tv051
台视,rtmp://f13h.mine.nu/sat/tv071
中视,rtmp://f13h.mine.nu/sat/tv091
华视,rtmp://f13h.mine.nu/sat/tv111
纬来体育,rtmp://f13h.mine.nu/sat/tv721
纬来育乐,rtmp://f13h.mine.nu/sat/tv701
纬来日本,rtmp://f13h.mine.nu/sat/tv771
东森超视,rtmp://f13h.mine.nu/sat/tv331
MoMo综合,rtmp://f13h.mine.nu/sat/tv761
ELEVEN体育1,rtmp://f13h.mine.nu/sat/tv731
ELEVEN体育2,rtmp://f13h.mine.nu/sat/tv741
TVBS新闻,rtmp://f13h.mine.nu/sat/tv551
东森财经新闻台,rtmp://f13h.mine.nu/sat/tv571
ELTA体育1,rtmp://f13h.mine.nu/sat/md051
ELTA体育2,rtmp://f13h.mine.nu/sat/md041
东森超视,rtmp://f13h.mine.nu/sat/tv331
超视34.5,http://38.64.72.148:80/hls/modn/list/2013/chunklist0.m3u8
超视34.5,http://38.64.72.148:80/hls/modn/list/2013/chunklist1.m3u8

东森超视,rtmp://f13h.mine.nu/sat/tv331
东森超视,rtmp://f13h.mine.nu/sat/tv331

astro QJ,http://php.jdshipin.com/smt.php?id=Quanjia
astroAec,http://php.jdshipin.com/smt.php?id=AEC
astroAod,http://php.jdshipin.com/smt.php?id=Aodhd
astro欢喜,http://php.jdshipin.com/smt.php?id=Huahee
astro爱奇艺,http://php.jdshipin.com/smt.php?id=Qiyi
八度空间,http://php.jdshipin.com/smt.php?id=TV8

纬来精采,http://61.221.215.25:8800/hls/48/index.m3u8
纬来精采,http://61.221.215.25:8800/hls/48/index.m3u8


█████████████████████████████████████████████
4 K 频道,#genre#
█████████████████████████████████████████████

4k频道
北京卫视4K,http://139.ye23.vip/dl/btv2502.php?id=bjws4
东方卫视4K,http://bp-resource-dfl.bestv.cn/148/3/video.m3u8
湖南卫视4K,http://hlsal-ldvt.qing.mgtv.com/nn_live/nn_x64/dWlwPTEyNy4wLjAuMSZ1aWQ9cWluZy1jbXMmbm5fdGltZXpvbmU9OCZjZG5leF9pZD1hbF9obHNfbGR2dCZ1dWlkPTliODY4NmU5ZTM2YzYwMmMmZT02OTE0NjA0JnY9MSZpZD1ITldTWkdTVCZzPTcwN2RiYTc2YzJjNmJmMTQ4MmUyZGYzOWU2NWM3YWFi/HNWSZGST.m3u8
浙江卫视4K,https://play-qukan.cztv.com/live/1758879019692345.m3u8

北京卫视4K,http://43.251.226.89/公众号潇雨萌萌.php?ch=%E5%8C%97%E4%BA%AC%E5%8D%AB%E8%A7%864K%E8%B6%85%E9%AB%98%E6%B8%85
深圳卫视4K,http://nn.7x9d.cn/深圳最新.php?id=szws4k
江苏卫视4K,https://43.251.226.89/jstv.php?id=jsws4k
苏州4K,https://tylive.kan0512.com/norecord/csztv4k_4k.m3u8
河北4K,https://event.pull.hebtv.com:443/live/live101.m3u8


北京卫视4K,http://ddns.xryo.cn:8888/udp/239.111.205.51:5140
东方卫视4K,http://ddns.xryo.cn:8888/udp/239.111.205.67:5140
浙江卫视4K,http://ddns.xryo.cn:8888/udp/239.111.205.65:5140
江苏卫视4K,http://ddns.xryo.cn:8888/udp/239.111.205.64:5140
湖南卫视4K,http://ddns.xryo.cn:8888/udp/239.111.205.63:5140
广东卫视4K,http://ddns.xryo.cn:8888/udp/239.111.205.103:5140
深圳卫视4K,http://ddns.xryo.cn:8888/udp/239.111.205.104:5140
山东卫视4K,http://ddns.xryo.cn:8888/udp/239.111.205.66:5140
四川卫视4K,http://ddns.xryo.cn:8888/udp/239.111.205.62:5140
北京卫视4K,http://49.235.65.250:600/beijing/beijing.php?id=bjws4k
深圳卫视4K,https://livepull-tcms.sztv.com.cn/live/sz4Kpgm.m3u8

苏州4K,https://tylive.kan0512.com/norecord/csztv4k_4k.m3u8
苏州4K,https://live-auth.51kandianshi.com/szgd/csztv4k_hd.m3u8
河北4K,https://event.pull.hebtv.com:443/live/live101.m3u8

CCTV4K,http://vip1.xinketongxun.fun:8082/tsfile/live/1026_1.m3u8
CCTV1,http://play-hsbj.vzan.com/978354/446938712125478466/live.m3u8

北京卫视4K,http://49.235.65.250:600/beijing/beijing.php?id=bjws4k

河北4K,http://106.53.99.30/tv/api.php?id=hebtv4k
苏州4K,http://106.53.99.30/tv/api.php?id=sztv4k
广东卫视4K,http://ikuai.haleeyo.cn:9003/udp/239.77.0.27:5146
深圳卫视4K,http://ikuai.haleeyo.cn:9003/udp/239.77.1.14:5146
广东卫视4K,http://go.bkpcp.top:80/mg/gdws
广东卫视4K,http://119.32.12.12:2901/udp/225.1.101.86:7523
北京卫视4K,http://ikuai.haleeyo.cn:9003/udp/239.77.0.2:5146
北京卫视4K,http://home.amucn.net:8800/udp/239.49.0.42:8000
广州南国都市4K,https://tencentplaybusiness.gztv.com/live/nanguodushi.m3u8
广州南国都市4K,https://live.ottiptv.cc/gztv/shenghuo

CCTV4K,http://www.520345.xyz:8188/rtp/239.69.1.111:10304?$3840x2160
CCTV4K,http://home.amucn.net:8800/udp/239.49.0.82:8000
CCTV16 4K,http://home.amucn.net:8800/udp/239.49.0.109:8000

广东卫视4K,http://ikuai.haleeyo.cn:9003/udp/239.77.0.27:5146&token=bc1a5ce7f260728b8fa3063d1466009e


法国时尚台4K,https://fash2043.cloudycdn.services/slive/ftv_ftv_4k_hevc_73d_42080_default_466_hls.smil/playlist.m3u8


体育频道,#genre#

红牛运动,http://rbmn-live.akamaized.net/hls/live/590964/BoRB-AT/master_1660.m3u8
红牛运动,http://rbmn-live.akamaized.net/hls/live/590964/BoRB-AT/master_6660.m3u8
红牛运动,https://rbmn-live.akamaized.net/hls/live/590964/BoRB-AT/master_3360.m3u8
迪拜体育,https://svs.itworkscdn.net/smc4sportslive/smc4.smil/playlist.m3u8
篮球专场,https://www.goodiptv.club/huya/20072708
羽毛球专场,https://www.goodiptv.club/huya/880221
乒乓球专场,https://www.goodiptv.club/huya/30020997
斯诺克专场,https://www.goodiptv.club/huya/880214
摔跤专场,https://www.goodiptv.club/huya/20072812
拳击专场,https://www.goodiptv.club/huya/18152380
格斗专场,https://www.goodiptv.club/huya/20072796
柔道专场,https://www.goodiptv.club/huya/20072837
WWE专场,https://www.goodiptv.club/huya/30021023
屿风体育,https://live.ottiptv.cc/douyu/10329889
拳击大王,https://live.ottiptv.cc/douyu/9385340
经典拳赛,https://live.ottiptv.cc/douyu/9412138
日本女子摔跤,https://live.ottiptv.cc/douyu/425809
篮球人物,https://live.ottiptv.cc/douyu/8434598
篮球小人物,https://live.ottiptv.cc/douyu/9184257
篮球过人技巧,https://live.ottiptv.cc/douyu/9406897
篮球长镜头,https://live.ottiptv.cc/douyu/9399887
只关于篮球的只老师,https://live.ottiptv.cc/douyu/9367541
篮球之家老李,https://live.ottiptv.cc/douyu/9170147
HOOPPAPK篮球公园,https://live.ottiptv.cc/douyu/10228726
乔丹/科比,https://www.goodiptv.club/huya/30806125
看球不费电,https://www.goodiptv.club/huya/29982603
超燃球场,https://www.goodiptv.club/huya/29982597
篮球五分位,https://www.goodiptv.club/huya/29982598


央卫限时,#genre#
CCTV1,https://zby.130519.xyz/PLTV/11/224/3221225673/index.m3u8
CCTV1,https://zby.130519.xyz/PLTV/11/224/3221225723/index.m3u8
CCTV2,https://zby.130519.xyz/PLTV/11/224/3221226122/index.m3u8
CCTV3,https://zby.130519.xyz/PLTV/11/224/3221225766/index.m3u8
CCTV3,http://153.0.171.163:9901/tsfile/live/1002_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV4,https://zby.130519.xyz/PLTV/11/224/3221226124/index.m3u8
CCTV5,http://153.0.171.163:9901/tsfile/live/0005_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV6,https://zby.130519.xyz/PLTV/11/224/3221225741/index.m3u8
CCTV6,http://153.0.171.163:9901/tsfile/live/0006_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV7,https://zby.130519.xyz/PLTV/11/224/3221225701/index.m3u8
CCTV7,https://ldocctvwbcdtxy.liveplay.myqcloud.com/ldocctvwbcd/cdrmldcctv7_1_td.m3u8
CCTV8,http://153.0.171.163:9901/tsfile/live/1007_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV10,https://zby.130519.xyz/PLTV/11/224/3221226169/index.m3u8
CCTV12,https://zby.130519.xyz/PLTV/11/224/3221226126/index.m3u8
CCTV13,https://zby.130519.xyz/PLTV/11/224/3221226128/index.m3u8
CCTV13,http://ali-m-l.cztv.com/channels/lantian/channel21/1080p.m3u8
CCTV15,https://zby.130519.xyz/PLTV/11/224/3221226147/index.m3u8
CCTV17,http://61.156.228.12:8154/tsfile/live/0019_1.m3u8?key=txiptv&playlive=1&authid=0

CCTV1,https://zby.130519.xyz/PLTV/11/224/3221226163/index.m3u8
CCTV1,https://zby.130519.xyz/PLTV/11/224/3221225770/index.m3u8
CCTV1,https://zby.130519.xyz/PLTV/11/224/3221225723/index.m3u8
CCTV1,https://zby.130519.xyz/PLTV/11/224/3221225673/index.m3u8
CCTV2,https://zby.130519.xyz/PLTV/11/224/3221226122/index.m3u8
CCTV3,https://zby.130519.xyz/PLTV/11/224/3221225766/index.m3u8
CCTV3,https://zby.130519.xyz/PLTV/11/224/3221226165/index.m3u8
CCTV4,https://zby.130519.xyz/PLTV/11/224/3221226124/index.m3u8
CCTV5,https://zby.130519.xyz/PLTV/11/224/3221225734/index.m3u8
CCTV5,https://zby.130519.xyz/PLTV/11/224/3221226146/index.m3u8
CCTV6,https://zby.130519.xyz/PLTV/11/224/3221225741/index.m3u8
CCTV6,https://zby.130519.xyz/PLTV/11/224/3221226148/index.m3u8
CCTV7,https://zby.130519.xyz/PLTV/11/224/3221225701/index.m3u8
CCTV7,https://zby.130519.xyz/PLTV/11/224/3221226143/index.m3u8
CCTV7,https://zby.130519.xyz/PLTV/11/224/3221226137/index.m3u8
CCTV8,https://zby.130519.xyz/PLTV/11/224/3221225736/index.m3u8
CCTV8,https://zby.130519.xyz/PLTV/11/224/3221226167/index.m3u8
CCTV10,https://zby.130519.xyz/PLTV/11/224/3221225743/index.m3u8
CCTV10,https://zby.130519.xyz/PLTV/11/224/3221226169/index.m3u8
CCTV11,https://zby.130519.xyz/PLTV/11/224/3221226101/index.m3u8
CCTV11,https://zby.130519.xyz/PLTV/11/224/3221226145/index.m3u8
CCTV12,https://zby.130519.xyz/PLTV/11/224/3221226103/index.m3u8
CCTV12,https://zby.130519.xyz/PLTV/11/224/3221226126/index.m3u8
CCTV13,https://zby.130519.xyz/PLTV/11/224/3221226128/index.m3u8
CCTV14,https://zby.130519.xyz/PLTV/11/224/3221225738/index.m3u8
CCTV14,https://zby.130519.xyz/PLTV/11/224/3221226150/index.m3u8
CCTV15,https://zby.130519.xyz/PLTV/11/224/3221226147/index.m3u8
CCTV16,https://zby.130519.xyz/PLTV/11/224/3221226120/index.m3u8

广东卫视,https://txmov2.a.kwimgs.com/upic/2023/01/26/09/BMjAyMzAxMjYwOTE3NDVfNzM5MzQzNzIyXzk0NjI1OTUwNTA3XzBfMw==_b_B81ddda927d33445d544befd008e60109.mp4
广东卫视,https://zby.130519.xyz/PLTV/11/224/3221225731/index.m3u8
浙江卫视,https://ali-m-l.cztv.com/channels/lantian/channel001/1080p.m3u8
浙江卫视,http://kbtv.zkbhj.com/liveRedirect/hotel.php?p=sdjn&id=33
浙江卫视,http://ali-m-l.cztv.com/channels/lantian/channel001/1080p.m3u8
湖南卫视,https://txmov2.a.kwimgs.com/bs3/video-hls/5199687338554291078_hlsb.m3u8
湖南卫视,https://zby.130519.xyz/PLTV/11/224/3221225726/index.m3u8
湖南卫视,http://kbtv.zkbhj.com/liveRedirect/hotel.php?p=sdjn&id=32
北京卫视,http://61.156.228.12:8154/tsfile/live/0122_1.m3u8
北京卫视,http://kbtv.zkbhj.com/liveRedirect/hotel.php?p=sdjn&id=36
湖北卫视,http://kbtv.zkbhj.com/liveRedirect/hotel.php?p=sdjn&id=42
黑龙江卫视,http://t.061899.xyz/tl/dq.php?id=hljws
黑龙江卫视,http://61.156.228.12:8154/tsfile/live/0143_1.m3u8
安徽卫视,http://kbtv.zkbhj.com/liveRedirect/hotel.php?p=sdjn&id=37
安徽卫视,https://zby.130519.xyz/PLTV/11/224/3221225739/index.m3u8
重庆卫视,https://zby.130519.xyz/PLTV/11/224/3221226171/index.m3u8
东方卫视,https://txmov2.a.kwimgs.com/bs3/video-hls/5219953535631090825_hlsb.m3u8
东南卫视,https://zby.130519.xyz/PLTV/11/224/3221225745/index.m3u8
东南卫视,http://kbtv.zkbhj.com/liveRedirect/hotel.php?p=sdjn&id=41
广西卫视,rtmp://live.gxrb.com.cn/hls/a23
海南卫视,https://zby.130519.xyz/PLTV/11/224/3221226154/index.m3u8
海南卫视,http://nn.7x9d.cn/地方台8563/海南.php?id=hnws
海南卫视,http://nn.7x9d.cn/地方台8563/海南.php?id=hnws&?key=txiptv
河南卫视,http://lxajh.top/tv/hn.php?id=hnws
河南卫视,http://1.94.31.214/php/hntv.php?id=hnws
河南卫视,https://zby.130519.xyz/PLTV/11/224/3221226132/index.m3u8
吉林卫视,https://zby.130519.xyz/PLTV/11/224/3221226149/index.m3u8
吉林卫视,http://61.156.228.12:8154/tsfile/live/0116_1.m3u8
江苏卫视,http://kbtv.zkbhj.com/liveRedirect/hotel.php?p=sdjn&id=35
江苏卫视,http://gfr.x3322.net:9901/tsfile/live/1086_1.m3u8
内蒙古卫视,https://ali-m-l.cztv.com/channels/lantian/channel007/1080p.m3u8
山东卫视,http://l.cztvcloud.com/channels/lantian/SXshengzhou1/720p.m3u8
山东卫视,http://kbtv.zkbhj.com/liveRedirect/hotel.php?p=sdjn&id=2
深圳卫视,http://38.64.72.148:80/hls/modn/list/4007/playlist.m3u8
深圳卫视,http://iptv.zkbhj.com/tv/url/go?id=9bfe9fa37a4156dd532726199fbaaf4ff2325e82e1723382000c25c9009b1449c82774ab2cba0c3ab0060596ffb0adc68b159ebdfc0a79d0e46bdfab58d3819e
云南卫视,https://zby.130519.xyz/PLTV/11/224/3221226151/index.m3u8


北京卫视,https://zby.130519.xyz/PLTV/11/224/3221225724/index.m3u8
东方卫视,https://zby.130519.xyz/PLTV/11/224/3221225725/index.m3u8
东方卫视,https://zby.130519.xyz/PLTV/11/224/3221226106/index.m3u8
浙江卫视,https://zby.130519.xyz/PLTV/11/224/3221225727/index.m3u8
江苏卫视,https://zby.130519.xyz/PLTV/11/224/3221225720/index.m3u8
湖南卫视,https://zby.130519.xyz/PLTV/11/224/3221225726/index.m3u8
广东卫视,https://zby.130519.xyz/PLTV/11/224/3221225731/index.m3u8
深圳卫视,https://zby.130519.xyz/PLTV/11/224/3221225728/index.m3u8
天津卫视,https://zby.130519.xyz/PLTV/11/224/3221225742/index.m3u8
安徽卫视,https://zby.130519.xyz/PLTV/11/224/3221225739/index.m3u8
山东卫视,https://zby.130519.xyz/PLTV/11/224/3221225733/index.m3u8
山西卫视,https://zby.130519.xyz/PLTV/11/224/3221226113/index.m3u8
辽宁卫视,https://zby.130519.xyz/PLTV/11/224/3221225747/index.m3u8
河北卫视,https://zby.130519.xyz/PLTV/11/224/3221226107/index.m3u8
河南卫视,https://zby.130519.xyz/PLTV/11/224/3221226132/index.m3u8
江西卫视,https://zby.130519.xyz/PLTV/11/224/3221225740/index.m3u8
四川卫视,https://zby.130519.xyz/PLTV/11/224/3221226152/index.m3u8
重庆卫视,https://zby.130519.xyz/PLTV/11/224/3221226171/index.m3u8
贵州卫视,https://zby.130519.xyz/PLTV/11/224/3221226173/index.m3u8
湖北卫视,https://zby.130519.xyz/PLTV/11/224/3221225729/index.m3u8
广西卫视,https://zby.130519.xyz/PLTV/11/224/3221226084/index.m3u8
广西卫视,https://zby.130519.xyz/PLTV/11/224/3221226130/index.m3u8
云南卫视,https://zby.130519.xyz/PLTV/11/224/3221226109/index.m3u8
云南卫视,https://zby.130519.xyz/PLTV/11/224/3221226151/index.m3u8
东南卫视,https://zby.130519.xyz/PLTV/11/224/3221225745/index.m3u8
海南卫视,https://zby.130519.xyz/PLTV/11/224/3221226154/index.m3u8
甘肃卫视,https://zby.130519.xyz/PLTV/11/224/3221226090/index.m3u8
青海卫视,https://zby.130519.xyz/PLTV/11/224/3221226105/index.m3u8
吉林卫视,https://zby.130519.xyz/PLTV/11/224/3221226149/index.m3u8
吉林卫视,https://zby.130519.xyz/PLTV/11/224/3221226082/index.m3u8
黑龙江卫视,https://zby.130519.xyz/PLTV/11/224/3221225722/index.m3u8
东方影视,https://zby.130519.xyz/PLTV/11/224/3221225744/index.m3u8
东方财经,https://zby.130519.xyz/PLTV/11/224/3221226134/index.m3u8
第一财经,https://zby.130519.xyz/PLTV/11/224/3221225737/index.m3u8
上海都市,https://zby.130519.xyz/PLTV/11/224/3221225749/index.m3u8
都市剧场,https://zby.130519.xyz/PLTV/11/224/3221225762/index.m3u8
都市剧场,https://zby.130519.xyz/PLTV/11/224/3221226155/index.m3u8
欢笑剧场,https://zby.130519.xyz/PLTV/11/224/3221225771/index.m3u8
新闻综合,https://zby.130519.xyz/PLTV/11/224/3221226136/index.m3u8
金色学堂,https://zby.130519.xyz/PLTV/11/224/3221225748/index.m3u8
生活时尚,https://zby.130519.xyz/PLTV/11/224/3221225768/index.m3u8
法治天地,https://zby.130519.xyz/PLTV/11/224/3221225994/index.m3u8
游戏风云,https://zby.130519.xyz/PLTV/11/224/3221226117/index.m3u8
游戏风云,https://zby.130519.xyz/PLTV/11/224/3221226140/index.m3u8
乐游频道,https://zby.130519.xyz/PLTV/11/224/3221226157/index.m3u8
乐游频道,https://zby.130519.xyz/PLTV/11/224/3221226115/index.m3u8
哈哈炫动,https://zby.130519.xyz/PLTV/11/224/3221226161/index.m3u8
哈哈炫动,https://zby.130519.xyz/PLTV/11/224/3221226175/index.m3u8
动漫秀场,https://zby.130519.xyz/PLTV/11/224/3221225764/index.m3u8
动漫秀场,https://zby.130519.xyz/PLTV/11/224/3221226138/index.m3u8
卡酷少儿,https://zby.130519.xyz/PLTV/11/224/3221226019/index.m3u8
金鹰卡通,https://zby.130519.xyz/PLTV/11/224/3221226094/index.m3u8

CCTV-6 电影,http://z.b.bkpcp.top/m.php?id=cctv6
CCTV-13 新闻,http://z.b.bkpcp.top/m.php?id=cctv13



█████████████████████████████████████████████
央卫咪咕,#genre#
█████████████████████████████████████████████
CCTV1,https://www.wmviv.com/iptv/bc2t.php?id=cctv1
CCTV2,https://www.wmviv.com/iptv/bc2t.php?id=cctv2
CCTV3,https://www.wmviv.com/iptv/bc2t.php?id=cctv3
CCTV4,https://www.wmviv.com/iptv/bc2t.php?id=cctv4
CCTV4,https://www.wmviv.com/iptv/bc2t.php?id=cctv4m
CCTV4,https://www.wmviv.com/iptv/bc2t.php?id=cctv4o
CCTV5,https://www.wmviv.com/iptv/bc2t.php?id=cctv5
CCTV5+,https://www.wmviv.com/iptv/bc2t.php?id=cctv5p
CCTV6,https://www.wmviv.com/iptv/bc2t.php?id=cctv6
CCTV7,https://www.wmviv.com/iptv/bc2t.php?id=cctv7
CCTV8,https://www.wmviv.com/iptv/bc2t.php?id=cctv8
CCTV9,https://www.wmviv.com/iptv/bc2t.php?id=cctv9
CCTV10,https://www.wmviv.com/iptv/bc2t.php?id=cctv10
CCTV11,https://www.wmviv.com/iptv/bc2t.php?id=cctv11
CCTV12,https://www.wmviv.com/iptv/bc2t.php?id=cctv12
CCTV13,https://www.wmviv.com/iptv/bc2t.php?id=cctv13
CCTV14,https://www.wmviv.com/iptv/bc2t.php?id=cctv14
CCTV15,https://www.wmviv.com/iptv/bc2t.php?id=cctv15
CCTV16,https://www.wmviv.com/iptv/bc2t.php?id=cctv16
CCTV17,https://www.wmviv.com/iptv/bc2t.php?id=cctv17
CCTV发现之旅,http://www.wmviv.com/iptv/bc2t.php?id=fxzl
CCTV老故事,http://www.wmviv.com/iptv/bc2t.php?id=lgs
CCTV中学生,http://www.wmviv.com/iptv/bc2t.php?id=zxs
CGTN,http://www.wmviv.com/iptv/bc2t.php?id=cgtn
CGTN纪录,http://www.wmviv.com/iptv/bc2t.php?id=cgtnjl
东方卫视,http://www.wmviv.com/iptv/bc2t.php?id=dfws
重庆卫视,http://www.wmviv.com/iptv/bc2t.php?id=cqws
吉林卫视,http://www.wmviv.com/iptv/bc2t.php?id=jlws
辽宁卫视,http://www.wmviv.com/iptv/bc2t.php?id=lnws
内蒙古卫视,http://www.wmviv.com/iptv/bc2t.php?id=nmws
宁夏卫视,http://www.wmviv.com/iptv/bc2t.php?id=nxws
甘肃卫视,http://www.wmviv.com/iptv/bc2t.php?id=gsws
青海卫视,http://www.wmviv.com/iptv/bc2t.php?id=qhws
陕西卫视,http://www.wmviv.com/iptv/bc2t.php?id=sxws
山东卫视,http://www.wmviv.com/iptv/bc2t.php?id=sdws
河南卫视,http://www.wmviv.com/iptv/bc2t.php?id=hnws
湖北卫视,http://www.wmviv.com/iptv/bc2t.php?id=hubws
湖南卫视,http://www.wmviv.com/iptv/bc2t.php?id=hunws
江西卫视,http://www.wmviv.com/iptv/bc2t.php?id=jxws
江苏卫视,http://www.wmviv.com/iptv/bc2t.php?id=jsws
东南卫视,http://www.wmviv.com/iptv/bc2t.php?id=dnws
海峡卫视,http://www.wmviv.com/iptv/bc2t.php?id=hxws
广东卫视,http://www.wmviv.com/iptv/bc2t.php?id=gdws
大湾区卫视,http://www.wmviv.com/iptv/bc2t.php?id=dwqws
广西卫视,http://www.wmviv.com/iptv/bc2t.php?id=gxws
云南卫视,http://www.wmviv.com/iptv/bc2t.php?id=ynws
贵州卫视,http://www.wmviv.com/iptv/bc2t.php?id=gzws
新疆卫视,http://www.wmviv.com/iptv/bc2t.php?id=xjws
西藏卫视,http://www.wmviv.com/iptv/bc2t.php?id=xzws
海南卫视,http://www.wmviv.com/iptv/bc2t.php?id=hinws
四海钓鱼,http://www.wmviv.com/iptv/bc2t.php?id=shdy
CHC动作电影,http://www.wmviv.com/iptv/bc2t.php?id=chcdzdy
CHC家庭影院,http://www.wmviv.com/iptv/bc2t.php?id=chcjtdy
东方影视,http://www.wmviv.com/iptv/bc2t.php?id=dfys
上海新闻综合,http://www.wmviv.com/iptv/bc2t.php?id=shxwzh
上海第一财经,http://www.wmviv.com/iptv/bc2t.php?id=dycj
上视纪实人文,http://www.wmviv.com/iptv/bc2t.php?id=shjsrw
上海外语,http://www.wmviv.com/iptv/bc2t.php?id=shics
法治天地,http://www.wmviv.com/iptv/bc2t.php?id=fztd
劲爆体育,http://www.wmviv.com/iptv/bc2t.php?id=jbty
魅力足球,http://www.wmviv.com/iptv/bc2t.php?id=mlzq
乐游,http://www.wmviv.com/iptv/bc2t.php?id=ly
欢笑剧场,http://www.wmviv.com/iptv/bc2t.php?id=hxjc
七彩戏剧,http://www.wmviv.com/iptv/bc2t.php?id=qcxj
游戏风云,http://www.wmviv.com/iptv/bc2t.php?id=yxfy
优漫卡通,http://www.wmviv.com/iptv/bc2t.php?id=ymkt



█████████████████████████████████████████████
央卫备用,#genre#
█████████████████████████████████████████████

CCTV1,http://112.27.235.94:8000/hls/1/index.m3u8
CCTV2,http://112.27.235.94:8000/hls/2/index.m3u8
CCTV3,http://112.27.235.94:8000/hls/3/index.m3u8
CCTV4,http://112.27.235.94:8000/hls/4/index.m3u8
CCTV5,http://112.27.235.94:8000/hls/5/index.m3u8
CCTV5+,http://112.27.235.94:8000/hls/6/index.m3u8
CCTV6,http://112.27.235.94:8000/hls/7/index.m3u8
CCTV7,http://112.27.235.94:8000/hls/8/index.m3u8
CCTV8,http://112.27.235.94:8000/hls/9/index.m3u8
CCTV9,http://112.27.235.94:8000/hls/10/index.m3u8
CCTV10,http://112.27.235.94:8000/hls/11/index.m3u8
CCTV11,http://112.27.235.94:8000/hls/12/index.m3u8
CCTV12,http://112.27.235.94:8000/hls/13/index.m3u8
CCTV13,http://112.27.235.94:8000/hls/14/index.m3u8
CCTV14,http://112.27.235.94:8000/hls/15/index.m3u8
CCTV15,http://112.27.235.94:8000/hls/16/index.m3u8
CGTN,http://112.27.235.94:8000/hls/17/index.m3u8
安徽卫视,http://112.27.235.94:8000/hls/26/index.m3u8
北京卫视,http://112.27.235.94:8000/hls/27/index.m3u8
上海卫视,http://112.27.235.94:8000/hls/28/index.m3u8
浙江卫视,http://112.27.235.94:8000/hls/29/index.m3u8
广东卫视,http://112.27.235.94:8000/hls/30/index.m3u8
湖南卫视,http://112.27.235.94:8000/hls/31/index.m3u8
江苏卫视,http://112.27.235.94:8000/hls/32/index.m3u8
深圳卫视,http://112.27.235.94:8000/hls/33/index.m3u8
山东卫视,http://112.27.235.94:8000/hls/34/index.m3u8
四川卫视,http://112.27.235.94:8000/hls/35/index.m3u8
重庆卫视,http://112.27.235.94:8000/hls/36/index.m3u8
河南卫视,http://112.27.235.94:8000/hls/37/index.m3u8
东南卫视,http://112.27.235.94:8000/hls/38/index.m3u8
河北卫视,http://112.27.235.94:8000/hls/39/index.m3u8
云南卫视,http://112.27.235.94:8000/hls/40/index.m3u8
湖北卫视,http://112.27.235.94:8000/hls/41/index.m3u8
天津卫视,http://112.27.235.94:8000/hls/42/index.m3u8
陕西卫视,http://112.27.235.94:8000/hls/43/index.m3u8
江西卫视,http://112.27.235.94:8000/hls/44/index.m3u8
山西卫视,http://112.27.235.94:8000/hls/45/index.m3u8
贵州卫视,http://112.27.235.94:8000/hls/46/index.m3u8
辽宁卫视,http://112.27.235.94:8000/hls/47/index.m3u8
黑龙江卫视,http://112.27.235.94:8000/hls/48/index.m3u8
内蒙古卫视,http://112.27.235.94:8000/hls/49/index.m3u8
重温经典,http://112.27.235.94:8000/hls/50/index.m3u8



CCTV1,http://hczn.x3322.net:9901/tsfile/live/0001_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV1,http://hczn.x3322.net:9902/tsfile/live/0001_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV2,http://hczn.x3322.net:9901/tsfile/live/0002_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV2,http://hczn.x3322.net:9902/tsfile/live/0002_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV3,http://hczn.x3322.net:9901/tsfile/live/0003_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV3,http://hczn.x3322.net:9902/tsfile/live/0003_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV4,http://hczn.x3322.net:9902/tsfile/live/0016_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV4,http://hczn.x3322.net:9901/tsfile/live/0016_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV5,http://hczn.x3322.net:9901/tsfile/live/0005_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV5,http://hczn.x3322.net:9902/tsfile/live/0005_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV6,http://hczn.x3322.net:9901/tsfile/live/0006_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV6,http://hczn.x3322.net:9902/tsfile/live/0006_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV8,http://hczn.x3322.net:9901/tsfile/live/0008_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV8,http://hczn.x3322.net:9902/tsfile/live/0008_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV10,http://hczn.x3322.net:9901/tsfile/live/0011_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV10,http://hczn.x3322.net:9902/tsfile/live/0011_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV1,http://btjg.net:809/hls/1/index.m3u8
CCTV2,http://btjg.net:809/hls/2/index.m3u8
CCTV3,http://btjg.net:809/hls/3/index.m3u8
CCTV4超,http://btjg.net:809/hls/141/index.m3u8
CCTV4,http://btjg.net:809/hls/4/index.m3u8
CCTV5,http://btjg.net:809/hls/5/index.m3u8
CCTV5+,http://btjg.net:809/hls/17/index.m3u8
CCTV6,http://btjg.net:809/hls/6/index.m3u8
CCTV7,http://btjg.net:809/hls/7/index.m3u8
CCTV8,http://btjg.net:809/hls/8/index.m3u8
CCTV9,http://btjg.net:809/hls/9/index.m3u8
CCTV10,http://btjg.net:809/hls/10/index.m3u8
CCTV11,http://btjg.net:809/hls/11/index.m3u8
CCTV12,http://btjg.net:809/hls/12/index.m3u8
CCTV13,http://btjg.net:809/hls/13/index.m3u8
CCTV13,http://btjg.net:809/hls/16/index.m3u8
CCTV14,http://btjg.net:809/hls/14/index.m3u8
CCTV15,http://btjg.net:809/hls/15/index.m3u8
CCTV17,http://btjg.net:809/hls/119/index.m3u8
安徽卫视,http://btjg.net:809/hls/42/index.m3u8
北京卫视,http://btjg.net:809/hls/43/index.m3u8
兵团卫视,http://btjg.net:809/hls/41/index.m3u8
重庆卫视,http://btjg.net:809/hls/54/index.m3u8
东南卫视,http://btjg.net:809/hls/44/index.m3u8
甘肃卫视,http://btjg.net:809/hls/63/index.m3u8
广东卫视,http://btjg.net:809/hls/32/index.m3u8
广西卫视,http://btjg.net:809/hls/40/index.m3u8
贵州卫视,http://btjg.net:809/hls/34/index.m3u8
海南卫视,http://btjg.net:809/hls/61/index.m3u8
河北卫视,http://btjg.net:809/hls/45/index.m3u8
河南卫视,http://btjg.net:809/hls/55/index.m3u8
黑龙江卫视,http://btjg.net:809/hls/39/index.m3u8
湖北卫视,http://btjg.net:809/hls/31/index.m3u8
湖南卫视,http://btjg.net:809/hls/47/index.m3u8
吉林卫视,http://btjg.net:809/hls/38/index.m3u8
江苏卫视,http://btjg.net:809/hls/30/index.m3u8
江西卫视,http://btjg.net:809/hls/56/index.m3u8
辽宁卫视,http://btjg.net:809/hls/36/index.m3u8
内蒙古卫视汉语,http://btjg.net:809/hls/19/index.m3u8
内蒙古卫视蒙语,http://btjg.net:809/hls/18/index.m3u8
宁夏卫视,http://btjg.net:809/hls/51/index.m3u8
青海卫视,http://btjg.net:809/hls/62/index.m3u8
三沙卫视,http://btjg.net:809/hls/142/index.m3u8
山东卫视,http://btjg.net:809/hls/37/index.m3u8
山西卫视,http://btjg.net:809/hls/33/index.m3u8
陕西卫视,http://btjg.net:809/hls/64/index.m3u8
上海卫视,http://btjg.net:809/hls/35/index.m3u8
深圳卫视,http://btjg.net:809/hls/50/index.m3u8
四川卫视,http://btjg.net:809/hls/48/index.m3u8
天津卫视,http://btjg.net:809/hls/46/index.m3u8
西藏卫视,http://btjg.net:809/hls/140/index.m3u8
新疆卫视,http://btjg.net:809/hls/111/index.m3u8
云南卫视,http://btjg.net:809/hls/53/index.m3u8
浙江卫视,http://btjg.net:809/hls/29/index.m3u8
环球购物,http://btjg.net:809/hls/154/index.m3u8
聚鲨环球,http://btjg.net:809/hls/152/index.m3u8
山东教育,http://btjg.net:809/hls/112/index.m3u8
山东教育,http://btjg.net:809/hls/120/index.m3u8
CETV1,http://btjg.net:809/hls/105/index.m3u8
CETV2,http://btjg.net:809/hls/106/index.m3u8
CETV4,http://btjg.net:809/hls/107/index.m3u8
CGTN阿拉伯语,http://btjg.net:809/hls/148/index.m3u8
CGTN法语,http://btjg.net:809/hls/147/index.m3u8
CNTG俄语,http://btjg.net:809/hls/146/index.m3u8
CNTG英文纪录,http://btjg.net:809/hls/145/index.m3u8
GGTN西班牙语,http://btjg.net:809/hls/72/index.m3u8
GGTN英语,http://btjg.net:809/hls/115/index.m3u8
包头经济,http://btjg.net:809/hls/28/index.m3u8
包头生活服务,http://btjg.net:809/hls/27/index.m3u8
包头新闻综合,http://btjg.net:809/hls/26/index.m3u8
佳嘉卡通,http://btjg.net:809/hls/139/index.m3u8
家有购物,http://btjg.net:809/hls/151/index.m3u8
金鹰纪实,http://btjg.net:809/hls/136/index.m3u8
金鹰卡通,http://btjg.net:809/hls/70/index.m3u8
卡酷少儿,http://btjg.net:809/hls/49/index.m3u8
内蒙古经济生活,http://btjg.net:809/hls/20/index.m3u8
内蒙古蒙语文化,http://btjg.net:809/hls/24/index.m3u8
内蒙古农牧,http://btjg.net:809/hls/22/index.m3u8
内蒙古少儿,http://btjg.net:809/hls/25/index.m3u8
内蒙古文体娱乐,http://btjg.net:809/hls/21/index.m3u8
内蒙古新闻综合,http://btjg.net:809/hls/23/index.m3u8
时尚购物,http://btjg.net:809/hls/150/index.m3u8
央广购物,http://btjg.net:809/hls/153/index.m3u8
优购物,http://btjg.net:809/hls/149/index.m3u8
中国教育1,http://btjg.net:809/hls/126/index.m3u8
中文国际,http://btjg.net:809/hls/144/index.m3u8
中文国际欧洲,http://btjg.net:809/hls/143/index.m3u8

CCTV3,http://117.36.76.86:9901/tsfile/live/0003_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV5,http://117.36.76.86:9901/tsfile/live/0005_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV6,http://117.36.76.86:9901/tsfile/live/0006_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV8,http://117.36.76.86:9901/tsfile/live/0008_1.m3u8?key=txiptv&playlive=1&authid=0
陕西卫视,http://117.36.76.86:9901/tsfile/live/0136_1.m3u8?key=txiptv&playlive=1&authid=0




测试备用,#genre#
https://gitee.com/mytv-android/iptv-api/raw/master/output/result.m3u

CCTV1,http://218.17.33.178:53290/tsfile/live/1001_1.m3u8?key=txiptv
CCTV1,http://112.123.243.37:50085/tsfile/live/0001_1.m3u8
CCTV1,http://39.164.180.36:19901/tsfile/live/0001_2.m3u8?key=txiptv&playlive=0&authid=0
CCTV1,http://iptv.huuc.edu.cn/hls/cctv1hd.m3u8
CCTV1,http://112.27.235.94:8000/hls/1/index.m3u8
CCTV1,https://cc06.tv12.xyz/1.m3u8
CCTV1,http://gslbmgsplive.miguvideo.com/wd_r2/cctv/cctv1hd/1200/index.m3u8?msisdn=20251015060032e36fb3a18c444eb99c24d1f58697d9b5&mdspid=&spid=699004&netType=0&sid=2201057821&pid=2028597139&timestamp=20251015060032&Channel_ID=0116_2600000900-99000-201600010010027&ProgramID=608807420&ParentNodeID=-99&assertID=2201057821&client_ip=106.13.250.83&SecurityKey=20251015060032&promotionId=&mvid=2201057821&mcid=500020&playurlVersion=WX-A1-8.9.2-RELEASE&userid=&jmhm=&videocodec=h264&bean=mgspad&tid=android&conFee=0&puData=2c5b102e31f3c614ab995c0aff0a3614&ddCalcu=421ce6513b8a1000f2fea301cf539c96b1a4
CCTV1,http://3501776.xyz:35455/gaoma/cctv1.m3u8
CCTV1,https://cdn5.163189.xyz/live/cctv1/stream.m3u8
CCTV1,http://lu.wqwqwq.sbs/itv/1000000005000265001.m3u8?cdn=ystenlive
CCTV1,https://hls-gateway.vpstv.net/streams/476879.m3u8
CCTV2,http://112.123.243.37:50085/tsfile/live/0002_1.m3u8
CCTV2,http://39.164.180.36:19901/tsfile/live/0002_1.m3u8?key=txiptv&playlive=0&authid=0
CCTV2,http://112.27.235.94:8000/hls/2/index.m3u8
CCTV2,http://112.132.10.54:9901/tsfile/live/0002_1.m3u8
CCTV2,https://smart.pendy.dpdns.org/Smart.php?id=cctv2
CCTV2,http://iptv.huuc.edu.cn/hls/cctv2hd.m3u8
CCTV2,https://cc06.tv12.xyz/2.m3u8
CCTV2,http://gslbmgsplive.miguvideo.com/wd_r2/cctv/cctv2hd/1500/index.m3u8?msisdn=20251015060032eabc76c3392e4275bc826b6c7d16733c&mdspid=&spid=699004&netType=0&sid=5500346945&pid=2028597139&timestamp=20251015060032&Channel_ID=0116_2600000900-99000-201600010010027&ProgramID=631780532&ParentNodeID=-99&assertID=5500346945&client_ip=106.13.250.83&SecurityKey=20251015060032&promotionId=&mvid=5101064231&mcid=500020&playurlVersion=WX-A1-8.9.2-RELEASE&userid=&jmhm=&videocodec=h264&bean=mgspad&tid=android&conFee=0&puData=60e067b4a8e8d2e10ba213fd56c19d26&ddCalcu=6620ede1901160c76b54daf83e182da2be01
CCTV2,http://3501776.xyz:35455/gaoma/cctv2.m3u8
CCTV2,http://hlsbkmgsplive.miguvideo.com/wd_r2/cctv/cctv2hd/1500/index.m3u8?&encrypt=
CCTV3,http://39.164.180.36:19901/tsfile/live/0001_1.m3u8?key=txiptv&playlive=0&authid=0
CCTV3,http://112.123.243.37:50085/tsfile/live/0003_1.m3u8
CCTV3,https://smart.pendy.dpdns.org/Smart.php?id=cctv3
CCTV3,http://zjzcf.synology.me:35455/gaoma/cctv3.m3u8
CCTV3,http://iptv.huuc.edu.cn/hls/cctv3hd.m3u8
CCTV3,https://cc06.tv12.xyz/3.m3u8
CCTV3,http://gslbmgsplive.miguvideo.com/wd_r2/2018/ocn/cctv3hd/2000/index.m3u8?msisdn=2025101506003280ced506aa504ccfbadea1d10d4dd910&mdspid=&spid=699004&netType=0&sid=5500212864&pid=2028597139&timestamp=20251015060032&Channel_ID=0116_2600000900-99000-201600010010027&ProgramID=624878271&ParentNodeID=-99&assertID=5500212864&client_ip=106.13.250.83&SecurityKey=20251015060032&promotionId=&mvid=5100001683&mcid=500020&playurlVersion=WX-A1-8.9.2-RELEASE&userid=&jmhm=&videocodec=h264&bean=mgspad&tid=android&conFee=0&puData=cc03358dd2c542325d51e3079e482221&ddCalcu=1c2ce20123483045e89d7d023ce51452d352
CCTV3,http://lu.wqwqwq.sbs/itv/1000000005000265003.m3u8?cdn=ystenlive
CCTV3,https://hls-gateway.vpstv.net/streams/476883.m3u8
CCTV4,http://39.164.180.36:19901/tsfile/live/0004_1.m3u8?key=txiptv&playlive=0&authid=0
CCTV4,https://live-play-hls.cctvnews.cctv.com/CCTVChannel/channel_cctv4_mbd.m3u8?auth_key=1760619711-1-pcs96643059f5174b48ab486ec863960de2-547d89f934a8553e18e4d9a36e3e9193&yid=pcs96643059f5174b48ab486ec863960de2
CCTV4,http://112.123.243.37:50085/tsfile/live/0004_1.m3u8
CCTV4,http://112.27.235.94:8000/hls/4/index.m3u8
CCTV4,http://z.b.bkpcp.top/m.php?id=CCTV-4国际
CCTV4,http://iptv.huuc.edu.cn/hls/cctv4hd.m3u8
CCTV4,https://cc06.tv12.xyz/4.m3u8
CCTV4,http://gslbmgsplive.miguvideo.com/wd_r2/cctv/cctv4hd/1500/index.m3u8?msisdn=202510150600322aa4462e5fab46b59baf118230e97d64&mdspid=&spid=699004&netType=0&sid=5500346947&pid=2028597139&timestamp=20251015060032&Channel_ID=0116_2600000900-99000-201600010010027&ProgramID=631780421&ParentNodeID=-99&assertID=5500346947&client_ip=106.13.250.83&SecurityKey=20251015060032&promotionId=&mvid=5101064235&mcid=500020&playurlVersion=WX-A1-8.9.2-RELEASE&userid=&jmhm=&videocodec=h264&bean=mgspad&tid=android&conFee=0&puData=749a10ee03608d78b21894d6715f873a&ddCalcu=a734e7918a1f10501e7e60d34690881d27b8
CCTV4,http://3501776.xyz:35455/itv/1000000005000265004.m3u8?cdn=ystenlive
CCTV4,http://lu.wqwqwq.sbs/itv/1000000005000265004.m3u8?cdn=ystenlive
CCTV5,http://112.27.235.94:8000/hls/5/index.m3u8
CCTV5,http://39.164.180.36:19901/tsfile/live/0005_1.m3u8?key=txiptv&playlive=0&authid=0
CCTV5,http://222.169.85.8:9901/tsfile/live/0005_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV5,http://112.123.243.37:50085/tsfile/live/0005_1.m3u8
CCTV5,http://iptv.huuc.edu.cn/hls/cctv5hd.m3u8
CCTV5,https://smart.pendy.dpdns.org/Smart.php?id=cctv5
CCTV5,https://ldcctvwbcdks.v.kcdnvip.com/ldcctvwbcd/cdrmldcctv5plus_1/index.m3u8?b=200-2100
CCTV5,http://nas.suntao.online:35455/itv/1000000005000265005.m3u8?cdn=ystenlive
CCTV5,https://cc06.tv12.xyz/5.m3u8
CCTV5,http://gslbmgsplive.miguvideo.com/wd_r2/cctv/cctv5hdnew/1200/index.m3u8?msisdn=20251015060033f5b9b021d5d942daabb96372c032dff7&mdspid=&spid=699004&netType=0&sid=5500516171&pid=2028597139&timestamp=20251015060033&Channel_ID=0116_2600000900-99000-201600010010027&ProgramID=641886683&ParentNodeID=-99&assertID=5500516171&client_ip=106.13.250.83&SecurityKey=20251015060033&promotionId=&mvid=5102048712&mcid=500020&playurlVersion=WX-A1-8.9.2-RELEASE&userid=&jmhm=&videocodec=h264&bean=mgspad&tid=android&conFee=0&puData=e9ad29573f7f044204ded7d0f6f636c3&ddCalcu=3ec9e6a13d1620f965f703df77dfe0d44402
CCTV6,http://39.164.180.36:19901/tsfile/live/0006_1.m3u8?key=txiptv&playlive=0&authid=0
CCTV6,http://112.123.243.37:50085/tsfile/live/0007_1.m3u8
CCTV6,http://112.27.235.94:8000/hls/7/index.m3u8
CCTV6,https://smart.pendy.dpdns.org/Smart.php?id=cctv6
CCTV6,http://iptv.huuc.edu.cn/hls/cctv6hd.m3u8
CCTV6,https://cc06.tv12.xyz/7.m3u8
CCTV6,http://gslbmgsplive.miguvideo.com/wd_r2/2018/ocn/cctv6hd/2000/index.m3u8?msisdn=2025101506003370612520fd4045e6a65317a0d82c54c7&mdspid=&spid=699004&netType=0&sid=5500212872&pid=2028597139&timestamp=20251015060033&Channel_ID=0116_2600000900-99000-201600010010027&ProgramID=624878396&ParentNodeID=-99&assertID=5500212872&client_ip=106.13.250.83&SecurityKey=20251015060033&promotionId=&mvid=5100001694&mcid=500020&playurlVersion=WX-A1-8.9.2-RELEASE&userid=&jmhm=&videocodec=h264&bean=mgspad&tid=android&conFee=0&puData=e0948750816bfb1b8dddade0b0c1b295&ddCalcu=5e90e291b44180c705b008e1d6abdfdbd18b
CCTV6,http://mobilelive-timeshift.ysp.cctv.cn/timeshift/ysp/2013693901/timeshift.m3u8?delay=0&cdn=5202
CCTV6,http://cdn.jdshipin.com:8880/ysp.php?id=cctv6
CCTV6,http://mobilelive-ds.ysp.cctv.cn/ysp/2013693901.m3u8
CCTV7,http://112.27.235.94:8000/hls/8/index.m3u8
CCTV7,http://39.164.180.36:19901/tsfile/live/0007_1.m3u8?key=txiptv&playlive=0&authid=0
CCTV7,http://112.123.243.37:50085/tsfile/live/0008_1.m3u8
CCTV7,http://iptv.huuc.edu.cn/hls/cctv7hd.m3u8
CCTV7,https://cc06.tv12.xyz/8.m3u8
CCTV7,http://lu.wqwqwq.sbs/itv/1000000005000265007.m3u8?cdn=ystenlive
CCTV7,http://tvbox6.com/tv/bfgd.php?id=127
CCTV7,https://hls-gateway.vpstv.net/streams/476891.m3u8
CCTV7,https://smart.pendy.dpdns.org/Smart.php
CCTV8,http://39.164.180.36:19901/tsfile/live/0008_1.m3u8?key=txiptv&playlive=0&authid=0
CCTV8,http://112.27.235.94:8000/hls/9/index.m3u8
CCTV8,http://112.123.243.37:50085/tsfile/live/0009_1.m3u8
CCTV8,https://hls-gateway.vpstv.net/streams/476892.m3u8
CCTV8,https://smart.pendy.dpdns.org/Smart.php?id=cctv8hd
CCTV8,http://iptv.huuc.edu.cn/hls/cctv8hd.m3u8
CCTV8,https://cc06.tv12.xyz/9.m3u8
CCTV8,http://gslbmgsplive.miguvideo.com/wd_r2/2018/ocn/cctv8hd/2000/index.m3u8?msisdn=2025101506003327a18f14223848718f76e0499f508497&mdspid=&spid=699004&netType=0&sid=5500212868&pid=2028597139&timestamp=20251015060033&Channel_ID=0116_2600000900-99000-201600010010027&ProgramID=624878356&ParentNodeID=-99&assertID=5500212868&client_ip=106.13.250.83&SecurityKey=20251015060033&promotionId=&mvid=5100001695&mcid=500020&playurlVersion=WX-A1-8.9.2-RELEASE&userid=&jmhm=&videocodec=h264&bean=mgspad&tid=android&conFee=0&puData=387bbb303a61c3adc3983b7a1c70914e&ddCalcu=e348e1719b40b07bc310a37ab6318c933acd
CCTV8,http://3501776.xyz:35455/gaoma/cctv8.m3u8
CCTV8,http://lu.wqwqwq.sbs/itv/1000000005000265008.m3u8?cdn=ystenlive
CCTV9,http://39.164.180.36:19901/tsfile/live/0009_1.m3u8?key=txiptv&playlive=0&authid=0
CCTV9,http://112.123.243.37:50085/tsfile/live/0010_1.m3u8
CCTV9,http://112.132.10.54:9901/tsfile/live/0009_1.m3u8
CCTV9,https://hls-gateway.vpstv.net/streams/476893.m3u8
CCTV9,http://iptv.huuc.edu.cn/hls/cctv9hd.m3u8
CCTV9,https://cc06.tv12.xyz/10.m3u8
CCTV9,http://gslbmgsplive.miguvideo.com/migu/kailu/20200324/cctv9hd/51/index.m3u8?msisdn=202510150600332fd29164c6c341b180d8361bca1e8306&mdspid=&spid=699004&netType=0&sid=5501083624&pid=2028597139&timestamp=20251015060033&Channel_ID=0116_2600000900-99000-201600010010027&ProgramID=673168140&ParentNodeID=-99&assertID=5501083624&client_ip=106.13.250.83&SecurityKey=20251015060033&promotionId=&mvid=5102910384&mcid=500020&playurlVersion=WX-A1-8.9.2-RELEASE&userid=&jmhm=&videocodec=h264&bean=mgspad&tid=android&conFee=0&puData=dbbb855245cac90d570e0407579c5935&ddCalcu=5d3be9b15b3c8095755274054c0aec09705d
CCTV9,http://3501776.xyz:35455/gaoma/cctv9.m3u8
CCTV9,http://hlsbkmgsplive.miguvideo.com/migu/kailu/20200324/cctv9hd/57/index.m3u8?&encrypt=
CCTV9,http://lu.wqwqwq.sbs/itv/1000000005000265009.m3u8?cdn=ystenlive
CCTV10,http://112.123.243.37:50085/tsfile/live/0011_1.m3u8
CCTV10,http://39.164.180.36:19901/tsfile/live/0010_1.m3u8?key=txiptv&playlive=0&authid=0
CCTV10,http://222.169.85.8:9901/tsfile/live/0010_1.m3u8
CCTV10,http://z.b.bkpcp.top/m.php?id=CCTV-10科教科教
CCTV10,https://smart.pendy.dpdns.org/Smart.php?id=cctv10hd
CCTV10,http://iptv.huuc.edu.cn/hls/cctv10hd.m3u8
CCTV10,https://cc06.tv12.xyz/11.m3u8
CCTV10,http://gslbmgsplive.miguvideo.com/wd_r2/2018/ocn/cctv10hd/2000/index.m3u8?msisdn=20251015060033875a5ecf86bb4c6683f714f089e56657&mdspid=&spid=699004&netType=0&sid=5500212874&pid=2028597139&timestamp=20251015060033&Channel_ID=0116_2600000900-99000-201600010010027&ProgramID=624878405&ParentNodeID=-99&assertID=5500212874&client_ip=106.13.250.83&SecurityKey=20251015060033&promotionId=&mvid=5100001696&mcid=500020&playurlVersion=WX-A1-8.9.2-RELEASE&userid=&jmhm=&videocodec=h264&bean=mgspad&tid=android&conFee=0&puData=39f0ca838eab73a1c595725be928c2a3&ddCalcu=33a9e2f1c048c02a98e3b85e2a7b57935ac1
CCTV10,http://3501776.xyz:35455/gaoma/cctv10.m3u8
CCTV10,http://lu.wqwqwq.sbs/itv/1000000005000265010.m3u8?cdn=ystenlive
CCTV11,http://39.164.180.36:19901/tsfile/live/0011_1.m3u8?key=txiptv&playlive=0&authid=0
CCTV11,http://112.123.243.37:50085/tsfile/live/0012_1.m3u8
CCTV11,http://222.169.85.8:9901/tsfile/live/0011_1.m3u8?key=txiptv
CCTV11,http://60.16.0.216:5757/hls/12/index.m3u8
CCTV11,https://smart.pendy.dpdns.org/Smart.php?id=cctv11
CCTV11,http://iptv.huuc.edu.cn/hls/cctv11hd.m3u8
CCTV11,https://cc06.tv12.xyz/12.m3u8
CCTV11,http://gslbmgsplive.miguvideo.com/migu/kailu/cctv11hd/51/20200103/index.m3u8?msisdn=202510150600348391e16693524eb7a5abce9ab8e17af7&mdspid=&spid=699004&netType=0&sid=5500988610&pid=2028597139&timestamp=20251015060034&Channel_ID=0116_2600000900-99000-201600010010027&ProgramID=667987558&ParentNodeID=-99&assertID=5500988610&client_ip=106.13.250.83&SecurityKey=20251015060034&promotionId=&mvid=5102751362&mcid=500020&playurlVersion=WX-A1-8.9.2-RELEASE&userid=&jmhm=&videocodec=h264&bean=mgspad&tid=android&conFee=0&puData=be3765c2fd78cb0d463b3642bcf15935&ddCalcu=5b3ee931577160f5ccb22f4d6738bc3b604d
CCTV11,http://3501776.xyz:35455/itv/1000000005000265011.m3u8?cdn=ystenlive
CCTV11,http://lu.wqwqwq.sbs/itv/1000000005000265011.m3u8?cdn=ystenlive
CCTV12,http://39.164.180.36:19901/tsfile/live/0012_1.m3u8?key=txiptv&playlive=0&authid=0
CCTV12,http://218.17.33.178:53290/tsfile/live/1012_1.m3u8?key=txiptv
CCTV12,http://112.123.243.37:50085/tsfile/live/0013_1.m3u8
CCTV12,http://222.169.85.8:9901/tsfile/live/0012_1.m3u8
CCTV12,http://60.16.0.216:5757/hls/13/index.m3u8
CCTV12,http://112.27.235.94:8000/hls/13/index.m3u8
CCTV12,http://112.132.10.54:9901/tsfile/live/0012_1.m3u8
CCTV12,http://z.b.bkpcp.top/m.php?id=CCTV-12社会与法社会与法
CCTV12,https://smart.pendy.dpdns.org/Smart.php?id=cctv12
CCTV12,http://iptv.huuc.edu.cn/hls/cctv12hd.m3u8
CCTV13,http://112.27.235.94:8000/hls/14/index.m3u8
CCTV13,http://39.164.180.36:19901/tsfile/live/0013_1.m3u8?key=txiptv&playlive=0&authid=0
CCTV13,http://112.123.243.37:50085/tsfile/live/0014_1.m3u8
CCTV13,http://ali-m-l.cztv.com/channels/lantian/channel21/1080p.m3u8
CCTV13,https://event.pull.hebtv.com/jishi/cp1.m3u8
CCTV13,http://z.b.bkpcp.top/m.php?id=cctv13
CCTV13,http://j.x.bkpcp.top/jx/CCTV13HD
CCTV13,http://jwplay.hebyun.com.cn/live/cctv13/1500k/tzwj_video.m3u8
CCTV13,https://ldncctvwbcdcnc.v.wscdns.com/ldncctvwbcd/cdrmldcctv13_1/index.m3u8
CCTV13,https://hls-gateway.vpstv.net/streams/476899.m3u8
CCTV14,http://39.164.180.36:19901/tsfile/live/0014_1.m3u8?key=txiptv&playlive=0&authid=0
CCTV14,http://112.123.243.37:50085/tsfile/live/0015_1.m3u8
CCTV14,http://222.169.85.8:9901/tsfile/live/0014_1.m3u8?key=txiptv
CCTV14,https://event.pull.hebtv.com/jishi/cp2.m3u8#rtsp://103.251.96.71/PLTV/88888888/224/3221225783/10000100000000060000000000726027_0.smil?icpid=SSPID&amp;accounttype=1&amp;limitflux=-1&amp;limitdur=-1&amp;accountinfo=:20240213104135
CCTV14,https://hls-gateway.vpstv.net/streams/476900.m3u8
CCTV14,http://iptv.huuc.edu.cn/hls/cctv14hd.m3u8
CCTV14,https://cc06.tv12.xyz/15.m3u8
CCTV14,http://gslbmgsplive.miguvideo.com/wd_r2/2018/ocn/cctv14hd/2000/index.m3u8?msisdn=20251015060034a60ab827388244818a921008bafd3152&mdspid=&spid=699004&netType=0&sid=5500212875&pid=2028597139&timestamp=20251015060034&Channel_ID=0116_2600000900-99000-201600010010027&ProgramID=624878440&ParentNodeID=-99&assertID=5500212875&client_ip=106.13.250.83&SecurityKey=20251015060034&promotionId=&mvid=5100001697&mcid=500020&playurlVersion=WX-A1-8.9.2-RELEASE&userid=&jmhm=&videocodec=h264&bean=mgspad&tid=android&conFee=0&puData=44740b3f2952bea2ede3af30cea4664b&ddCalcu=b444e671644400abe3cf0239f5a23beedae2
CCTV14,http://3501776.xyz:35455/gaoma/cctv14.m3u8
CCTV14,http://lu.wqwqwq.sbs/itv/1000000005000265013.m3u8?cdn=ystenlive
CCTV15,http://112.27.235.94:8000/hls/16/index.m3u8
CCTV15,http://112.123.243.37:50085/tsfile/live/0016_1.m3u8
CCTV15,http://112.132.10.54:9901/tsfile/live/0015_1.m3u8?key=txiptv&playlive=0&authid=0
CCTV15,https://smart.pendy.dpdns.org/Smart.php?id=cctv15
CCTV15,https://hls-gateway.vpstv.net/streams/476901.m3u8
CCTV15,https://cc06.tv12.xyz/16.m3u8
CCTV15,http://gslbmgsplive.miguvideo.com/migu/kailu/20200324/cctv15hd/51/index.m3u8?msisdn=20251015060034640a7ab5fefe4beb8b0d6d7f2977d016&mdspid=&spid=699004&netType=0&sid=5501083628&pid=2028597139&timestamp=20251015060034&Channel_ID=0116_2600000900-99000-201600010010027&ProgramID=673168223&ParentNodeID=-99&assertID=5501083628&client_ip=106.13.250.83&SecurityKey=20251015060034&promotionId=&mvid=5102910391&mcid=500020&playurlVersion=WX-A1-8.9.2-RELEASE&userid=&jmhm=&videocodec=h264&bean=mgspad&tid=android&conFee=0&puData=b5f45d1918cc80c01da17132701bae57&ddCalcu=7b55eef1a43b501d017921381c7c18a0dc10
CCTV15,http://3501776.xyz:35455/itv/1000000005000265014.m3u8?cdn=ystenlive
CCTV15,http://lu.wqwqwq.sbs/itv/1000000005000265014.m3u8?cdn=ystenlive
CCTV15,http://tvbox6.com/tv/bfgd.php?id=133
CCTV16,https://hls-gateway.vpstv.net/streams/709089.m3u8
CCTV16,https://yunmei.tv/main/cctv-16.m3u8
CCTV16,http://lu.wqwqwq.sbs/itv/1000000006000233002.m3u8?cdn=ystenlive
CCTV16,http://livetv.wqwqwq.sbs/gaoma/cctv4k16.m3u8
CCTV17,http://222.169.85.8:9901/tsfile/live/0007_1.m3u8?key=txiptv&playlive=1&authid=0
CCTV17,https://cc06.tv12.xyz/17.m3u8
CCTV17,https://jzb.wwkejishe.top/?id=594
CCTV17,http://gslbmgsplive.miguvideo.com/migu/kailu/20200324/cctv17hd/51/index.m3u8?msisdn=20251015060034c568ddc47357442b8fec64ac9dc0b459&mdspid=&spid=699004&netType=0&sid=5501083631&pid=2028597139&timestamp=20251015060034&Channel_ID=0116_2600000900-99000-201600010010027&ProgramID=673168256&ParentNodeID=-99&assertID=5501083631&client_ip=106.13.250.83&SecurityKey=20251015060034&promotionId=&mvid=5102910396&mcid=500020&playurlVersion=WX-A1-8.9.2-RELEASE&userid=&jmhm=&videocodec=h264&bean=mgspad&tid=android&conFee=0&puData=0e93dd0c9575f692db310cd490bb5a7d&ddCalcu=d07eea91533bd0bd009c49d5c7051f36b9d2
CCTV17,http://3501776.xyz:35455/itv/1000000005000265015.m3u8?cdn=ystenlive
CCTV17,http://lu.wqwqwq.sbs/itv/1000000005000265015.m3u8?cdn=ystenlive
CCTV17,http://tvbox6.com/tv/bfgd.php?id=204
CCTV17,https://hls-gateway.vpstv.net/streams/708820.m3u8
CCTV5+,http://218.17.33.178:53290/tsfile/live/1005_1.m3u8?key=txiptv
CCTV5+,http://112.123.243.37:50085/tsfile/live/0006_1.m3u8
CCTV5+,http://39.164.180.36:19901/tsfile/live/0016_1.m3u8?key=txiptv&playlive=0&authid=0
CCTV5+,http://222.169.85.8:9901/tsfile/live/0116_1.m3u8
CCTV5+,https://smart.pendy.dpdns.org/Smart.php?id=cctv5plus
CCTV5+,http://nas.suntao.online:35455/itv/6000000001000015875.m3u8?cdn=wasusyt
CCTV5+,https://hls-gateway.vpstv.net/streams/476888.m3u8
CCTV5+,https://cc06.tv12.xyz/6.m3u8
CCTV5+,http://gslbmgsplive.miguvideo.com/wd_r2/cctv/cctv5plusnew/1200/index.m3u8?msisdn=20251015060033356055c9d8704d2bb94e2c86804fc90d&mdspid=&spid=699004&netType=0&sid=5500516288&pid=2028597139&timestamp=20251015060033&Channel_ID=0116_2600000900-99000-201600010010027&ProgramID=641886773&ParentNodeID=-99&assertID=5500516288&client_ip=106.13.250.83&SecurityKey=20251015060033&promotionId=&mvid=5102048803&mcid=500020&playurlVersion=WX-A1-8.9.2-RELEASE&userid=&jmhm=&videocodec=h264&bean=mgspad&tid=android&conFee=0&puData=8982ba8f60d1e70beb7602ab67fc81ad&ddCalcu=d8a9e181821cb0fa786fb6a02d016e77b0eb
CCTV5+,http://3501776.xyz:35455/itv/1000000005000265016.m3u8?cdn=ystenlive
CETV1,http://rrs01.hw.gmcc.net:8088/PLTV/81/224/3221226673/1.m3u8
CETV1,https://cc06.tv12.xyz/23.m3u8
CETV1,http://gslbmgsplive.miguvideo.com/migu/kailu/cetv1/51/20240709/index.m3u8?msisdn=202510150801562737315e1fe34321ab7ef64db53de0b5&mdspid=&spid=699004&netType=0&sid=5910022150&pid=2028597139&timestamp=20251015080156&Channel_ID=0116_2600000900-99000-201600010010027&ProgramID=923287154&ParentNodeID=-99&assertID=5910022150&client_ip=106.13.250.83&SecurityKey=20251015080156&promotionId=&mvid=5900006636&mcid=500020&playurlVersion=WX-A1-8.9.2-RELEASE&userid=&jmhm=&videocodec=h264&bean=mgspad&tid=android&conFee=0&puData=109f568db5e00ba3463eb2d97293915c&ddCalcu=c150e1919f335096287d9bd52eb0e03b6a43
CETV2,http://rrs01.hw.gmcc.net:8088/PLTV/81/224/3221226718/1.m3u8
CETV2,https://cc06.tv12.xyz/24.m3u8
CETV2,http://gslbmgsplive.miguvideo.com/migu/kailu/cetv2/50/20240709/index.m3u8?msisdn=20250903090033bf55eab2bb984fe0b4ac863e60d28ac6&mdspid=&spid=699004&netType=0&sid=5910022152&pid=2028597139&timestamp=20250903090033&Channel_ID=0116_2600037000-99000-200300220100002&ProgramID=923287211&ParentNodeID=-99&assertID=5910022152&client_ip=106.13.250.83&SecurityKey=20250903090033&promotionId=&mvid=5900006638&mcid=500020&playurlVersion=WX-A1-8.8.1-RELEASE&userid=&jmhm=&videocodec=h264&bean=mgspad&tid=android&conFee=0&puData=ebfbdc6c83654112720d2b5599373223&ddCalcu=3e2bv2fa3ba7da3c969c5853b625d4012172&sv=10004&ct=android
CETV4,https://gcalic.v.myalicdn.com/gc/wgw05_1/index.m3u8?contentid=2820180516001
CETV4,http://rrs01.hw.gmcc.net:8088/PLTV/81/224/3221226724/1.m3u8
CETV4,http://gslbmgsplive.miguvideo.com/migu/kailu/cetv4/51/20240709/index.m3u8?msisdn=20251015080156ac7cc9d98f16472784ef3fc44afd2f05&mdspid=&spid=699004&netType=0&sid=5910022154&pid=2028597139&timestamp=20251015080156&Channel_ID=0116_2600000900-99000-201600010010027&ProgramID=923287339&ParentNodeID=-99&assertID=5910022154&client_ip=106.13.250.83&SecurityKey=20251015080156&promotionId=&mvid=5900006640&mcid=500020&playurlVersion=WX-A1-8.9.2-RELEASE&userid=&jmhm=&videocodec=h264&bean=mgspad&tid=android&conFee=0&puData=67557c98c946f706f4999187b69cbd9a&ddCalcu=a697ed51b53c709c69b87c8914969f9740f6
CETV1,http://rrs01.hw.gmcc.net:8088/PLTV/81/224/3221226673/1.m3u8
CETV1,https://cc06.tv12.xyz/23.m3u8
CETV1,http://gslbmgsplive.miguvideo.com/migu/kailu/cetv1/51/20240709/index.m3u8?msisdn=202510150801562737315e1fe34321ab7ef64db53de0b5&mdspid=&spid=699004&netType=0&sid=5910022150&pid=2028597139&timestamp=20251015080156&Channel_ID=0116_2600000900-99000-201600010010027&ProgramID=923287154&ParentNodeID=-99&assertID=5910022150&client_ip=106.13.250.83&SecurityKey=20251015080156&promotionId=&mvid=5900006636&mcid=500020&playurlVersion=WX-A1-8.9.2-RELEASE&userid=&jmhm=&videocodec=h264&bean=mgspad&tid=android&conFee=0&puData=109f568db5e00ba3463eb2d97293915c&ddCalcu=c150e1919f335096287d9bd52eb0e03b6a43
CETV2,http://rrs01.hw.gmcc.net:8088/PLTV/81/224/3221226718/1.m3u8
CETV2,https://cc06.tv12.xyz/24.m3u8
CETV2,http://gslbmgsplive.miguvideo.com/migu/kailu/cetv2/50/20240709/index.m3u8?msisdn=20250903090033bf55eab2bb984fe0b4ac863e60d28ac6&mdspid=&spid=699004&netType=0&sid=5910022152&pid=2028597139&timestamp=20250903090033&Channel_ID=0116_2600037000-99000-200300220100002&ProgramID=923287211&ParentNodeID=-99&assertID=5910022152&client_ip=106.13.250.83&SecurityKey=20250903090033&promotionId=&mvid=5900006638&mcid=500020&playurlVersion=WX-A1-8.8.1-RELEASE&userid=&jmhm=&videocodec=h264&bean=mgspad&tid=android&conFee=0&puData=ebfbdc6c83654112720d2b5599373223&ddCalcu=3e2bv2fa3ba7da3c969c5853b625d4012172&sv=10004&ct=android
CETV3,http://rrs01.hw.gmcc.net:8088/PLTV/81/224/3221226722/1.m3u8
CETV3,http://ott.mobaibox.com/PLTV/3/224/3221227018/index.m3u8
CETV4,http://rrs01.hw.gmcc.net:8088/PLTV/81/224/3221226724/1.m3u8
CETV4,http://gslbmgsplive.miguvideo.com/migu/kailu/cetv4/51/20240709/index.m3u8?msisdn=20251015080156ac7cc9d98f16472784ef3fc44afd2f05&mdspid=&spid=699004&netType=0&sid=5910022154&pid=2028597139&timestamp=20251015080156&Channel_ID=0116_2600000900-99000-201600010010027&ProgramID=923287339&ParentNodeID=-99&assertID=5910022154&client_ip=106.13.250.83&SecurityKey=20251015080156&promotionId=&mvid=5900006640&mcid=500020&playurlVersion=WX-A1-8.9.2-RELEASE&userid=&jmhm=&videocodec=h264&bean=mgspad&tid=android&conFee=0&puData=67557c98c946f706f4999187b69cbd9a&ddCalcu=a697ed51b53c709c69b87c8914969f9740f6


文化精品,https://hls-gateway.vpstv.net/streams/708832.m3u8
央视台球,https://hls-gateway.vpstv.net/streams/708855.m3u8
风云音乐,https://hls-gateway.vpstv.net/streams/708858.m3u8
第一剧场,http://iptv.4666888.xyz/iptv2A.php?id=13
第一剧场,https://hls-gateway.vpstv.net/streams/708862.m3u8
第一剧场,http://tl.061833.xyz/tl/null-6
第一剧场,https://100.061833.xyz/stream/mytv/null-6/stream.m3u8?uid=2190244325&u=hahayy&p=29624e2e4c4ccee26ed8f3e0ca1012ea57a8f2191be6149f632250f7036119cc
风云剧场,https://hls-gateway.vpstv.net/streams/708861.m3u8
怀旧剧场,https://cc06.tv12.xyz/52.m3u8
怀旧剧场,https://hls-gateway.vpstv.net/streams/708853.m3u8
女性时尚,https://cc06.tv12.xyz/95.m3u8
高尔夫网球,https://hls-gateway.vpstv.net/streams/708857.m3u8
风云足球,https://hls-gateway.vpstv.net/streams/708859.m3u8
风云足球,https://cc06.tv12.xyz/41.m3u8
电视指南,https://cc06.tv12.xyz/39.m3u8
世界地理,https://cc06.tv12.xyz/104.m3u8
兵器科技,https://hls-gateway.vpstv.net/streams/708856.m3u8

广东卫视,https://txmov2.a.kwimgs.com/upic/2023/01/26/09/BMjAyMzAxMjYwOTE3NDVfNzM5MzQzNzIyXzk0NjI1OTUwNTA3XzBfMw==_b_B81ddda927d33445d544befd008e60109.mp4
广东卫视,http://39.164.180.36:19901/tsfile/live/0125_1.m3u8?key=txiptv&playlive=0&authid=0
广东卫视,http://222.169.85.8:9901/tsfile/live/0125_1.m3u8?#rtsp://116.176.26.18/PLTV/88888910/224/3221225527/10000100000000060000000000107307_0.smil#rtsp://60.13.39.18/PLTV/88888910/224/3221225551/10000100000000060000000000107331_0.smil
广东卫视,http://z.b.bkpcp.top/m.php?id=gdws
广东卫视,http://j.x.bkpcp.top/jx/GUANGDHD
广东卫视,http://3501776.xyz:35455/itv/1000000005000265034.m3u8?cdn=ystenlive
广东卫视,http://dsk.cc/php/xxtv.php?id=gdws
广东卫视,http://iptv.huuc.edu.cn/hls/gdhd.m3u8
广东卫视,http://dsj.motem.top:8880/bptv/10000100000000050000000003873459.m3u8
广东卫视,https://cc06.tv12.xyz/43.m3u8
香港卫视,http://cctvtxyh5c.liveplay.myqcloud.com/cstv/xianggangweishi_2/index.m3u8
香港卫视,https://yvxymm.tv12.xyz/175.m3u8
浙江卫视,https://ali-m-l.cztv.com/channels/lantian/channel001/1080p.m3u8
浙江卫视,http://39.164.180.36:19901/tsfile/live/0124_1.m3u8?key=txiptv&playlive=0&authid=0
浙江卫视,http://112.27.235.94:8000/hls/29/index.m3u8
浙江卫视,http://61.163.181.78:85/tsfile/live/1035_1.m3u8?key=txiptv&playlive=1&authid=0#rtsp://221.7.61.147/PLTV/88888910/224/3221225530/10000100000000060000000000107310_0.smil
浙江卫视,http://112.132.10.54:9901/tsfile/live/1007_1.m3u8
浙江卫视,http://cssbyd.imwork.net:8082/hls/22/index.m3u8
浙江卫视,http://z.b.bkpcp.top/m.php?id=zjws
浙江卫视,http://3501776.xyz:35455/itv/1000000005000265031.m3u8?cdn=ystenlive
浙江卫视,http://dsk.cc/php/xxtv.php?id=zjws
浙江卫视,http://iptv.huuc.edu.cn/hls/zjhd.m3u8
湖南卫视,https://txmov2.a.kwimgs.com/bs3/video-hls/5199687338554291078_hlsb.m3u8
湖南卫视,http://39.164.180.36:19901/tsfile/live/0128_2.m3u8?key=txiptv&playlive=0&authid=0
湖南卫视,http://218.17.33.178:53290/tsfile/live/0128_1.m3u8?key=txiptv
湖南卫视,http://antvlive.ab5c6921.cdnviet.com/antv/playlist.m3u8
湖南卫视,http://61.163.181.78:85/tsfile/live/1045_1.m3u8?key=txiptv&playlive=1&authid=0
湖南卫视,http://222.169.85.8:9901/tsfile/live/0128_1.m3u8?key=txiptv&playlive=1&authid=0
湖南卫视,http://z.b.bkpcp.top/m.php?id=hunws
湖南卫视,http://j.x.bkpcp.top/jx/HUNANHD
湖南卫视,http://3501776.xyz:35455/itv/1000000005000265024.m3u8?cdn=ystenlive
湖南卫视,http://dsk.cc/php/xxtv.php?id=hunws
北京卫视,http://39.164.180.36:19901/tsfile/live/0122_1.m3u8?key=txiptv&playlive=0&authid=0
北京卫视,http://183.215.134.239:19901/tsfile/live/0122_1.m3u8?key=txiptv&playlive=1&authid=0
北京卫视,http://112.27.235.94:8000/hls/27/index.m3u8
北京卫视,http://z.b.bkpcp.top/m.php?id=bjws
北京卫视,http://j.x.bkpcp.top/jx/BEIJHD
北京卫视,http://3501776.xyz:35455/itv/1000000005000265027.m3u8?cdn=ystenlive
北京卫视,http://dsk.cc/bjtv/btime.php?id=bjws
北京卫视,http://iptv.huuc.edu.cn/hls/btv1hd.m3u8
北京卫视,https://cc06.tv12.xyz/27.m3u8
北京卫视,http://lu.wqwqwq.sbs/itv/1000000005000265027.m3u8?cdn=ystenlive
湖北卫视,http://39.164.180.36:19901/tsfile/live/0132_1.m3u8?key=txiptv&playlive=0&authid=0
湖北卫视,http://222.169.85.8:9901/tsfile/live/0132_1.m3u8?key=txiptv&playlive=1&authid=0
湖北卫视,http://112.123.243.37:50085/tsfile/live/1001_1.m3u8
湖北卫视,http://112.132.10.54:9901/tsfile/live/1027_1.m3u8
湖北卫视,http://z.b.bkpcp.top/m.php?id=hubws
湖北卫视,http://j.x.bkpcp.top/jx/HUBEIHD
湖北卫视,http://3501776.xyz:35455/itv/1000000005000265023.m3u8?cdn=ystenlive
湖北卫视,http://dsk.cc/php/xxtv.php?id=hubws
湖北卫视,https://smart.pendy.dpdns.org/Smart.php?id=hubei
湖北卫视,http://iptv.huuc.edu.cn/hls/hbhd.m3u8
黑龙江卫视,https://s1.abntelevision.com/avivamientoabr/stream/avivamientohd/avivamientohd/chunks.m3u8
黑龙江卫视,http://39.164.180.36:19901/tsfile/live/0143_1.m3u8?key=txiptv&playlive=0&authid=0
黑龙江卫视,http://112.27.235.94:8000/hls/48/index.m3u8
黑龙江卫视,http://j.x.bkpcp.top/jx/HEILJHD
黑龙江卫视,http://dsk.cc/php/xxtv.php?id=hljws
黑龙江卫视,https://hls-gateway.vpstv.net/streams/708854.m3u8
黑龙江卫视,http://iptv.huuc.edu.cn/hls/hljhd.m3u8
黑龙江卫视,https://cc06.tv12.xyz/53.m3u8
黑龙江卫视,http://lu.wqwqwq.sbs/itv/1000000001000001925.m3u8?cdn=ystenlive
黑龙江卫视,http://tvbox6.com/tv/bfgd.php?id=095
安徽卫视,http://39.164.180.36:19901/tsfile/live/0130_1.m3u8?key=txiptv&playlive=0&authid=0
安徽卫视,http://112.27.235.94:8000/hls/26/index.m3u8
安徽卫视,http://112.123.243.37:50085/tsfile/live/0130_1.m3u8?key=txiptv&playlive=0&authid=0
安徽卫视,http://222.169.85.8:9901/tsfile/live/0130_1.m3u8?key=txiptv&playlive=1&authid=0
安徽卫视,http://j.x.bkpcp.top/jx/ANHUIHD
安徽卫视,http://dsk.cc/php/xxtv.php?id=ahws
安徽卫视,http://iptv.huuc.edu.cn/hls/ahhd.m3u8
安徽卫视,https://cc06.tv12.xyz/26.m3u8
安徽卫视,http://3501776.xyz:35455/itv/1000000005000265025.m3u8?cdn=ystenlive
安徽卫视,http://lu.wqwqwq.sbs/itv/1000000005000265025.m3u8?cdn=ystenlive
重庆卫视,http://39.164.180.36:19901/tsfile/live/0142_1.m3u8?key=txiptv&playlive=0&authid=0
重庆卫视,http://112.132.10.54:9901/tsfile/live/0142_1.m3u8
重庆卫视,http://z.b.bkpcp.top/m.php?id=cqws
重庆卫视,http://j.x.bkpcp.top/jx/CHONGQHD
重庆卫视,http://dsk.cc/php/xxtv.php?id=cqws
重庆卫视,http://iptv.huuc.edu.cn/hls/cqhd.m3u8
重庆卫视,https://cc06.tv12.xyz/34.m3u8
重庆卫视,http://3501776.xyz:35455/itv/1000000005000265017.m3u8?cdn=ystenlive
重庆卫视,http://lu.wqwqwq.sbs/itv/1000000005000265017.m3u8?cdn=ystenlive
重庆卫视,http://tvbox6.com/tv/bfgd.php?id=107
东方卫视,https://txmov2.a.kwimgs.com/bs3/video-hls/5219953535631090825_hlsb.m3u8
东方卫视,http://39.164.180.36:19901/tsfile/live/0107_1.m3u8?key=txiptv&playlive=0&authid=0
东方卫视,http://z.b.bkpcp.top/m.php?id=dfws#rtsp://115.85.232.19/PLTV/88888910/224/3221225531/10000100000000060000000000107311_0.smil
东方卫视,http://3501776.xyz:35455/itv/1000000005000265018.m3u8?cdn=ystenlive
东方卫视,http://dsk.cc/php/xxtv.php?id=dfws
东方卫视,https://cc06.tv12.xyz/37.m3u8
东方卫视,http://iptv.huuc.edu.cn/hls/dfhd.m3u8
东方卫视,http://gslbmgsplive.miguvideo.com/wd_r4/dfl/dongfangwshd/1200/index.m3u8?msisdn=20251015060036ccfaa22ff8d040b4b2c740d5ed502d76&mdspid=&spid=600697&netType=0&sid=5910022185&pid=2028597139&timestamp=20251015060036&Channel_ID=0116_2600000900-99000-201600010010027&ProgramID=651632648&ParentNodeID=-99&assertID=5910022185&client_ip=106.13.250.83&SecurityKey=20251015060036&promotionId=&mvid=5100043384&mcid=500020&playurlVersion=WX-A1-8.9.2-RELEASE&userid=&jmhm=&videocodec=h264&bean=mgspad&tid=android&conFee=0&puData=89d41d8c5efa8526787f83e0dd57d8b3&ddCalcu=38b9e8d1d417105dd8dc05ee3f8af8758276
东方卫视,http://lu.wqwqwq.sbs/itv/1000000005000265018.m3u8?cdn=ystenlive
东方卫视,http://tvbox6.com/tv/bfgd.php?id=093
东南卫视,http://39.164.180.36:19901/tsfile/live/0137_1.m3u8?key=txiptv&playlive=0&authid=0
东南卫视,http://z.b.bkpcp.top/m.php?id=dnws
东南卫视,http://j.x.bkpcp.top/jx/DONGNHD
东南卫视,http://dsk.cc/php/xxtv.php?id=dnws
东南卫视,http://iptv.huuc.edu.cn/hls/dnhd.m3u8
东南卫视,https://cc06.tv12.xyz/38.m3u8
东南卫视,http://3501776.xyz:35455/itv/1000000005000265033.m3u8?cdn=ystenlive
东南卫视,http://lu.wqwqwq.sbs/itv/1000000005000265033.m3u8?cdn=ystenlive
东南卫视,http://tvbox6.com/tv/bfgd.php?id=483
东南卫视,http://live.zohi.tv/video/s10001-fztv-3/index.m3u8
甘肃卫视,http://39.164.180.36:19901/tsfile/live/0141_1.m3u8?key=txiptv&playlive=0&authid=0
甘肃卫视,http://218.17.33.178:53290/tsfile/live/0141_1.m3u8?key=txiptv
甘肃卫视,http://112.132.10.54:9901/tsfile/live/0141_1.m3u8
甘肃卫视,http://live.zohi.tv/video/s10001-fztv-3/index.m3u8
甘肃卫视,http://z.b.bkpcp.top/m.php?id=gsws
甘肃卫视,http://j.x.bkpcp.top/jx/GSWS
甘肃卫视,http://3501776.xyz:35455/itv/5000000011000031121.m3u8?cdn=bestzb
甘肃卫视,http://dsk.cc/php/xxtv.php?id=gsws
甘肃卫视,https://cc06.tv12.xyz/44.m3u8
甘肃卫视,http://tvbox6.com/tv/bfgd.php?id=119
广西卫视,http://39.164.180.36:19901/tsfile/live/0113_1.m3u8?key=txiptv&playlive=0&authid=0
广西卫视,http://222.169.85.8:9901/tsfile/live/0113_1.m3u8?key=txiptv&playlive=1&authid=0#rtsp://115.85.232.19/PLTV/88888910/224/3221225552/10000100000000060000000000107332_0.smil
广西卫视,http://z.b.bkpcp.top/m.php?id=gxws
广西卫视,http://3501776.xyz:35455/itv/5000000011000031118.m3u8?cdn=bestzb
广西卫视,https://mobilelive.gxtv.cn/live/gx_live1004/playlist.m3u8
广西卫视,http://live.cztv.cc:85/live/ggpd.m3u8
广西卫视,http://dsk.cc/php/xxtv.php?id=gxws
广西卫视,https://smart.pendy.dpdns.org/Smart.php?id=guangxi
广西卫视,https://hlscdn.liangtv.cn/live/de0f97348eb84f62aa6b7d8cf0430770/dd505d87880c478f901f38560ca4d4e6.m3u8
广西卫视,https://cc06.tv12.xyz/46.m3u8
贵州卫视,http://39.164.180.36:19901/tsfile/live/0120_1.m3u8?key=txiptv&playlive=0&authid=0
贵州卫视,http://112.123.243.37:50085/tsfile/live/0130_2.m3u8
贵州卫视,http://cssbyd.imwork.net:8082/hls/39/index.m3u8
贵州卫视,http://222.169.85.8:9901/tsfile/live/0120_1.m3u8?key=txiptv&playlive=1&authid=0
贵州卫视,http://z.b.bkpcp.top/m.php?id=gzws
贵州卫视,http://j.x.bkpcp.top/jx/GUIZHD
贵州卫视,http://3501776.xyz:35455/itv/5000000004000025843.m3u8?cdn=bestzb
贵州卫视,http://dsk.cc/php/xxtv.php?id=gzws
贵州卫视,https://cc06.tv12.xyz/48.m3u8
贵州卫视,http://lu.wqwqwq.sbs/itv/5000000004000025843.m3u8?cdn=bestzb
海南卫视,http://nn.7x9d.cn/地方台8563/海南.php?id=hnws&?key=txiptv
海南卫视,http://112.132.10.54:9901/tsfile/live/1023_1.m3u8
海南卫视,http://z.b.bkpcp.top/m.php?id=hinws
海南卫视,http://j.x.bkpcp.top/jx/HAINHD
海南卫视,http://3501776.xyz:35455/itv/5000000004000006211.m3u8?cdn=bestzb
海南卫视,https://cc06.tv12.xyz/93.m3u8
海南卫视,http://gslbmgsplive.miguvideo.com/envivo_x/SD/lvyou/711/index.m3u8?msisdn=202510150600372736847065384130bd5318a72dc8106a&mdspid=&spid=600633&netType=0&sid=5910022165&pid=2028597139&timestamp=20251015060037&Channel_ID=0116_2600000900-99000-201600010010027&ProgramID=947472502&ParentNodeID=-99&assertID=5910022165&client_ip=106.13.250.83&SecurityKey=20251015060037&promotionId=&mvid=5900004359&mcid=500020&playurlVersion=WX-A1-8.9.2-RELEASE&userid=&jmhm=&videocodec=h264&bean=mgspad&tid=android&conFee=0&puData=d95657495de45684e9a710d294d38b8e&ddCalcu=ed89eb51867350d7449925dd0e1475a698e4
海南卫视,http://lu.wqwqwq.sbs/itv/5000000004000006211.m3u8?cdn=bestzb
海南卫视,http://tvbox6.com/tv/bfgd.php?id=473
海南卫视,http://live.wqwqwq.sbs/itv/5000000004000006211.m3u8?cdn=bestzb
河北卫视,http://39.164.180.36:19901/tsfile/live/0117_1.m3u8?key=txiptv&playlive=0&authid=0
河北卫视,http://112.123.243.37:50085/tsfile/live/0018_1.m3u8
河北卫视,http://z.b.bkpcp.top/m.php?id=hbws
河北卫视,https://jwplay.hebyun.com.cn/live/hbwstv/1500k/tzwj_video.m3u8
河北卫视,http://dsk.cc/php/xxtv.php?id=hbws
河北卫视,http://iptv.huuc.edu.cn/hls/hebhd.m3u8
河北卫视,https://cc06.tv12.xyz/51.m3u8
河北卫视,http://tv.pull.hebtv.com/jishi/weishipindao.m3u8?t=2510710360&k=3d44740039027301acf8341d7361ab59
河北卫视,http://lu.wqwqwq.sbs/itv/5000000006000040016.m3u8?cdn=bestzb
河北卫视,http://live.wqwqwq.sbs/itv/5000000006000040016.m3u8?cdn=bestzb
河南卫视,http://lxajh.top/tv/hn.php?id=hnws
河南卫视,http://1.94.31.214/php/hntv.php?id=hnws
河南卫视,http://112.27.235.94:8000/hls/37/index.m3u8
河南卫视,http://tvpull.dxhmt.cn:9081/tv/11425-1.m3u8#http://1.94.31.214/php/hntv.php?id=hnws
河南卫视,http://z.b.bkpcp.top/m.php?id=hnws
河南卫视,http://j.x.bkpcp.top/jx/HENHD
河南卫视,http://3501776.xyz:35455/itv/1000000002000027731.m3u8?cdn=ystenlive
河南卫视,https://cc06.tv12.xyz/49.m3u8
河南卫视,http://gslbmgsplive.miguvideo.com/wd-henanwssd-600/index.m3u8?msisdn=2025101506003749ac759a1d77423a9cf7e799d87c1ef7&mdspid=&spid=600633&netType=0&sid=5910021585&pid=2028597139&timestamp=20251015060037&Channel_ID=0116_2600000900-99000-201600010010027&ProgramID=790187291&ParentNodeID=-99&assertID=5910021585&client_ip=106.13.250.83&SecurityKey=20251015060037&promotionId=&mvid=5900005706&mcid=500020&playurlVersion=WX-A1-8.9.2-RELEASE&userid=&jmhm=&videocodec=h264&bean=mgspad&tid=android&conFee=0&puData=16558795102fea05d58ba7c0126316b1&ddCalcu=11b6e65115038067291501c072afbe8a50d5
河南卫视,http://tvcdn.stream3.hndt.com/tv/65c4a6d5017e1000b2b6ea2500000000_transios/playlist.m3u8?wsSecret=04e32a3bd883f58fb71ed009a6a8b7c6&wsTime=1740891619
吉林卫视,http://39.164.180.36:19901/tsfile/live/0116_1.m3u8?key=txiptv&playlive=0&authid=0
吉林卫视,http://z.b.bkpcp.top/m.php?id=jlws
吉林卫视,http://j.x.bkpcp.top/jx/JILHD
吉林卫视,http://dsk.cc/php/xxtv.php?id=jlws
吉林卫视,https://cc06.tv12.xyz/60.m3u8
吉林卫视,http://gslbmgsplive.miguvideo.com/envivo_v/2018/SD/jilin/1000/index.m3u8?msisdn=20251015060037848b11276df540e482d609f1bb7e7e9c&mdspid=&spid=600633&netType=0&sid=5910022164&pid=2028597139&timestamp=20251015060037&Channel_ID=0116_2600000900-99000-201600010010027&ProgramID=947472500&ParentNodeID=-99&assertID=5910022164&client_ip=106.13.250.83&SecurityKey=20251015060037&promotionId=&mvid=5900004357&mcid=500020&playurlVersion=WX-A1-8.9.2-RELEASE&userid=&jmhm=&videocodec=h264&bean=mgspad&tid=android&conFee=0&puData=102bef9210aa0185b19451a9600fbe60&ddCalcu=0160ee21bb7fe00f096291a01a5a409118b5
吉林卫视,http://tvbox6.com/tv/bfgd.php?id=097
吉林卫视,https://hls-gateway.vpstv.net/streams/708844.m3u8
江苏卫视,http://112.27.235.94:8000/hls/32/index.m3u8
江苏卫视,http://39.164.180.36:19901/tsfile/live/0127_1.m3u8?key=txiptv&playlive=0&authid=0
江苏卫视,http://61.163.181.78:85/tsfile/live/1044_1.m3u8?key=txiptv&playlive=1&authid=0
江苏卫视,http://222.169.85.8:9901/tsfile/live/0127_1.m3u8?key=txiptv&playlive=1&authid=0
江苏卫视,http://60.16.0.216:5757/hls/24/index.m3u8
江苏卫视,http://z.b.bkpcp.top/m.php?id=jsws
江苏卫视,http://3501776.xyz:35455/itv/1000000005000265030.m3u8?cdn=ystenlive
江苏卫视,http://dsk.cc/php/xxtv.php?id=jsws
江苏卫视,http://iptv.huuc.edu.cn/hls/jshd.m3u8
江苏卫视,https://cc06.tv12.xyz/61.m3u8
江西卫视,http://39.164.180.36:19901/tsfile/live/0138_1.m3u8?key=txiptv&playlive=0&authid=0
江西卫视,http://218.17.33.178:53290/tsfile/live/0138_1.m3u8?key=txiptv
江西卫视,http://112.27.235.94:8000/hls/44/index.m3u8
江西卫视,http://222.169.85.8:9901/tsfile/live/0138_1.m3u8?key=txiptv&playlive=1&authid=0
江西卫视,http://z.b.bkpcp.top/m.php?id=jxws
江西卫视,http://iptv.huuc.edu.cn/hls/jxhd.m3u8
江西卫视,https://cc06.tv12.xyz/62.m3u8
江西卫视,http://gslbmgsplive.miguvideo.com/migu/kailu/jxwshd/51/20190820/index.m3u8?msisdn=202510150600374d7f0c7979ab4b22b15a44765fab8561&mdspid=&spid=600633&netType=0&sid=5910021492&pid=2028597139&timestamp=20251015060037&Channel_ID=0116_2600000900-99000-201600010010027&ProgramID=783847495&ParentNodeID=-99&assertID=5910021492&client_ip=106.13.250.83&SecurityKey=20251015060037&promotionId=&mvid=5900004351&mcid=500020&playurlVersion=WX-A1-8.9.2-RELEASE&userid=&jmhm=&videocodec=h264&bean=mgspad&tid=android&conFee=0&puData=66d6b50e10872042d9ec26a898f0750c&ddCalcu=c606e5d17630b0f5809e81a06827c2e094d2
江西卫视,http://3501776.xyz:35455/itv/1000000005000265032.m3u8?cdn=ystenlive
江西卫视,http://lu.wqwqwq.sbs/itv/1000000005000265032.m3u8?cdn=ystenlive
辽宁卫视,http://39.164.180.36:19901/tsfile/live/0121_1.m3u8?key=txiptv&playlive=0&authid=0
辽宁卫视,http://218.17.33.178:53290/tsfile/live/0121_1.m3u8?key=txiptv
辽宁卫视,http://112.123.243.37:50085/tsfile/live/0126_1.m3u8
辽宁卫视,http://z.b.bkpcp.top/m.php?id=lnws
辽宁卫视,http://j.x.bkpcp.top/jx/LIAONHD
辽宁卫视,http://3501776.xyz:35455/itv/1000000005000265022.m3u8?cdn=ystenlive
辽宁卫视,http://dsk.cc/php/xxtv.php?id=lnws
辽宁卫视,http://iptv.huuc.edu.cn/hls/lnhd.m3u8
辽宁卫视,https://cc06.tv12.xyz/70.m3u8
辽宁卫视,http://gslbmgsplive.miguvideo.com/wd_r2/2018/ocn/liaoningwshd/2000/index.m3u8?msisdn=202510150600383a448a64dabc4d699579c0fd4b80bdc5&mdspid=&spid=600572&netType=0&sid=5910022198&pid=2028597139&timestamp=20251015060038&Channel_ID=0116_2600000900-99000-201600010010027&ProgramID=630291707&ParentNodeID=-99&assertID=5910022198&client_ip=106.13.250.83&SecurityKey=20251015060038&promotionId=&mvid=5101043014&mcid=500020&playurlVersion=WX-A1-8.9.2-RELEASE&userid=&jmhm=&videocodec=h264&bean=mgspad&tid=android&conFee=0&puData=d3e37ef05d88aa1bb727a01f0645790e&ddCalcu=ed03e9e17305704e6f00f51d08a87a2a71bb
内蒙古卫视,http://z.b.bkpcp.top/m.php?id=nmws
内蒙古卫视,http://j.x.bkpcp.top/jx/NMGWS
内蒙古卫视,https://cc06.tv12.xyz/94.m3u8
内蒙古卫视,http://tvbox6.com/tv/bfgd.php?id=110
宁夏卫视,http://z.b.bkpcp.top/m.php?id=nxws
宁夏卫视,http://j.x.bkpcp.top/jx/NXWS
宁夏卫视,http://3501776.xyz:35455/itv/1000000002000031451.m3u8?cdn=ystenlive
宁夏卫视,http://dsk.cc/php/xxtv.php?id=nxws
宁夏卫视,https://cc06.tv12.xyz/96.m3u8
宁夏卫视,http://tvbox6.com/tv/bfgd.php?id=118
青海卫视,http://39.164.180.36:19901/tsfile/live/0140_1.m3u8?key=txiptv&playlive=0&authid=0
青海卫视,http://z.b.bkpcp.top/m.php?id=qhws
青海卫视,http://j.x.bkpcp.top/jx/QHWS
青海卫视,http://3501776.xyz:35455/itv/1000000002000013359.m3u8?cdn=ystenlive
青海卫视,https://cc06.tv12.xyz/97.m3u8
青海卫视,http://gslbmgsplive.miguvideo.com/envivo_w/2018/SD/qinghai/1000/index.m3u8?msisdn=202510150600374017489264014ffe907bf0df0c322ca6&mdspid=&spid=600633&netType=0&sid=5910022166&pid=2028597139&timestamp=20251015060037&Channel_ID=0116_2600000900-99000-201600010010027&ProgramID=947472506&ParentNodeID=-99&assertID=5910022166&client_ip=106.13.250.83&SecurityKey=20251015060037&promotionId=&mvid=5900004353&mcid=500020&playurlVersion=WX-A1-8.9.2-RELEASE&userid=&jmhm=&videocodec=h264&bean=mgspad&tid=android&conFee=0&puData=a5edcc95d622f2cf76f40dc9e8967dda&ddCalcu=aad5ede17d76c09c89e59dc6d2024ff26c7f
青海卫视,http://lu.wqwqwq.sbs/itv/1000000002000013359.m3u8?cdn=ystenlive
青海卫视,http://tvbox6.com/tv/bfgd.php?id=111
青海卫视,https://hls-gateway.vpstv.net/streams/708825.m3u8
山东卫视,http://39.164.180.36:19901/tsfile/live/0131_1.m3u8?key=txiptv&playlive=0&authid=0
山东卫视,http://l.cztvcloud.com/channels/lantian/SXshengzhou1/720p.m3u8
山东卫视,http://222.169.85.8:9901/tsfile/live/0131_1.m3u8?key=txiptv&playlive=1&authid=0
山东卫视,http://z.b.bkpcp.top/m.php?id=sdws
山东卫视,http://j.x.bkpcp.top/jx/SHANDHD
山东卫视,http://3501776.xyz:35455/itv/1000000005000265019.m3u8?cdn=ystenlive
山东卫视,http://dsk.cc/php/xxtv.php?id=sdws
山东卫视,http://iptv.huuc.edu.cn/hls/sdhd.m3u8
山东卫视,https://cc06.tv12.xyz/101.m3u8
山东卫视,http://lu.wqwqwq.sbs/itv/1000000005000265019.m3u8?cdn=ystenlive
山西卫视,http://39.164.180.36:19901/tsfile/live/0118_1.m3u8?key=txiptv&playlive=0&authid=0
山西卫视,http://j.x.bkpcp.top/jx/SXWS
山西卫视,http://3501776.xyz:35455/itv/1000000002000021220.m3u8?cdn=ystenlive
山西卫视,http://m3u8.channel.wsrtv.com.cn/cms/videos/nmip-media/channellive/channel7/playlist.m3u8
山西卫视,https://cc06.tv12.xyz/107.m3u8
陕西卫视,http://39.164.180.36:19901/tsfile/live/0136_1.m3u8?key=txiptv&playlive=0&authid=0
陕西卫视,http://112.27.235.94:8000/hls/43/index.m3u8
陕西卫视,http://222.169.85.8:9901/tsfile/live/0136_1.m3u8?key=txiptv&playlive=1&authid=0
陕西卫视,http://z.b.bkpcp.top/m.php?id=sxws
陕西卫视,http://gat.bkpcp.top/ymg.php?id=sxws
陕西卫视,http://3501776.xyz:35455/itv/1000000002000007495.m3u8?cdn=ystenlive
陕西卫视,https://cc06.tv12.xyz/106.m3u8
陕西卫视,https://jzb.wwkejishe.top/?id=603
陕西卫视,http://gslbmgsplive.miguvideo.com/migu/kailu/shan3xiws/51/20220809/index.m3u8?msisdn=20251015060037b2c1602d82af4072a1677d920d1d53d9&mdspid=&spid=600633&netType=0&sid=5910020475&pid=2028597139&timestamp=20251015060037&Channel_ID=0116_2600000900-99000-201600010010027&ProgramID=738910838&ParentNodeID=-99&assertID=5910020475&client_ip=106.13.250.83&SecurityKey=20251015060037&promotionId=&mvid=5900004331&mcid=500020&playurlVersion=WX-A1-8.9.2-RELEASE&userid=&jmhm=&videocodec=h264&bean=mgspad&tid=android&conFee=0&puData=659793d05a2cbf83faaccea3e2755210&ddCalcu=0615e291578590732de035aae2cccbafa8f3
陕西卫视,http://hlsbkmgsplive.miguvideo.com/migu/kailu/shan3xiws/57/20220809/index.m3u8
四川卫视,http://39.164.180.36:19901/tsfile/live/0123_1.m3u8?key=txiptv&playlive=0&authid=0
四川卫视,http://218.17.33.178:53290/tsfile/live/0123_1.m3u8?key=txiptv
四川卫视,http://222.169.85.8:9901/tsfile/live/0123_1.m3u8?key=txiptv&playlive=1&authid=0#rtsp://180.95.143.19/PLTV/88888910/224/3221225543/10000100000000060000000000107323_0.smil
四川卫视,http://z.b.bkpcp.top/m.php?id=scws
四川卫视,http://j.x.bkpcp.top/jx/SICHD
四川卫视,http://3501776.xyz:35455/itv/5000000004000006119.m3u8?cdn=bestzb
四川卫视,http://iptv.huuc.edu.cn/hls/schd.m3u8
四川卫视,https://cc06.tv12.xyz/99.m3u8
四川卫视,http://lu.wqwqwq.sbs/itv/5000000004000006119.m3u8?cdn=bestzb
四川卫视,http://live.wqwqwq.sbs/itv/5000000004000006119.m3u8?cdn=bestzb
深圳卫视,http://39.164.180.36:19901/tsfile/live/0125_2.m3u8?key=txiptv&playlive=0&authid=0
深圳卫视,http://38.64.72.148:80/hls/modn/list/4007/playlist.m3u8
深圳卫视,http://dsk.cc/php/xxtv.php?id=szws
深圳卫视,http://iptv.huuc.edu.cn/hls/szhd.m3u8
深圳卫视,https://smart.pendy.dpdns.org/Smart.php?id=shenzhen
深圳卫视,http://dsj.motem.top:8880/bptv/10000100000000050000000003873474.m3u8
深圳卫视,http://z.b.bkpcp.top/m.php?id=szws
深圳卫视,https://cc06.tv12.xyz/108.m3u8
深圳卫视,http://3501776.xyz:35455/itv/1000000005000265028.m3u8?cdn=ystenlive
深圳卫视,http://lu.wqwqwq.sbs/itv/1000000005000265028.m3u8?cdn=ystenlive
三沙卫视,https://live3.hnntv.cn/srs/tv/ssws.m3u8
天津卫视,http://39.164.180.36:19901/tsfile/live/0135_1.m3u8?key=txiptv&playlive=0&authid=0
天津卫视,http://60.16.0.216:5757/hls/34/index.m3u8
天津卫视,http://j.x.bkpcp.top/jx/TIANJHD
天津卫视,http://dsk.cc/php/xxtv.php?id=tjws
天津卫视,http://iptv.huuc.edu.cn/hls/tjhd.m3u8
天津卫视,http://dsj.motem.top:8880/bptv/10000100000000050000000003873466.m3u8
天津卫视,http://3501776.xyz:35455/itv/1000000005000265026.m3u8?cdn=ystenlive
天津卫视,http://live.wqwqwq.sbs/itv/5000000004000006827.m3u8?cdn=bestzb
天津卫视,http://lu.wqwqwq.sbs/itv/1000000005000265026.m3u8?cdn=ystenlive
天津卫视,http://tvbox6.com/tv/bfgd.php?id=084
西藏卫视,http://cssbyd.imwork.net:8082/hls/46/index.m3u8
西藏卫视,http://www.lysvc.cc/daili/xztv.php?id=0
西藏卫视,http://z.b.bkpcp.top/m.php?id=xzws
西藏卫视,https://cc06.tv12.xyz/112.m3u8
西藏卫视,http://tvbox6.com/tv/bfgd.php?id=121
新疆卫视,http://z.b.bkpcp.top/m.php?id=xjws
新疆卫视,http://j.x.bkpcp.top/jx/XJWS
新疆卫视,http://dsk.cc/php/xxtv.php?id=xjws
新疆卫视,http://dsj.motem.top:8880/bptv/10000100000000050000000003887448.m3u8
新疆卫视,https://cc06.tv12.xyz/109.m3u8
新疆卫视,http://tvbox6.com/tv/bfgd.php?id=150
新疆卫视,http://nas.jdshipin.com:8801/xjtv.php?id=xjws
新疆卫视,http://cdn.jdshipin.com:8880/ysp.php?id=xjws
云南卫视,http://39.164.180.36:19901/tsfile/live/0119_1.m3u8?key=txiptv&playlive=0&authid=0
云南卫视,http://112.27.235.94:8000/hls/40/index.m3u8
云南卫视,http://z.b.bkpcp.top/m.php?id=ynws
云南卫视,http://3501776.xyz:35455/itv/5000000011000031120.m3u8?cdn=bestzb
云南卫视,http://dsk.cc/php/xxtv.php?id=ynws#rtsp://221.7.61.147/PLTV/88888910/224/3221225554/10000100000000060000000000107334_0.smil#rtsp://60.13.39.18/PLTV/88888910/224/3221225554/10000100000000060000000000107334_0.smil
云南卫视,https://cc06.tv12.xyz/114.m3u8
云南卫视,http://tvbox6.com/tv/bfgd.php?id=115
云南卫视,http://live.wqwqwq.sbs/itv/5000000011000031120.m3u8?cdn=bestzb
云南卫视,https://hls-gateway.vpstv.net/streams/708863.m3u8

█████████████████████████████████████████████
央卫V6源,#genre#
█████████████████████████████████████████████
CCTV1,http://iptv.huuc.edu.cn/hls/cctv1hd.m3u8
CCTV2,http://iptv.huuc.edu.cn/hls/cctv2hd.m3u8
CCTV3,http://iptv.huuc.edu.cn/hls/cctv3hd.m3u8
CCTV4,http://iptv.huuc.edu.cn/hls/cctv4hd.m3u8
CCTV5,http://iptv.huuc.edu.cn/hls/cctv5hd.m3u8
CCTV6,http://iptv.huuc.edu.cn/hls/cctv6hd.m3u8
CCTV7,http://iptv.huuc.edu.cn/hls/cctv7hd.m3u8
CCTV8,http://iptv.huuc.edu.cn/hls/cctv8hd.m3u8
CCTV9,http://iptv.huuc.edu.cn/hls/cctv9hd.m3u8
CCTV10,http://iptv.huuc.edu.cn/hls/cctv10hd.m3u8
CCTV11,http://iptv.huuc.edu.cn/hls/cctv11hd.m3u8
CCTV12,http://iptv.huuc.edu.cn/hls/cctv12hd.m3u8
CCTV13,http://iptv.huuc.edu.cn/hls/cctv13hd.m3u8
CCTV14,http://iptv.huuc.edu.cn/hls/cctv14hd.m3u8
CGTNhttp://iptv.huuc.edu.cn/hls/cgtnhd.m3u8
北京卫视,http://iptv.huuc.edu.cn/hls/btv1hd.m3u8
北京文艺,http://iptv.huuc.edu.cn/hls/btv2hd.m3u8
北京体育http://iptv.huuc.edu.cn/hls/btv6hd.m3u8
北京影视,http://iptv.huuc.edu.cn/hls/btv4hd.m3u8
北京新闻,http://iptv.huuc.edu.cn/hls/btv9hd.m3u8
北京体育休闲,http://iptv.huuc.edu.cn/hls/btv11hd.m3u8
湖南卫视,http://iptv.huuc.edu.cn/hls/hunanhd.m3u8
浙江卫视,http://iptv.huuc.edu.cn/hls/zjhd.m3u8
江苏卫视,http://iptv.huuc.edu.cn/hls/jshd.m3u8
东方卫视,http://iptv.huuc.edu.cn/hls/dfhd.m3u8
安徽卫视,http://iptv.huuc.edu.cn/hls/ahhd.m3u8
黑龙江卫视,http://iptv.huuc.edu.cn/hls/hljhd.m3u8
辽宁卫视,http://iptv.huuc.edu.cn/hls/lnhd.m3u8
深圳卫视,http://iptv.huuc.edu.cn/hls/szhd.m3u8
广东卫视,http://iptv.huuc.edu.cn/hls/gdhd.m3u8
天津卫视,http://iptv.huuc.edu.cn/hls/tjhd.m3u8
湖北卫视,http://iptv.huuc.edu.cn/hls/hbhd.m3u8
山东卫视,http://iptv.huuc.edu.cn/hls/sdhd.m3u8
重庆卫视,http://iptv.huuc.edu.cn/hls/cqhd.m3u8
上海纪实http://iptv.huuc.edu.cn/hls/docuchina.m3u8
四川卫视,http://iptv.huuc.edu.cn/hls/schd.m3u8
金鹰纪实http://iptv.huuc.edu.cn/hls/gedocu.m3u8
东南卫视,http://iptv.huuc.edu.cn/hls/dnhd.m3u8
河北卫视http://iptv.huuc.edu.cn/hls/hebhd.m3u8
江西卫视,http://iptv.huuc.edu.cn/hls/jxhd.m3u8

CGTN英语https://0472.org/hls/cgtn.m3u8
CGTN记录,https://0472.org/hls/cgtnd.m3u8
CGTN俄语,https://0472.org/hls/cgtne.m3u8
CGTN法语,https://0472.org/hls/cgtnf.m3u8
CGTN西语,https://0472.org/hls/cgtnx.m3u8
CGTN阿语,https://0472.org/hls/cgtna.m3u8


https://tvv.tw/https://raw.githubusercontent.com/tushen6/xxooo/refs/heads/main/fyzb/ipv6.txt
上海v6

CCTV1,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226163/index.m3u8#http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225770/index.m3u8#http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225723/index.m3u8
CCTV2,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226122/index.m3u8
CCTV3,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225766/index.m3u8#http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226165/index.m3u8
CCTV4,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226124/index.m3u8
CCTV5,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225734/index.m3u8#http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226146/index.m3u8
CCTV6,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225741/index.m3u8#http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226148/index.m3u8
CCTV7,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225701/index.m3u8#http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226137/index.m3u8#http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226143/index.m3u8
CCTV8,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225736/index.m3u8#http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226167/index.m3u8
CCTV10,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225743/index.m3u8#http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226169/index.m3u8
CCTV11,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226101/index.m3u8#http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226145/index.m3u8
CCTV12,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226103/index.m3u8#http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226125/index.m3u8
CCTV13,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226128/index.m3u8
CCTV14,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225738/index.m3u8#http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226150/index.m3u8
CCTV15,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226147/index.m3u8
CCTV16,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226120/index.m3u8

江苏卫视,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225720/index.m3u8
黑龙江卫视,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225722/index.m3u8
北京卫视,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225724/index.m3u8
海南卫视,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226154/index.m3u8
东方卫视,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225725/index.m3u8#http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226106/index.m3u8
湖南卫视,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225726/index.m3u8
浙江卫视,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225727/index.m3u8
深圳卫视,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225728/index.m3u8
湖北卫视,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225729/index.m3u8
广东卫视,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225731/index.m3u8
山东卫视,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225733/index.m3u8
安徽卫视,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225739/index.m3u8
江西卫视,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225740/index.m3u8
天津卫视,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225742/index.m3u8
东南卫视,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225745/index.m3u8
辽宁卫视,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225747/index.m3u8
康巴卫视,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225773/index.m3u8
厦门卫视,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226008/index.m3u8
内蒙古卫视,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226011/index.m3u8
吉林卫视,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226082/index.m3u8#http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226149/index.m3u8
广西卫视,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226084/index.m3u8#http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226130/index.m3u8
西藏卫视,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226012/index.m3u8
陕西卫视,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226086/index.m3u8
新疆卫视,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226088/index.m3u8
甘肃卫视,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226090/index.m3u8
宁夏卫视,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226092/index.m3u8
青海卫视,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226105/index.m3u8
河北卫视,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226107/index.m3u8
云南卫视,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226109/index.m3u8#http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226151/index.m3u8
兵团卫视,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226111/index.m3u8
山西卫视,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226113/index.m3u8
河南卫视,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226132/index.m3u8
四川卫视,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226152/index.m3u8
重庆卫视,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226171/index.m3u8
贵州卫视,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226173/index.m3u8

五星体育,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225732/index.m3u8
第一财经,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225737/index.m3u8
东方影视,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225744/index.m3u8
金色学堂,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225748/index.m3u8
都市都市,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225749/index.m3u8
都市剧场,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225762/index.m3u8#http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226155/index.m3u8
动漫秀场,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225764/index.m3u8#http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226138/index.m3u8
不知道,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225767/index.m3u8
生活时尚,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225768/index.m3u8
欢笑剧场,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225771/index.m3u8
CETV1,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225775/index.m3u8
法治天地,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225994/index.m3u8
CGTN,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226016/index.m3u8
少儿频道,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226019/index.m3u8
卡通动画,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226021/index.m3u8
86,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226050/index.m3u8
87,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226069/index.m3u8
金鹰卡通,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226094/index.m3u8
动画,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226102/index.m3u8
乐游,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226115/index.m3u8#http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226157/index.m3u8
晴彩竞技,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226116/index.m3u8
游戏风云,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226117/index.m3u8#http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226140/index.m3u8
睛彩篮球,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226118/index.m3u8
咪咕体育111,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226123/index.m3u8
东方财经,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226134/index.m3u8
新闻综合,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226136/index.m3u8
睛彩广场舞,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226139/index.m3u8
CETV4,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226153/index.m3u8
哈哈炫动,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226161/index.m3u8#http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226175/index.m3u8

BESTV赛事1,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225663/1.m3u8
BESTV赛事2,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225664/1.m3u8
BESTV赛事3,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225665/1.m3u8
BESTV赛事4,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225666/1.m3u8
BESTV赛事5,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225667/1.m3u8
BESTV赛事6,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225669/1.m3u8
BESTV赛事7,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225670/1.m3u8
BESTV赛事8,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225671/1.m3u8
BESTV赛事9,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226102/1.m3u8
BESTV赛事10,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226123/1.m3u8
咪视界1,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225636/1.m3u8
咪视界2,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225637/1.m3u8
咪视界3,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225638/1.m3u8
咪视界4,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225639/1.m3u8
咪视界5,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225640/1.m3u8
咪视界6,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225641/1.m3u8
咪视界7,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225643/1.m3u8
咪视界8,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225644/1.m3u8
咪视界9,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225646/1.m3u8
咪视界10,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225657/1.m3u8
咪视界11,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225674/1.m3u8
咪视界12,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225676/1.m3u8
咪视界13,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225678/1.m3u8
咪视界14,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225679/1.m3u8
咪视界15,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225680/1.m3u8
咪视界16,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225681/1.m3u8
咪视界17,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225682/1.m3u8
咪视界18,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225683/1.m3u8
咪视界19,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225684/1.m3u8
咪视界20,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225685/1.m3u8
咪视界21,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225686/1.m3u8
咪视界22,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225688/1.m3u8
咪视界23,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225689/1.m3u8
咪视界24,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225690/1.m3u8
咪视界25,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225692/1.m3u8
咪视界26,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225693/1.m3u8
咪视界27,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225694/1.m3u8
咪视界28,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225695/1.m3u8
咪视界29,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225697/1.m3u8
咪视界30,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225699/1.m3u8
咪视界31,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226125/1.m3u8
金色学堂,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225748/1.m3u8
卡酷少儿,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226019/1.m3u8
嘉佳卡通,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226021/1.m3u8
动漫秀场,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226138/1.m3u8
哈哈炫动,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226161/1.m3u8
金鹰卡通,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226094/1.m3u8
东方购物1,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226141/1.m3u8
东方购物2,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226142/1.m3u8
东方购物3,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221226144/1.m3u8
好享购物,http://[2409:8087:1e01:20::3]/PLTV/11/224/3221225781/1.m3u8



浙江频道,#genre#
浙江钱江都市,http://ali-m-l.cztv.com/channels/lantian/channel002/1080p.m3u8
浙江经济生活,http://ali-m-l.cztv.com/channels/lantian/channel003/1080p.m3u8
浙江教科影院,http://ali-m-l.cztv.com/channels/lantian/channel004/1080p.m3u8
浙江民生休闲,http://ali-m-l.cztv.com/channels/lantian/channel006/1080p.m3u8
浙江新闻频道,http://ali-m-l.cztv.com/channels/lantian/channel007/1080p.m3u8
浙江少儿频道,http://ali-m-l.cztv.com/channels/lantian/channel008/1080p.m3u8
中国蓝新闻台,http://ali-m-l.cztv.com/channels/lantian/channel009/1080p.m3u8
浙江国际频道,http://ali-m-l.cztv.com/channels/lantian/channel010/1080p.m3u8
数码时代频道,http://ali-m-l.cztv.com/channels/lantian/channel012/1080p.m3u8
萧山新闻综合,http://l.cztvcloud.com/channels/lantian/SXxiaoshan1/720p.m3u8?zzhed
萧山生活频道,http://l.cztvcloud.com/channels/lantian/SXxiaoshan2/720p.m3u8?zzhed
杭州萧山综合,http://l.cztvcloud.com/channels/lantian/SXxiaoshan3/720p.m3u8
杭州余杭平安,http://l.cztvcloud.com/channels/lantian/SXyuhang2/720p.m3u8
余杭综合频道,http://l.cztvcloud.com/channels/lantian/SXyuhang1/720p.m3u8?zzhed
余杭未来E频道,http://l.cztvcloud.com/channels/lantian/SXyuhang3/720p.m3u8?zzhed
余姚新闻综合,http://l.cztvcloud.com/channels/lantian/SXyuyao1/720p.m3u8?zzhed
余姚姚江文化,http://l.cztvcloud.com/channels/lantian/SXyuyao3/720p.m3u8?zzhed
宁波余姚生活,http://l.cztvcloud.com/channels/lantian/SXyuyao2/720p.m3u8
宁波象山综合,http://l.cztvcloud.com/channels/lantian/SXxiangshan1/720p.m3u8
衢州开化综合,http://l.cztvcloud.com/channels/lantian/SXkaihua1/720p.m3u8
衢州龙游生活,https://l.cztvcloud.com/channels/lantian/SXlongyou2/720p.m3u8
衢州龙游综合,https://l.cztvcloud.com/channels/lantian/SXlongyou1/720p.m3u8
衢州衢江综合,http://l.cztvcloud.com/channels/lantian/SXqujiang1/720p.m3u8
温州永嘉综合,http://l.cztvcloud.com/channels/lantian/SXyongjia1/720p.m3u8
上虞新闻综合,http://l.cztvcloud.com/channels/lantian/SXshangyu1/720p.m3u8?zzhed
上虞文化影院,http://l.cztvcloud.com/channels/lantian/SXshangyu2/720p.m3u8?zzhed
上虞新商都,http://l.cztvcloud.com/channels/lantian/SXshangyu3/720p.m3u8?zzhed
绍兴嵊州综合,http://l.cztvcloud.com/channels/lantian/SXshengzhou1/720p.m3u8
金华东阳综合,http://l.cztvcloud.com/channels/lantian/SXdongyang1/720p.m3u8
金华兰溪综合,http://l.cztvcloud.com/channels/lantian/SXlanxi1/720p.m3u8
武义新闻综合,http://l.cztvcloud.com/channels/lantian/SXwuyi1/720p.m3u8?zzhed
平湖新闻综合,http://l.cztvcloud.com/channels/lantian/SXpinghu1/720p.m3u8?zzhed
诸暨新闻综合,http://l.cztvcloud.com/channels/lantian/SXzhuji3/720p.m3u8?zzhed
丽水缙云综合,http://l.cztvcloud.com/channels/lantian/SXjinyun1/720p.m3u8
丽水龙泉综合,http://l.cztvcloud.com/channels/lantian/SXlongquan1/720p.m3u8
丽水青田综合,http://l.cztvcloud.com/channels/lantian/SXqingtian1/720p.m3u8
丽水庆元综合,http://l.cztvcloud.com/channels/lantian/SXqingyuan1/720p.m3u8
丽水松阳综合,http://l.cztvcloud.com/channels/lantian/SXsongyang1/720p.m3u8
丽水遂昌综合,http://l.cztvcloud.com/channels/lantian/SXsuichang1/720p.m3u8
丽水云和综合,http://l.cztvcloud.com/channels/lantian/SXyunhe1/720p.m3u8
普陀新闻综合,http://l.cztvcloud.com/channels/lantian/SXputuo1/720p.m3u8
文成综合,http://l.cztvcloud.com/channels/lantian/SXwencheng1/720p.m3u8
舟山嵊泗综合,http://l.cztvcloud.com/channels/lantian/SXshengsi1/720p.m3u8
开化国家公园,http://l.cztvcloud.com/channels/lantian/SXkaihua2/720p.m3u8?zzhed
洞头综合频道,http://l.cztvcloud.com/channels/lantian/SXdongtou1/720p.m3u8?zzhed
苍南新闻综合,http://l.cztvcloud.com/channels/lantian/SXcangnan1/720p.m3u8?zzhed
绍兴新闻综合,http://live.shaoxing.com.cn/video/s10001-sxtv1/index.m3u8?zzhed
绍兴新闻综合,http://live.shaoxing.com.cn/video/s10001-sxhb/index.m3u8?zzhed
绍兴公共频道,http://live.shaoxing.com.cn/video/s10001-sxtv2/index.m3u8?zzhed
绍兴文化影院,http://live.shaoxing.com.cn/video/s10001-sxtv3/index.m3u8?zzhed
海宁生活服务,http://live.hndachao.cn/shfw/sd/live.m3u8?zzhed
淳安电视频道,https://wtmtyoutlive.watonemt.com/f2p7vq/lf76v9.m3u8?zzhed

云和新闻综合,http://l.cztvcloud.com/channels/lantian/SXyunhe1/720p.m3u8?zzhed
兰溪新闻综合,http://l.cztvcloud.com/channels/lantian/SXlanxi1/720p.m3u8?zzhed
宁波余姚生活,http://l.cztvcloud.com/channels/lantian/SXyuyao2/720p.m3u8
嵊州公共新闻综合,http://l.cztvcloud.com/channels/lantian/SXshengzhou1/720p.m3u8?zzhed
平湖公共新闻综合,http://l.cztvcloud.com/channels/lantian/SXpinghu1/720p.m3u8?zzhed
平湖新闻综合,http://l.cztvcloud.com/channels/lantian/SXpinghu1/720p.m3u8
平湖民生休闲,http://l.cztvcloud.com/channels/lantian/SXpinghu2/720p.m3u8?zzhed
庆元综合频道,http://l.cztvcloud.com/channels/lantian/SXqingyuan1/720p.m3u8?zzhed
开化新闻综合,http://l.cztvcloud.com/channels/lantian/SXkaihua1/720p.m3u8?zzhed
文成综合频道,http://l.cztvcloud.com/channels/lantian/SXwencheng1/720p.m3u8?zzhed
普陀新闻综合,http://l.cztvcloud.com/channels/lantian/SXputuo1/720p.m3u8
松阳综合频道,http://l.cztvcloud.com/channels/lantian/SXsongyang1/720p.m3u8?zzhed
永嘉新闻综合,http://l.cztvcloud.com/channels/lantian/SXyongjia1/720p.m3u8?zzhed
温州永嘉综合,http://l.cztvcloud.com/channels/lantian/SXyongjia1/720p.m3u8
绍兴上虞影视,http://l.cztvcloud.com/channels/lantian/SXshangyu2/720p.m3u8
绍兴上虞综合,http://l.cztvcloud.com/channels/lantian/SXshangyu1/720p.m3u8
绍兴嵊州综合,http://l.cztvcloud.com/channels/lantian/SXshengzhou1/720p.m3u8
缙云综合频道,http://l.cztvcloud.com/channels/lantian/SXjinyun1/720p.m3u8?zzhed
苍南新闻综合,http://l.cztvcloud.com/channels/lantian/SXcangnan1/720p.m3u8
诸暨新闻综合,http://l.cztvcloud.com/channels/lantian/SXzhuji3/720p.m3u8
遂昌综合频道,http://l.cztvcloud.com/channels/lantian/SXsuichang1/720p.m3u8?zzhed
金华东阳综合,http://l.cztvcloud.com/channels/lantian/SXdongyang1/720p.m3u8
金华兰溪综合,http://l.cztvcloud.com/channels/lantian/SXlanxi1/720p.m3u8
青田电视台,http://l.cztvcloud.com/channels/lantian/SXqingtian1/720p.m3u8?zzhed
龙泉公共新闻综合,http://l.cztvcloud.com/channels/lantian/SXlongquan1/720p.m3u8?zzhed
龙游新闻综合,http://l.cztvcloud.com/channels/lantian/SXlongyou1/720p.m3u8
龙游生活娱乐,http://l.cztvcloud.com/channels/lantian/SXlongyou2/720p.m3u8?zzhed

江苏频道,#genre#

江苏卫视,http://140.210.9.53:8800/SuanFaZhibo/live5/jiangsu/jiangsu.php?id=jsws
江苏新闻,http://140.210.9.53:8800/SuanFaZhibo/live5/jiangsu/jiangsu.php?id=jsxw
江苏国际,http://140.210.9.53:8800/SuanFaZhibo/live5/jiangsu/jiangsu.php?id=jsgj
江苏城市,http://140.210.9.53:8800/SuanFaZhibo/live5/jiangsu/jiangsu.php?id=jscs
江苏综艺,http://140.210.9.53:8800/SuanFaZhibo/live5/jiangsu/jiangsu.php?id=jszy
江苏影视,http://140.210.9.53:8800/SuanFaZhibo/live5/jiangsu/jiangsu.php?id=jsys
江苏教育,http://140.210.9.53:8800/SuanFaZhibo/live5/jiangsu/jiangsu.php?id=jsjy
江苏体育,http://140.210.9.53:8800/SuanFaZhibo/live5/jiangsu/jiangsu.php?id=jsty
江苏卡通,http://140.210.9.53:8800/SuanFaZhibo/live5/jiangsu/jiangsu.php?id=ymkt
 
江苏卫视,http://140.210.9.53:8800/SuanFaZhibo/live5/jiangsu/jiangsu.php?id=jsws
江苏新闻,http://vapi.91kds.cc/live2/jstv.m3u8?apiKey=73c963d13814ce7d0e4743c5e7d033cc&id=jsgg
江苏国际,http://vapi.91kds.cc/live2/jstv.m3u8?apiKey=73c963d13814ce7d0e4743c5e7d033cc&id=jsgj
江苏城市,http://vapi.91kds.cc/live2/jstv.m3u8?apiKey=73c963d13814ce7d0e4743c5e7d033cc&id=jscs
江苏教育,http://vapi.91kds.cc/live2/jstv.m3u8?apiKey=73c963d13814ce7d0e4743c5e7d033cc&id=jsjy
江苏影视,http://vapi.91kds.cc/live2/jstv.m3u8?apiKey=73c963d13814ce7d0e4743c5e7d033cc&id=jsys
江苏综艺,http://vapi.91kds.cc/live2/jstv.m3u8?apiKey=73c963d13814ce7d0e4743c5e7d033cc&id=jszy
江苏体育,http://vapi.91kds.cc/live2/jstv.m3u8?apiKey=73c963d13814ce7d0e4743c5e7d033cc&id=jsty
江苏卡通,http://vapi.91kds.cc/live2/jstv.m3u8?apiKey=73c963d13814ce7d0e4743c5e7d033cc&id=ymkt
 
江苏卫视,http://xxwx.yoesun.com/xxw/江苏网.php?id=jsws
江苏新闻,http://xxwx.yoesun.com/xxw/江苏网.php?id=jsxw
江苏国际,http://xxwx.yoesun.com/xxw/江苏网.php?id=jsgj
江苏城市,http://xxwx.yoesun.com/xxw/江苏网.php?id=jscs
江苏综艺,http://xxwx.yoesun.com/xxw/江苏网.php?id=jszy
江苏影视,http://xxwx.yoesun.com/xxw/江苏网.php?id=jsys
江苏教育,http://xxwx.yoesun.com/xxw/江苏网.php?id=jsjy
江苏体育,http://xxwx.yoesun.com/xxw/江苏网.php?id=jsty
江苏卡通,http://xxwx.yoesun.com/xxw/江苏网.php?id=ymkt
 
苏州综合,https://live-auth.51kandianshi.com/szgd/csztv1.m3u8
苏州经济,https://live-auth.51kandianshi.com/szgd/csztv2.m3u8
苏州生活,https://live-auth.51kandianshi.com/szgd/csztv3.m3u8
苏州娱乐,https://live-auth.51kandianshi.com/szgd/csztv4.m3u8
苏州资讯,https://live-auth.51kandianshi.com/szgd/csztv5.m3u8 
苏州4K台,https://live-auth.51kandianshi.com/szgd/csztv4k_hd.m3u8
镇江综合,http://zjtv-wshls.homecdn.com/live/2aa50.m3u8
镇江民生,http://zjtv-wshls.homecdn.com/live/2aa16.m3u8
无锡综合,http://stream.thmz.com/wxtv1/playlist.m3u8
无锡娱乐,http://stream.thmz.com/wxtv2/playlist.m3u8
无锡都市,http://stream.thmz.com/wxtv3/playlist.m3u8
无锡生活,http://stream.thmz.com/wxtv4/playlist.m3u8
南通综合,https://cm-live.ntjoy.com/live/4f1.flv
南通生活,https://cm-live.ntjoy.com/live/4f3.flv
南通公共,https://cm-live.ntjoy.com/live/4f5.flv
泗阳综合,http://siyang-tv-hls.cm.jstv.com/siyang-tv/siyangzh.m3u8
泗阳资讯,http://siyang-tv-hls.cm.jstv.com/siyang-tv/siyangzx.m3u8
句容综合,http://jrlive.jrntv.com/live/_definst_/jrxwzhs/playlist.m3u8 
句容生活,http://jrlive.jrntv.com/live/_definst_/shenghuos/playlist.m3u8 
句容党建,http://jrlive.jrntv.com/live/_definst_/dangjians/playlist.m3u8 
经典影艺,rtmp://live.gxrb.com.cn/pull/red_movies_0501

宜兴新闻,http://yixing-tv-ori-hls.jstv.com/yixing-tv-ori/yixing_xw.m3u8?zjiangsd
溧水新闻综合,https://lishui-tv-hls.cm.jstv.com/lishui-tv/lsxwzh.m3u8
溧水新闻综合,http://lishui-tv-hls.cm.jstv.com/lishui-tv/lsxwzh.m3u8
苏州新闻综合,https://live-auth.51kandianshi.com/szgd/csztv1.m3u8
苏州生活资讯,https://live-auth.51kandianshi.com/szgd/csztv5.m3u8
苏州社会经济,https://live-auth.51kandianshi.com/szgd/csztv2.m3u8
镇江新闻综合,http://zjtv-wshls.homecdn.com/live/2aa50.m3u8
镇江新闻综合,http://zjtv-wshls.homecdn.com/live/2aa50.m3u8?wsSession=a263bdc5a26cd01b57a80359-170493712215358&amp;wsIPSercert=f56bd6194d219a5172dbed60eca6e9b0

江苏无锡新闻综合,http://stream.thmz.com/wxtv1/sd/live.m3u8?zjiangsd
江苏无锡新闻综合,http://stream.thmz.com/wxtv1/sd/live.m3u8
江苏无锡新闻综合,http://stream.thmz.com/wxtv1/playlist.m3u8
江苏无锡都市资讯,http://stream.thmz.com/wxtv3/sd/live.m3u8?zjiangsd
江苏无锡都市资讯,http://stream.thmz.com/wxtv3/playlist.m3u8
江苏无锡娱乐,http://stream.thmz.com/wxtv2/playlist.m3u8
江苏无锡娱乐,http://stream.thmz.com/wxtv2/sd/live.m3u8?zjiangsd
江苏无锡生活,http://stream.thmz.com/wxtv4/sd/live.m3u8?zjiangsd
江苏无锡生活,http://stream.thmz.com/wxtv4/playlist.m3u8
江苏苏州4k,http://liveshowbak2.kan0512.com/ksz-norecord/csztv4k_4k.m3u8?zjiangsd
江苏泗阳综合频道,http://siyang-tv-hls.cm.jstv.com/siyang-tv/siyangzh.m3u8?zjiangsd
江苏泗阳资讯频道,http://siyang-tv-hls.cm.jstv.com/siyang-tv/siyangzx.m3u8?zjiangsd
江苏如东新闻,http://rudong-tv-hls.cm.jstv.com/rudong-tv/rdxwzh.m3u8
江苏睢宁三农频道,http://suining-tv-hls.cm.jstv.com/suining-tv/suiningsn.m3u8?zjiangsd
江苏金坛新闻频道,http://jintan-tv-ori-hls.jstv.com/jintan-tv-ori/jintan_xw.m3u8?zjiangsd
江苏睢宁生活教育,http://suining-tv-hls.cm.jstv.com/suining-tv/suiningsh.m3u8?zjiangsd
江苏沭阳综合频道,http://shuyang-tv-hls.cm.jstv.com/shuyang-tv/shuyangzh.m3u8?zjiangsd
江苏涟水综合频道,http://lianshui-tv-hls.cm.jstv.com/lianshui-tv/lsxw.m3u8?zjiangsd
江苏金湖新闻综合,http://jinhu-tv-hls.cm.jstv.com/jinhu-tv/jinhuzh.m3u8?zjiangsd
江苏如东新闻综合,http://rudong-tv-hls.cm.jstv.com/rudong-tv/rdxwzh.m3u8?zjiangsd
江苏泗洪新闻综合,http://sihong-tv-hls.cm.jstv.com/sihong-tv/sihongxinwenzonghe.m3u8?zjiangsd
江苏赣榆新闻综合,http://ganyu-tv-hls.cm.jstv.com/ganyu-tv/ganyutv.m3u8?zjiangsd
江苏淮安公共频道,http://live1.habctv.com/ggpdsl/sd/live.m3u8?zjiangsd
江苏海安新闻综合,http://haian-tv-hls.cm.jstv.com/haian-tv/haaxwzh.m3u8?zjiangsd
江苏淮安影院娱乐,http://live1.habctv.com/ysylsl/sd/live.m3u8?zjiangsd
江苏连云港公共,http://live.lyg1.com/ggpd/sd/live.m3u8
江苏东海新闻频道,http://donghai-tv-hls.cm.jstv.com/donghai-tv/donghaixinwensp.m3u8?zjiangsd
江苏江宁新闻频道,https://jiangning-tv-hls.cm.jstv.com/jiangning-tv/jnxwzh.m3u8?zjiangsd
江苏常熟民生经济,http://cstvplay.21cs.cn/cstv2/cstv2.m3u8
江苏江阴新闻综合,http://221.228.70.101:8080/live/xinwen.m3u8
江苏沛县新闻综合,http://peixian-tv-hls.cm.jstv.com/peixian-tv/pxzh.m3u8?zjiangsd
江苏高邮综合频道,http://gaoyou-tv-hls.cm.jstv.com/gaoyou-tv/gaoyouxw.m3u8?zjiangsd
江苏宿豫综合频道,https://suyu-tv-hls.cm.jstv.com/suyu-tv/syzhpd.m3u8?zjiangsd
江苏武进新闻频道,https://live.wjyanghu.com/live/CH1.m3u8?zjiangsd
江苏武进生活频道,https://live.wjyanghu.com/live/CH2.m3u8?zjiangsd
江苏常熟综合,http://cstvplay.21cs.cn/cstv1/cstv1.m3u8
江苏睢宁综合频道,http://suining-tv-hls.cm.jstv.com/suining-tv/suiningzh.m3u8?zjiangsd
江苏靖江新闻综合,http://visit.jjbctv.com:1935/live/xwzhpc/playlist.m3u8
江苏靖江新闻综合,http://visit.jjbctv.com:1935/live/xwzhmb/playlist.m3u8?zjiangsd
江苏姜堰新闻综合,https://jiangyan-tv-hls.cm.jstv.com/jiangyan-tv/jiangyanzh.m3u8?zjiangsd
江苏镇江新闻综合,http://zjtv-wshls.homecdn.com/live/2aa50.m3u8
扬州综合,https://cm-wshls.homecdn.com/live/8bb.m3u8
扬州城市,https://cm-wshls.homecdn.com/live/8bd.m3u8
扬州生活,https://cm-wshls.homecdn.com/live/8bf.m3u8
扬州邗江,https://cm-wshls.homecdn.com/live/8c3.m3u8
江宁电视台,http://jiangning-tv-hls.cm.jstv.com/jiangning-tv/jnxwzh.m3u8?zjiangsd#http://jiangning-tv-hls.cm.jstv.com/jiangning-tv/jnxwzh.m3u8
赣榆电视台,http://ganyu-tv-hls.cm.jstv.com/ganyu-tv/ganyutv.m3u8#http://ganyu-tv-hls.cm.jstv.com/ganyu-tv/ganyutv.m3u8?zjiangsd
淮安公共频道,http://live1.habctv.com/ggpdsl/sd/live.m3u8#http://live1.habctv.com/ggpdsl/sd/live.m3u8?zjiangsd
金湖电视台,http://jinhu-tv-hls.cm.jstv.com/jinhu-tv/jinhuzh.m3u8?zjiangsd#http://jinhu-tv-hls.cm.jstv.com/jinhu-tv/jinhuzh.m3u8
句容新闻综合频道,http://jrlive.jrntv.com/live/_definst_/jrxwzhs/playlist.m3u8?zjiangsd#http://jrlive.jrntv.com/live/_definst_/jrxwzhs/playlist.m3u8
句容生活频道,http://jrlive.jrntv.com/live/_definst_/shenghuos/playlist.m3u8?zjiangsd#http://jrlive.jrntv.com/live/_definst_/shenghuos/playlist.m3u8
句容影视频道,http://jrlive.jrntv.com/live/_definst_/yingshis/playlist.m3u#http://jrlive.jrntv.com/live/_definst_/yingshis/playlist.m3u8
句容党建频道,http://jrlive.jrntv.com/live/_definst_/dangjians/playlist.m3u8#http://jrlive.jrntv.com/live/_definst_/dangjians/playlist.m3u8?zjiangsd
靖江新闻综合频道,http://visit.jjbctv.com:1935/live/xwzhmb/playlist.m3u8?zjiangsd#http://visit.jjbctv.com:1935/live/xwzhpc/playlist.m3u8#http://visit.jjbctv.com:1935/live/xwzhpc/playlist.m3u8?zjiangsd#http://visit.jjbctv.com:1935/live/xwzhmb/playlist.m3u8
武进新闻频道,http://live.wjyanghu.com/live/CH1.m3u8?zjiangsd#http://live.wjyanghu.com/live/CH1.m3u8
金坛电视台,http://jintan-tv-ori-hls.jstv.com/jintan-tv-ori/jintan_xw.m3u8?zjiangsd#http://jintan-tv-ori-hls.jstv.com/jintan-tv-ori/jintan_xw.m3u8
沛县电视台,http://peixian-tv-hls.cm.jstv.com/peixian-tv/pxzh.m3u8?zjiangsd#http://peixian-tv-hls.cm.jstv.com/peixian-tv/pxzh.m3u8
睢宁新闻综合频道,http://suining-tv-hls.cm.jstv.com/suining-tv/suiningzh.m3u8?zjiangsd#http://3739115311.cloudvdn.com/a.m3u8?domain=suining-tv-hls.cm.jstv.com&player=TwMAAPjPskOkJ6kX&secondToken=secondToken%3AjegfwzYXwUE9HzG7kRfhCd81WMU&streamid=suining-tv%3Asuining-tv%2Fsuiningzh&v3=1&zjiangsd=#http://suining-tv-hls.cm.jstv.com/suining-tv/suiningzh.m3u8
无锡新闻综合频道,http://stream.thmz.com/wxtv1/sd/live.m3u8?zjiangsd#http://stream.thmz.com/wxtv1/sd/live.m3u8?_upt=4ba3ab191698644028#http://stream.thmz.com/wxtv1/playlist.m3u8#http://stream.thmz.com/wxtv1/playlist.m3u8?_upt=156143371706166361
无锡都市资讯频道,http://stream.thmz.com/wxtv3/sd/live.m3u8?_upt=978cd8731706199708#http://stream.thmz.com/wxtv3/sd/live.m3u8?zjiangsd#http://stream.thmz.com/wxtv3/playlist.m3u8#http://stream.thmz.com/wxtv3/playlist.m3u8?_upt=1758133b1706166861
宜兴电视台,http://yixing-tv-ori-hls.jstv.com/yixing-tv-ori/yixing_xw.m3u8#http://yixing-tv-ori-hls.jstv.com/yixing-tv-ori/yixing_xw.m3u8?zjiangsd
无锡经济频道,http://stream.thmz.com/wxtv5/sd/live.m3u8?_upt=cfacd5221704890772#http://stream.thmz.com/wxtv5/sd/live.m3u8?zjiangsd#http://stream.thmz.com/wxtv5/playlist.m3u8?_upt=10155d141706166867#http://stream.thmz.com/wxtv5/playlist.m3u8
无锡生活频道,http://stream.thmz.com/wxtv4/playlist.m3u8?_upt=da4d81381706172263#http://stream.thmz.com/wxtv4/sd/live.m3u8?_upt=968c13b81704871272#http://stream.thmz.com/wxtv4/playlist.m3u8#http://stream.thmz.com/wxtv4/sd/live.m3u8?zjiangsd
无锡移动电视,http://m.m3u8.wifiwx.com/live/wifiwx-494.m3u8
吴江电视台,http://30515.hlsplay.aodianyun.com/lms_30515/tv_channel_239.m3u8?auth_key=4849225473-0-0-ccc3233d52ea78642c7045805f46ea58&extra_key=kuPfWJHmelFzV3-zoreYDOH4OVvUscNtgFUPukN0LjrE7j9GbJe-1SiVIo_invs13HOTHPShIbZWuurqH8qWSk1Ouqm4Z10UlHpsUzS1j4nZoIRkEzTmKDOrVq3vGwbvmvC6qDLIKmmLHfFxL7WJeMpZZlN8MDPUoCW9CYoMIW0
泗阳电视台,http://siyang-tv-hls.cm.jstv.com/siyang-tv/siyangzh.m3u8?zjiangsd#http://3739115337.cloudvdn.com/a.m3u8?domain=siyang-tv-hls.cm.jstv.com&player=nwEAAKHdjSKP_58X&secondToken=secondToken%3A5FUijZmDyNMxtCDdne0YzSAwjuw&streamid=siyang-tv%3Asiyang-tv%2Fsiyangzh&v3=1
宿豫电视台,http://suyu-tv-hls.cm.jstv.com/suyu-tv/syzhpd.m3u8?zjiangsd
如东新闻,http://rudong-tv-hls.cm.jstv.com/rudong-tv/rdxwzh.m3u8#http://rudong-tv-hls.cm.jstv.com/rudong-tv/rdxwzh.m3u8?zjiangsd
泗阳资讯频道,http://siyang-tv-hls.cm.jstv.com/siyang-tv/siyangzx.m3u8?zjiangsd#http://siyang-tv-hls.cm.jstv.com/siyang-tv/siyangzx.m3u8
苏州-1,rtmp://csztv.2500sz.com/live/c01
苏州-2,rtmp://csztv.2500sz.com/live/c02
苏州-3,rtmp://csztv.2500sz.com/live/c03
苏州-5,rtmp://csztv.2500sz.com/live/c04
盐城3套,https://live1yc.0515yc.cn/ycst03/sd/live.m3u8?_upt=063361c91707142304
无锡综合,http://stream.thmz.com/wxtv1/playlist.m3u8?_upt=df50c8ad1706195780
无锡都市,http://stream.thmz.com/wxtv3/sd/live.m3u8?_upt=978cd8731706199708
无锡生活,http://stream.thmz.com/wxtv4/sd/live.m3u8?_upt=95a5f0d51706199864
无锡经济,http://stream.thmz.com/wxtv5/sd/live.m3u8?_upt=31414f601706199828
镇江2套,http://zjtv-wshls.homecdn.com/live/2aa16.m3u8
江宁综合,https://jiangning-tv-hls.cm.jstv.com/jiangning-tv/jnxwzh.m3u8
姜堰综合,https://jiangyan-tv-hls.cm.jstv.com/jiangyan-tv/jiangyanzh.m3u8
沭阳综合,http://shuyang-tv-hls.cm.jstv.com/shuyang-tv/shuyangzh.m3u8
泗阳综合,http://siyang-tv-hls.cm.jstv.com/siyang-tv/siyangzh.m3u8
泗阳资讯,http://siyang-tv-hls.cm.jstv.com/siyang-tv/siyangzx.m3u8
高邮综合频道,http://gaoyou-tv-hls.cm.jstv.com/gaoyou-tv/gaoyouxw.m3u8
宿豫综合频道,https://suyu-tv-hls.cm.jstv.com/suyu-tv/syzhpd.m3u8
金湖新闻综合,http://jinhu-tv-hls.cm.jstv.com/jinhu-tv/jinhuzh.m3u8
金坛新闻频道,http://jintan-tv-ori-hls.jstv.com/jintan-tv-ori/jintan_xw.m3u8
无锡生活,http://stream.thmz.com/wxtv4/sd/live.m3u8
无锡经济,http://stream.thmz.com/wxtv5/sd/live.m3u8
连云港新闻综合,http://live.lyg1.com/zhpd/sd/live.m3u8

山东频道,#genre#
莱阳综合,http://106.53.99.30/tv/sdtv.php?id=ytlyzh
莱阳民生综艺,http://106.53.99.30/tv/sdtv.php?id=ytlyms
山东齐鲁,http://nw.jiayinkeji.xin/migunew/gtqilu.php?id=qlpd
山东新闻,http://58.58.111.222:808/hls/63/index.m3u8?key=txiptv
山东综艺,http://nw.jiayinkeji.xin/migunew/gtqilu.php?id=yxzy
山东生活,http://nw.jiayinkeji.xin/migunew/gtqilu.php?id=yxsh
山东文旅,http://nw.jiayinkeji.xin/migunew/gtqilu.php?id=yxys
山东农科,http://nw.jiayinkeji.xin/migunew/gtqilu.php?id=nkpd
山东体育,http://nw.jiayinkeji.xin/migunew/gtqilu.php?id=typd
山东教育,http://test1.live.sdetv.com.cn/live/dianshizhibo/playlist.m3u8
山东少儿,http://58.58.111.222:808/hls/65/index.m3u8?key=txiptv
山东卫视,http://58.58.111.222:808/hls/57/index.m3u8?key=txiptv

山东齐鲁,http://58.58.111.222:808/hls/58/index.m3u8?key=txiptv
山东新闻,http://58.58.111.222:808/hls/63/index.m3u8?key=txiptv
山东综艺,http://58.58.111.222:808/hls/61/index.m3u8?key=txiptv
山东文旅,http://nw.jiayinkeji.xin/migunew/gtqilu.php?id=yxys
山东生活,http://58.58.111.222:808/hls/60/index.m3u8?key=txiptv
山东农科,http://58.58.111.222:808/hls/64/index.m3u8?key=txiptv
山东教育,http://58.58.111.222:808/hls/67/index.m3u8?key=txiptv
山东少儿,http://58.58.111.222:808/hls/65/index.m3u8?key=txiptv
山东体育,http://58.58.111.222:808/hls/62/index.m3u8?key=txiptv
山东卫视,http://58.58.111.222:808/hls/57/index.m3u8?key=txiptv

山东齐鲁,http://122.4.104.5/00/SNM/CHANNEL10000313/index.m3u8
山东新闻,http://122.4.104.5/00/SNM/CHANNEL10000314/index.m3u8
山东综艺,http://122.4.104.5/00/SNM/CHANNEL10000054/index.m3u8
山东生活,http://122.4.104.5/00/SNM/CHANNEL10000055/index.m3u8
山东文旅,http://122.4.104.5/00/SNM/CHANNEL10000056/index.m3u8
山东体育,http://122.4.104.5/00/SNM/CHANNEL00000057/index.m3u8
山东农科,http://122.4.104.5/00/SNM/CHANNEL10000058/index.m3u8
山东少儿,http://122.4.104.5/00/SNM/CHANNEL10000059/index.m3u8
山东教育,http://122.4.104.5/00/SNM/CHANNEL00000331/index.m3u8
山东卫视,http://122.4.104.5/00/SNM/CHANNEL10000301/index.m3u8

山东齐鲁,http://150.138.8.132/00/SNM/CHANNEL10000313/index.m3u8
山东新闻,http://150.138.8.132/00/SNM/CHANNEL10000314/index.m3u8
山东体育,http://150.138.8.132/00/SNM/CHANNEL00000315/index.m3u8
山东生活,http://150.138.8.132/00/SNM/CHANNEL00000336/index.m3u8
山东文旅,http://150.138.8.132/00/SNM/CHANNEL00000337/index.m3u8
山东综艺,http://150.138.8.132/00/SNM/CHANNEL00000338/index.m3u8
山东农科,http://150.138.8.132/00/SNM/CHANNEL00000339/index.m3u8
山东少儿,http://150.138.8.132/00/SNM/CHANNEL00000340/index.m3u8
山东教育,http://150.138.8.132/00/SNM/CHANNEL00000331/index.m3u8
山东卫视,http://150.138.8.132/00/SNM/CHANNEL10000301/index.m3u8
山东体育,http://218.56.123.244:85/tsfile/live/1005_1.m3u8?key=txiptv
山东体育,http://61.156.228.12:8154/tsfile/live/1006_1.m3u8
山东体育,http://222.173.108.238:352/tsfile/live/1000_1.m3u8
山东体育,http://119.167.49.46:4000/udp/239.253.254.22:8000

山东齐鲁,http://221.0.164.97:6666/udp/239.253.254.114:8000
山东齐鲁,http://123.129.70.178:9901/tsfile/live/0019_1.m3u8
山东齐鲁,http://119.187.121.178:8091/PLTV/88888888/224/3221226516/10000100000000060000000001311826_0.smil/01.m3u8?fmt=ts2hls

山东生活,http://58.58.111.222:808/hls/60/index.m3u8?key=txiptv
山东生活,http://113.120.46.146:8123/udp/239.21.1.56:5002
山东生活,https://stream1.freetv.fun/78b52dd6e306fc85903331b0e9841f1d70469104d6fc7c86c7316f423ae18b93.m3u8
山东生活,http://livealone.iqilu.com/iqilu/shpdhjOF03kn.m3u8
山东生活,http://[2409:8087:3c02:0021:0000:0001:0000:100a]:6410/shandong_cabletv.live.zte.com////CHANNEL00000336/index.m3u8?IASHttpSessionId=
山东生活,http://119.187.121.178:8091/PLTV/88888888/224/3221225809/10000100000000060000000000215679_0.smil/01.m3u8?fmt=ts2hls

山东齐鲁,http://119.164.216.162:9901/tsfile/live/1003_1.m3u8
山东齐鲁,http://119.164.216.162:9901/tsfile/live/1000_1.m3u8
山东齐鲁,http://39.136.48.2:8089/PLTV/88888888/224/3221226045/index.m3u8
山东生活,http://119.164.216.162:9901/tsfile/live/1006_1.m3u8
山东生活,http://39.136.48.2:8089/PLTV/88888888/224/3221225841/index.m3u8
山东生活,http://39.136.48.8:8089/PLTV/88888888/224/3221225841/index.m3u8
山东体育,http://39.136.48.2:8089/PLTV/88888888/224/3221226075/index.m3u8
山东体育,http://119.164.216.162:9901/tsfile/live/1002_1.m3u8
山东新闻,http://119.164.216.162:9901/tsfile/live/1005_1.m3u8
山东新闻,http://119.164.216.162:9901/tsfile/live/1004_1.m3u8
山东新闻,http://39.136.48.2:8089/PLTV/88888888/224/3221226077/index.m3u8
山东新闻,http://39.136.48.98:8089/PLTV/88888888/224/3221225962/index.m3u8
山东综艺,http://39.136.48.2:8089/PLTV/88888888/224/3221225855/index.m3u8
山东综艺,http://119.164.216.162:9901/tsfile/live/1001_1.m3u8
山东综艺,http://39.136.48.8:8089/PLTV/88888888/224/3221225855/index.m3u8
山东少儿,http://39.136.48.98:8089/PLTV/88888888/224/3221226001/index.m3u8
山东少儿,http://39.136.48.2:8089/PLTV/88888888/224/3221226195/index.m3u8
山东文旅,http://39.136.48.2:8089/PLTV/88888888/224/3221225802/index.m3u8
山东农科,http://39.136.48.4:8089/PLTV/88888888/224/3221226018/index.m3u8
山东农科,http://39.136.48.20:8089/PLTV/88888888/224/3221225870/index.m3u8
山东教育,http://39.135.138.58:18890/PLTV/88888888/224/3221225719/index.m3u8
山东教育,http://livewai.sdetv.com.cn/live/da4ebbb91ee8468db5a9d230a535391f_transios/playlist.m3u8
山东教育,http://39.134.65.162/PLTV/88888888/224/3221225558/1.m3u8
山东教育,http://39.134.65.164/PLTV/88888888/224/3221225558/1.m3u8
山东教育,http://migu.jilu8.cn/3221231549/index.m3u8
山东教育,http://117.148.179.157/PLTV/88888888/224/3221231549/index.m3u8
山东教育,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225719/index.m3u8

烟台公共频道,http://live.yantaitv.cn/live/e50f104a4ffe4a41b2217cbda534146f/d86092e69df94668b33390278b061700-1.m3u8
烟台影视频道,http://live.yantaitv.cn/live/e9f1d9045d474c31884d13fa4ffbbd16/a4a9b3704d854756907845107cc56129-1.m3u8
烟台经济科技,http://live.yantaitv.cn/live/27f84144e95a4652ae9e5c211b2a6b55/405f3e33ba384aa0a16014d0becd1261-1.m3u8
烟台新闻综合,http://live.yantaitv.cn/live/3e81a8879da44c5dadf3bd9c10468e1c/9b776d420ee4438199b7657c8eb88f07-1.m3u8
山东齐鲁,http://nw.jiayinkeji.xin/migunew/gtqilu.php?id=qlpd
山东新闻,http://58.58.111.222:808/hls/63/index.m3u8?key=txiptv
山东综艺,http://nw.jiayinkeji.xin/migunew/gtqilu.php?id=yxzy
山东生活,http://nw.jiayinkeji.xin/migunew/gtqilu.php?id=yxsh
山东文旅,http://nw.jiayinkeji.xin/migunew/gtqilu.php?id=yxys
山东农科,http://nw.jiayinkeji.xin/migunew/gtqilu.php?id=nkpd
山东体育,http://nw.jiayinkeji.xin/migunew/gtqilu.php?id=typd

山东少儿,http://58.58.111.222:808/hls/65/index.m3u8?key=txiptv
山东卫视,http://58.58.111.222:808/hls/57/index.m3u8?key=txiptv
山东齐鲁,http://58.58.111.222:808/hls/58/index.m3u8?key=txiptv
山东综艺,http://58.58.111.222:808/hls/61/index.m3u8?key=txiptv

山东农科,http://58.58.111.222:808/hls/64/index.m3u8?key=txiptv
山东教育,http://58.58.111.222:808/hls/67/index.m3u8?key=txiptv
山东体育,http://58.58.111.222:808/hls/62/index.m3u8?key=txiptv

山西频道,#genre#
晋城新闻,http://live.jinnews.com.cn/xwzh/sd/live.m3u8?zshanxd
晋城公共,http://live.jinnews.com.cn/ggpd/sd/live.m3u8?zshanxd
晋中新闻,http://jzlive.jztvnews.com:90/live/jzzh.m3u8
晋中公共,http://jzlive.jztvnews.com:90/live/jzgg.m3u8
黎城综合,http://111.53.96.67:8081/live/1/index.m3u8
武乡新闻综合1,http://60.220.198.84:81/0.m3u8
武乡新闻综合2,http://uzoiczhh.live.sxmty.com/live/hls/0d41f1480c4042d49927858f01fde707/53130407737b417b9a6259b57246bae3.m3u8
闻喜综合,https://www.wxhcgbds.com:8081/channelTv/WXTV_1.m3u8?zshanxd
定襄综合,http://lbyzztfe.live.sxmty.com/live/hls/645ff4c60e0a49f0a203abbd73dd8be9/0720e665f10f48e98c9639f4f492fb4a-1.m3u8?zshanxd
怀仁综合,http://1yp7hc5p.live.sxmty.com/live/hls/bff8529922344209985b6e49baa9555a/efa2543628fc4a7ea93d3d6c975f77dc.m3u8?zshanxd
汾西综合,https://qmmqvzoz.live.sxmty.com/live/hls/f24f8a390c084386a564074c9260100c/be3fdf07606145739ab2c4b80fe0136a.m3u8?zshanxd

湖北频道,#genre#
武汉新闻综合,http://www.zyhfm.com:8088/rtp/239.69.1.145:10506
武汉电视剧,http://www.zyhfm.com:8088/rtp/239.69.1.146:10512
武汉科技生活,http://www.zyhfm.com:8088/rtp/239.69.1.251:11148
武汉经济,http://www.zyhfm.com:8088/rtp/239.69.1.35:9850
武汉文体,http://www.zyhfm.com:8088/rtp/239.69.1.147:10518
武汉外语,http://www.zyhfm.com:8088/rtp/239.69.1.36:9856
武汉教育,http://www.zyhfm.com:8088/rtp/239.69.1.60:9994
湖北公共新闻,http://www.zyhfm.com:8088/rtp/239.69.1.40:9880
湖北经视,http://www.zyhfm.com:8088/rtp/239.69.1.41:9886
湖北综合,http://www.zyhfm.com:8088/rtp/239.69.1.42:9892
湖北垄上,http://www.zyhfm.com:8088/rtp/239.69.1.43:9898
湖北影视,http://www.zyhfm.com:8088/rtp/239.69.1.204:10866
湖北生活,http://www.zyhfm.com:8088/rtp/239.69.1.205:10872
湖北教育,http://www.zyhfm.com:8088/rtp/239.69.1.206:10878
武汉新闻综合,http://stream.appwuhan.com/1tzb/sd/live.m3u8
武汉电视剧,http://stream.appwuhan.com/2tzb/sd/live.m3u8
武汉科技生活,http://stream.appwuhan.com/3tzb/sd/live.m3u8
武汉经济,http://stream.appwuhan.com/4tzb/sd/live.m3u8
武汉文体,http://stream.appwuhan.com/5tzb/sd/live.m3u8
武汉外语,http://stream.appwuhan.com/6tzb/sd/live.m3u8
武汉少儿,http://stream.appwuhan.com/7tzb/sd/live.m3u8
武汉教育,http://stream.appwuhan.com/jyzb/sd/live.m3u8

鄂州新闻综合,http://ezhou-live21.cjyun.org/10098/s10098-EZ1T.m3u8?auth_key=1767196799-ced13be0a8ae11efa7dfa7dfd677b8f3-0-0f99f7df9fd0d3fca9beca6bafa6b043
鄂州公共,http://ezhou-live21.cjyun.org/10098/s10098-EZ2T.m3u8?auth_key=1767196799-ced13be0a8ae11efa7dfa7dfd677b8f3-0-ab320ba90f39f94baba04e30ff07c52e
黄石新闻综合,http://huangshifb-live21.cjyun.org/10200/s10200-huangshitv01.m3u8?auth_key=1767196799-ced13be0a8ae11efa7dfa7dfd677b8f3-0-e22af05072c6fa8bc1fc35e042e97467
大冶一套,http://dayeyun-live21.cjyun.org/10102/s10102-TC1T.m3u8?auth_key=1767196799-ced13be0a8ae11efa7dfa7dfd677b8f3-0-c3d27fbc279c3efc9187853aca3da012
阳新新闻,http://yangxin-live21.cjyun.org/10104/s10104-yangxin-tv01.m3u8?auth_key=1767196799-ced13be0a8ae11efa7dfa7dfd677b8f3-0-a27d99b67d0e39445f1df5ea6ad088ec
咸宁综合,http://xianning-live21.cjyun.org/10140/s10140-XNTV-1.m3u8?auth_key=1767196799-ced13be0a8ae11efa7dfa7dfd677b8f3-0-fea9ed9b2105c8e66da382be47a0acae
咸宁经济生活,http://xianning-live21.cjyun.org/10140/s10140-XNGG.m3u8?auth_key=1767196799-ced13be0a8ae11efa7dfa7dfd677b8f3-0-8cb875770938fdeb7179752f74e13062
赤壁一套,http://chibi-live21.cjyun.org/10138/s10138-CBTV1.m3u8?auth_key=1767196799-ced13be0a8ae11efa7dfa7dfd677b8f3-0-a9f4eb22b55c750628c090d53a445bbc
嘉鱼新闻综合,http://jiayu-live21.cjyun.org/10131/s10131-jyzh.m3u8?auth_key=1767196799-ced13be0a8ae11efa7dfa7dfd677b8f3-0-9ca56ee7b0e7b23d7ccb3f6649b2686a
通山综合,http://tongshan-live21.cjyun.org/10134/s10134-TONGSHAN-live.m3u8?auth_key=1767196799-ced13be0a8ae11efa7dfa7dfd677b8f3-0-23ad1b5ada69ec0d4796d8227f737ca6
孝感新闻综合,http://xiaogan-live21.cjyun.org/10139/s10139-shpd.m3u8?auth_key=1767196799-ced13be0a8ae11efa7dfa7dfd677b8f3-0-2286294457518d52f02d91906380d72a
孝感生活,http://xiaogan-live21.cjyun.org/10139/s10139-xg.m3u8?auth_key=1767196799-ced13be0a8ae11efa7dfa7dfd677b8f3-0-1d24a98d45449c0f85cda4bddc5d72a6
孝昌新闻党建,http://xiaochang-live21.cjyun.org/10128/s10128-xcxw.m3u8?auth_key=1767196799-ced13be0a8ae11efa7dfa7dfd677b8f3-0-948b2cf2777e352d9f83660c9b79aa3f
应城综合,http://yingcheng-live21.cjyun.org/10135/s10135-YCZH.m3u8?auth_key=1767196799-ced13be0a8ae11efa7dfa7dfd677b8f3-0-683be43745bd3709006be7b43135de61
荆州新闻,http://jingzhou-live21.cjyun.org/10085/s10085-jingzhou-tv01.m3u8?auth_key=1767196799-ced13be0a8ae11efa7dfa7dfd677b8f3-0-2bb0015980b1b3742cea1d78f13eb6ca
荆州垄上,http://jingzhou-live21.cjyun.org/10085/s10085-jingzhou-tv03.m3u8?auth_key=1767196799-ced13be0a8ae11efa7dfa7dfd677b8f3-0-7dff02969ff316d795ac73c86747fd05
松滋综合,http://songzi-live21.cjyun.org/10194/s10194-songzi-tv1.m3u8?auth_key=1767196799-ced13be0a8ae11efa7dfa7dfd677b8f3-0-388ba0519fa8a2846925a78282f2aa1f

黄陂新闻,http://livehprm.hptv.com.cn/zbpd/sd/live.m3u8
荆州新闻,https://jingzhou-live21.cjyun.org:443/10085/s10085-jingzhou-tv01.m3u8?auth_key=1767196799-ced13be0a8ae11efa7dfa7dfd677b8f3-0-2bb0015980b1b3742cea1d78f13eb6ca
荆州陇上,https://jingzhou-live21.cjyun.org:443/10085/s10085-jingzhou-tv03.m3u8?auth_key=1767196799-ced13be0a8ae11efa7dfa7dfd677b8f3-0-7dff02969ff316d795ac73c86747fd05
十堰新闻,http://p8.vzan.com/slowlive/034028687228317362/live.m3u8
十堰新闻,https://p8.vzan.com/slowlive/034028687228317362/live.m3u8?zbid=351104&amp;tpid=868100086
十堰新闻,http://p8.vzan.com/slowlive/034028687228317362/live.m3u8
十堰经济,https://p8.vzan.com/slowlive/701367497774448672/live.m3u8
荆门新闻,http://stream.jmtv.com.cn/xwzh/sd/live.m3u8
荆门教育,http://stream.jmtv.com.cn/ggsh/sd/live.m3u8
江夏新闻,http://59.175.226.142:280/gb28181/xwzh.m3u8
崇阳综合,http://61.184.176.248:10500/live/live.m3u8
潜江综合,http://hbqjdb.chinashadt.com:2035/live/3.stream/playlist.m3u8
潜江乡村,http://hbqjdb.chinashadt.com:2035/live/4.stream/playlist.m3u8
十堰新闻综合,video://https://www.syiptv.com/tv?station_id=1
十堰新闻综合,webview://https://www.syiptv.com/tv
十堰经济旅游,video://https://www.syiptv.com/tv?station_id=3
十堰经济旅游,webview://https://www.syiptv.com/tv?station_id=3
十堰新闻综合,video://http://52zb.online/xzb/sytv.php?id=1
十堰经济旅游,video://http://52zb.online/xzb/sytv.php?id=3
荆门新闻综合,video://https://www.jmtv.com.cn/folder48/folder50/folder62
孝感综合,video://https://share.xgrb.cn/live_detail?newsid=25009136_xgrb
孝感生活,video://https://share.xgrb.cn/live_detail?newsid=25009684_xgrb
黄冈广播电视,video://http://m-huanggang.cjyun.org/zhibo?2022

武汉新闻综合,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=6EBYbZ&tk=YGJeCMRBQ0DY
武汉电视剧,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=psXKt7&tk=YGJeCMRBQ0DY
武汉生活,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=5Mstn5&tk=YGJeCMRBQ0DY
武汉教育,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=ficm2g&tk=YGJeCMRBQ0DY
湖北公共新闻,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=5d8Iyz&tk=YGJeCMRBQ0DY
湖北经视,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=ILED08&tk=YGJeCMRBQ0DY
湖北综合,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=5DIZo2&tk=YGJeCMRBQ0DY
湖北垄上,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=2ZVTt7&tk=YGJeCMRBQ0DY
湖北影视,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=BPlzf9&tk=YGJeCMRBQ0DY
湖北生活,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=SDV9Dg&tk=YGJeCMRBQ0DY
湖北教育,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=77JNcf&tk=YGJeCMRBQ0DY

湖南频道,#genre#
湖南经视,http://php.jdshipin.com:8880/iptv.php?id=hnjs
湖南都市,http://php.jdshipin.com:8880/iptv.php?id=hnds
湖南爱晚,http://php.jdshipin.com:8880/iptv.php?id=hngg
湖南电视剧,http://php.jdshipin.com:8880/iptv.php?id=hndsj
湖南电影,http://php.jdshipin.com:8880/iptv.php?id=hndy
湖南娱乐,http://php.jdshipin.com:8880/iptv.php?id=hnyl
湖南国际,http://php.jdshipin.com:8880/iptv.php?id=hngj
湘潭新闻综合,http://live.hnxttv.com:9601/live/xwzh/800K/tzwj_video.m3u8
湘潭公共频道,http://live.hnxttv.com:9601/live/dspd/800K/tzwj_video.m3u8
湘潭新闻综合,http://live.hnxttv.com:9601/live/xwzh/800K/tzwj_video.m3u8?zhund
湘潭公共频道,http://live.hnxttv.com:9601/live/dspd/800K/tzwj_video.m3u8?zhund
金鹰卡通,video://https://live.mgtv.com/?channelId=287#video://https://www.mgtv.com/live/
湖南卡通,video://https://live.mgtv.com/?channelId=346
湘潭,video://http://www.hnxttv.com/live/ivideo/index.html
邵阳1,video://http://www.sytv.net.cn/folder2188/folder2190
邵阳2,video://http://share.sytv.net.cn/?_hgOutLink=live/livedetail&channel_id=34
娄底综合,video://http://www.ldntv.cn/folder51/folder154/folder171
郴州综合,video://https://www.ngcz.tv/folder83/folder86

湖南卫视,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=TIoVqm&tk=YGJeCMRBQ0DY
湖南经视,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=HWxJYB&tk=YGJeCMRBQ0DY
湖南国际,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=NDp3fx&tk=YGJeCMRBQ0DY
湖南都市,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=yM1Ikq&tk=YGJeCMRBQ0DY
湖南娱乐,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=phHX1h&tk=YGJeCMRBQ0DY
湖南电影,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=zWWw5H&tk=YGJeCMRBQ0DY
湖南公共,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=BxN6st&tk=YGJeCMRBQ0DY
湖南电视剧,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=fwg9Xq&tk=YGJeCMRBQ0DY
金鹰卡通,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=dcur8w&tk=YGJeCMRBQ0DY
金鹰纪实,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=DGc7SA&tk=YGJeCMRBQ0DY
长沙政法,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=TiaiiV&tk=YGJeCMRBQ0DY
长沙新闻,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=9PCuIT&tk=YGJeCMRBQ0DY
长沙女性,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=RwsM4q&tk=YGJeCMRBQ0DY
长沙影视,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=ZoiTmP&tk=YGJeCMRBQ0DY
湘西综合,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=jYfCgG&tk=YGJeCMRBQ0DY
湘西综合,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=Eg3Uq7&tk=YGJeCMRBQ0DY
河南梨园,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=QY000M&tk=YGJeCMRBQ0DY
文物宝库,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=sTO09i&tk=YGJeCMRBQ0DY
武术世界,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=Ijwwxp&tk=YGJeCMRBQ0DY
张家界2,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=XkzRxd&tk=YGJeCMRBQ0DY
张家界综合,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=aJDuBP&tk=YGJeCMRBQ0DY
快乐垂钓,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=v5ujKR&tk=YGJeCMRBQ0DY
浏阳,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=UTi1oT&tk=YGJeCMRBQ0DY
常德综合,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=Jjn22S&tk=YGJeCMRBQ0DY
常德公共,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=r3Iy5q&tk=YGJeCMRBQ0DY
衡阳综合,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=c6BKAx&tk=YGJeCMRBQ0DY
衡阳公共,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=cPW7I8&tk=YGJeCMRBQ0DY
娄底综合,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=g9zols&tk=YGJeCMRBQ0DY
娄底公共,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=xislaf&tk=YGJeCMRBQ0DY
张家界综合,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=jZyAHv&tk=YGJeCMRBQ0DY
张家界2,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=o2wbfv&tk=YGJeCMRBQ0DY
LDETV,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=wADjG0&tk=YGJeCMRBQ0DY
XNXTV,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=ism1Bz&tk=YGJeCMRBQ0DY
邵阳新闻,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=XWXzYv&tk=YGJeCMRBQ0DY
永州新闻,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=khUpvD&tk=YGJeCMRBQ0DY
怀化综合,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=nH18F7&tk=YGJeCMRBQ0DY
湖南卫视,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=7FV2ZE&tk=YGJeCMRBQ0DY
湖南国际,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=yLLBC2&tk=YGJeCMRBQ0DY
湖南卫视F,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=S0OwDo&tk=YGJeCMRBQ0DY
湖南经视,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=fOFl52&tk=YGJeCMRBQ0DY
湖南都市,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=RWgBbI&tk=YGJeCMRBQ0DY
湖南娱乐,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=9wshOU&tk=YGJeCMRBQ0DY
湖南电影,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=6C5ftS&tk=YGJeCMRBQ0DY
湖南电视剧,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=S8uMMY&tk=YGJeCMRBQ0DY
金鹰卡通,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=8hOT0E&tk=YGJeCMRBQ0DY
湖南公共,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=oA5lU4&tk=YGJeCMRBQ0DY
金鹰纪实,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=hyOPyU&tk=YGJeCMRBQ0DY
长沙新闻,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=PZOeFV&tk=YGJeCMRBQ0DY
长沙政法,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=03wGgK&tk=YGJeCMRBQ0DY
湖南卫视,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=v0lXye&tk=YGJeCMRBQ0DY
湖南经视,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=ofPXsP&tk=YGJeCMRBQ0DY
湖南电视剧,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=y7KI2U&tk=YGJeCMRBQ0DY
湖南电影,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=C6yYdT&tk=YGJeCMRBQ0DY
金鹰卡通,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=1nOeAh&tk=YGJeCMRBQ0DY
湖南公共,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=XnBk2Z&tk=YGJeCMRBQ0DY
湖南娱乐,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=7kgKmb&tk=YGJeCMRBQ0DY
金鹰纪实,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=9WATwu&tk=YGJeCMRBQ0DY
湖南国际,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=MEePD4&tk=YGJeCMRBQ0DY
湖南都市,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=4N6cOM&tk=YGJeCMRBQ0DY
快乐垂钓,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=9c6m2L&tk=YGJeCMRBQ0DY
长沙影视,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=yqdFe4&tk=YGJeCMRBQ0DY
湘西综合,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=XzKFfk&tk=YGJeCMRBQ0DY
湘西公共,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=bASfbO&tk=YGJeCMRBQ0DY
湘西公共,http://kkk.888.3116598.xyz/api.php?n=ghbzhx&id=vbJaZa&tk=YGJeCMRBQ0DY

上海频道,#genre#
东方影视,https://zby.130519.xyz/PLTV/11/224/3221225744/index.m3u8
东方财经,https://zby.130519.xyz/PLTV/11/224/3221226134/index.m3u8
新闻综合,https://zby.130519.xyz/PLTV/11/224/3221226136/index.m3u8
法治天地,https://zby.130519.xyz/PLTV/11/224/3221225994/index.m3u8
上海新闻综合,video://https://live.kankanews.com/huikan?id=2
上海都市,video://https://live.kankanews.com/huikan?id=4
第一财经,video://https://live.kankanews.com/huikan?id=5
哈哈炫动,video://https://live.kankanews.com/huikan?id=9
五星体育,video://https://live.kankanews.com/huikan?id=10
魔都眼,video://https://live.kankanews.com/huikan?id=11
新纪实,video://https://live.kankanews.com/huikan?id=12

广东频道,#genre#
广州综合频道,http://tencentplaygzrb01.gztv.com/live/zonghes.m3u8
广州新闻频道,http://tencentplaygzrb01.gztv.com/live/xinwen.m3u8
广州竞赛频道,http://tencentplaygzrb01.gztv.com/live/jingsai.m3u8
广州影视频道,http://tencentplaygzrb01.gztv.com/live/yingshi.m3u8
广州法治频道,http://tencentplaygzrb01.gztv.com/live/fazhi.m3u8
广州南国频道,http://tencentplaygzrb01.gztv.com/live/nanguodushi.m3u8
广州竞赛频道,http://php.jdshipin.com:8880/gztv.php?id=jingsai
南国都市频道,http://php.jdshipin.com:8880/gztv.php?id=shenghuo
番禺电视频道,http://video.epaper.pybtv.cn:8080/live/rtmp_live_demo.flv

广州综合,https://tencentplay.gztv.com/live/zonghes.m3u8?txSecret=9e5008d4b91944fa76a957a93ae54870&txTime=1903e5f1cfd
广州影视,https://tencentplay.gztv.com/live/yingshi.m3u8?txSecret=ec79a0d817981989c161f548c48c2954&txTime=1903e79e680
广州新闻,https://tencentplay.gztv.com/live/xinwen.m3u8?txSecret=4c09e8c2d093bcb692e036ae54ff87c7&txTime=1903e37cd8a
广州竞赛,https://tencentplay.gztv.com/live/jingsai.m3u8?txSecret=9be68e7c35579d02d11f6968531343ea&txTime=1903ea2dd6a
广州法治,https://tencentplay.gztv.com/live/fazhi.m3u8?txSecret=040cda8ae37088f2b96bea7b68bd0eb5&txTime=1903e5b8abe
广州南国都市,https://tencentplay.gztv.com/live/nanguodushi.m3u8?txSecret=550af55c0ea34ce492748481415b6dfa&txTime=1903e7b17de
东莞综合,https://stream.sun0769.com/dgrtv1/mp4tv1_1500/index.m3u8
东莞生活资讯,https://stream.sun0769.com/dgrtv1/mp4tv2_1500/index.m3u8
河源综合,http://tmpstream.hyrtv.cn/xwzh/sd/live.m3u8
河源公共,http://tmpstream.hyrtv.cn/hygg/sd/live.m3u8
梅州综合,http://pili-live-hls.xianchangliving.gdmztv.com:80/meizhou-xianchangliving/mztv1.m3u8
客家生活,http://pili-live-hls.xianchangliving.gdmztv.com:80/meizhou-xianchangliving/mztv2.m3u8
云浮综合,https://livestream.oeeee.com/slive/17806.m3u8
云浮文旅,https://livestream.oeeee.com/slive/17807.m3u8
韶关综合,https://www.sgmsw.cn/videos/tv/201805/1308/SB05RIYZOU8JR418AUQOF62CAJQ08D0E/hls/live.m3u8
番禺新闻,http://video.epaper.pybtv.cn:8080/live/rtmp_live_demo.flv

广西频道,#genre#
南宁公共,rtmp://live.gxrb.com.cn/tv/nntv_gg
南宁新闻综合,rtmp://tv.qntv.net/channellive/ch1?zguizd
南宁新闻综合,rtmp://live.gxrb.com.cn/tv/nntv
桂林新闻,https://pull.gltvs.com:443/live/glxw/playlist.m3u8?v=b0528684bf934e120e1c30fc808e6576&t=1796868188
桂林新闻,https://pull.gltvs.com/live/glxw/playlist.m3u8?v=b0528684bf934e120e1c30fc808e6576&t=1796868188

河南频道,#genre#
河南卫视,http://140.210.9.53:8800/SuanFaZhibo/live5/henan/henan.php?id=hnws
河南新闻,http://140.210.9.53:8800/SuanFaZhibo/live5/henan/henan.php?id=hnxw
河南都市,http://140.210.9.53:8800/SuanFaZhibo/live5/henan/henan.php?id=hnds
河南民生,http://140.210.9.53:8800/SuanFaZhibo/live5/henan/henan.php?id=hnms
河南公共,http://140.210.9.53:8800/SuanFaZhibo/live5/henan/henan.php?id=hngg
河南乡村,http://140.210.9.53:8800/SuanFaZhibo/live5/henan/henan.php?id=hnxc
河南梨园,http://140.210.9.53:8800/SuanFaZhibo/live5/henan/henan.php?id=hnly
河南法治,http://140.210.9.53:8800/SuanFaZhibo/live5/henan/henan.php?id=hmfz
河南电视剧,http://140.210.9.53:8800/SuanFaZhibo/live5/henan/henan.php?id=hndsj
武术世界,http://140.210.9.53:8800/SuanFaZhibo/live5/henan/henan.php?id=wspd
文物宝库,http://140.210.9.53:8800/SuanFaZhibo/live5/henan/henan.php?id=wwbk
睛彩中原,http://140.210.9.53:8800/SuanFaZhibo/live5/henan/henan.php?id=jczy
移动戏曲,http://140.210.9.53:8800/SuanFaZhibo/live5/henan/henan.php?id=ydxj
大象视界,http://140.210.9.53:8800/SuanFaZhibo/live5/henan/henan.php?id=xsj
欢腾购物,http://140.210.9.53:8800/SuanFaZhibo/live5/henan/henan.php?id=htgw
郑州综合,http://140.210.9.53:8800/SuanFaZhibo/live5/henan/henan.php?id=zz1
开封综合,http://140.210.9.53:8800/SuanFaZhibo/live5/henan/henan.php?id=kf1
开封文旅,http://live.dxhmt.cn:9081/tv/10200-3.m3u8?/henan/henan.php?id=kf2
洛阳综合,http://140.210.9.53:8800/SuanFaZhibo/live5/henan/henan.php?id=ly1
安阳综合,http://140.210.9.53:8800/SuanFaZhibo/live5/henan/henan.php?id=ay1
鹤壁综合,http://140.210.9.53:8800/SuanFaZhibo/live5/henan/henan.php?id=hb1
新乡综合,http://140.210.9.53:8800/SuanFaZhibo/live5/henan/henan.php?id=xx1
焦作综合,http://140.210.9.53:8800/SuanFaZhibo/live5/henan/henan.php?id=jz1
濮阳综合,http://140.210.9.53:8800/SuanFaZhibo/live5/henan/henan.php?id=py1
许昌综合,http://140.210.9.53:8800/SuanFaZhibo/live5/henan/henan.php?id=xc1
漯河综合,http://140.210.9.53:8800/SuanFaZhibo/live5/henan/henan.php?id=lh1
南阳综合,http://140.210.9.53:8800/SuanFaZhibo/live5/henan/henan.php?id=ny1
商丘综合,http://140.210.9.53:8800/SuanFaZhibo/live5/henan/henan.php?id=sq1
信阳综合,http://140.210.9.53:8800/SuanFaZhibo/live5/henan/henan.php?id=xy1
周口综合,http://140.210.9.53:8800/SuanFaZhibo/live5/henan/henan.php?id=zk1
济源综合,http://140.210.9.53:8800/SuanFaZhibo/live5/henan/henan.php?id=jy1
平顶山综合,http://140.210.9.53:8800/SuanFaZhibo/live5/henan/henan.php?id=pds1
三门峡综合,http://140.210.9.53:8800/SuanFaZhibo/live5/henan/henan.php?id=smx1
驻马店综合,http://140.210.9.53:8800/SuanFaZhibo/live5/henan/henan.php?id=zmd1
 
河南卫视,http://150.158.10.195:80/dxxw.php?id=hnws
河南新闻,http://150.158.10.195:80/dxxw.php?id=hnxw
河南都市,http://150.158.10.195:80/dxxw.php?id=hnds
河南民生,http://150.158.10.195:80/dxxw.php?id=hnms
河南公共,http://150.158.10.195:80/dxxw.php?id=hngg
河南乡村,http://150.158.10.195:80/dxxw.php?id=hnxc
河南梨园,http://150.158.10.195:80/dxxw.php?id=hnly
河南法治,http://150.158.10.195:80/dxxw.php?id=hmfz
河南电视剧,http://150.158.10.195:80/dxxw.php?id=hndsj
武术世界,http://150.158.10.195:80/dxxw.php?id=wspd
文物宝库,http://150.158.10.195:80/dxxw.php?id=wwbk
睛彩中原,http://150.158.10.195:80/dxxw.php?id=jczy
移动戏曲,http://150.158.10.195:80/dxxw.php?id=ydxj
大象视界,http://150.158.10.195:80/dxxw.php?id=xsj
欢腾购物,http://150.158.10.195:80/dxxw.php?id=htgw
郑州综合,http://150.158.10.195:80/dxxw.php?id=zz1
开封综合,http://150.158.10.195:80/dxxw.php?id=kf1
开封文旅,http://live.dxhmt.cn:9081/tv/10200-3.m3u8
洛阳综合,http://150.158.10.195:80/dxxw.php?id=ly1
安阳综合,http://150.158.10.195:80/dxxw.php?id=ay1
鹤壁综合,http://150.158.10.195:80/dxxw.php?id=hb1
新乡综合,http://150.158.10.195:80/dxxw.php?id=xx1
焦作综合,http://150.158.10.195:80/dxxw.php?id=jz1
濮阳综合,http://150.158.10.195:80/dxxw.php?id=py1
许昌综合,http://150.158.10.195:80/dxxw.php?id=xc1
漯河综合,http://150.158.10.195:80/dxxw.php?id=lh1
南阳综合,http://150.158.10.195:80/dxxw.php?id=ny1
商丘综合,http://150.158.10.195:80/dxxw.php?id=sq1
信阳综合,http://150.158.10.195:80/dxxw.php?id=xy1
周口综合,http://150.158.10.195:80/dxxw.php?id=zk1
济源综合,http://150.158.10.195:80/dxxw.php?id=jy1
平顶山综合,http://150.158.10.195:80/dxxw.php?id=pds1
三门峡综合,http://150.158.10.195:80/dxxw.php?id=smx1
驻马店综合,http://150.158.10.195:80/dxxw.php?id=zmd1
 
河南卫视,http://1.94.31.214/php/hntv.php?id=hnws
河南新闻,http://1.94.31.214/php/hntv.php?id=hnxw
河南都市,http://1.94.31.214/php/hntv.php?id=hnds
河南民生,http://1.94.31.214/php/hntv.php?id=hnms
河南公共,http://1.94.31.214/php/hntv.php?id=hngg
河南乡村,http://1.94.31.214/php/hntv.php?id=hnxc
河南梨园,http://1.94.31.214/php/hntv.php?id=hnly
河南法治,http://1.94.31.214/php/hntv.php?id=hmfz
河南电视剧,http://1.94.31.214/php/hntv.php?id=hndsj
武术世界,http://1.94.31.214/php/hntv.php?id=wspd
文物宝库,http://1.94.31.214/php/hntv.php?id=wwbk
睛彩中原,http://1.94.31.214/php/hntv.php?id=jczy
移动戏曲,http://1.94.31.214/php/hntv.php?id=ydxj
大象视界,http://1.94.31.214/php/hntv.php?id=xsj
欢腾购物,http://1.94.31.214/php/hntv.php?id=htgw

河南卫视,http://xxwx.yoesun.com/xxw/河南网.php?id=hnws
河南新闻,http://xxwx.yoesun.com/xxw/河南网.php?id=hnxw
河南都市,http://xxwx.yoesun.com/xxw/河南网.php?id=hnds
河南民生,http://xxwx.yoesun.com/xxw/河南网.php?id=hnms
河南公共,http://xxwx.yoesun.com/xxw/河南网.php?id=hngg
河南乡村,http://xxwx.yoesun.com/xxw/河南网.php?id=hnxc
河南梨园,http://xxwx.yoesun.com/xxw/河南网.php?id=hnly
河南法治,http://xxwx.yoesun.com/xxw/河南网.php?id=hmfz
河南电视剧,http://xxwx.yoesun.com/xxw/河南网.php?id=hndsj
武术世界,http://xxwx.yoesun.com/xxw/河南网.php?id=wspd
文物宝库,http://xxwx.yoesun.com/xxw/河南网.php?id=wwbk
睛彩中原,http://xxwx.yoesun.com/xxw/河南网.php?id=jczy
移动戏曲,http://xxwx.yoesun.com/xxw/河南网.php?id=ydxj
大象视界,http://xxwx.yoesun.com/xxw/河南网.php?id=xsj
欢腾购物,http://xxwx.yoesun.com/xxw/河南网.php?id=htgw
河南卫视,http://www.dsk.cc/hntv/hntv.php?id=hnws
河南新闻,http://www.dsk.cc/hntv/hntv.php?id=hnxw
河南都市,http://www.dsk.cc/hntv/hntv.php?id=hnds
河南民生,http://www.dsk.cc/hntv/hntv.php?id=hnms
河南公共,http://www.dsk.cc/hntv/hntv.php?id=hngg
河南乡村,http://www.dsk.cc/hntv/hntv.php?id=hnxc
河南梨园,http://www.dsk.cc/hntv/hntv.php?id=hnly
河南法治,http://www.dsk.cc/hntv/hntv.php?id=hmfz
河南电视剧,http://www.dsk.cc/hntv/hntv.php?id=hndsj
武术世界,http://www.dsk.cc/hntv/hntv.php?id=wspd
文物宝库,http://www.dsk.cc/hntv/hntv.php?id=wwbk
睛彩中原,http://www.dsk.cc/hntv/hntv.php?id=jczy
移动戏曲,http://www.dsk.cc/hntv/hntv.php?id=ydxj
大象视界,http://www.dsk.cc/hntv/hntv.php?id=xsj
欢腾购物,http://www.dsk.cc/hntv/hntv.php?id=htgw
郑州综合,http://www.dsk.cc/hntv/hntv.php?id=zz1
开封综合,http://www.dsk.cc/hntv/hntv.php?id=kf1
开封文旅,http://live.dxhmt.cn:9081/tv/10200-3.m3u8
兰考综合,http://live.dxhmt.cn:9081/tv/10225-1.m3u8
洛阳综合,http://www.dsk.cc/hntv/hntv.php?id=ly1
安阳综合,http://www.dsk.cc/hntv/hntv.php?id=ay1
鹤壁综合,http://www.dsk.cc/hntv/hntv.php?id=hb1
新乡综合,http://www.dsk.cc/hntv/hntv.php?id=xx1
焦作综合,http://www.dsk.cc/hntv/hntv.php?id=jz1
濮阳综合,http://www.dsk.cc/hntv/hntv.php?id=py1
许昌综合,http://www.dsk.cc/hntv/hntv.php?id=xc1
漯河综合,http://www.dsk.cc/hntv/hntv.php?id=lh1
南阳综合,http://www.dsk.cc/hntv/hntv.php?id=ny1
商丘综合,http://www.dsk.cc/hntv/hntv.php?id=sq1
信阳综合,http://www.dsk.cc/hntv/hntv.php?id=xy1
周口综合,http://www.dsk.cc/hntv/hntv.php?id=zk1
济源综合,http://www.dsk.cc/hntv/hntv.php?id=jy1
平顶山综合,http://www.dsk.cc/hntv/hntv.php?id=pds1
三门峡综合,http://www.dsk.cc/hntv/hntv.php?id=smx1
驻马店综合,http://www.dsk.cc/hntv/hntv.php?id=zmd1
开封新闻综合,http://tvpull.dxhmt.cn:9081/tv/10200-2.m3u8
开封文化旅游,http://tvpull.dxhmt.cn:9081/tv/10200-3.m3u8
潢川综合,http://tvpull.dxhmt.cn:9081/tv/11526-1.m3u8
郏县综合,http://tvpull.dxhmt.cn:9081/tv/10425-1.m3u8?zhend
兰考新闻,http://tvpull.dxhmt.cn:9081/tv/10225-1.m3u8
叶县一套,http://tvpull.dxhmt.cn:9081/tv/10422-1.m3u8
新野综合,http://tvpull.dxhmt.cn:9081/tv/11329-1.m3u8
封丘新闻综合,http://tvpull.dxhmt.cn:9081/tv/10727-1.m3u8
辉县新闻综合,http://tvpull.dxhmt.cn:9081/tv/10782-1.m3u8
舞钢新闻综合,http://tvpull.dxhmt.cn:9081/tv/10481-1.m3u8
巩义新闻综合,http://tvpull.dxhmt.cn:9081/tv/10181-1.m3u8
舞阳新闻综合,http://tvpull.dxhmt.cn:9081/tv/11121-1.m3u8
镇平新闻综合,http://tvpull.dxhmt.cn:9081/tv/11324-1.m3u8
渑池新闻综合,http://tvpull.dxhmt.cn:9081/tv/11221-1.m3u8
沁阳新闻综合,http://tvpull.dxhmt.cn:9081/tv/10882-1.m3u8
泌阳新闻综合,http://tvpull.dxhmt.cn:9081/tv/11726-1.m3u8
桐柏新闻综合,http://tvpull.dxhmt.cn:9081/tv/11330-1.m3u8
新乡县电视台,http://tvpull.dxhmt.cn:9081/tv/10721-1.m3u8
义马新闻综合,http://tvpull.dxhmt.cn:9081/tv/11281-1.m3u8
灵宝新闻综合,http://tvpull.dxhmt.cn:9081/tv/11282-1.m3u8
杞县新闻综合,http://tvpull.dxhmt.cn:9081/tv/10221-1.m3u8
台前新闻综合,http://tvpull.dxhmt.cn:9081/tv/10927-1.m3u8
新安新闻综合,http://tvpull.dxhmt.cn:9081/tv/10323-1.m3u8
原阳新闻综合,http://tvpull.dxhmt.cn:9081/tv/10725-1.m3u8
宝丰综合频道,http://tvpull.dxhmt.cn:9081/tv/10421-1.m3u8?zhend
济源电视一套,http://tvpull.dxhmt.cn:9081/tv/19001-1.m3u8?zhend
灵宝新闻综合,http://tvpull.dxhmt.cn:9081/tv/11282-1.m3u8?zhend
鹿邑新闻频道,http://tvpull.dxhmt.cn:9081/tv/11628-1.m3u8?zhend
嵩县综合新闻,http://tvpull.dxhmt.cn:9081/tv/10325-1.m3u8?zhend
桐柏新闻综合,http://tvpull.dxhmt.cn:9081/tv/11330-1.m3u8?zhend
新安新闻综合,http://tvpull.dxhmt.cn:9081/tv/10323-1.m3u8?zhend
新乡县电视台,http://tvpull.dxhmt.cn:9081/tv/10721-1.m3u8?zhend
淇县电视台,http://tvpull.dxhmt.cn:9081/tv/10622-1.m3u8
上街电视台,http://tvpull.dxhmt.cn:9081/tv/10106-1.m3u8
滑县快乐3,http://tvpull.dxhmt.cn:9081/tv/10526-3.m3u8
太康综合,http://tvpull.dxhmt.cn:9081/tv/11627-1.m3u8
固始综合,http://tvpull.dxhmt.cn:9081/tv/11525-1.m3u8
新密新闻,http://tvpull.dxhmt.cn:9081/tv/10183-2.m3u8
唐河一套,http://tvpull.dxhmt.cn:9081/tv/11328-1.m3u8
孟州综合,http://tvpull.dxhmt.cn:9081/tv/10883-1.m3u8
林州综合,http://tvpull.dxhmt.cn:9081/tv/10581-1.m3u8
鲁山综合,http://tvpull.dxhmt.cn:9081/tv/10423-1.m3u8
登封综合,http://tvpull.dxhmt.cn:9081/tv/10185-1.m3u8
建安综合,http://tvpull.dxhmt.cn:9081/tv/11003-1.m3u8
孟津新闻,http://tvpull.dxhmt.cn:9081/tv/10322-2.m3u8
上蔡综合,http://tvpull.dxhmt.cn:9081/tv/11722-1.m3u8
淅川综合,http://tvpull.dxhmt.cn:9081/tv/11326-1.m3u8
襄城综合,http://tvpull.dxhmt.cn:9081/tv/11025-1.m3u8
项城新闻,http://tvpull.dxhmt.cn:9081/tv/11681-1.m3u8
新郑综合,http://tvpull.dxhmt.cn:9081/tv/10184-1.m3u8
鄢陵综合,http://tvpull.dxhmt.cn:9081/tv/11024-1.m3u8
社旗综合,http://tvpull.dxhmt.cn:9081/tv/11327-1.m3u8
扶沟综合,http://tvpull.dxhmt.cn:9081/tv/11621-1.m3u8
临颍综合,http://tvpull.dxhmt.cn:9081/tv/11122-1.m3u8
西平综合,http://tvpull.dxhmt.cn:9081/tv/11721-1.m3u8
光山综合,http://tvpull.dxhmt.cn:9081/tv/11522-1.m3u8
淮滨综合,http://tvpull.dxhmt.cn:9081/tv/11527-1.m3u8
内乡综合,http://tvpull.dxhmt.cn:9081/tv/11325-1.m3u8
汝南综合,http://tvpull.dxhmt.cn:9081/tv/11727-1.m3u8
新蔡综合,http://tvpull.dxhmt.cn:9081/tv/11729-1.m3u8
新县综合,http://tvpull.dxhmt.cn:9081/tv/11523-1.m3u8
禹州公共,http://tvpull.dxhmt.cn:9081/tv/11081-2.m3u8
禹州综合,http://tvpull.dxhmt.cn:9081/tv/11081-1.m3u8
遂平一套,http://tvpull.dxhmt.cn:9081/tv/11728-1.m3u8
安阳新闻,http://tvpull.dxhmt.cn:9081/tv/10522-1.m3u8
宝丰综合,http://tvpull.dxhmt.cn:9081/tv/10421-1.m3u8
邓州新闻,http://tvpull.dxhmt.cn:9081/tv/11381-1.m3u8
方城一套,http://tvpull.dxhmt.cn:9081/tv/11322-1.m3u8
滑县民生,http://tvpull.dxhmt.cn:9081/tv/10526-2.m3u8
滑县新闻,http://tvpull.dxhmt.cn:9081/tv/10526-1.m3u8
获嘉综合,http://tvpull.dxhmt.cn:9081/tv/10724-1.m3u8
郏县综合,http://tvpull.dxhmt.cn:9081/tv/10425-1.m3u8
浚县一套,http://tvpull.dxhmt.cn:9081/tv/10621-1.m3u8
鹿邑新闻,http://tvpull.dxhmt.cn:9081/tv/11628-1.m3u8
罗山综合,http://tvpull.dxhmt.cn:9081/tv/11521-1.m3u8
孟津生活,http://tvpull.dxhmt.cn:9081/tv/10322-1.m3u8
南乐综合,http://tvpull.dxhmt.cn:9081/tv/10923-1.m3u8
平舆综合,http://tvpull.dxhmt.cn:9081/tv/11723-1.m3u8
清丰综合,http://tvpull.dxhmt.cn:9081/tv/10922-1.m3u8
确山综合,http://tvpull.dxhmt.cn:9081/tv/11725-1.m3u8
汝州科教,http://tvpull.dxhmt.cn:9081/tv/10482-2.m3u8
汝州新闻,http://tvpull.dxhmt.cn:9081/tv/10482-1.m3u8
商城新闻,http://tvpull.dxhmt.cn:9081/tv/11524-1.m3u8
汤阴综合,http://tvpull.dxhmt.cn:9081/tv/10523-1.m3u8
通许综合,http://tvpull.dxhmt.cn:9081/tv/10222-1.m3u8
卫辉综合,http://tvpull.dxhmt.cn:9081/tv/10781-1.m3u8
尉氏综合,http://tvpull.dxhmt.cn:9081/tv/10223-1.m3u8
温县综合,http://tvpull.dxhmt.cn:9081/tv/10825-1.m3u8
西华综合,http://tvpull.dxhmt.cn:9081/tv/11622-1.m3u8
夏邑新闻,http://tvpull.dxhmt.cn:9081/tv/11426-1.m3u8
延津综合,http://tvpull.dxhmt.cn:9081/tv/10726-1.m3u8
永城民生,http://tvpull.dxhmt.cn:9081/tv/11481-2.m3u8
永城新闻,http://tvpull.dxhmt.cn:9081/tv/11481-1.m3u8
长垣综合,http://tvpull.dxhmt.cn:9081/tv/10728-1.m3u8
方城一套,http://tvpull.dxhmt.cn:9081/tv/11322-1.m3u8?zhend
扶沟综合,http://tvpull.dxhmt.cn:9081/tv/11621-1.m3u8?zhend
滑县新闻,http://tvpull.dxhmt.cn:9081/tv/10526-1.m3u8?zhend
温县综合,http://tvpull.dxhmt.cn:9081/tv/10825-1.m3u8?zhend
新野综合,http://tvpull.dxhmt.cn:9081/tv/11329-1.m3u8?zhend
荥阳综合,http://tvpull.dxhmt.cn:9081/tv/10182-1.m3u8?zhend
禹州综合,http://tvpull.dxhmt.cn:9081/tv/11081-1.m3u8?zhend
济源电视一套,http://tvpull.dxhmt.cn:9081/tv/19001-1.m3u8
宜阳综合频道,http://tvpull.dxhmt.cn:9081/tv/10327-1.m3u8
嵩县综合新闻,http://tvpull.dxhmt.cn:9081/tv/10325-1.m3u8
内黄综合频道,http://tvpull.dxhmt.cn:9081/tv/10527-1.m3u8
荥阳综合,http://tvpull.dxhmt.cn:9081/tv/10182-1.m3u8
郸城新闻综合,http://live.dxhmt.cn:9081/tv/11625-1.m3u8
济源电视一套,http://live.dxhmt.cn:9081/tv/19001-1.m3u8
周口扶沟,http://live.dxhmt.cn:9081/tv/11621-1.m3u8
叶县电视,http://live.dxhmt.cn:9081/tv/10422-1.m3u8
义马电视,http://live.dxhmt.cn:9081/tv/11281-1.m3u8
禹州综合,http://live.dxhmt.cn:9081/tv/11081-1.m3u8
新乡综合,http://live.dxhmt.cn:9081/tv/10721-1.m3u8
影用仓库,https://img.piexl.cn/view.php/8b3eea23e7bf605e907b2850b7a57815.mp4
范县新闻综合,http://live.dxhmt.cn:9080/13603832636/13abd3089d9c47058fe34c49a6182981.m3u8
焦作公共,http://zhpull.dxhmt.cn/jiaozuo/29b65b69130c4ef1a3283cc7b913da05/playlist.m3u8
焦作教育,http://zhpull.dxhmt.cn/jiaozuo/9c10435ad24c409baee219ec289e17d0/playlist.m3u8
焦作综合,http://zhpull.dxhmt.cn/jiaozuo/b75a92c9503e47cf9e89f7ff247b65f2/playlist.m3u8
睛彩焦作,http://zhpull.dxhmt.cn/jiaozuo/c5eb91b47f0e42318f34fc0247c8acaa/playlist.m3u8
鹤岗新闻综合,http://live.hznet.tv:1935/live/live2/500K/tzwj_video.m3u8
郑州教育,https://livezzutv.chinamcache.com/live/zb01.m3u8?auth_key=1677911572-0-0-f4af513ba8c09e7801f4700f1573be2c


河南｜荥阳综合,http://tvpull.dxhmt.cn:9081/tv/10182-1.m3u8?zhend
河南｜禹州公共,http://tvpull.dxhmt.cn:9081/tv/11081-2.m3u8
河南｜西华综合,http://tvpull.dxhmt.cn:9081/tv/11622-1.m3u8?zhend
河南｜邓州新闻,http://tvpull.dxhmt.cn:9081/tv/11381-1.m3u8?zhend
河南｜郏县综合,http://tvpull.dxhmt.cn:9081/tv/10425-1.m3u8?zhend
河南｜鄢陵综合,http://tvpull.dxhmt.cn:9081/tv/11024-1.m3u8
河南｜鹿邑新闻频道,http://tvpull.dxhmt.cn:9081/tv/11628-1.m3u8?zhend
河南｜卫辉综合频道,http://tvpull.dxhmt.cn:9081/tv/10781-1.m3u8?zhend
河南｜禹州综合,http://tvpull.dxhmt.cn:9081/tv/11081-1.m3u8
河南｜项城新闻,http://tvpull.dxhmt.cn:9081/tv/11681-1.m3u8
开封新闻,http://tvpull.dxhmt.cn:9081/tv/10200-2.m3u8
开封文化旅游,http://tvpull.dxhmt.cn:9081/tv/10200-3.m3u8
潢川,http://tvpull.dxhmt.cn:9081/tv/11526-1.m3u8
郏县,http://tvpull.dxhmt.cn:9081/tv/10425-1.m3u8?zhend
兰考新闻,http://tvpull.dxhmt.cn:9081/tv/10225-1.m3u8
叶县一套,http://tvpull.dxhmt.cn:9081/tv/10422-1.m3u8
新野,http://tvpull.dxhmt.cn:9081/tv/11329-1.m3u8
封丘新闻,http://tvpull.dxhmt.cn:9081/tv/10727-1.m3u8
辉县新闻,http://tvpull.dxhmt.cn:9081/tv/10782-1.m3u8
舞钢新闻,http://tvpull.dxhmt.cn:9081/tv/10481-1.m3u8
河南｜扶沟综合,http://tvpull.dxhmt.cn:9081/tv/11621-1.m3u8
河南｜扶沟综合,http://tvpull.dxhmt.cn:9081/tv/11621-1.m3u8?zhend
河南｜新乡县电视台,http://tvpull.dxhmt.cn:9081/tv/10721-1.m3u8?zhend
河南｜新乡县电视台,http://tvpull.dxhmt.cn:9081/tv/10721-1.m3u8
河南｜新县综合,http://tvpull.dxhmt.cn:9081/tv/11523-1.m3u8
河南｜新安新闻综合,http://tvpull.dxhmt.cn:9081/tv/10323-1.m3u8?zhend
河南｜新蔡综合,http://tvpull.dxhmt.cn:9081/tv/11729-1.m3u8
河南｜新野综合,http://tvpull.dxhmt.cn:9081/tv/11329-1.m3u8?zhend
河南｜方城一套,http://tvpull.dxhmt.cn:9081/tv/11322-1.m3u8?zhend
河南｜桐柏新闻综合,http://tvpull.dxhmt.cn:9081/tv/11330-1.m3u8
河南｜桐柏新闻综合,http://tvpull.dxhmt.cn:9081/tv/11330-1.m3u8?zhend
河南｜泌阳新闻综合,http://tvpull.dxhmt.cn:9081/tv/11726-1.m3u8
河南｜济源电视一套,http://tvpull.dxhmt.cn:9081/tv/19001-1.m3u8?zhend
河南｜渑池新闻综合,http://tvpull.dxhmt.cn:9081/tv/11221-1.m3u8
河南｜温县综合,http://tvpull.dxhmt.cn:9081/tv/10825-1.m3u8?zhend
河南｜滑县新闻,http://tvpull.dxhmt.cn:9081/tv/10526-1.m3u8?zhend
河南｜潢川综合,http://tvpull.dxhmt.cn:9081/tv/11526-1.m3u8
河南｜灵宝新闻综合,http://tvpull.dxhmt.cn:9081/tv/11282-1.m3u8?zhend
河南｜登封综合,http://tvpull.dxhmt.cn:9081/tv/10185-1.m3u8
河南｜禹州综合,http://tvpull.dxhmt.cn:9081/tv/11081-1.m3u8?zhend
尉氏综合,http://tvpull.dxhmt.cn:9081/tv/10223-1.m3u8
夏邑新闻,http://tvpull.dxhmt.cn:9081/tv/11426-1.m3u8
延津综合,http://tvpull.dxhmt.cn:9081/tv/10726-1.m3u8
永城民生,http://tvpull.dxhmt.cn:9081/tv/11481-2.m3u8
长垣综合,http://tvpull.dxhmt.cn:9081/tv/10728-1.m3u8
滑县新闻,http://tvpull.dxhmt.cn:9081/tv/10526-1.m3u8?zhend
禹州综合,http://tvpull.dxhmt.cn:9081/tv/11081-1.m3u8?zhend
河南｜临颍综合,http://tvpull.dxhmt.cn:9081/tv/11122-1.m3u8
河南｜义马新闻综合,http://tvpull.dxhmt.cn:9081/tv/11281-1.m3u8
河南｜光山综合,http://tvpull.dxhmt.cn:9081/tv/11522-1.m3u8
河南｜兰考新闻,http://tvpull.dxhmt.cn:9081/tv/10225-1.m3u8
河南｜内黄综合频道,http://tvpull.dxhmt.cn:9081/tv/10527-1.m3u8?zhend
河南｜叶县,http://tvpull.dxhmt.cn:9081/tv/10422-1.m3u8
河南｜唐河一套,http://tvpull.dxhmt.cn:9081/tv/11328-1.m3u8
河南｜唐河一套,http://tvpull.dxhmt.cn:9081/tv/11328-1.m3u8?zhend
河南｜固始综合,http://tvpull.dxhmt.cn:9081/tv/11525-1.m3u8
河南｜宜阳综合频道,http://tvpull.dxhmt.cn:9081/tv/10327-1.m3u8?zhend
河南｜宝丰综合频道,http://tvpull.dxhmt.cn:9081/tv/10421-1.m3u8?zhend
河南｜嵩县综合新闻,http://tvpull.dxhmt.cn:9081/tv/10325-1.m3u8?zhend
河南｜巩义新闻综合,http://tvpull.dxhmt.cn:9081/tv/10181-1.m3u8?zhend
新密新闻,http://tvpull.dxhmt.cn:9081/tv/10183-2.m3u8
鲁山综合,http://tvpull.dxhmt.cn:9081/tv/10423-1.m3u8
建安综合,http://tvpull.dxhmt.cn:9081/tv/11003-1.m3u8
孟津新闻,http://tvpull.dxhmt.cn:9081/tv/10322-2.m3u8
襄城综合,http://tvpull.dxhmt.cn:9081/tv/11025-1.m3u8
新郑综合,http://tvpull.dxhmt.cn:9081/tv/10184-1.m3u8
社旗综合,http://tvpull.dxhmt.cn:9081/tv/11327-1.m3u8
汝南综合,http://tvpull.dxhmt.cn:9081/tv/11727-1.m3u8
安阳新闻,http://tvpull.dxhmt.cn:9081/tv/10522-1.m3u8
滑县民生,http://tvpull.dxhmt.cn:9081/tv/10526-2.m3u8
获嘉综合,http://tvpull.dxhmt.cn:9081/tv/10724-1.m3u8
鹿邑新闻,http://tvpull.dxhmt.cn:9081/tv/11628-1.m3u8
罗山综合,http://tvpull.dxhmt.cn:9081/tv/11521-1.m3u8
孟津生活,http://tvpull.dxhmt.cn:9081/tv/10322-1.m3u8
南乐综合,http://tvpull.dxhmt.cn:9081/tv/10923-1.m3u8
清丰综合,http://tvpull.dxhmt.cn:9081/tv/10922-1.m3u8
汝州科教,http://tvpull.dxhmt.cn:9081/tv/10482-2.m3u8
汝州新闻,http://tvpull.dxhmt.cn:9081/tv/10482-1.m3u8
商城新闻,http://tvpull.dxhmt.cn:9081/tv/11524-1.m3u8
通许综合,http://tvpull.dxhmt.cn:9081/tv/10222-1.m3u8
固始综合频道,http://tvpull.dxhmt.cn:9081/tv/11525-1.m3u8
淮滨综合频道,http://tvpull.dxhmt.cn:9081/tv/11527-1.m3u8
潢川综合频道,http://tvpull.dxhmt.cn:9081/tv/11526-1.m3u8
罗山综合频道,http://tvpull.dxhmt.cn:9081/tv/11521-1.m3u8
新县综合频道,http://tvpull.dxhmt.cn:9081/tv/11523-1.m3u8
建安综合频道,http://tvpull.dxhmt.cn:9081/tv/11003-1.m3u8
襄城综合频道,http://tvpull.dxhmt.cn:9081/tv/11025-1.m3u8
鄢陵综合频道,http://tvpull.dxhmt.cn:9081/tv/11024-1.m3u8
禹州综合,http://tvpull.dxhmt.cn:9081/tv/11081-1.m3u8
淮滨综合,http://tvpull.dxhmt.cn:9081/tv/11527-1.m3u8
临颍综合,http://tvpull.dxhmt.cn:9081/tv/11122-1.m3u8
开封新闻综合,http://tvpull.dxhmt.cn:9081/tv/10200-2.m3u8
台前新闻综合,http://tvpull.dxhmt.cn:9081/tv/10927-1.m3u8
宝丰综合频道,http://tvpull.dxhmt.cn:9081/tv/10421-1.m3u8?zhend
鹿邑新闻频道,http://tvpull.dxhmt.cn:9081/tv/11628-1.m3u8?zhend
嵩县综合新闻,http://tvpull.dxhmt.cn:9081/tv/10325-1.m3u8?zhend
新乡县电视台,http://tvpull.dxhmt.cn:9081/tv/10721-1.m3u8?zhend
上街电视台,http://tvpull.dxhmt.cn:9081/tv/10106-1.m3u8
星城上街电视台,http://tvpull.dxhmt.cn:9081/tv/10106-1.m3u8
滑县快乐3,http://tvpull.dxhmt.cn:9081/tv/10526-3.m3u8
上蔡综合,http://tvpull.dxhmt.cn:9081/tv/11722-1.m3u8
遂平一套,http://tvpull.dxhmt.cn:9081/tv/11728-1.m3u8
西平综合,http://tvpull.dxhmt.cn:9081/tv/11721-1.m3u8
长垣综合频道,http://tvpull.dxhmt.cn:9081/tv/10728-1.m3u8
封丘新闻综合,http://tvpull.dxhmt.cn:9081/tv/10727-1.m3u8
获嘉综合频道,http://tvpull.dxhmt.cn:9081/tv/10724-1.m3u8
辉县新闻综合,http://tvpull.dxhmt.cn:9081/tv/10782-1.m3u8
卫辉综合频道,http://tvpull.dxhmt.cn:9081/tv/10781-1.m3u8
延津综合频道,http://tvpull.dxhmt.cn:9081/tv/10726-1.m3u8
原阳新闻综合,http://tvpull.dxhmt.cn:9081/tv/10725-1.m3u8
灵宝新闻综合,http://tvpull.dxhmt.cn:9081/tv/11282-1.m3u8
卢氏综合频道,http://tvpull.dxhmt.cn:9081/tv/11224-1.m3u8
安阳县新闻综合,http://tvpull.dxhmt.cn:9081/tv/10522-1.m3u8
滑县新闻,http://tvpull.dxhmt.cn:9081/tv/10526-1.m3u8
林州综合,http://tvpull.dxhmt.cn:9081/tv/10581-1.m3u8
内黄综合频道,http://tvpull.dxhmt.cn:9081/tv/10527-1.m3u8
淇县电视台,http://tvpull.dxhmt.cn:9081/tv/10622-1.m3u8
浚县一套,http://tvpull.dxhmt.cn:9081/tv/10621-1.m3u8
南乐综合频道,http://tvpull.dxhmt.cn:9081/tv/10923-1.m3u8
光山综合频道,http://tvpull.dxhmt.cn:9081/tv/11522-1.m3u8
宜阳综合频道,http://tvpull.dxhmt.cn:9081/tv/10327-1.m3u8
孟州综合,http://tvpull.dxhmt.cn:9081/tv/10883-1.m3u8
武陟新闻综合,http://tvpull.dxhmt.cn:9081/tv/10823-1.m3u8
邓州新闻,http://tvpull.dxhmt.cn:9081/tv/11381-1.m3u8
内乡综合,http://tvpull.dxhmt.cn:9081/tv/11325-1.m3u8
淅川综合,http://tvpull.dxhmt.cn:9081/tv/11326-1.m3u8
镇平新闻综合,http://tvpull.dxhmt.cn:9081/tv/11324-1.m3u8
扶沟综合频道,http://tvpull.dxhmt.cn:9081/tv/11621-1.m3u8
鹿邑新闻频道,http://tvpull.dxhmt.cn:9081/tv/11628-1.m3u8
沈丘新闻综合,http://tvpull.dxhmt.cn:9081/tv/11624-1.m3u8
太康综合,http://tvpull.dxhmt.cn:9081/tv/11627-1.m3u8
西华综合频道,http://tvpull.dxhmt.cn:9081/tv/11622-1.m3u8
兰考新闻频道,http://tvpull.dxhmt.cn:9081/tv/10225-1.m3u8
杞县新闻综合,http://tvpull.dxhmt.cn:9081/tv/10221-1.m3u8
通许综合频道,http://tvpull.dxhmt.cn:9081/tv/10222-1.m3u8
尉氏综合频道,http://tvpull.dxhmt.cn:9081/tv/10223-1.m3u8
临颍综合频道,http://tvpull.dxhmt.cn:9081/tv/11122-1.m3u8
舞阳新闻综合,http://tvpull.dxhmt.cn:9081/tv/11121-1.m3u8
平舆综合,http://tvpull.dxhmt.cn:9081/tv/11723-1.m3u8
确山综合,http://tvpull.dxhmt.cn:9081/tv/11725-1.m3u8
宝丰综合,http://tvpull.dxhmt.cn:9081/tv/10421-1.m3u8#http://live.dxhmt.cn:9081/tv/10421-1.m3u8
郏县综合,http://tvpull.dxhmt.cn:9081/tv/10425-1.m3u8#http://live.dxhmt.cn:9081/tv/10425-1.m3u8
鲁山综合,http://tvpull.dxhmt.cn:9081/tv/10423-1.m3u8#http://live.dxhmt.cn:9081/tv/10423-1.m3u8
舞钢综合,http://tvpull.dxhmt.cn:9081/tv/10481-1.m3u8#http://live.dxhmt.cn:9081/tv/10481-1.m3u8#http://live.dxhmt.cn:9080/13937510433/1fd30c3556cd401089d087167a7879fe.m3u8
叶县一套,http://tvpull.dxhmt.cn:9081/tv/10422-1.m3u8#http://live.dxhmt.cn:9081/tv/10422-1.m3u8
永城新闻,http://tvpull.dxhmt.cn:9081/tv/11481-1.m3u8
登封综合频道,http://tvpull.dxhmt.cn:9081/tv/10185-1.m3u8
新密新闻频道,http://tvpull.dxhmt.cn:9081/tv/10183-2.m3u8
新郑综合频道,http://tvpull.dxhmt.cn:9081/tv/10184-1.m3u8
宝丰综合频道,http://tvpull.dxhmt.cn:9081/tv/10421-1.m3u8
郏县综合频道,http://tvpull.dxhmt.cn:9081/tv/10425-1.m3u8
鲁山综合频道,http://tvpull.dxhmt.cn:9081/tv/10423-1.m3u8
舞钢新闻综合,http://tvpull.dxhmt.cn:9081/tv/10481-1.m3u8
叶县一套,http://tvpull.dxhmt.cn:9081/tv/10422-1.m3u8
栾川新闻频道,http://tvpull.dxhmt.cn:9081/tv/10324-1.m3u8
孟津新闻频道,http://tvpull.dxhmt.cn:9081/tv/10322-2.m3u8
汝阳综合频道,http://tvpull.dxhmt.cn:9081/tv/10326-1.m3u8
嵩县综合新闻,http://tvpull.dxhmt.cn:9081/tv/10325-1.m3u8
伊川电视台,http://tvpull.dxhmt.cn:9081/tv/10329-1.m3u8
偃师新闻频道,http://tvpull.dxhmt.cn:9081/tv/10381-1.m3u8
淮滨综合,http://tvpull.dxhmt.cn:9081/tv/11527-1.m3u8#http://live.dxhmt.cn:9081/tv/11527-1.m3u8
潢川综合,http://tvpull.dxhmt.cn:9081/tv/11526-1.m3u8#http://live.dxhmt.cn:9081/tv/11526-1.m3u8
罗山综合,http://tvpull.dxhmt.cn:9081/tv/11521-1.m3u8#http://live.dxhmt.cn:9081/tv/11521-1.m3u8
商城综合,http://tvpull.dxhmt.cn:9081/tv/11524-1.m3u8#http://live.dxhmt.cn:9081/tv/11524-1.m3u8
新县综合,http://tvpull.dxhmt.cn:9081/tv/11523-1.m3u8#http://live.dxhmt.cn:9081/tv/11523-1.m3u8
临颍综合,http://tvpull.dxhmt.cn:9081/tv/11122-1.m3u8#http://live.dxhmt.cn:9081/tv/11122-1.m3u8
舞阳综合,http://tvpull.dxhmt.cn:9081/tv/11121-1.m3u8#http://live.dxhmt.cn:9081/tv/11121-1.m3u8
济源一套,http://tvpull.dxhmt.cn:9081/tv/19001-1.m3u8#http://live.dxhmt.cn:9081/tv/19001-1.m3u8
泌阳综合,http://tvpull.dxhmt.cn:9081/tv/11726-1.m3u8#http://live.dxhmt.cn:9081/tv/11726-1.m3u8
平舆综合,http://tvpull.dxhmt.cn:9081/tv/11723-1.m3u8#http://live.dxhmt.cn:9081/tv/11723-1.m3u8
确山综合,http://tvpull.dxhmt.cn:9081/tv/11725-1.m3u8#http://live.dxhmt.cn:9081/tv/11725-1.m3u8
上蔡综合,http://tvpull.dxhmt.cn:9081/tv/11722-1.m3u8#http://live.dxhmt.cn:9081/tv/11722-1.m3u8
新蔡综合,http://tvpull.dxhmt.cn:9081/tv/11729-1.m3u8#http://live.dxhmt.cn:9081/tv/11729-1.m3u8
西平综合,http://tvpull.dxhmt.cn:9081/tv/11721-1.m3u8#http://live.dxhmt.cn:9081/tv/11721-1.m3u8
长垣综合,http://tvpull.dxhmt.cn:9081/tv/10728-1.m3u8#http://live.dxhmt.cn:9081/tv/10728-1.m3u8
封丘综合,http://tvpull.dxhmt.cn:9081/tv/10727-1.m3u8#http://live.dxhmt.cn:9081/tv/10727-1.m3u8
辉县综合,http://tvpull.dxhmt.cn:9081/tv/10782-1.m3u8#http://live.dxhmt.cn:9081/tv/10782-1.m3u8
卫辉综合,http://tvpull.dxhmt.cn:9081/tv/10781-1.m3u8#http://live.dxhmt.cn:9081/tv/10781-1.m3u8
新乡综合,http://tvpull.dxhmt.cn:9081/tv/10721-1.m3u8#http://live.dxhmt.cn:9081/tv/10721-1.m3u8
原阳综合,http://tvpull.dxhmt.cn:9081/tv/10725-1.m3u8#http://live.dxhmt.cn:9081/tv/10725-1.m3u8
襄城综合,http://tvpull.dxhmt.cn:9081/tv/11025-1.m3u8#http://live.dxhmt.cn:9081/tv/11025-1.m3u8
鄢陵综合,http://tvpull.dxhmt.cn:9081/tv/11024-1.m3u8#http://live.dxhmt.cn:9081/tv/11024-1.m3u8
禹州综合,http://tvpull.dxhmt.cn:9081/tv/11081-1.m3u8#http://live.dxhmt.cn:9081/tv/11081-1.m3u8
开封综合,http://tvpull.dxhmt.cn:9081/tv/10200-2.m3u8#http://live.dxhmt.cn:9081/tv/10200-2.m3u8
开封公共,http://tvpull.dxhmt.cn:9081/tv/10200-3.m3u8#http://live.dxhmt.cn:9081/tv/10200-3.m3u8
兰考新闻,http://tvpull.dxhmt.cn:9081/tv/10225-1.m3u8#http://live.dxhmt.cn:9081/tv/10225-1.m3u8
杞县综合,http://tvpull.dxhmt.cn:9081/tv/10221-1.m3u8#http://live.dxhmt.cn:9081/tv/10221-1.m3u8
尉氏综合,http://tvpull.dxhmt.cn:9081/tv/10223-1.m3u8#http://live.dxhmt.cn:9081/tv/10223-1.m3u8
扶沟综合,http://tvpull.dxhmt.cn:9081/tv/11621-1.m3u8#http://live.dxhmt.cn:9081/tv/11621-1.m3u8
鹿邑新闻,http://tvpull.dxhmt.cn:9081/tv/11628-1.m3u8#http://live.dxhmt.cn:9081/tv/11628-1.m3u8
沈丘综合,http://tvpull.dxhmt.cn:9081/tv/11624-1.m3u8#http://live.dxhmt.cn:9081/tv/11624-1.m3u8
项城综合,http://tvpull.dxhmt.cn:9081/tv/11681-1.m3u8#http://live.dxhmt.cn:9081/tv/11681-1.m3u8
西华综合,http://tvpull.dxhmt.cn:9081/tv/11622-1.m3u8#http://live.dxhmt.cn:9081/tv/11622-1.m3u8
永城综合,http://tvpull.dxhmt.cn:9081/tv/11481-1.m3u8#http://live.dxhmt.cn:9081/tv/11481-1.m3u8
灵宝综合,http://tvpull.dxhmt.cn:9081/tv/11282-1.m3u8#http://live.dxhmt.cn:9081/tv/11282-1.m3u8
卢氏综合,http://tvpull.dxhmt.cn:9081/tv/11224-1.m3u8#http://live.dxhmt.cn:9081/tv/11224-1.m3u8
渑池综合,http://tvpull.dxhmt.cn:9081/tv/11221-1.m3u8#http://live.dxhmt.cn:9081/tv/11221-1.m3u8
义马综合,http://tvpull.dxhmt.cn:9081/tv/11281-1.m3u8#http://live.dxhmt.cn:9081/tv/11281-1.m3u8
光山综合,http://tvpull.dxhmt.cn:9081/tv/11522-1.m3u8#http://live.dxhmt.cn:9081/tv/11522-1.m3u8
固始综合,http://tvpull.dxhmt.cn:9081/tv/11525-1.m3u8#http://live.dxhmt.cn:9081/tv/11525-1.m3u8
新郑综合,http://tvpull.dxhmt.cn:9081/tv/10184-1.m3u8#http://live.dxhmt.cn:9081/tv/10184-1.m3u8
林州综合,http://tvpull.dxhmt.cn:9081/tv/10581-1.m3u8#http://live.dxhmt.cn:9081/tv/10581-1.m3u8
内黄综合,http://tvpull.dxhmt.cn:9081/tv/10527-1.m3u8#http://live.dxhmt.cn:9081/tv/10527-1.m3u8
邓州综合,http://tvpull.dxhmt.cn:9081/tv/11381-1.m3u8#http://live.dxhmt.cn:9081/tv/11381-1.m3u8
方城一套,http://tvpull.dxhmt.cn:9081/tv/11322-1.m3u8#http://live.dxhmt.cn:9081/tv/11322-1.m3u8
内乡综合,http://tvpull.dxhmt.cn:9081/tv/11325-1.m3u8#http://live.dxhmt.cn:9081/tv/11325-1.m3u8
唐河一套,http://tvpull.dxhmt.cn:9081/tv/11328-1.m3u8#http://live.dxhmt.cn:9081/tv/11328-1.m3u8
淅川综合,http://tvpull.dxhmt.cn:9081/tv/11326-1.m3u8#http://live.dxhmt.cn:9081/tv/11326-1.m3u8
新野综合,http://tvpull.dxhmt.cn:9081/tv/11329-1.m3u8#http://live.dxhmt.cn:9081/tv/11329-1.m3u8
镇平新闻综合,http://tvpull.dxhmt.cn:9081/tv/11324-1.m3u8#http://live.dxhmt.cn:9081/tv/11324-1.m3u8
栾川综合,http://tvpull.dxhmt.cn:9081/tv/10324-1.m3u8#http://live.dxhmt.cn:9081/tv/10324-1.m3u8
孟津综合,http://tvpull.dxhmt.cn:9081/tv/10322-2.m3u8#http://live.dxhmt.cn:9081/tv/10322-2.m3u8
汝阳综合,http://tvpull.dxhmt.cn:9081/tv/10326-1.m3u8#http://live.dxhmt.cn:9081/tv/10326-1.m3u8
嵩县综合,http://tvpull.dxhmt.cn:9081/tv/10325-1.m3u8#http://live.dxhmt.cn:9081/tv/10325-1.m3u8
新安综合,http://tvpull.dxhmt.cn:9081/tv/10323-1.m3u8#http://live.dxhmt.cn:9081/tv/10323-1.m3u8
偃师综合,http://tvpull.dxhmt.cn:9081/tv/10381-1.m3u8#http://live.dxhmt.cn:9081/tv/10381-1.m3u8
宜阳综合,http://tvpull.dxhmt.cn:9081/tv/10327-1.m3u8#http://live.dxhmt.cn:9081/tv/10327-1.m3u8
孟州综合,http://tvpull.dxhmt.cn:9081/tv/10883-1.m3u8#http://live.dxhmt.cn:9081/tv/10883-1.m3u8
温县综合,http://tvpull.dxhmt.cn:9081/tv/10825-1.m3u8#http://live.dxhmt.cn:9081/tv/10825-1.m3u8
武陟综合,http://tvpull.dxhmt.cn:9081/tv/10823-1.m3u8#http://live.dxhmt.cn:9081/tv/10823-1.m3u8#http://live.dxhmt.cn:9080/wuzhiAdmin/719b76b2e06e456e9b30ad2b03e9122d.m3u8


吉林频道,#genre#
吉林磐石综合,http://stream5.jlntv.cn/ps/playlist.m3u8
吉林公主岭综合,http://stream5.jlntv.cn/gzl/playlist.m3u8
吉林东丰综合,http://stream5.jlntv.cn/df/playlist.m3u8
吉林东辽综合,http://stream5.jlntv.cn/dl/playlist.m3u8
吉林辉南综合,http://stream5.jlntv.cn/hn/playlist.m3u8
延边-2,http://stream5.jlntv.cn/wq/playlist.m3u8
磐石综合,http://stream5.jlntv.cn/ps/sd/live.m3u8?_upt=e05f429d1702757565
东丰综合,http://stream5.jlntv.cn/df/sd/live.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
双辽综合,http://stream5.jlntv.cn/sl/sd/live.m3u8?_upt=73404dd11699197122
辉南新闻综合,http://stream5.jlntv.cn/hn/sd/live.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
柳河综合,http://stream5.jlntv.cn/lh/sd/live.m3u8?_upt=db16d5e41702758050
通化县综合,http://stream5.jlntv.cn/thx/sd/live.m3u8?zjild
汪清综合,http://stream5.jlntv.cn/wq/sd/live.m3u8?_upt=eb80947d1699080781
吉林卫视,http://stream5.jlntv.cn/df/sd/live.m3u8
东丰综合,http://stream5.jlntv.cn/df/sd/live.m3u8?zjild
双辽综合,http://stream5.jlntv.cn/sl/sd/live.m3u8
双辽综合,http://stream5.jlntv.cn/sl/sd/live.m3u8?zjild
柳河综合,http://stream5.jlntv.cn/lh/sd/live.m3u8
柳河综合,http://stream5.jlntv.cn/lh/sd/live.m3u8?zjild
汪清综合,http://stream5.jlntv.cn/wq/sd/live.m3u8
汪清综合,http://stream5.jlntv.cn/wq/sd/live.m3u8?zjild
磐石综合,http://stream5.jlntv.cn/ps/sd/live.m3u8
磐石综合,http://stream5.jlntv.cn/ps/sd/live.m3u8?zjild
辉南新闻综合,http://stream5.jlntv.cn/hn/sd/live.m3u8?zjild
东辽综合,http://stream5.jlntv.cn/dl/sd/live.m3u8
辉南新闻综合,http://stream5.jlntv.cn/hn/sd/live.m3u8
通化县综合,http://stream5.jlntv.cn/thx/sd/live.m3u8
通化通化县综合,http://stream5.jlntv.cn/thx/playlist.m3u8
通化柳河综合,http://stream5.jlntv.cn/lh/playlist.m3u8
四平双辽综合,http://stream5.jlntv.cn/sl/playlist.m3u8
白城洮南综合,http://stream5.jlntv.cn/tn/playlist.m3u8

重庆频道,#genre#
重庆新闻,http://8.138.7.223/tv/cbg.php?id=3#http://8.138.7.223/tv/cbg2.php$蜂巢影视•IPV4『线路2』
重庆新闻,https://cqonsitecdn.cbgcloud.com/qf6jl2/m20256.m3u8$蜂巢影视•IPV4『线路1』
重庆新闻,http://183.66.13.82:60033/tsfile/live/0016_1.m3u8$蜂巢影视•IPV4『线路3』

四川频道,#genre# 已验证
乐至综合,http://175.155.106.72:89/live1/live1.m3u8?zsicd
井研综合,http://tvfile.jyrmt.cn/nmip-media/channellive/channel104452/playlist.m3u8
利州综合,http://tvfile.lzgbdst.com/nmip-media/channellive/channel106876/playlist.m3u8?zsicd
利州综合,http://tv.drs.lzgbdst.com:8100/channellive/lztv2.flv?zsicd
名山综合,rtmp://tv.yunxya.com:1937/channellive/mingshan
四川科教,http://182.150.115.21:8030/pcgacg/pcgacg_0.m3u8
宝兴综合,rtmp://tv.yunxya.com:1937/channellive/baoxing
宝兴综合,https://m3u8channel-bx.yunxya.com/nmip-media/channellive/channel104666/playlist.m3u8
广元公共,https://m3u8.channel.dzsm.com/nmip-media/channellive/channel101257/playlist.m3u8
广元综合,https://m3u8.channel.dzsm.com/nmip-media/channellive/channel100999/playlist.m3u8
旺苍新闻综合,rtmp://tv.wcrmt.cn/channellive/ch1
旺苍新闻综合,http://channel.wcrmt.cn:80/nmip-media/channellive/channel105268/playlist.m3u8
沐川综合,rtmp://tv.mcrm.org.cn:1935/channellive/tv01
石棉综合,https://m3u8channel-sm.yunxya.com/nmip-media/channellive/channel100420/playlist.m3u8
金川新闻综合,rtmp://live.jinchuanrmt.com/live/zhxw
金川新闻综合,rtmp://139.203.180.9/live/zhxw
雅安新闻综合,https://m3u8channel.yunxya.com/nmip-media/channellive/channel100028/playlist.m3u8
青川综合,http://qcfile.qcrmt.com/nmip-media/channellive/channel100933/playlist.m3u8

万州综合,http://123.146.162.24:8013/tslslive/noEX9SG/hls/live_sd.m3u8
万州影视,http://123.146.162.24:8013/tslslive/vWlnEzU/hls/live_sd.m3u8
万州三峡移民,http://123.146.162.24:8013/tslslive/PU2vzMI/hls/live_sd.m3u8
德阳新闻综合,http://scdytv.cn:1935/live/m_xwpd_livevideo/playlist.m3u8
德阳文旅科教,http://scdytv.cn:1935/live/m_ggpd_livevideo/playlist.m3u8
广安公共,http://live1.gatv.com.cn:85/live/GGPD_ggpdzm.m3u8
广安新闻综合,http://live1.gatv.com.cn:85/live/XWZH.m3u8
广安文旅乡村,http://live1.gatv.com.cn:85/live/GGPD_ggpdzm.m3u8
金川新闻综合,http://live.jinchuanrmt.com:90/live/zhxw.m3u8
金川乡村频道,http://live.jinchuanrmt.com:90/live/jcxc.m3u8
乐至综合,http://175.155.106.72:89/live1/live1.m3u8
利州综合,http://tvfile.lzgbdst.com/nmip-media/channellive/channel106876/playlist.m3u8
利州综合,http://tv.drs.lzgbdst.com:8100/channellive/lztv2.flv
凉山语,http://file.yizu.tv/nmip-media/channellive/channel107323/playlist.m3u8
汶川新闻综合,http://live.iwcmt.cn:90/live/zhxw.m3u8
营山电视台,http://file.ysxtv.cn/cms/videos/nmip-media/channellive/channel4/playlist.m3u8
璧山综合,http://222.179.42.129:8181/hls1.m3u8
荣昌综合,http://183.64.181.25:40023/rongchang01.m3u8
万载综合,http://live-echotv.cdnvideo.ru/echotv/echotv.sdp/playlist.m3u8
德阳公共,http://scdytv.cn:1935/live/m_ggpd_livevideo/playlist.m3u8?zsicd
甘孜综合,http://tv.drs.ganzitv.com:8100/channellive/gztv.flv
叙州新闻综合,http://pili-live-hls.ybcxjd.com/jdh-live/2108111201035597.m3u8?zsicd
青神综合,http://lmt.scqstv.com/live1/live1.m3u8?zsicd
达州新闻综合,http://tv.drs.dzxw.net/channellive/xwzhpd-dz1.flv
达州文化生活,http://tv.drs.dzxw.net/channellive/ggpd-dz2.flv
达州通川频道,http://tv.drs.dzxw.net/channellive/tcpd-dz3.flv
泸州科教生活,http://m3u8.channel.luzhoubs.com/nmip-media/channellive/channel103074/playlist.m3u8
泸州新闻综合,http://m3u8.channel.luzhoubs.com/nmip-media/channellive/channel106011/playlist.m3u8
叙州综合频道,http://pili-live-hls.ybcxjd.com/jdh-live/2108111201035597.m3u8
叙永综合频道,http://luzhi.xuyongrongmei.com:1935/live/_definst_/xyxw/playlist.m3u8
什邡新闻频道,http://live.sfrmt.com:85/live/zhpd.m3u8
四川科教,http://182.150.115.21:8030/pcgacg/pcgacg_0.m3u8
自贡综合,http://110.189.153.160:1001/zhpd.flv
自贡文化生活,http://110.189.153.160:1002/ggpd.flv
黑水新闻综合,http://live.schstv.com:90/live/xwzh.m3u8

云南频道,#genre# 已验证
麻栗坡,http://tvdrs.wsrtv.com.cn:8100/channellive/mlptv.flv
麻栗坡台,http://m3u8.channel.wsrtv.com.cn/cms/videos/nmip-media/channellive/channel18/playlist.m3u8
丘北新闻综合,http://m3u8.channel.wsrtv.com.cn/cms/videos/nmip-media/channellive/channel14/playlist.m3u8
文山电视台,http://m3u8.channel.wsrtv.com.cn/cms/videos/nmip-media/channellive/channel17/playlist.m3u8
文山公共,http://m3u8.channel.wsrtv.com.cn/cms/videos/nmip-media/channellive/channel8/playlist.m3u8
文山综合,http://tvdrs.wsrtv.com.cn:8100/channellive/ch1.flv
文山综合,http://m3u8.channel.wsrtv.com.cn/cms/videos/nmip-media/channellive/channel7/playlist.m3u8
砚山频道,http://m3u8.channel.wsrtv.com.cn/cms/videos/nmip-media/channellive/channel16/playlist.m3u8

福建频道,#genre#
武夷山综合,http://fjwysdb.chinashadt.com:2036/live/1.stream/playlist.m3u8
武夷山文旅茶,http://fjwysdb.chinashadt.com:2036/live/3.stream/playlist.m3u8
云霄综合,http://live.zzyxxw.com:85/live/xwzh.m3u8?fujian
福州生活,http://live.zohi.tv/video/s10001-fztv-3/index.m3u8
福州新闻,http://live.zohi.tv/video/s10001-fztv-1/index.m3u8
福州少儿,http://live.zohi.tv/video/s10001-fztv-4/index.m3u8

新疆频道,#genre# 已验证
可克达拉新闻综合,http://test5.btzx.com.cn/live/kkdl.stream/playlist.m3u8
石河子新闻综合,http://124.88.144.73:1935/live/xwzh/playlist.m3u8
伊犁汉语综合,http://110.153.180.106:55555/out_1/index.m3u8
伊犁维吾尔,http://110.153.180.106:55555/out_2/index.m3u8
伊犁哈萨克,http://110.153.180.106:55555/out_3/index.m3u8
伊犁经济法制,http://110.153.180.106:55555/out_4/index.m3u8
五师综合,http://liveout.btzx.com.cn/62ds9e/4nxdih.m3u8
五师双河,http://liveout.btzx.com.cn/62ds9e/6o77s4.m3u8
五家渠综合频道,https://liveout.btzx.com.cn/62ds9e/d9vi5g.m3u8
新星综合,http://test5.btzx.com.cn/live/13TV.stream/playlist.m3u8
克拉玛依-3,http://klmysjtzb.rcsxzx.com/hls/klmy3.m3u8

哈密二套,https://tvpull.hmgbtv.com/hmtv/channel108259412c6a6711/playlist.m3u8
哈密三套,https://tvpull.hmgbtv.com/hmtv/channelfb0e5c505477aa44/playlist.m3u8
伊犁汉语综合,http://110.153.180.106:55555/out_1/index.m3u8?zxinjd
伊犁维吾尔,http://110.153.180.106:55555/out_2/index.m3u8?zxinjd
伊犁哈萨克,http://110.153.180.106:55555/out_3/index.m3u8?zxinjd
伊犁经济法制,http://110.153.180.106:55555/out_4/index.m3u8?zxinjd


内蒙频道,#genre#
内蒙古蒙语,http://play1-qk.nmtv.cn/live/1686560387346365.m3u8
内蒙古文化频道,http://play1-qk.nmtv.cn/live/1686561065304370.m3u8
内蒙古新闻综合,http://play1-qk.nmtv.cn/live/1686560423879174.m3u8
内蒙古少儿频道,http://play1-qk.nmtv.cn/live/1686560464515368.m3u8
内蒙古文体娱乐,http://play1-qk.nmtv.cn/live/1686561195713372.m3u8
内蒙古农牧频道,http://play1-qk.nmtv.cn/live/1686561299036179.m3u8
内蒙古经济生活,http://play1-qk.nmtv.cn/live/1686562470947181.m3u8
包头新闻综合,http://play1-qk.nmtv.cn/live/1735546150395017.m3u8
呼伦贝尔新闻综合,http://play1-qk.nmtv.cn/live/1735546791130040.m3u8
兴安新闻综合,http://play1-qk.nmtv.cn/live/1735546886977046.m3u8
通辽新闻综合,http://play1-qk.nmtv.cn/live/1735546745882037.m3u8
赤峰新闻综合,http://play1-qk.nmtv.cn/live/1735546697341033.m3u8
锡林郭勒盟一套,http://play1-qk.nmtv.cn/live/1735546994821050.m3u8
乌兰察布新闻综合,http://play1-qk.nmtv.cn/live/1735546836103043.m3u8
鄂尔多斯新闻综合,http://play1-qk.nmtv.cn/live/1735546299241021.m3u8
巴彦淖尔新闻综合,http://play1-qk.nmtv.cn/live/1735546423467029.m3u8
乌海新闻综合,http://play1-qk.nmtv.cn/live/1735546358166026.m3u8
阿拉善新闻综合,http://play1-qk.nmtv.cn/live/1735547046115053.m3u8

奎屯汉语综合,http://218.84.12.186:8001/hls/main/playlist.m3u8
奎屯哈萨克语,http://218.84.12.186:8002/hls/main/playlist.m3u8
玛纳斯综合频道,http://218.84.127.245:1026/hls/main1/playlist.m3u8
可克达拉综合,http://test5.btzx.com.cn/live/kkdl.stream/playlist.m3u8
七星关电视台,https://p8.vzan.com:443/slowlive/147077707554082780/live.m3u8

青海综合,#genre#
大通电视台,http://dtrmlive.qhdtrm.cn/testpush/sd/live.m3u8
青海综合,http://lmt.scqstv.com/live1/live1.m3u8

甘肃频道,#genre# 
武威综合,https://play.kankanlive.com/live/1693539781636986.m3u8
天祝综合,https://play.kankanlive.com/live/1656487214793905.m3u8
永昌综合,https://play.kankanlive.com/live/1652755738635915.m3u8
敦煌频道,https://play.kankanlive.com/live/1698234808271963.m3u8
白银综合,https://play.kankanlive.com/live/1720408089419110.m3u8
白银文教,https://play.kankanlive.com/live/1720408280309109.m3u8
平凉综合,https://play.kankanlive.com/live/1694661314645984.m3u8
庆阳综合,https://play.kankanlive.com/live/1700643403411931.m3u8
张掖农旅,http://play.kankanlive.com/live/1720583009200246.m3u8
以上已验证

武威综合,https://play.kankanlive.com/live/1693539781636986.m3u8
武威综合,http://lishiwan.xicp.net:8563/udp/239.255.36.104:8231
武威凉州,http://lishiwan.xicp.net:8563/udp/239.255.36.106:8231
天祝综合,https://play.kankanlive.com/live/1656487214793905.m3u8
永昌综合,https://play.kankanlive.com/live/1652755738635915.m3u8
酒泉综合,https://play.kankanlive.com/live/1702033926169975.m3u8
酒泉文旅,https://play.kankanlive.com/live/1702036477193973.m3u8
敦煌频道,https://play.kankanlive.com/live/1698234808271963.m3u8
白银综合,https://play.kankanlive.com/live/1720408089419110.m3u8
白银文教,https://play.kankanlive.com/live/1720408280309109.m3u8
嘉峪关综合,https://play.kankanlive.com/live/1690854462058921.m3u8
定西综合,https://play.kankanlive.com/live/1707969054968992.m3u8
定西文旅,https://play.kankanlive.com/live/1707482307440963.m3u8
永昌综合,https://play.kankanlive.com/live/1652755738635915.m3u8
陇南公共,https://play.kankanlive.com/live/1709171893138901.m3u8
陇南综合,https://play.kankanlive.com/live/1709171819929902.m3u8
平凉综合,https://play.kankanlive.com/live/1694661314645984.m3u8
庆阳综合,https://play.kankanlive.com/live/1700643403411931.m3u8
庆阳文旅,https://play.kankanlive.com/live/1700643349159930.m3u8
甘南综合,https://play.kankanlive.com/live/1711955176432990.m3u8
甘南夏河,https://play.kankanlive.com/live/1718872789499909.m3u8
甘南卓尼,https://play.kankanlive.com/live/1711955964973985.m3u8
甘南迭部,https://play.kankanlive.com/live/1711955827175988.m3u8
舟曲综合,https://play.kankanlive.com/live/1711956058188984.m3u8
张掖综合,http://play.kankanlive.com/live/1720583434627241.m3u8
张掖农旅,http://play.kankanlive.com/live/1720583009200246.m3u8
静宁综合,https://play.kankanlive.com/live/1722996149311198.m3u8
甘州综合,https://play.kankanlive.com/live/1656898082155960.m3u8
秦安综合,https://play.kankanlive.com/live/1680577080200944.m3u8
清水综合,https://play.kankanlive.com/live/1724065906329286.m3u8
景泰综合,https://play.kankanlive.com/live/1624439143745981.m3u8
靖远综合,https://play.kankanlive.com/live/1692005762394912.m3u8
陇西综合,https://play.kankanlive.com/live/1702426649052972.m3u8
渭源综合,https://play.kankanlive.com/live/1701943385631927.m3u8
兰州兰石,http://play.kankanlive.com/live/1679470864707966.m3u8
庄浪综合,https://play.kankanlive.com/live/1687654127961989.m3u8
西峰综合,https://play.kankanlive.com/live/1683944827526991.m3u8
西和综合,https://play.kankanlive.com/live/1659926941626981.m3u8
成县综合,https://play.kankanlive.com/live/1702454377323961.m3u8
岷县综合,https://play.kankanlive.com/live/1722561653629309.m3u8
会宁综合,https://play.kankanlive.com/live/1721783897283302.m3u8
甘肃卫视,rtmp://livein.gstv.com.cn/49048r/y3nga4
甘肃经济,rtmp://livein.gstv.com.cn/49048r/9kzvr5
甘肃移动,rtmp://livein.gstv.com.cn/49048r/y72q36
都市频道,rtmp://livein.gstv.com.cn/49048r/4o7e76
文化影视,rtmp://livein.gstv.com.cn/49048r/068vw9
公共应急,rtmp://livein.gstv.com.cn/49048r/2v86i8
少儿频道,rtmp://livein.gstv.com.cn/49048r/oj57of


安徽频道,#genre#
宿州科教频道,http://live.ahsz.tv/video/s10001-kxjy/index.m3u8
固镇综合,http://www.guzhenm.com:7001/hls/hd-live.m3u8
灵璧综合,http://live.cms.anhuinews.com/video/s10003-lbtv/index.m3u8

江西频道,#genre#
万载综合,http://live-echotv.cdnvideo.ru/echotv/echotv.sdp/playlist.m3u8

龙江频道,#genre#
哈尔滨新闻综合,https://masterpull.hljtv.com/live/sPvVy8Ju.m3u8
林甸综合,https://masterpull.hljtv.com/live/23PN6NW9.m3u8
鸡西新闻综合,https://masterpull.hljtv.com/live/uqFwlQDH.m3u8
巴彦综合,https://masterpull.hljtv.com/live/vAtZi96R.m3u8
依兰综合,https://masterpull.hljtv.com/live/4sTJDdbE.m3u8
五常综合,https://masterpull.hljtv.com/live/R9bOklLT.m3u8
通河综合,https://masterpull.hljtv.com/live/b71kCDir.m3u8
尚志市综合,https://masterpull.hljtv.com/live/EQnKvoc9.m3u8
延寿综合,https://masterpull.hljtv.com/live/XBqKssjB.m3u8
方正综合,https://masterpull.hljtv.com/live/sSN2Uyb2.m3u8
龙江综合,https://masterpull.hljtv.com/live/vRSdDMSR.m3u8
依安综合,https://masterpull.hljtv.com/live/4hhgo1mX.m3u8
泰来综合,https://masterpull.hljtv.com/live/cfkAgOUK.m3u8
富裕综合,https://masterpull.hljtv.com/live/MKFLhcpa.m3u8
克山综合,https://masterpull.hljtv.com/live/58lOw0L5.m3u8
克东综合,https://masterpull.hljtv.com/live/PO1DiGiN.m3u8
讷河市综合,https://masterpull.hljtv.com/live/PXWxDY1V.m3u8
甘南综合,https://masterpull.hljtv.com/live/YbFyF4Jb.m3u8
绥芬河综合,https://masterpull.hljtv.com/live/pXxFNIbi.m3u8
宁安综合,https://masterpull.hljtv.com/live/BV2wr0vH.m3u8
穆棱新闻综合,https://masterpull.hljtv.com/live/5c9Mi3FV.m3u8
林口综合,https://masterpull.hljtv.com/live/pqheD07F.m3u8
东宁综合,https://masterpull.hljtv.com/live/UQdxnsw8.m3u8
佳木斯新闻综合,https://masterpull.hljtv.com/live/l9wQtsVs.m3u8
同江综合,https://masterpull.hljtv.com/live/oFc7fCUf.m3u8
富锦综合,https://masterpull.hljtv.com/live/wOBN3GqO.m3u8
桦川综合,https://masterpull.hljtv.com/live/NYQcW0fS.m3u8
桦南综合,https://masterpull.hljtv.com/live/76oCVZd3.m3u8
汤原综合,https://masterpull.hljtv.com/live/lt2CmppY.m3u8
抚远综合,https://masterpull.hljtv.com/live/tVnkOTOG.m3u8
大庆新闻综合,https://masterpull.hljtv.com/live/4WdrZLCq.m3u8
肇州综合,https://masterpull.hljtv.com/live/imOHYJ77.m3u8
肇源综合,https://masterpull.hljtv.com/live/XkQg7QSI.m3u8
虎林综合,https://masterpull.hljtv.com/live/SJJAEqBS.m3u8
密山综合,https://masterpull.hljtv.com/live/iYi97JTN.m3u8
集贤综合,https://masterpull.hljtv.com/live/CyJ3RKND.m3u8
友谊综合,https://masterpull.hljtv.com/live/LVpBWYXl.m3u8
宝清综合,https://masterpull.hljtv.com/live/HBp9MLoA.m3u8
饶河综合,https://masterpull.hljtv.com/live/DokNxER6.m3u8
伊春综合,https://masterpull.hljtv.com/live/vQtnS3vX.m3u8
嘉荫综合,https://masterpull.hljtv.com/live/k5IX9frJ.m3u8
铁力市综合,https://masterpull.hljtv.com/live/iUtbDFud.m3u8
七台河新闻综合,https://masterpull.hljtv.com/live/9FZ7k2XF.m3u8
勃利综合,https://masterpull.hljtv.com/live/6rx9bifO.m3u8
鹤岗新闻综合,https://masterpull.hljtv.com/live/rApKWXbX.m3u8
绥滨综合,https://masterpull.hljtv.com/live/DQiqZPCj.m3u8
绥化新闻综合,https://masterpull.hljtv.com/live/v4o2g1hs.m3u8
望奎综合,https://masterpull.hljtv.com/live/d3loVdqX.m3u8
兰西综合,https://masterpull.hljtv.com/live/SYG06DEw.m3u8
绥棱综合,https://masterpull.hljtv.com/live/p7WSvrJJ.m3u8
海伦市综合,https://masterpull.hljtv.com/live/VFNlgeFO.m3u8
黑河新闻综合,https://masterpull.hljtv.com/live/iyoENgSP.m3u8
嫩江市综合,https://masterpull.hljtv.com/live/hrSfaA6T.m3u8
孙吴综合,https://masterpull.hljtv.com/live/eXFjvNaf.m3u8
北安市综合,https://masterpull.hljtv.com/live/EfoBDa06.m3u8
五大连池市综合,https://masterpull.hljtv.com/live/6ic4FFgF.m3u8
大兴安岭新闻综合,https://masterpull.hljtv.com/live/H2kVyS15.m3u8
呼玛综合,https://masterpull.hljtv.com/live/yN3vDovm.m3u8
塔河综合,https://masterpull.hljtv.com/live/qXrATpGj.m3u8
漠河市综合,https://masterpull.hljtv.com/live/rlVvbTZN.m3u8
齐齐哈尔新闻综合,https://masterpull.hljtv.com/live/dUi8b96l.m3u8
海林综合,https://masterpull.hljtv.com/live/lqo9Fcdy.m3u8
杜尔伯特综合,https://masterpull.hljtv.com/live/eCNHwyyW.m3u8
逊克综合,https://masterpull.hljtv.com/live/a0CULO9O.m3u8
鸡东综合,https://masterpull.hljtv.com/live/o4NExHSz.m3u8
哈尔滨都市资讯,http://stream.hrbtv.net/zxpd/sd/live.m3u8
哈尔滨娱乐,http://stream.hrbtv.net/ylpd/sd/live.m3u8
哈尔滨娱乐,https://stream.hrbtv.net/ylpd/sd/live.m3u8
拜泉综合,https://masterpull.hljtv.com/live/zHtOXXUz.m3u8

黑龙江新闻法治,http://htgy.zynas.top:4000/rtp/229.58.190.16:5000
黑龙江影视,http://htgy.zynas.top:4000/rtp/229.58.190.14:5000
黑龙江文体,http://htgy.zynas.top:4000/rtp/229.58.190.30:5000
黑龙江都市,http://htgy.zynas.top:4000/rtp/229.58.190.34:5000
黑龙江农业科教,http://htgy.zynas.top:4000/rtp/229.58.190.7:5000
黑龙江少儿,http://htgy.zynas.top:4000/rtp/229.58.190.39:5000



黑龙江新闻法治,http://ottrrs.hl.chinamobile.com/PLTV/88888888/224/3221226330/index.m3u8
黑龙江都市,http://ottrrs.hl.chinamobile.com/PLTV/88888888/224/3221226301/index.m3u8
黑龙江文体,http://ottrrs.hl.chinamobile.com/PLTV/88888888/224/3221226239/index.m3u8
黑龙江农业科教,http://ottrrs.hl.chinamobile.com/PLTV/88888888/224/3221226242/index.m3u8
黑龙江影视,http://ottrrs.hl.chinamobile.com/PLTV/88888888/224/3221226298/index.m3u8
黑龙江少儿,http://ottrrs.hl.chinamobile.com/PLTV/88888888/224/3221226304/index.m3u8

黑龙江新闻法治,https://idclive.hljtv.com:4430/live/hljxw_hd.m3u8
黑龙江文体,https://idclive.hljtv.com:4430/live/hljwy_hd.m3u8
黑龙江影视,https://idclive.hljtv.com:4430/live/hljys_hd.m3u8
黑龙江都市,https://idclive.hljtv.com:4430/live/dushi_hd.m3u8
黑龙江少儿,https://idclive.hljtv.com:4430/live/hljse_hd.m3u8
黑龙江农业科教,https://idclive.hljtv.com:4430/live/hljgg_hd.m3u8

哈尔滨新闻综合,https://rmplive.hljtv.com/live/haerbin.m3u8
                 #rtmp://rmplive.hljtv.com/live/haerbin
                 #https://masterpull.hljtv.com/live/sPvVy8Ju.m3u8
                 #rtmp://masterpull.hljtv.com/live/sPvVy8Ju
宾县综合,https://rmplive.hljtv.com/live/binxian.m3u8
        #rtmp://rmplive.hljtv.com/live/binxian
         #https://masterpull.hljtv.com/live/DlkgB2B7.m3u8
        #rtmp://masterpull.hljtv.com/live/DlkgB2B7
巴彦电视台,https://rmplive.hljtv.com/live/bayan.m3u8
           #rtmp://masterpull.hljtv.com/live/vAtZi96R
           #https://masterpull.hljtv.com/live/vAtZi96R.m3u8
           #rtmp://masterpull.hljtv.com/live/vAtZi96R
方正综合,https://rmplive.hljtv.com/live/fangzheng.m3u8
         #rtmp://rmplive.hljtv.com/live/fangzheng
         #https://masterpull.hljtv.com/live/sSN2Uyb2.m3u8
         #rtmp://masterpull.hljtv.com/live/sSN2Uyb2
呼兰综合,https://rmplive.hljtv.com/live/hulan.m3u8
         #rtmp://rmplive.hljtv.com/live/hulan
         #https://masterpull.hljtv.com/live/zja8TAIO.m3u8
         #rtmp://masterpull.hljtv.com/live/zja8TAIO
尚志新闻综合,https://rmplive.hljtv.com/live/shangzhi.m3u8
            #rtmp://rmplive.hljtv.com/live/shangzhi
             #https://masterpull.hljtv.com/live/EQnKvoc9.m3u8
             #rtmp://masterpull.hljtv.com/live/EQnKvoc9
通河新闻,https://rmplive.hljtv.com/live/tonghe.m3u8
         #rtmp://rmplive.hljtv.com/live/tonghe
         #https://masterpull.hljtv.com/live/b71kCDir.m3u8
         #rtmp://masterpull.hljtv.com/live/b71kCDir
五常综合,https://rmplive.hljtv.com/live/wuchang.m3u8
         #rtmp://rmplive.hljtv.com/live/wuchang
         #https://masterpull.hljtv.com/live/R9bOklLT.m3u8
         #rtmp://masterpull.hljtv.com/live/R9bOklLT
依兰新闻综合,https://rmplive.hljtv.com/live/yilan.m3u8
             #rtmp://rmplive.hljtv.com/live/yilan
         #https://masterpull.hljtv.com/live/4sTJDdbE.m3u8
         #rtmp://masterpull.hljtv.com/live/4sTJDdbE
延寿综合,https://rmplive.hljtv.com/live/yanshou.m3u8
         #rtmp://rmplive.hljtv.com/live/yanshou

齐齐哈尔新闻综合,https://rmplive.hljtv.com/live/qiqihaer.m3u8
                 #rtmp://rmplive.hljtv.com/live/qiqihaer
                 #https://masterpull.hljtv.com/live/dUi8b96l.m3u8
                 #rtmp://masterpull.hljtv.com/live/dUi8b96l
拜泉综合,https://rmplive.hljtv.com/live/baiquan.m3u8
         #rtmp://rmplive.hljtv.com/live/baiquan
         #https://masterpull.hljtv.com/live/zHtOXXUz.m3u8
         #rtmp://masterpull.hljtv.com/live/zHtOXXUz
富裕综合,https://rmplive.hljtv.com/live/fuyu.m3u8
         #rtmp://rmplive.hljtv.com/live/fuyu
         #https://masterpull.hljtv.com/live/MKFLhcpa.m3u8
         #rtmp://masterpull.hljtv.com/live/MKFLhcpa
甘南县综合,https://rmplive.hljtv.com/live/gannan.m3u8
           #rtmp://rmplive.hljtv.com/live/gannan
           #https://masterpull.hljtv.com/live/YbFyF4Jb.m3u8
           #rtmp://masterpull.hljtv.com/live/YbFyF4Jb
克东综合,https://rmplive.hljtv.com/live/kedong.m3u8
         #rtmp://rmplive.hljtv.com/live/kedong
         #https://masterpull.hljtv.com/live/PO1DiGiN.m3u8
         #rtmp://masterpull.hljtv.com/live/PO1DiGiN
克山综合,https://rmplive.hljtv.com/live/keshan.m3u8
         #rtmp://rmplive.hljtv.com/live/keshan
         #https://masterpull.hljtv.com/live/58lOw0L5.m3u8
         #rtmp://masterpull.hljtv.com/live/58lOw0L5
龙江综合,https://rmplive.hljtv.com/live/longjiang.m3u8
         rtmp://rmplive.hljtv.com/live/longjiang
         https://masterpull.hljtv.com/live/vRSdDMSR.m3u8
         rtmp://masterpull.hljtv.com/live/vRSdDMSR
讷河综合,https://rmplive.hljtv.com/live/nehe.m3u8
         #rtmp://rmplive.hljtv.com/live/nehe
         #https://masterpull.hljtv.com/live/PXWxDY1V.m3u8
         #rtmp://masterpull.hljtv.com/live/PXWxDY1V
泰来综合,https://rmplive.hljtv.com/live/tailai.m3u8
         #rtmp://rmplive.hljtv.com/live/tailai
         #https://masterpull.hljtv.com/live/cfkAgOUK.m3u8
         #rtmp://masterpull.hljtv.com/live/cfkAgOUK
依安综合,https://rmplive.hljtv.com/live/yian.m3u8
         #rtmp://rmplive.hljtv.com/live/yian
         #https://masterpull.hljtv.com/live/4hhgo1mX.m3u8
         #rtmp://masterpull.hljtv.com/live/4hhgo1mX

牡丹江新闻综合,https://masterpull.hljtv.com/live/newLqQS9Lcp.m3u8
               #rtmp://masterpull.hljtv.com/live/newLqQS9Lcp
东宁综合,https://rmplive.hljtv.com/live/dongning.m3u8
         #rtmp://rmplive.hljtv.com/live/dongning
         #https://masterpull.hljtv.com/live/UQdxnsw8.m3u8
         #rtmp://masterpull.hljtv.com/live/UQdxnsw8
海林综合,https://rmplive.hljtv.com/live/hailin.m3u8
         #rtmp://rmplive.hljtv.com/live/hailin
        #https://masterpull.hljtv.com/live/lqo9Fcdy.m3u8
         #rtmp://masterpull.hljtv.com/live/lqo9Fcdy
林口综合,https://rmplive.hljtv.com/live/linkou.m3u8
         #rtmp://rmplive.hljtv.com/live/linkou
         #https://masterpull.hljtv.com/live/pqheD07F.m3u8
         #rtmp://masterpull.hljtv.com/live/pqheD07F
穆棱综合,https://rmplive.hljtv.com/live/muleng.m3u8
         #rtmp://rmplive.hljtv.com/live/muleng
         #https://masterpull.hljtv.com/live/5c9Mi3FV.m3u8
         #rtmp://masterpull.hljtv.com/live/5c9Mi3FV
宁安综合,https://rmplive.hljtv.com/live/ningan.m3u8
         #rtmp://rmplive.hljtv.com/live/ningan
         #https://masterpull.hljtv.com/live/BV2wr0vH.m3u8
         #rtmp://masterpull.hljtv.com/live/BV2wr0vH
绥芬河综合,https://rmplive.hljtv.com/live/suifenhe.m3u8
           #rtmp://rmplive.hljtv.com/live/suifenhe
           #https://masterpull.hljtv.com/live/pXxFNIbi.m3u8
           #rtmp://masterpull.hljtv.com/live/pXxFNIbi

佳木斯市新闻综合,https://rmplive.hljtv.com/live/jiamusi.m3u8
                 #rtmp://rmplive.hljtv.com/live/jiamusi               
                 #https://masterpull.hljtv.com/live/l9wQtsVs.m3u8
                 #rtmp://masterpull.hljtv.com/live/l9wQtsVs
富锦电视台,https://rmplive.hljtv.com/live/fujin.m3u8
           #rtmp://rmplive.hljtv.com/live/fujin
          #https://masterpull.hljtv.com/live/wOBN3GqO.m3u8
           #rtmp://masterpull.hljtv.com/live/wOBN3GqO
抚远电视台,https://rmplive.hljtv.com/live/fuyuan.m3u8
           #rtmp://rmplive.hljtv.com/live/fuyuan
           #https://masterpull.hljtv.com/live/tVnkOTOG.m3u8
           #rtmp://masterpull.hljtv.com/live/tVnkOTOG
桦川新闻综合,https://rmplive.hljtv.com/live/huachuan.m3u8
             #rtmp://rmplive.hljtv.com/live/huachuan
             #https://masterpull.hljtv.com/live/NYQcW0fS.m3u8
             #rtmp://masterpull.hljtv.com/live/NYQcW0fS
桦南综合,https://rmplive.hljtv.com/live/huanan.m3u8
         #rtmp://rmplive.hljtv.com/live/huanan
         #https://masterpull.hljtv.com/live/76oCVZd3.m3u8
         #rtmp://masterpull.hljtv.com/live/76oCVZd3
同江电视台,https://rmplive.hljtv.com/live/tongjiang.m3u8
          #rtmp://rmplive.hljtv.com/live/tongjiang
           #https://masterpull.hljtv.com/live/oFc7fCUf.m3u8
           #rtmp://masterpull.hljtv.com/live/oFc7fCUf
汤原综合,https://rmplive.hljtv.com/live/tangyuan.m3u8
         #rtmp://rmplive.hljtv.com/live/tangyuan
         #https://masterpull.hljtv.com/live/lt2CmppY.m3u8
         #rtmp://masterpull.hljtv.com/live/lt2CmppY

大庆市新闻综合,https://rmplive.hljtv.com/live/daqing.m3u8
               #rtmp://rmplive.hljtv.com/live/daqing
               #https://masterpull.hljtv.com/live/4WdrZLCq.m3u8
               #rtmp://masterpull.hljtv.com/live/4WdrZLCq
杜尔伯特综合,https://rmplive.hljtv.com/live/duerbote.m3u8 x
             #rtmp://rmplive.hljtv.com/live/duerbote x
林甸综合,https://rmplive.hljtv.com/live/lindian.m3u8
         #rtmp://rmplive.hljtv.com/live/lindian
         #https://masterpull.hljtv.com/live/23PN6NW9.m3u8
         #rtmp://masterpull.hljtv.com/live/23PN6NW9
肇源综合,https://rmplive.hljtv.com/live/zhaoyuan.m3u8
         #rtmp://rmplive.hljtv.com/live/zhaoyuan
         #https://masterpull.hljtv.com/live/XkQg7QSI.m3u8
         #rtmp://masterpull.hljtv.com/live/XkQg7QSI
肇州综合,https://rmplive.hljtv.com/live/zhaozhou.m3u8
         #rtmp://rmplive.hljtv.com/live/zhaozhou
         #rtmp://masterpull.hljtv.com/live/imOHYJ77.m3u8
         #rtmp://masterpull.hljtv.com/live/imOHYJ77

鸡西市新闻综合,https://rmplive.hljtv.com/live/jixi.m3u8
               #rtmp://rmplive.hljtv.com/live/jixi
               #https://masterpull.hljtv.com/live/uqFwlQDH.m3u8
               #rtmp://masterpull.hljtv.com/live/uqFwlQDH
虎林综合,https://rmplive.hljtv.com/live/hulin.m3u8
         #rtmp://rmplive.hljtv.com/live/hulin
         #https://masterpull.hljtv.com/live/SJJAEqBS.m3u8
         #rtmp://masterpull.hljtv.com/live/SJJAEqBS
鸡东综合,https://rmplive.hljtv.com/live/jidong.m3u8
         rtmp://rmplive.hljtv.com/live/jidong
         https://masterpull.hljtv.com/live/o4NExHSz.m3u8
         rtmp://masterpull.hljtv.com/live/o4NExHSz
密山综合,https://rmplive.hljtv.com/live/mishan.m3u8
         #rtmp://rmplive.hljtv.com/live/mishan
         #https://masterpull.hljtv.com/live/iYi97JTN.m3u8
         #rtmp://masterpull.hljtv.com/live/iYi97JTN

双鸭山新闻综合,https://masterpull.hljtv.com/live/BowdCSzZ.m3u8
               #rtmp://masterpull.hljtv.com/live/BowdCSzZ
宝清综合,https://rmplive.hljtv.com/live/baoqing.m3u8
         #rtmp://rmplive.hljtv.com/live/baoqing
         #https://masterpull.hljtv.com/live/HBp9MLoA.m3u8
         #rtmp://masterpull.hljtv.com/live/HBp9MLoA
集贤综合,https://rmplive.hljtv.com/live/jixian.m3u8
         #rtmp://rmplive.hljtv.com/live/jixian
饶河综合,https://rmplive.hljtv.com/live/raohe.m3u8
         #rtmp://rmplive.hljtv.com/live/raohe
         #https://masterpull.hljtv.com/live/DokNxER6.m3u8
         #rtmp://masterpull.hljtv.com/live/DokNxER6
友谊综合,https://rmplive.hljtv.com/live/youyi.m3u8
         #rtmp://rmplive.hljtv.com/live/youyi
         #https://masterpull.hljtv.com/live/LVpBWYXl.m3u8
         #rtmp://masterpull.hljtv.com/live/LVpBWYXl

伊春综合,https://rmplive.hljtv.com/live/yichun.m3u8
         #rtmp://rmplive.hljtv.com/live/yichun
         #https://masterpull.hljtv.com/live/vQtnS3vX.m3u8
         #rtmp://masterpull.hljtv.com/live/vQtnS3vX
嘉荫综合,https://rmplive.hljtv.com/live/jiayin.m3u8
         #rtmp://rmplive.hljtv.com/live/jiayin
铁力综合,https://rmplive.hljtv.com/live/tieli.m3u8
         #rtmp://rmplive.hljtv.com/live/tieli
         #https://masterpull.hljtv.com/live/iUtbDFud.m3u8
         #rtmp://masterpull.hljtv.com/live/iUtbDFud

七台河新闻综合,https://rmplive.hljtv.com/live/qitaihe.m3u8
               #rtmp://rmplive.hljtv.com/live/qitaihe
               #https://masterpull.hljtv.com/live/9FZ7k2XF.m3u8
               #rtmp://masterpull.hljtv.com/live/9FZ7k2XF
勃利综合,https://rmplive.hljtv.com/live/boli.m3u8
         #rtmp://rmplive.hljtv.com/live/boli
         #https://masterpull.hljtv.com/live/6rx9bifO.m3u8
        #rtmp://masterpull.hljtv.com/live/6rx9bifO

鹤岗新闻综合,https://rmplive.hljtv.com/live/hegang.m3u8
             #rtmp://rmplive.hljtv.com/live/hegang
             #https://masterpull.hljtv.com/live/rApKWXbX.m3u8
             #rtmp://masterpull.hljtv.com/live/rApKWXbX
萝北综合,https://rmplive.hljtv.com/live/luobei.m3u8
         #rtmp://rmplive.hljtv.com/live/luobei
绥滨综合,https://rmplive.hljtv.com/live/suibin.m3u8
         #rtmp://rmplive.hljtv.com/live/suibin
         #https://masterpull.hljtv.com/live/DQiqZPCj.m3u8
         #rtmp://masterpull.hljtv.com/live/DQiqZPCj

绥化新闻综合,https://rmplive.hljtv.com/live/suihua.m3u8
             #rtmp://rmplive.hljtv.com/live/suihua
             #https://masterpull.hljtv.com/live/v4o2g1hs.m3u8
             #rtmp://masterpull.hljtv.com/live/v4o2g1hs
安达综合,https://rmplive.hljtv.com/live/anda.m3u8
         #rtmp://rmplive.hljtv.com/live/anda
         #https://masterpull.hljtv.com/live/FsGxlDZQ.m3u8
         #rtmp://masterpull.hljtv.com/live/FsGxlDZQ
海伦综合,https://rmplive.hljtv.com/live/hailun.m3u8
         #rtmp://rmplive.hljtv.com/live/hailun
         #https://masterpull.hljtv.com/live/VFNlgeFO.m3u8
         #rtmp://masterpull.hljtv.com/live/VFNlgeFO
兰西综合,https://rmplive.hljtv.com/live/lanxi.m3u8
         #rtmp://rmplive.hljtv.com/live/lanxi
         #https://masterpull.hljtv.com/live/SYG06DEw.m3u8
         #rtmp://masterpull.hljtv.com/live/SYG06DEw
明水综合,https://rmplive.hljtv.com/live/mingshui.m3u8
         #rtmp://rmplive.hljtv.com/live/mingshui
         #https://masterpull.hljtv.com/live/bOJ0OStw.m3u8
         #rtmp://masterpull.hljtv.com/live/bOJ0OStw
庆安综合,https://rmplive.hljtv.com/live/qingan.m3u8
         #rtmp://rmplive.hljtv.com/live/qingan
         #httpsp://masterpull.hljtv.com/live/ayksl1Ur.m3u8
         #rtmp://masterpull.hljtv.com/live/ayksl1Ur
青冈综合,https://rmplive.hljtv.com/live/qinggang.m3u8
         #rtmp://rmplive.hljtv.com/live/qinggang
         #https://masterpull.hljtv.com/live/bJGIloJe.m3u8
         #rtmp://masterpull.hljtv.com/live/bJGIloJe
绥棱综合,https://rmplive.hljtv.com/live/suileng.m3u8
         #rtmp://rmplive.hljtv.com/live/suileng
         #https://masterpull.hljtv.com/live/p7WSvrJJ.m3u8
         #rtmp://masterpull.hljtv.com/live/p7WSvrJJ
望奎综合,https://rmplive.hljtv.com/live/wangkui.m3u8
         #rtmp://rmplive.hljtv.com/live/wangkui
         #https://masterpull.hljtv.com/live/d3loVdqX.m3u8
         #rtmp://masterpull.hljtv.com/live/d3loVdqX
肇东综合,https://rmplive.hljtv.com/live/zhaodong.m3u8
         #rtmp://rmplive.hljtv.com/live/zhaodong
         #https://masterpull.hljtv.com/live/G84ZsUTP.m3u8
         #rtmp://masterpull.hljtv.com/live/G84ZsUTP

黑河新闻综合,https://rmplive.hljtv.com/live/heihe.m3u8
             #rtmp://rmplive.hljtv.com/live/heihe
             #https://masterpull.hljtv.com/live/iyoENgSP.m3u8
             #rtmp://masterpull.hljtv.com/live/iyoENgSP
北安综合,https://rmplive.hljtv.com/live/beian.m3u8
         #rtmp://rmplive.hljtv.com/live/beian
        #https://masterpull.hljtv.com/live/EfoBDa06.m3u8
         #rtmp://masterpull.hljtv.com/live/EfoBDa06
嫩江综合,https://rmplive.hljtv.com/live/nenjiang.m3u8
         #rtmp://rmplive.hljtv.com/live/nenjiang
         #https://masterpull.hljtv.com/live/hrSfaA6T.m3u8
         #rtmp://masterpull.hljtv.com/live/hrSfaA6T
孙吴综合,https://rmplive.hljtv.com/live/sunwu.m3u8
         #rtmp://rmplive.hljtv.com/live/sunwu
         #https://masterpull.hljtv.com/live/eXFjvNaf.m3u8
         #rtmp://masterpull.hljtv.com/live/eXFjvNaf
五大连池综合,https://rmplive.hljtv.com/live/wudalianchi.m3u8
             #rtmp://rmplive.hljtv.com/live/wudalianchi
             #https://masterpull.hljtv.com/live/6ic4FFgF.m3u8
             #rtmp://masterpull.hljtv.com/live/6ic4FFgF
逊克综合,https://rmplive.hljtv.com/live/xunke.m3u8
         #rtmp://rmplive.hljtv.com/live/xunke
         #https://masterpull.hljtv.com/live/a0CULO9O.m3u8
         #rtmp://masterpull.hljtv.com/live/a0CULO9O

大兴安岭新闻综合,https://rmplive.hljtv.com/live/daxinganling.m3u8
                 #rtmp://rmplive.hljtv.com/live/daxinganling
                 #https://masterpull.hljtv.com/live/H2kVyS15.m3u8
                 #rtmp://masterpull.hljtv.com/live/H2kVyS15
呼玛综合,https://rmplive.hljtv.com/live/huma.m3u8
           #rtmp://rmplive.hljtv.com/live/huma
           #https://masterpull.hljtv.com/live/yN3vDovm.m3u8
           #rtmp://masterpull.hljtv.com/live/yN3vDovm
塔河综合,https://rmplive.hljtv.com/live/tahe.m3u8
         #rtmp://rmplive.hljtv.com/live/tahe
         #https://masterpull.hljtv.com/live/qXrATpGj.m3u8
         #rtmp://masterpull.hljtv.com/live/qXrATpGj
漠河综合,https://rmplive.hljtv.com/live/mohe.m3u8
         #rtmp://rmplive.hljtv.com/live/mohe
        #https://masterpull.hljtv.com/live/rlVvbTZN.m3u8
         #rtmp://masterpull.hljtv.com/live/rlVvbTZN


巴彦综合,https://rmplive.hljtv.com/live/bayan.m3u8
依兰综合,https://rmplive.hljtv.com/live/yilan.m3u8
五常综合,https://rmplive.hljtv.com/live/wuchang.m3u8
通河综合,https://rmplive.hljtv.com/live/tonghe.m3u8
通河综合,https://rmplive.hljtv.com/live/tonghe.m3u8
宾县综合,https://rmplive.hljtv.com/live/binxian.m3u8
尚志综合,https://rmplive.hljtv.com/live/shangzhi.m3u8
延寿综合,https://rmplive.hljtv.com/live/yanshou.m3u8 
方正综合,https://rmplive.hljtv.com/live/fangzheng.m3u8
齐齐哈尔新闻综合,https://rmplive.hljtv.com/live/qiqihaer.m3u8
龙江综合,https://rmplive.hljtv.com/live/longjiang.m3u8
依安综合,https://rmplive.hljtv.com/live/yian.m3u8
泰来综合,https://rmplive.hljtv.com/live/tailai.m3u8
富裕综合,https://rmplive.hljtv.com/live/fuyu.m3u8
克山综合,https://rmplive.hljtv.com/live/keshan.m3u8
克东综合,https://rmplive.hljtv.com/live/kedong.m3u8
讷河综合,https://rmplive.hljtv.com/live/nehe.m3u8
甘南综合,https://rmplive.hljtv.com/live/gannan.m3u8
拜泉综合,https://rmplive.hljtv.com/live/baiquan.m3u8
拜泉综合,https://rmplive.hljtv.com/live/baiquan.m3u8
绥芬河综合,https://rmplive.hljtv.com/live/suifenhe.m3u8
宁安综合,https://rmplive.hljtv.com/live/ningan.m3u8
海林综合,https://rmplive.hljtv.com/live/hailin.m3u8
穆棱新闻综合,https://rmplive.hljtv.com/live/muleng.m3u8
林口综合,https://rmplive.hljtv.com/live/linkou.m3u8
东宁综合,https://rmplive.hljtv.com/live/dongning.m3u8
佳木斯新闻综合, https://rmplive.com/live/jiamusi.m3u8
同江综合,https://rmplive.hljtv.com/live/tongjiang.m3u8
富锦综合,https://rmplive.hljtv.com/live/fujin.m3u8
桦川综合,https://rmplive.hljtv.com/live/huachuan.m3u8
桦南综合,https://rmplive.hljtv.com/live/huanan.m3u8 
汤原综合,https://rmplive.hljtv.com/live/tangyuan.m3u8
抚远综合,https://rmplive.hljtv.com/live/fuyuan.m3u8
大庆新闻综合,https://rmplive.hljtv.com/live/daqing.m3u8 
肇州综合,https://rmplive.hljtv.com/live/zhaozhou.m3u8 
肇源综合,https://rmplive.hljtv.com/live/zhaoyuan.m3u8
林甸综合,https://rmplive.hljtv.com/live/lindian.m3u8
杜尔伯特综合,https://rmplive.hljtv.com/live/duerbote.m3u8 
鸡西新闻综合,https://rmplive.hljtv.com/live/jixi.m3u8
鸡东综合,https://rmplive.hljtv.com/live/jidong.m3u8 
虎林综合,https://rmplive.hljtv.com/live/hulin.m3u8
密山综合,https://rmplive.hljtv.com/live/mishan.m3u8
集贤综合,https://rmplive.hljtv.com/live/jixian.m3u8 
友谊综合,https://rmplive.hljtv.com/live/youyi.m3u8
宝清综合,https://rmplive.hljtv.com/live/baoqing.m3u8
饶河综合,https://rmplive.hljtv.com/live/raohe.m3u8
伊春综合,https://rmplive.hljtv.com/live/yichun.m3u8
嘉荫综合,https://rmplive.hljtv.com/live/jiayin.m3u8 
铁力综合,https://rmplive.hljtv.com/live/tieli.m3u8
七台河新闻综合,https://rmplive.hljtv.com/live/qitaihe.m3u8
勃利综合,https://rmplive.hljtv.com/live/boli.m3u8
鹤岗新闻综合,https://rmplive.hljtv.com/live/hegang.m3u8
绥滨综合,https://rmplive.hljtv.com/live/suibin.m3u8 
绥化新闻综合,https://rmplive.hljtv.com/live/suihua.m3u8
望奎综合,https://rmplive.hljtv.com/live/wangkui.m3u8
兰西综合,https://rmplive.hljtv.com/live/lanxi.m3u8
青冈综合,https://rmplive.hljtv.com/live/qinggang.m3u8
庆安综合,https://rmplive.hljtv.com/live/qingan.m3u8
明水综合,https://rmplive.hljtv.com/live/mingshui.m3u8 
绥棱综合,https://rmplive.hljtv.com/live/suileng.m3u8
安达综合,https://rmplive.hljtv.com/live/anda.m3u8
肇东综合,https://rmplive.hljtv.com/live/zhaodong.m3u8
海伦综合,https://rmplive.hljtv.com/live/hailun.m3u8
黑河新闻综合,https://rmplive.hljtv.com/live/heihe.m3u8
嫩江综合,https://rmplive.hljtv.com/live/nenjiang.m3u8
逊克综合,https://rmplive.hljtv.com/live/xunke.m3u8 
孙吴综合,https://rmplive.hljtv.com/live/sunwu.m3u8
北安综合,https://rmplive.hljtv.com/live/beian.m3u8
五大连池综合,https://rmplive.hljtv.com/live/wudalianchi.m3u8
大兴安岭新闻综合,https://rmplive.hljtv.com/live/daxinganling.m3u8 
呼玛综合,https://rmplive.hljtv.com/live/huma.m3u8
塔河综合,https://rmplive.hljtv.com/live/tahe.m3u8
漠河综合,https://rmplive.hljtv.com/live/mohe.m3u8


 
===非实时===
 四川成都环球中心,https://gcalic.v.myalicdn.com/gc/zjjbfh_1/index.m3u8
 四川成都天府熊猫塔,https://gcalic.v.myalicdn.com/gc/ljgcszsnkgc_1/index.m3u8
 天津海河,https://gcalic.v.myalicdn.com/gc/hkylxs05_1/index.m3u8
 江苏无锡大剧院,https://gcalic.v.myalicdn.com/gc/taishan05_1/index.m3u8
 西藏山南浪卡子县鲁日拉景观台,https://gcalic.v.myalicdn.com/gc/hkts07_1/index.m3u8
 西藏林芝米林岷山彩门民宿,https://gcalic.v.myalicdn.com/gc/hkylxs06_1/index.m3u8
 西藏日喀则珠穆朗玛峰,https://gcalic.v.myalicdn.com/gc/qdls02_1/index.m3u8
 西藏林芝工布江达县岷山错高民宿,https://gcalic.v.myalicdn.com/gc/zjjybf_1/index.m3u8
 西藏林芝南迦巴瓦,https://gcalic.v.myalicdn.com/gc/jhs05_1/index.m3u8
 云南普洱景东县无量山羊山瀑布,https://gcalic.v.myalicdn.com/gc/blg05_1/index.m3u8
 云南丽江玉龙雪山,https://gcalic.v.myalicdn.com/gc/ylxs11_1/index.m3u8
 云南保山板桥镇青龙街,https://gcalic.v.myalicdn.com/gc/ylxs12_1/index.m3u8
 云南德宏勐焕大金塔,https://gcalic.v.myalicdn.com/gc/dhyyqsm_1/index.m3u8
 云南保山比顿咖啡产业文化园,https://gcalic.v.myalicdn.com/gc/zyqcdx01_1/index.m3u8
 云南昆明寻甸县城区,https://gcalic.v.myalicdn.com/gc/mdjxxmhjyxj_1/index.m3u8
 云南西双版纳千年古寨曼丢,https://gcalic.v.myalicdn.com/gc/fcw03_1/index.m3u8
 云南普洱澜沧县景迈山,https://gcalic.v.myalicdn.com/gc/tms05_1/index.m3u8
 云南红河民族风情旅游月亮小镇,https://gcalic.v.myalicdn.com/gc/hsyg_1/index.m3u8
 云南丽江古城万古楼遥望玉龙雪山,https://gcalic.v.myalicdn.com/gc/ljgcwglytylxs_1/index.m3u8
 云南大理云南驿茶马古道,https://gcalic.v.myalicdn.com/gc/tyhjtys_1/index.m3u8
 云南大理无量樱花谷,https://gcalic.v.myalicdn.com/gc/taishan01_1/index.m3u8
 浙江舟山嵊泗县中心渔港,https://gcalic.v.myalicdn.com/gc/emsyh_1/index.m3u8
 浙江乌镇蓝印花布,https://gcalic.v.myalicdn.com/gc/zjwzlyhb_1/index.m3u8
 乐山大佛全景,https://gcalic.v.myalicdn.com/gc/lsdfgfl_1/index.m3u8
 河北沧州南川老街,https://gcalic.v.myalicdn.com/gc/lpsgmjng01_1/index.m3u8
 北京黄花城水长城,https://gcalic.v.myalicdn.com/gc/wgw01_1/index.m3u8
 江苏徐州之夜,https://gcalic.v.myalicdn.com/gc/hspyt_1/index.m3u8
 山东济南趵突泉,https://gcalic.v.myalicdn.com/gc/wgw03_1/index.m3u8
 沈阳辽宁浑河桥,https://gcalic.v.myalicdn.com/gc/ljgcdsc_1/index.m3u8
 陕西渭南潼关县东山景区,https://gcalic.v.myalicdn.com/gc/hkylxs03_1/index.m3u8
 陕西渭南韩城市党家村景区,https://gcalic.v.myalicdn.com/gc/gly01_1/index.m3u8
 陕西渭南蒲城县中心广场,https://gcalic.v.myalicdn.com/gc/hsxksqj_1/index.m3u8
 陕西西安阎良关山石川河风景区,https://gcalic.v.myalicdn.com/gc/nss01_1/index.m3u8
 湖南邵阳莨山八角寨,https://gcalic.v.myalicdn.com/gc/hkts02_1/index.m3u8
 湖南邵阳崀山骆驼峰,https://gcalic.v.myalicdn.com/gc/dlst01_1/index.m3u8
 内蒙古乌审旗萨拉乌苏考古遗迹公园,https://gcalic.v.myalicdn.com/gc/taishan06_1/index.m3u8
 贵州黔东南加榜梯田,https://gcalic.v.myalicdn.com/gc/qdls03_1/index.m3u8
 山西晋城釜山泫水湖,https://gcalic.v.myalicdn.com/gc/zh02_1/index.m3u8
 山西大同鼓楼,https://gcalic.v.myalicdn.com/gc/emswfs_1/index.m3u8
 青海省祁连山国家公园,https://gcalic.v.myalicdn.com/gc/emspxps_1/index.m3u8
 望乡台,https://gcalic.v.myalicdn.com/gc/hlwxt_1/index.m3u8
 重庆渝中李子坝,https://gcalic.v.myalicdn.com/gc/ylh04_1/index.m3u8
 河南商丘永城市日月湖景区,https://gcalic.v.myalicdn.com/gc/hgsspzxdpb_1/index.m3u8
 河南鹤壁浚县古城景区北城门,https://gcalic.v.myalicdn.com/gc/hlzycc_1/index.m3u8



国际测试,#genre#

CNN,https://turnerlive.warnermediacdn.com/hls/live/586495/cnngo/cnn_slate/VIDEO_0_3564000.m3u8
BBC News,https://vs-hls-push-ww-live.akamaized.net/x=4/i=urn:bbc:pips:service:bbc_news_channel_hd/t=3840/v=pv14/b=5070016/main.m3u8
CNA,https://d2e1asnsl7br7b.cloudfront.net/7782e205e72f43aeb4a48ec97f66ebbe/index_5.m3u8
RT News,https://rt-glb.rttv.com/dvr/rtnews/playlist_4500Kb.m3u8
ABC News,https://content.uplynk.com/channel/3324f2467c414329b3b0cc5cd987b6be.m3u8
CNBC,https://fl1.moveonjoy.com/CNBC/index.m3u8
NBC,https://fl1.moveonjoy.com/FL_Tampa_NBC/index.m3u8
MSNBC,http://41.205.93.154/MSNBC/index.m3u8
NBC News Now,https://livehub-voidnet.onrender.com/cluster/streamcore/us/NBC_REDIS.m3u8
LiveNow,https://jmp2.uk/rok-f9c0d48b540a55dcb98b04d2cc8abf25.m3u8
Euronews,https://jmp2.uk/rok-dafd06b712a35fbe9935d4c04c2e8b53.m3u8
Al Jazeera,https://live-hls-aje-ak.getaj.net/AJE/01.m3u8
TRT World,https://tv-trtworld.medya.trt.com.tr/master_1080.m3u8
Fox Business,http://fl1.moveonjoy.com/FOX_Business_Network/index.m3u8
Bloomberg TV,https://1cd69008d08c486ca5abc0f1c4e2ef63.mediatailor.ap-northeast-1.amazonaws.com/v1/manifest/3722c60a815c199d9c0ef36c5b73da68a62b09d1/Bloomberg-kr-prod/87e22cf4-e302-42f6-a781-1d726fc87835/0.m3u8
NEWSMAX,https://nmx1ota.akamaized.net/hls/live/2107010/Live_1/3.m3u8
Global News,https://live.corusdigitaldev.com/groupd/live/49a91e7f-1023-430f-8d66-561055f3d0f7/live.isml/live-audio_1=96000-video=2499968.m3u8
Arirang K-Pop,https://stream.ads.ottera.tv/playlist.m3u8?network_id=5468
WION,https://d7x8z4yuq42qn.cloudfront.net/index_7.m3u8
TalkTV,https://live-talktv-ssai.simplestreamcdn.com/v1/master/774d979dd66704abea7c5b62cb34c6815fda0d35/talktv-live/index.m3u8
Arirang,https://amdlive-ch01-ctnd-com.akamaized.net/arirang_1ch/smil:arirang_1ch.smil/chunklist_b3256000_sleng.m3u8
Taiwan Plus,https://bcovlive-a.akamaihd.net/rce33d845cb9e42dfa302c7ac345f7858/ap-northeast-1/6282251407001/playlist.m3u8
RT Documentary,https://rt-rtd.rttv.com/live/rtdoc/playlist_4500Kb.m3u8
Newsy,https://547f72e6652371c3.mediapackage.us-east-1.amazonaws.com/out/v1/e3e6e29095844c4ba7d887f01e44a5ef/index_8.m3u8
Redbull,http://rbmn-live.akamaized.net/hls/live/590964/BoRB-AT/master_3360.m3u8
HollyWire,https://bozztv.com/hwotta/playlist/HD3400/HD3400.m3u8
MovieSphere,https://moviesphereuk-samsunguk.amagi.tv/playlist.m3u8
Trace Sport Stars,https://lightning-tracesport-samsungau.amagi.tv/playlist.m3u8
SportsGrid,https://jmp2.uk/rok-62f1cd0d4c395a2a8ab72cff688666a0.m3u8
Eurosport 4K,http://nvsoo4tx.megogo.xyz/iptv/UWA8DBPMZFQ9PX9ZLSBM7FFX/31475/index.m3u8
BEIN Sports,http://fl1.moveonjoy.com/BEIN_SPORTS/index.m3u8
BEIN Sports Extra,https://bein-xtra-xumo.amagi.tv/playlist.m3u8
Wild Earth,https://wildearth-plex.amagi.tv/masterR1080p.m3u8
Love Nature,http://nvsoo4tx.megogo.xyz/iptv/UWA8DBPMZFQ9PX9ZLSBM7FFX/5001/index.m3u8
Fashion Channel,http://fl1001.bozztv.com/ushba19/tracks-v1a1/mono.m3u8
Fashion TV,http://91.247.68.229:8000/play/Fashion/index.m3u8
4K Travel,https://d35j504z0x2vu2.cloudfront.net/v1/master/0bc8e8376bd8417a1b6761138aa41c26c7309312/4k-travel-tv/manifest.m3u8
Action Hollywood,https://cdn-apse1-prod.tsv2.amagi.tv/linear/amg01076-lightningintern-actionhollywood-samsungau/playlist.m3u8
Mytime Movie,https://appletree-mytimeau-samsung.amagi.tv/playlist.m3u8
MTV,http://143.244.60.30/MTV/index.m3u8
Pulse,https://cdn-apse1-prod.tsv2.amagi.tv/linear/amg01076-lightningintern-pulse-samsungau/playlist.m3u8
Tastemade,https://cdn-ue1-prod.tsv2.amagi.tv/linear/tastemade-tastemade-int-aus-samsungau/playlist.m3u8
Travel XP,http://nvsoo4tx.megogo.xyz/iptv/UWA8DBPMZFQ9PX9ZLSBM7FFX/14026/index.m3u8
PowerNation,https://cdn-uw2-prod.tsv2.amagi.tv/linear/amg01258-raycomsports-powernationau-samsungau/playlist.m3u8
Trace Urban,https://lightning-traceurban-samsungau.amagi.tv/playlist.m3u8
Kartoon Channel,https://lightning-fnf-samsungaus.amagi.tv/playlist.m3u8
History Hit,https://cdn-ue1-prod.tsv2.amagi.tv/linear/ldsAAAAAA-timeline-samsungau/playlist.m3u8
Outdoor Channel,https://cdn-apse1-prod.tsv2.amagi.tv/linear/amg00718-outdoorchannela-outdoortvnz-samsungnz/playlist.m3u8
HBO,http://fl1.moveonjoy.com/HBO/index.m3u8
HBO Hits,http://fl1.moveonjoy.com/HBO_2/index.m3u8
HBO Movies,http://fl1.moveonjoy.com/HBO_ZONE/index.m3u8
Paramount+ with Showtime,http://fl1.moveonjoy.com/SHOWTIME/index.m3u8
Showtime 2,http://fl1.moveonjoy.com/SHOWTIME_2/index.m3u8
Showtime Extreme,http://fl1.moveonjoy.com/SHOWTIME_EXTREME/index.m3u8
Showtime Next,http://fl1.moveonjoy.com/SHOWTIME_NEXT/index.m3u8
Showtime Women,http://fl1.moveonjoy.com/SHOWTIME_WOMEN/index.m3u8
Starz Comedy,http://fl1.moveonjoy.com/STARZ_COMEDY/index.m3u8
Sony One Action HITS,https://89514e758f814907be6d14bbc0aa66b7.mediatailor.us-west-2.amazonaws.com/v1/master/ba62fe743df0fe93366eba3a257d792884136c7f/LINEAR-800-UK-SONYONEACTIONHITS-LG_UK/playlist.m3u8
Sony One Comedy HITS,https://9f8e2ffcd87f4c469be7194e48f84874.mediatailor.us-west-2.amazonaws.com/v1/master/ba62fe743df0fe93366eba3a257d792884136c7f/LINEAR-802-UK-SONYONECOMEDYHITS-LG_UK/playlist.m3u8
Top Movies,https://0145451975a64b35866170fd2e8fa486.mediatailor.eu-west-1.amazonaws.com/v1/master/0547f18649bd788bec7b67b746e47670f558b6b2/production-LiveChannel-5987/master.m3u8
Action Movies,https://54045f0c40fd442c8b06df076aaf1e85.mediatailor.eu-west-1.amazonaws.com/v1/master/0547f18649bd788bec7b67b746e47670f558b6b2/production-LiveChannel-6065/master.m3u8
Comedy Movies,https://9be783d652cd4b099cf63e1dc134c4a3.mediatailor.eu-west-1.amazonaws.com/v1/master/0547f18649bd788bec7b67b746e47670f558b6b2/production-LiveChannel-6181/master.m3u8
Thrillers,https://thriller-rakuten-tv-uk.fast.rakuten.tv/v1/master/0547f18649bd788bec7b67b746e47670f558b6b2/production-LiveChannel-6482/master.m3u8?ads.app_bundle=[APP_BUNDLE]&ads.app_name=LG%20Channel%20Plus&ads.app_store_url=[APP_STOREURL]&ads.app_version=[APP_VERSION]&ads.brand_name=[DEVICE_MAKE]&ads.content_livestream=0&ads.device_lmt=[LMT]&ads.device_model=[DEVICE_MODEL]&ads.did=[IFA]&ads.fck=[FCK]&ads.gdpr_consent=[GDPR_CONSENT]&ads.ifa_type=[IFA_TYPE]&ads.market=uk&ads.platform=lg_channelplus&ads.pod_type=playerpage_midroll&ads.rtv_channel_name=thriller-rakuten-tv_uk&ads.rtv_content_id=6482&ads.rtv_language=en&ads.viewsize=[VIEWSIZE]&channel_id=6482&disable_subtitles=true&publishing_platform_id=2
Sci-Fi,https://sci-fi-rakuten-tv-uk.fast.rakuten.tv/v1/master/0547f18649bd788bec7b67b746e47670f558b6b2/production-LiveChannel-6241/master.m3u8?ads.app_bundle=[APP_BUNDLE]&ads.app_name=LG%20Channel%20Plus&ads.app_store_url=[APP_STOREURL]&ads.app_version=[APP_VERSION]&ads.brand_name=[DEVICE_MAKE]&ads.content_livestream=0&ads.device_lmt=[LMT]&ads.device_model=[DEVICE_MODEL]&ads.did=[IFA]&ads.fck=[FCK]&ads.gdpr_consent=[GDPR_CONSENT]&ads.ifa_type=[IFA_TYPE]&ads.market=uk&ads.platform=lg_channelplus&ads.pod_type=playerpage_midroll&ads.rtv_channel_name=sci-fi-rakuten-tv_uk&ads.rtv_content_id=6241&ads.rtv_language=en&ads.viewsize=[VIEWSIZE]&channel_id=6241&disable_subtitles=true&publishing_platform_id=2
Romance Movies,https://romance-rakuten-tv-uk.fast.rakuten.tv/v1/master/0547f18649bd788bec7b67b746e47670f558b6b2/production-LiveChannel-6194/master.m3u8?ads.app_bundle=[APP_BUNDLE]&ads.app_name=LG%20Channel%20Plus&ads.app_store_url=[APP_STOREURL]&ads.app_version=[APP_VERSION]&ads.brand_name=[DEVICE_MAKE]&ads.content_livestream=0&ads.device_lmt=[LMT]&ads.device_model=[DEVICE_MODEL]&ads.did=[IFA]&ads.fck=[FCK]&ads.gdpr_consent=[GDPR_CONSENT]&ads.ifa_type=[IFA_TYPE]&ads.market=uk&ads.platform=lg_channelplus&ads.pod_type=playerpage_midroll&ads.rtv_channel_name=romance-rakuten-tv_uk&ads.rtv_content_id=6194&ads.rtv_language=en&ads.viewsize=[VIEWSIZE]&channel_id=6194&disable_subtitles=true&publishing_platform_id=2
Drama Movies,https://fee09fd665814f51b939b6d106cf5f66.mediatailor.eu-west-1.amazonaws.com/v1/master/0547f18649bd788bec7b67b746e47670f558b6b2/production-LiveChannel-6093/master.m3u8
Thriller TV,https://52aad07d9d4f4d479d9b27e08ddf9e8b.mediatailor.us-west-2.amazonaws.com/v1/master/ba62fe743df0fe93366eba3a257d792884136c7f/LINEAR-808-UK-SONYONETHRILLERTV-LG_UK/playlist.m3u8
Comedy TV,https://ec613694ee5049d3b8f30913b619662e.mediatailor.us-west-2.amazonaws.com/v1/master/ba62fe743df0fe93366eba3a257d792884136c7f/LINEAR-804-UK-SONYONECOMEDYTV-LG_UK/playlist.m3u8
Sony One FAVES,https://8a4805800dac428ebbf1d3cde0cdcf87.mediatailor.us-west-2.amazonaws.com/v1/master/ba62fe743df0fe93366eba3a257d792884136c7f/LINEAR-806-UK-SONYONEFAVES-LG_UK/playlist.m3u8
Sony One Dragons' Den,https://5dae1f2dfec54d8f9992b7d2ac0bc627.mediatailor.us-west-2.amazonaws.com/v1/master/ba62fe743df0fe93366eba3a257d792884136c7f/LINEAR-810-UK-SONYONEDRAGONSDEN-LG_UK/playlist.m3u8
Great British Menu,https://7ed93f662af44c2e9bdf93b56464f6a8.mediatailor.us-east-1.amazonaws.com/v1/master/44f73ba4d03e9607dcd9bebdcb8494d86964f1d8/LG-gb_GreatBritishMenu/playlist.m3u8
Icon Film Channel,https://09e3020901654256a51f2f2e9213765a.mediatailor.us-east-1.amazonaws.com/v1/master/04fd913bb278d8775298c26fdca9d9841f37601f/LG-gb_IconFilmChannelClassics/playlist.m3u8
Popflix,https://2e90a1efd576492a8eaf4364feedf8d5.mediatailor.us-east-1.amazonaws.com/v1/master/04fd913bb278d8775298c26fdca9d9841f37601f/LG-gb_Popflix/playlist.m3u8
LG 1 Film,https://stream.ads.ottera.tv/playlist.m3u8?network_id=15465&avod=1&coppa=0&td=6&is_lat=[LMT]&dnt=[DNS]&us_privacy=[US_PRIVACY]&did=[DEVICE_ID]&ip=[IP]&ua=[UA]&ifa_type=[IFA_TYPE]&app_bundle=[APP_BUNDLE]&app_store_url=[APP_STOREURL]&app_name=[APP_NAME]&custom_targeting=html5&custom_4=lg_channels_uk&player_height=720&player_width=1280&content_channel=lg_channels&content_dist_name=lg_channels&device_make=[DEVICE_MAKE]&device_model=[DEVICE_MODEL]&device_os=html5&consent=[GDPR_CONSENT]&gdpr=[GDPR]&gender=not_specified&yob=0&livestream=1&custom_param_0=[DEVICE_MODEL]&custom_param_1=tv&custom_param_2=[DEVICE_MAKE]&custom_param_3=[DEVICE_ID]&custom_param_4=lg_channels&custom_param_5=html5&fck=[FCK]&viewsize=[VIEWSIZE]
LG 1 Spotlight,https://stream.ads.ottera.tv/playlist.m3u8?network_id=13959&avod=1&coppa=0&td=6&is_lat=[LMT]&dnt=[DNS]&us_privacy=[US_PRIVACY]&did=[DEVICE_ID]&ip=[IP]&ua=[UA]&ifa_type=[IFA_TYPE]&app_bundle=[APP_BUNDLE]&app_store_url=[APP_STOREURL]&app_name=[APP_NAME]&custom_targeting=html5&custom_4=lg_channels_uk&player_height=720&player_width=1280&content_channel=lg_channels&content_dist_name=lg_channels&device_make=[DEVICE_MAKE]&device_model=[DEVICE_MODEL]&device_os=html5&consent=[GDPR_CONSENT]&gdpr=[GDPR]&gender=not_specified&yob=0&livestream=1&custom_param_0=[DEVICE_MODEL]&custom_param_1=tv&custom_param_2=[DEVICE_MAKE]&custom_param_3=[DEVICE_ID]&custom_param_4=lg_channels&custom_param_5=html5&fck=[FCK]&viewsize=[VIEWSIZE]
LG 1,https://stream.ads.ottera.tv/playlist.m3u8?network_id=10957&avod=1&coppa=0&td=6&is_lat=[LMT]&dnt=[DNS]&us_privacy=[US_PRIVACY]&did=[DEVICE_ID]&ip=[IP]&ua=[UA]&ifa_type=[IFA_TYPE]&app_bundle=[APP_BUNDLE]&app_store_url=[APP_STOREURL]&app_name=[APP_NAME]&custom_targeting=html5&custom_4=lg_channels_uk&player_height=720&player_width=1280&content_channel=lg_channels&content_dist_name=lg_channels&device_make=[DEVICE_MAKE]&device_model=[DEVICE_MODEL]&device_os=html5&consent=[GDPR_CONSENT]&gdpr=[GDPR]&gender=not_specified&yob=0&livestream=1&custom_param_0=[DEVICE_MODEL]&custom_param_1=tv&custom_param_2=[DEVICE_MAKE]&custom_param_3=[DEVICE_ID]&custom_param_4=lg_channels&custom_param_5=html5&fck=[FCK]&viewsize=[VIEWSIZE]
Real Madrid,https://wurlcineverse.global.transmit.live/hls/678aa19b0d785cafbf15414a/v1/cinedigm_entertainment_corp_realmadrid_1/lg_ca/latest/main/hls/playlist.m3u8?wurl_channel=1865&wurl_name=RealMadrid&coppa=0&uid=[DEVICE_ID]&rdid=[IFA]&ifatype=[IFA_TYPE]&dnt=[LMT]&donotsell=[DNS]&isgdpr=[GDPR]&gdpr=[GDPR_CONSENT]&country=[COUNTRY]&pr=[US_PRIVACY]&appstoreurl=[APP_STOREURL]&bundleid=[APP_BUNDLE]&appname=[APP_NAME]&appversion=[APP_VERSION]&dt=[DEVICE_TYPE]&make=[DEVICE_MAKE]&model=[DEVICE_MODEL]&targetad=[TARGETAD_ALLOWED]
GoUSA TV,https://cc2b7c60df304389ba60c76790d1a82f.mediatailor.us-east-1.amazonaws.com/v1/master/44f73ba4d03e9607dcd9bebdcb8494d86964f1d8/LG-au_GoUSATV/playlist.m3u8
Autentic Travel,https://2d1ef59f0ad34d14888d8abce1b99264.mediatailor.us-east-1.amazonaws.com/v1/master/04fd913bb278d8775298c26fdca9d9841f37601f/LG-au_AutenticTravel/playlist.m3u8
Inside Outside,https://52405cd167dc41c68edcaa842b916ccd.mediatailor.us-east-1.amazonaws.com/v1/master/44f73ba4d03e9607dcd9bebdcb8494d86964f1d8/LG-au_InsideOutside/playlist.m3u8
SBS Drama,https://ads.its-newid.net/api/manifest.m3u8?tp=lg_channels&channel_name=sbsk-drama&channel_id=newid_008&mpf=c064f5f4-39af1962-7c36be2c&apikey=48230e6b-1cea0097-15975f93-39af1962&auth=474ab4cb-5d47aa0a-84d0cbca-2a3730a6&ads.live=[CONTENT_LIVE]&ads.deviceid=[DEVICE_ID]&ads.ifa=[IFA]&ads.ifatype=[IFA_TYPE]&ads.lat=[LMT]&ads.donotsell=[DNS]&ads.ua=[UA]&ads.ip=[IP]&ads.gdpr=[GDPR]&ads.gdpr_consent=[GDPR_CONSENT]&ads.country=[COUNTRY]&ads.us_privacy=[US_PRIVACY]&ads.appstoreurl=[APP_STOREURL]&ads.bundleid=[APP_BUNDLE]&ads.appname=[APP_NAME]&ads.appversion=[APP_VERSION]&ads.devicetype=[DEVICE_TYPE]&ads.devicemake=[DEVICE_MAKE]&ads.devicemodel=[DEVICE_MODEL]&ads.targetad=[TARGETAD_ALLOWED]&ads.fck=[FCK]&ads.viewsize=[VIEWSIZE]&ads.givn=[NONCE]
New Kmovies,https://ads.its-newid.net/api/manifest.m3u8?tp=lg_channels&channel_name=newkmovies&channel_id=newid_219&mpf=adfc204d-39af1962-13a2f01a&apikey=48230e6b-1cea0097-15975f93-39af1962&auth=b62c2c8b-8316a771-295eba28-f4663ddd&ads.live=[CONTENT_LIVE]&ads.deviceid=[DEVICE_ID]&ads.ifa=[IFA]&ads.ifatype=[IFA_TYPE]&ads.lat=[LMT]&ads.donotsell=[DNS]&ads.ua=[UA]&ads.ip=[IP]&ads.gdpr=[GDPR]&ads.gdpr_consent=[GDPR_CONSENT]&ads.country=[COUNTRY]&ads.us_privacy=[US_PRIVACY]&ads.appstoreurl=[APP_STOREURL]&ads.bundleid=[APP_BUNDLE]&ads.appname=[APP_NAME]&ads.appversion=[APP_VERSION]&ads.devicetype=[DEVICE_TYPE]&ads.devicemake=[DEVICE_MAKE]&ads.devicemodel=[DEVICE_MODEL]&ads.targetad=[TARGETAD_ALLOWED]&ads.fck=[FCK]&ads.viewsize=[VIEWSIZE]&ads.givn=[NONCE]
Tennis Channel,https://cdn-uw2-prod.tsv2.amagi.tv/linear/amg01444-tennischannelth-tennischnlintl-lggb/playlist.m3u8?ads.deviceid=[DEVICE_ID]&ads.ifa=[IFA]&ads.ifatype=[IFA_TYPE]&ads.lat=[LMT]&ads.donotsell=[DNS]&ads.ua=[UA]&ads.ip=[IP]&ads.gdpr=[GDPR]&ads.gdprconsent=[GDPR_CONSENT]&ads.country=[COUNTRY]&ads.usprivacy=[US_PRIVACY]&ads.appstoreurl=[APP_STOREURL]&ads.bundleid=[APP_BUNDLE]&ads.appname=[APP_NAME]&ads.appversion=[APP_VERSION]&ads.devicetype=[DEVICE_TYPE]&ads.devicemake=[DEVICE_MAKE]&ads.devicemodel=[DEVICE_MODEL]&ads.coppa=0&ads.targetad=[TARGETAD_ALLOWED]&ads.fck=[FCK]&ads.viewsize=[VIEWSIZE]&ads.givn=[NONCE]
Universal Monsters,https://d4whmvwm0rdvi.cloudfront.net/10007/99993044/hls/master.m3u8?ads.xumo_channelId=99993044&ads.asnw=169843&ads.afid=380753606&ads.sfid=17850336&ads.csid=lgchannels_us_nbcuuniversalmonsters_ssai_cro&ads._fw_is_lat=[LMT]&ads._fw_us_privacy=[US_PRIVACY]&ads._fw_coppa=0&ads._fw_did=[IFA]&ads._fw_vcid2=512116:[IFA]&ads._fw_app_bundle=[APP_BUNDLE]&ads._fw_app_store_url=[APP_STOREURL]&ads._fw_content_category=IAB1-7&ads._fw_content_genre=television&ads._fw_content_language=en&ads._fw_content_rating=tv-14&ads._fw_deviceMake=[DEVICE_MAKE]&ads._fw_device_model=[DEVICE_MODEL]&ads._fw_deviceType=3-Connected_TV&ads.appVersion=[APP_VERSION]&ads.appName=lgchannels&ads.xumo_contentId=3940&ads.xumo_contentName=NBCUUniversalMonsters&ads.xumo_providerId=3940&ads.xumo_providerName=NBCUUniversalMonsters&ads.channelId=99993044&ads._fw_ifa_type=dpid&ads.givn=[NONCE]&ads.fck=[FCK]&ads.viewsize=[VIEWSIZE]
ION Plus,https://cdn-uw2-prod.tsv2.amagi.tv/linear/amg01438-ewscrippscompan-ionplus-tablo/playlist.m3u8
Billiard TV,https://stream.ads.ottera.tv/playlist.m3u8?network_id=15270&avod=1&coppa=0&td=6&is_lat=[LMT]&dnt=[DNS]&us_privacy=[US_PRIVACY]&did=[DEVICE_ID]&ip=[IP]&ua=[UA]&ifa_type=[IFA_TYPE]&app_bundle=[APP_BUNDLE]&app_store_url=[APP_STOREURL]&app_name=[APP_NAME]&custom_targeting=html5&custom_4=lg_channels_us&player_height=720&player_width=1280&content_channel=lg_channels&content_dist_name=lg_channels&device_make=[DEVICE_MAKE]&device_model=[DEVICE_MODEL]&device_os=html5&consent=[GDPR_CONSENT]&gdpr=[GDPR]&gender=not_specified&yob=0&livestream=1&custom_param_0=[DEVICE_MODEL]&custom_param_1=tv&custom_param_2=[DEVICE_MAKE]&custom_param_3=[DEVICE_ID]&custom_param_4=lg_channels&custom_param_5=html5&fck=[FCK]&viewsize=[VIEWSIZE]&nonce=[NONCE]
NBA TV,http://fl1.moveonjoy.com/NBA_TV/index.m3u8
MLB Network,http://fl1.moveonjoy.com/MLB_NETWORK/index.m3u8
TNT Sports 1,https://7pal.short.gy/tntspts1
TNT Sports 2,https://7pal.short.gy/tntspts2
TNT Sports 3,https://7pal.short.gy/tntspts3
TNT Sports 4,https://7pal.short.gy/tntspts4
TNT Sports Ultimate,https://a1xs.vip/2000031
TSN 1,http://fl1.moveonjoy.com/TSN_1/mpegts
TSN 4,http://fl1.moveonjoy.com/TSN_4/mpegts
Sky Sports Premier League,https://7pal.short.gy/ssportspl
Sky Sports Football,https://7pal.short.gy/ssportsfb
Sky Sports+,https://a1xs.vip/2000012
Sky Sports News,https://7pal.short.gy/ssportsnw
Sky Sports NFL,https://a1xs.vip/2000011
Sky Sports Mix,https://a1xs.vip/2000008
ESPNU,http://fl1.moveonjoy.com/ESPN_U/index.m3u8
ESPN2,http://1tv41.icu:8080/8434692955/judgen64@yahoo.com/2210
FS1,http://fl1.moveonjoy.com/FOX_Sports_1/index.m3u8
FS2,https://a1xs.vip/40000022
NHL Network,http://23.237.104.106:8080/USA_NHL_NETWORK/index.m3u8
Aspire,http://fl1.moveonjoy.com/Aspire/index.m3u8
Persuit Channel,https://d2qa45tniogkj6.cloudfront.net/out/v1/30f129d3a8a8482b9efe5092cf46e601/index.m3u8
Bravo TV,http://fl1.moveonjoy.com/BRAVO/index.m3u8
The First,https://thefirst-oando.amagi.tv/playlist.m3u8
Cooking Channel,https://fl1.moveonjoy.com/COOKING_CHANNEL/index.m3u8
FX Movie Channel,http://fl1.moveonjoy.com/FX_MOVIE/index.m3u8
FYI TV,http://fl1.moveonjoy.com/FYI/index.m3u8
Grit TV,http://fl1.moveonjoy.com/GRIT_TV/index.m3u8
Golf Channel,https://fl1.moveonjoy.com/GOLF/index.m3u8
Hallmark Channel,http://fl1.moveonjoy.com/HALLMARK_CHANNEL/index.m3u8
Hallmark Family,https://fl1.moveonjoy.com/HALLMARK_DRAMA/index.m3u8
Hallmark Mystery,https://fl1.moveonjoy.com/HALLMARK_MOVIES_MYSTERIES/index.m3u8
Lifetime,http://fl1.moveonjoy.com/LIFETIME/index.m3u8
YES Network,https://fl1.moveonjoy.com/YES_NETWORK/index.m3u8

已测试
BBC News,https://vs-hls-push-ww-live.akamaized.net/x=4/i=urn:bbc:pips:service:bbc_news_channel_hd/t=3840/v=pv14/b=5070016/main.m3u8
CNN,https://turnerlive.warnermediacdn.com/hls/live/586495/cnngo/cnn_slate/VIDEO_0_3564000.m3u8
CNA,https://d2e1asnsl7br7b.cloudfront.net/7782e205e72f43aeb4a48ec97f66ebbe/index_5.m3u8
GB News,https://cdn-apse1-prod.tsv2.amagi.tv/linear/amg01076-lightningintern-gbnewsnz-samsungnz/playlist.m3u8
RT News,https://rt-glb.rttv.com/dvr/rtnews/playlist_4500Kb.m3u8
Euronews,https://jmp2.uk/rok-dafd06b712a35fbe9935d4c04c2e8b53.m3u8
TRT World,https://tv-trtworld.medya.trt.com.tr/master_1080.m3u8
Fox News,http://panelguys.top:8080/txd7Fd/030774/1818
Al Jazeera,http://live-hls-web-aje.getaj.net/AJE/01.m3u8
CBS News,http://panelguys.top:8080/txd7Fd/030774/21259
Global News,https://live.corusdigitaldev.com/groupd/live/49a91e7f-1023-430f-8d66-561055f3d0f7/live.isml/live-audio_1=96000-video=2499968.m3u8
Newsmax 2,https://nmxlive.akamaized.net/hls/live/529965/Live_1/1.m3u8
TBS Seoul,https://cdntv.tbs.seoul.kr/tbs/tbs_tv_web.smil/playlist.m3u8
WION,https://d7x8z4yuq42qn.cloudfront.net/index_7.m3u8
PBS HD,http://panelguys.top:8080/txd7Fd/030774/57276
Cheddar News,https://cheddar-us.samsung.wurl.tv/playlist_4300k.m3u8
Newsy,https://547f72e6652371c3.mediapackage.us-east-1.amazonaws.com/out/v1/e3e6e29095844c4ba7d887f01e44a5ef/index_8.m3u8
HollyWire,https://bozztv.com/hwotta/playlist/HD3400/HD3400.m3u8
NEWS 12,http://panelguys.top:8080/qcFA9B/963626/167741
Arirang,https://amdlive-ch01-ctnd-com.akamaized.net/arirang_1ch/smil:arirang_1ch.smil/chunklist_b3256000_sleng.m3u8
Taiwan Plus,https://bcovlive-a.akamaihd.net/rce33d845cb9e42dfa302c7ac345f7858/ap-northeast-1/6282251407001/playlist.m3u8
RT Documentary,https://rt-rtd.rttv.com/live/rtdoc/playlist_4500Kb.m3u8
NBA TV,http://panelguys.top:8080/txd7Fd/030774/22995
Redbull,http://rbmn-live.akamaized.net/hls/live/590964/BoRB-AT/master_3360.m3u8
Sportsnet East,http://panelguys.top:8080/txd7Fd/030774/41836
Animal Planet,http://panelguys.top:8080/txd7Fd/030774/57377
Cartoon Network,http://panelguys.top:8080/txd7Fd/030774/57380
CPAC,http://panelguys.top:8080/txd7Fd/030774/57402
CRAVE 1 HD,http://panelguys.top:8080/txd7Fd/030774/57309
CRAVE 2 HD,http://panelguys.top:8080/txd7Fd/030774/57310
CRAVE 3 HD,http://panelguys.top:8080/txd7Fd/030774/57322
CRAVE 4 HD,http://panelguys.top:8080/txd7Fd/030774/57311
CTV Comedy Channel,http://panelguys.top:8080/txd7Fd/030774/57408
CTV Drama Channel,http://panelguys.top:8080/txd7Fd/030774/57254
CTV News Channel,http://panelguys.top:8080/txd7Fd/030774/57350
Disney Junior,http://panelguys.top:8080/txd7Fd/030774/57349
Food Network,http://panelguys.top:8080/txd7Fd/030774/57247
FXX,http://panelguys.top:8080/txd7Fd/030774/57429
Game Show Network,http://panelguys.top:8080/txd7Fd/030774/57430
HGTV,http://panelguys.top:8080/txd7Fd/030774/57273
MSNBC,http://panelguys.top:8080/txd7Fd/030774/47332
NatGeo Wild,http://panelguys.top:8080/txd7Fd/030774/57280
OLN,http://panelguys.top:8080/txd7Fd/030774/57366
OWN,http://panelguys.top:8080/txd7Fd/030774/57277
Showcase,http://panelguys.top:8080/txd7Fd/030774/47366
Slice TV,http://panelguys.top:8080/txd7Fd/030774/57274
Smithsonian Channel,http://panelguys.top:8080/txd7Fd/030774/47369
Sportsnet 360,http://panelguys.top:8080/txd7Fd/030774/57299
Sportsnet East,http://panelguys.top:8080/txd7Fd/030774/57298
Sportsnet One,http://panelguys.top:8080/txd7Fd/030774/47379
Sportsnet Pacific,http://panelguys.top:8080/txd7Fd/030774/9860
Sportsnet West,http://panelguys.top:8080/txd7Fd/030774/20975
Sportsnet World,http://panelguys.top:8080/txd7Fd/030774/75675
TSN 2,http://panelguys.top:8080/txd7Fd/030774/16129
TSN 3,http://panelguys.top:8080/txd7Fd/030774/47444
TSN 4,http://panelguys.top:8080/txd7Fd/030774/66783
Premier Sports 1,http://6c72636e.amazzin.pw/iptv/4HP7GES799X3WU/2160/index.m3u8
Discovery Channel,http://panelguys.top:8080/txd7Fd/030774/53684
Film 4,http://panelguys.top:8080/txd7Fd/030774/53702
H2,http://panelguys.top:8080/txd7Fd/030774/53692
ITV2,http://panelguys.top:8080/txd7Fd/030774/53671
ITV 3,http://panelguys.top:8080/txd7Fd/030774/53665
ITV 4,http://cord-cutter.net:8080/23290078/13941299/53666
MUTV,http://panelguys.top:8080/txd7Fd/030774/53717
NICKELODEON,http://panelguys.top:8080/txd7Fd/030774/53728
Willow Cricket,http://panelguys.top:8080/txd7Fd/030774/41979
World Poker,https://d3w4n3hhseniak.cloudfront.net/v1/master/9d062541f2ff39b5c0f48b743c6411d25f62fc25/WPT-DistroTV/150.m3u
Trace Sport Stars,https://lightning-tracesport-samsungau.amagi.tv/playlist720p.m3u8
Lifetime Movies,http://panelguys.top:8080/txd7Fd/030774/20863
WWE Network,http://panelguys.top:8080/txd7Fd/030774/11645
Bally Sports Southwest,http://panelguys.top:8080/txd7Fd/030774/21843
FanDuel Sports West,http://panelguys.top:8080/txd7Fd/030774/20932
ESPN NEWS,http://panelguys.top:8080/txd7Fd/030774/17707
FanDuel Sports Ohio,http://panelguys.top:8080/txd7Fd/030774/17752
YES Network,http://panelguys.top:8080/txd7Fd/030774/57972
UniMas,http://panelguys.top:8080/txd7Fd/030774/57969
Univision,http://panelguys.top:8080/txd7Fd/030774/15336
Spectrum SportsNet,http://panelguys.top:8080/txd7Fd/030774/20946
StarMax,http://panelguys.top:8080/txd7Fd/030774/13381
ABC,http://panelguys.top:8080/txd7Fd/030774/22990
AMC,http://panelguys.top:8080/txd7Fd/030774/18925
Bet Gospel,http://panelguys.top:8080/txd7Fd/030774/66080
BET,http://panelguys.top:8080/txd7Fd/030774/13702
Bravo,http://panelguys.top:8080/txd7Fd/030774/20859
BUZZR,http://panelguys.top:8080/txd7Fd/030774/21896
Cinemax,http://panelguys.top:8080/txd7Fd/030774/13380
CMT,http://panelguys.top:8080/txd7Fd/030774/46706
CNBC,http://panelguys.top:8080/txd7Fd/030774/9815
Comet,http://panelguys.top:8080/txd7Fd/030774/66244
Decades,http://panelguys.top:8080/txd7Fd/030774/20189
Discovery Velocity,http://panelguys.top:8080/txd7Fd/030774/46212
Magnolia Network,http://panelguys.top:8080/txd7Fd/030774/10503
Epix Hits,http://panelguys.top:8080/txd7Fd/030774/12744
ESPN 1,http://panelguys.top:8080/txd7Fd/030774/14197
ESPN 2,http://panelguys.top:8080/txd7Fd/030774/2210
Fox Business Network,http://panelguys.top:8080/txd7Fd/030774/17639
BEIN Sports Xtra,https://bein-xtra-xumo.amagi.tv/playlist.m3u8
FX East,http://panelguys.top:8080/txd7Fd/030774/46690
FXM,http://panelguys.top:8080/txd7Fd/030774/10260
Grit TV,http://panelguys.top:8080/txd7Fd/030774/20861
HGTV,http://panelguys.top:8080/txd7Fd/030774/46717
History Channel,http://panelguys.top:8080/txd7Fd/030774/46724
INSP,http://panelguys.top:8080/txd7Fd/030774/16262
ION,http://panelguys.top:8080/txd7Fd/030774/9297
Laff,http://panelguys.top:8080/txd7Fd/030774/17777
Lifetime,http://panelguys.top:8080/txd7Fd/030774/46714
More Max,http://panelguys.top:8080/txd7Fd/030774/17776
MSG Plus,http://panelguys.top:8080/txd7Fd/030774/9276
Nat Geo Wild East,http://panelguys.top:8080/txd7Fd/030774/11664
One America News,http://panelguys.top:8080/txd7Fd/030774/21752
Wild Earth,https://wildearth-plex.amagi.tv/masterR1080p.m3u8
Love Nature,https://jmp2.uk/rok-479fe0d11f3f5132a3f36b617547da3b.m3u8
OWN,http://panelguys.top:8080/txd7Fd/030774/46698
Oxygen,http://panelguys.top:8080/txd7Fd/030774/46695
Paramount Network,http://panelguys.top:8080/txd7Fd/030774/46694
PixL,http://panelguys.top:8080/txd7Fd/030774/21648
TBN,http://panelguys.top:8080/txd7Fd/030774/21895
TLC,http://panelguys.top:8080/txd7Fd/030774/47703
TNT West,http://panelguys.top:8080/txd7Fd/030774/46688
TNT East,http://panelguys.top:8080/txd7Fd/030774/10455
TRUTV East,http://panelguys.top:8080/txd7Fd/030774/10224
TV Land,http://panelguys.top:8080/txd7Fd/030774/46696
VICELAND,http://panelguys.top:8080/txd7Fd/030774/46697
Fashion Channel,http://fl1001.bozztv.com/ushba19/tracks-v1a1/mono.m3u8
4K Travel,https://d35j504z0x2vu2.cloudfront.net/v1/manifest/0bc8e8376bd8417a1b6761138aa41c26c7309312/4k-travel-tv/1967b0de-bf90-4339-a563-a5d06bba32ed/2.m3u8
HBO East HD,http://panelguys.top:8080/txd7Fd/030774/46713
HBO 2,http://panelguys.top:8080/txd7Fd/030774/57438
AMC Thrillers,http://panelguys.top:8080/txd7Fd/030774/66243
MovieSphere,https://moviesphereuk-samsunguk.amagi.tv/playlist.m3u8


国际频道,#genre#
🇬🇷希腊ATTICA,https://atticatv.siliconweb.com/atticatv/atticaliveabr/playlist.m3u8
🇪🇸西班牙DW Español Ⓢ,https://dwamdstream104.akamaized.net/hls/live/2015530/dwstream104/stream04/streamPlaylist.m3u8
🇲🇽墨西哥Alcarria TV,http://cls.alcarria.tv/live/alcarriatv-livestream.m3u8
🇮🇹意大利Food Network,https://dk3okdd5036kz.cloudfront.net/v1/master/3722c60a815c199d9c0ef36c5b73da68a62b09d1/cc-o4pw0nc02sthz/Foodnetwork_IT.m3u8
🇫🇮芬兰Alfa Ⓢ,https://irrtv2.digitacdn.net/live/ott/irrtv/playlist.m3u8?organizationId=229401409&suiteItemId=230439940
🇭🇷克罗地亚Al Jazeera Balkans,https://live-hls-web-ajb.getaj.net/AJB/index.m3u8
🇨🇷哥斯达黎加Canal 8,http://mdstrm.com/live-stream-playlist/5a7b1e63a8da282c34d65445.m3u8
🇨🇱智利UCV Televisión,https://unlimited1-cl-isp.dps.live/ucvtv2/ucvtv2.smil/playlist.m3u8
🇹🇩乍得Tchad 24,http://102.131.58.110/out_1/index.m3u8
🇧🇷巴西Record News,https://stream.ads.ottera.tv/playlist.m3u8?network_id=2116
🇧🇾白俄罗斯Radio HIT Orsk,http://hithd.camsh.orsk.ru/hls/hithd.m3u8
🇦🇱阿尔巴尼亚Syri,https://stream.syritv.al/SyriTV/index.m3u8
🇹🇷土耳其TRT World,https://tv-trtworld.medya.trt.com.tr/master.m3u8
🇳🇱荷兰Omrop Fryslân,https://d3pvma9xb2775h.cloudfront.net/live/omropfryslan/f8f68bd5/playlist.m3u8
🇧🇩孟加拉国DurontoTV,https://tvsen4.aynaott.com/durontotv/index.m3u8
🇮🇩印度尼西亚CNN Indonesia,http://live.cnnindonesia.com/livecnn/smil:cnntv.smil/chunklist_w1285822120_b384000_sleng.m3u8
🇹🇭泰国Thai PBS,http://thaipbs-live.cdn.byteark.com/live-en/playlist_720p/index.m3u8
🇺🇦乌克兰KPBIM,https://cdn.1tvcrimea.ru/1tvcrimea.m3u8
🇶🇦卡塔尔Al Jazeera English,https://live-hls-web-aje.getaj.net/AJE/01.m3u8
🇶🇦卡塔尔Al Jazeera Arabic,http://live-hls-web-aja.getaj.net/AJA/02.m3u8
🇰🇷韩国KBS Drama,http://8.138.7.223/tv/korea.php?id=32
🇰🇷韩国AriangTV,http://amdlive-ch01.ctnd.com.edgesuite.net:80/arirang_1ch/smil:arirang_1ch.smil/chunklist_b2256000_sleng.m3u8
🇰🇷韩国GS Shop,https://gstv-gsshop.gsshop.com/gsshop_hd/gsshop_hd.stream/playlist.m3u8
🇺🇸美国Fox weather,https://247wlive.foxweather.com/stream/index_1280x720.m3u8
🇺🇸美国Cable News Network,https://turnerlive.warnermediacdn.com/hls/live/586495/cnngo/cnn_slate/VIDEO_0_3564000.m3u8
🇺🇸美国Pac-12 Network,https://pac12-samsungus.amagi.tv/playlist480_p.m3u8
🇮🇳印度9Bharatvarsh,https://dyjmyiv3bp2ez.cloudfront.net/pub-iotv9hinjzgtpe/liveabr/pub-iotv9hinjzgtpe/live_720p/chunks.m3u8
🇮🇳印度JALSHA MOVIES,https://live.dinesh29.com.np/stream/jiotvplus/jalshamovieshd/master.m3u8
🇮🇳印度Zee-Bangla2,http://smart.bengaldigital.live/Zee-Bangla/index.m3u8
🇮🇳印度colorsbangla,https://catchup.yuppcdn.net/amazonv2/36/preview/colorsbanglahd/master/chunklist.m3u8
🇮🇳印度Moon,http://player.mslivestream.net/mslive/e10bb900976df9177b9a080314f26f86.sdp/index.m3u8

半岛新闻,https://live-hls-aje-ak.getaj.net/AJE/01.m3u8#https://live-hls-v3-aje.getaj.net/AJE-V3/01.m3u8#https://live-hls-web-aje.getaj.net/AJE/02.m3u8
CNA新闻,https://d2e1asnsl7br7b.cloudfront.net/7782e205e72f43aeb4a48ec97f66ebbe/index_5.m3u8
CBS新闻,https://www.cbsnews.com/common/video/cbsn-ny-prod.m3u8
CBN新闻,https://bcovlive-a.akamaihd.net/re8d9f611ee4a490a9bb59e52db91414d/us-east-1/734546207001/playlist.m3u8
GBN新闻,https://live-gbnews.simplestreamcdn.com/live5/gbnews/bitrate1.isml/manifest.m3u8
RT新闻,https://rt-glb.rttv.com/dvr/rtnews/playlist_4500Kb.m3u8
RT纪录,https://rt-rtd.rttv.com/live/rtdoc/playlist_4500Kb.m3u8
美国·彭博财经,https://liveprodusphoenixeast.akamaized.net/USPhx-HD/Channel-TX-USPhx-AWS-virginia-1/Source-USPhx-16k-1-s6lk2-BP-07-02-81ykIWnsMsg_live.m3u8
加拿大·Global新闻,https://live.corusdigitaldev.com/groupd/live/49a91e7f-1023-430f-8d66-561055f3d0f7/live.isml/master.m3u8
美·红牛运动,http://rbmn-live.akamaized.net/hls/live/590964/BoRB-AT/master_1660.m3u8
朝鲜中央电视台,https://tv.nknews.org/tvhls/stream.m3u8
韩·BBS,http://bbstv.clouducs.com:1935/bbstv-live/livestream/chunklist_w1216149699.m3u8
韩·EBS1,http://ebsonairios.ebs.co.kr/groundwavefamilypc/familypc1m/playlist.m3u8
韩·EBS2,http://ebsonairios.ebs.co.kr/ebs2familypc/familypc1m/playlist.m3u8
韩·EBSe,http://ebsonairios.ebs.co.kr/plus3familypc/familypc1m/playlist.m3u8
韩·EBS1,http://ebsonairios.ebs.co.kr/ebsutablet500k/tablet500k/playlist.m3u8
韩·EBS2,http://ebsonairios.ebs.co.kr/ebs2tablet500k/tablet500k/ebs2tablet500k.index.m3u8
韩·EBS1,http://ebsonairios.ebs.co.kr/groundwavetablet500k/tablet500k/playlist.m3u8
韩·EBS1,http://ebsonairios.ebs.co.kr/groundwavetablet500k/tablet500k/groundwavetablet500k.m3u8
韩·EBSi,http://ebsonairios.ebs.co.kr/plus1tablet500k/tablet500k/plus1tablet500k.index.m3u8
韩·EBS+2,http://ebsonairios.ebs.co.kr/plus2tablet500k/tablet500k/plus2tablet500k.index.m3u8
韩·KBS LIVE,http://kbs-dokdo.gscdn.com/dokdo_300/dokdo_300.stream/playlist.m3u8
韩·Arirang,http://amdlive-ch01.ctnd.com.edgesuite.net/arirang_1ch/smil:arirang_1ch.smil/playlist.m3u8
韩·KoreaTV,https://hlive.ktv.go.kr/live/klive_h.stream/playlist.m3u8
韩·TBS,https://cdntv.tbs.seoul.kr/tbs/_definst_/tbs_tv_web_720.smil/playlist.m3u8
韩·KBS Drama,http://mytv.dothome.co.kr/ch/catv/2.php
韩·KBS Joy,http://mytv.dothome.co.kr/ch/catv/3.php
韩·KBS Story,http://mytv.dothome.co.kr/ch/catv/4.php
韩·KBS World,http://mytv.dothome.co.kr/ch/catv/7.php
韩·KBS 1TV,https://code.vthanhtivi.pw/getlink/kbs/11/playlist.m3u8
韩·KBS 1TV,http://mytv.dothome.co.kr/ch/public/1.php
韩·KBS 2TV,http://mytv.dothome.co.kr/ch/public/3.php
韩·OUN,https://live.knou.ac.kr/knou1/live1/playlist.m3u8
韩·TBS Seoul,https://cdntv.tbs.seoul.kr/tbs/tbs_tv_web.smil/playlist.m3u8
韩·大田MBC,https://ns1.tjmbc.co.kr/live/myStream.sdp/playlist.m3u8
韩·木浦MBC,http://vod.mpmbc.co.kr:1935/live/encoder-tv/playlist.m3u8
韩·济州MBC,https://wowza.jejumbc.com/live/tv_jejumbc/playlist.m3u8
韩·江原岭东MBC,http://123.254.72.24:1935/tvlive/livestream2/playlist.m3u8
韩·KFN,http://mediaworks.dema.mil.kr:1935/live_edge/cudo.sdp/playlist.m3u8
印度TV 9 BHARATVARSH,https://dyjmyiv3bp2ez.cloudfront.net/pub-iotv9hinjzgtpe/liveabr/pub-iotv9hinjzgtpe/live_720p/chunks.m3u8
日本東映チャンネル,https://stream02.willfonk.com/live_playlist.m3u8?cid=CS218&r=FHD&ccode=JP&m=d0:20:20:04:35:cc&t=0d6938cb3dcf4b79848bc1753a59daf1#https://stream01.willfonk.com/live_playlist.m3u8?cid=CS218&r=FHD&ccode=JP&m=d0:20:20:04:35:cc&t=0d6938cb3dcf4b79848bc1753a59d
日本电影台,http://v2.catcast.tv/content/40546/index.m3u8
俄罗斯Russia Today,https://rt-glb.rttv.com/live/rtnews/playlist_4500Kb.m3u8
美国Go2Travel,https://go2thls.wns.live/hls/stream.m3u8
美国Palm Beaches TV,https://live.feed.thepalmbeaches.tv/index.m3u8
美国Travelxp,https://27c980761ff9437d929e64647afe183a.mediatailor.us-east-1.amazonaws.com/v1/master/44f73ba4d03e9607dcd9bebdcb8494d86964f1d8/RakutenTV-eu_TravelXP/playlist.m3u8
泰国ASTV-News,http://news1.live14.com/stream/news1_hi.m3u8
泰国PBS,http://thaipbs-live.cdn.byteark.com/live-en/playlist_720p/index.m3u8
菲律宾NDTV,https://ndtv24x7elemarchana.akamaized.net/hls/live/2003678/ndtv24x7/ndtv24x7master.m3u8
菲律宾AI-Jazeera,https://live-hls-web-aje.getaj.net/AJE/01.m3u8#http://125.227.210.37:8938/VideoInput/play.ts
俄罗斯GITV,http://hls-igi.cdnvideo.ru/igi/igi_hq/playlist.m3u8
俄罗斯camapa,http://live.guberniatv.cdnvideo.ru/guberniatv/guberniatv.sdp/playlist.m3u8
马来西亚RTM Asean,https://smart.pendy.dpdns.org/Smart.php?id=Rtmasean
马来西亚WION,https://smart.pendy.dpdns.org/Smart.php?id=Wion
马来西亚Astro Rusi,https://smart.pendy.dpdns.org/Smart.php?id=Rusi
马来西亚Astro LOL,https://smart.pendy.dpdns.org/Smart.php?id=Astro_lol
马来西亚Goshop,https://smart.pendy.dpdns.org/Smart.php?id=Goshop
韩国Gsmyshop,https://gstv-myshop.gsshop.com/myshop_hd/myshop_hd.stream/playlist.m3u8
Shop Channel,http://stream1.shopch.jp/HLS/out1/prog_index.m3u8
CNN-INDO,http://live.cnnindonesia.com/livecnn/smil:cnntv.smil/chunklist_w1285822120_b384000_sleng.m3u8
韩国NBS新闻,https://media.joycorp.co.kr:4443/live/live_720p/playlist.m3u8
韩国CJB新闻,http://1.222.207.80:1935/live/cjbtv/chunklist_w1357270949.m3u8
韩国EBS+1,http://ebsonairios.ebs.co.kr/plus1tablet500k/tablet500k/PLAYLIST.m3u8
韩国EBD-Kids,http://ebsonairios.ebs.co.kr/ebsutablet500k/_definst_/tablet500k/chunklist_w1965791004.m3u8
韩国BBS,http://bbstv.clouducs.com:1935/bbstv-live/livestream/playlist.m3u8
韩国NBS,https://media.joycorp.co.kr:4443/live/live_360p/playlist.m3u8
韩国KCTV,http://119.77.96.184:1935/chn05/chn05/chunklist_w1306745753.m3u8
CNN,https://turnerlive.warnermediacdn.com/hls/live/586495/cnngo/cnn_slate/VIDEO_0_3564000.m3u8
半岛新闻,https://live-hls-web-aje.getaj.net/AJE/01.m3u8
伊朗新闻,http://live-hls-web-aja.getaj.net/AJA/02.m3u8
FTV,http://lb.streaming.sk/fashiontv/stream/chunklist_w1906011378.m3u8
MBC,http://211.33.246.4:32954/cj_live/myStream.sdp/chunklist_w517347500.m3u8
台湾Plus,https://bcovlive-a.akamaihd.net/rce33d845cb9e42dfa302c7ac345f7858/ap-northeast-1/6282251407001/playlist.m3u8
Wild Earth,https://wildearth-plex.amagi.tv/masterR1080p.m3u8
Tokyo mx1,http://vthanh.utako.moe/Tokyo_MX1/index.m3u8
ABC,http://fl1.moveonjoy.com/ABC_EAST/index.m3u8
Fox,http://fl1.moveonjoy.com/FOX_EAST/index.m3u8
Amc,http://fl5.moveonjoy.com/AMC_NETWORK/index.m3u8
comedycentral,http://fl3.moveonjoy.com/Comedy_Central/index.m3u8
cookingchannel,http://fl3.moveonjoy.com/COOKING_CHANNEL/index.m3u8
bounce,http://fl3.moveonjoy.com/BOUNCE_TV/index.m3u8
AHC,http://fl3.moveonjoy.com/American_Heroes_Channel/index.m3u8
nbc,http://fl1.moveonjoy.com/NBC_EAST/index.m3u8
boomerang,http://fl3.moveonjoy.com/BOOMERANG/index.m3u8
nickelodeon,http://fl1.moveonjoy.com/NICKELODEON/index.m3u8
nicktoons,http://fl1.moveonjoy.com/NICKTOONS/index.m3u8
discovery,http://fl3.moveonjoy.com/Discovery_Channel/index.m3u8
tbs,http://fl1.moveonjoy.com/TBS/index.m3u8
tcm,http://fl1.moveonjoy.com/TCM/index.m3u8
wetv,http://fl1.moveonjoy.com/WE_TV/index.m3u8
cmt,http://fl3.moveonjoy.com/CMT/index.m3u8
cnbc,http://fl3.moveonjoy.com/CNBC/index.m3u8
big ten network,http://fl3.moveonjoy.com/BIG_TEN_NETWORK/index.m3u8
YT,https://hls.yourtime.live/hls/stream.m3u8
新加坡国际,https://d2e1asnsl7br7b.cloudfront.net/7782e205e72f43aeb4a48ec97f66ebbe/index_4.m3u8
联合国UNTV,https://cdnapi.kaltura.com/p/2503451/sp/250345100/playManifest/entryId/1_gb6tjmle/protocol/https/format/applehttp/a.m3u8
Travel Escapes TV,https://b385eb878e03425999616e7aedfe3605.mediatailor.us-east-1.amazonaws.com/v1/master/44f73ba4d03e9607dcd9bebdcb8494d86964f1d8/TCLTVPlus_TravelEscapes/playlist.m3u8
PAC-12 TV,https://pac12-samsungus.amagi.tv/playlist.m3u8
GLEWED Yoga TV,https://d35j504z0x2vu2.cloudfront.net/v1/master/0bc8e8376bd8417a1b6761138aa41c26c7309312/glewedtv-yoga/master.m3u8
Love the Planet,https://amg01821-lovetvchannels-lovetheplanetuksamsung-samsunguk-apopw.amagi.tv/playlist/amg01821-lovetvchannels-lovetheplanetuksamsung-samsunguk/playlist.m3u8
STADIUM,https://2d006483e2aa43fe812f7b464cb2916d.mediatailor.us-east-1.amazonaws.com/v1/master/44f73ba4d03e9607dcd9bebdcb8494d86964f1d8/Samsung_Stadium/playlist.m3u8
C31 TV,https://d1k6kax80wecy5.cloudfront.net/RLnAKY/index.m3u8
Gusto TV,https://gusto-localnow.amagi.tv/playlist.m3u8
Comedy Hub,https://d2iqvao9cpdq89.cloudfront.net/v1/master/3722c60a815c199d9c0ef36c5b73da68a62b09d1/cc-o28f6cbl23ij7/playlist.m3u8
Laugh Out Loud Network,https://364656c7dbf24400867e98eed23cec82.mediatailor.us-east-1.amazonaws.com/v1/master/04fd913bb278d8775298c26fdca9d9841f37601f/Samsung-gb_LOLNetwork/playlist.m3u8
Horizon Sports,https://d35j504z0x2vu2.cloudfront.net/v1/master/0bc8e8376bd8417a1b6761138aa41c26c7309312/horizon-sports/master.m3u8
Inside Crime,https://amg00841-aenetworksukane-insidecrime-samsunguk-o968i.amagi.tv/playlist/amg00841-aenetworksukane-insidecrime-samsunguk/playlist.m3u8
Wicked Tuna,https://amg00353-lionsgatestudio-wickedtuna-samsunguk-ajti1.amagi.tv/playlist/amg00353-lionsgatestudio-wickedtuna-samsunguk/playlist.m3u8
柯南·奥布莱恩TV,https://dsvt0yq4k5a5x.cloudfront.net/v1/master/3722c60a815c199d9c0ef36c5b73da68a62b09d1/cc-zkvjbxpwh4s5n/index.m3u8
WORLD FASHION,https://cdn.wfc.tv/cdn/stream-eng.m3u8
DELUXE MUSIC TV,https://sdn-global-live-streaming-packager-cache.3qsdn.com/13456/13456_264_live.m3u8
DUCK TV,https://dz4jacps8l0pw.cloudfront.net/v1/master/3722c60a815c199d9c0ef36c5b73da68a62b09d1/cc-h2eezuzejgrr2-ssai-prd/playlist.m3u8
SONIC TV,https://d36joy6bh8xxe2.cloudfront.net/v1/master/3722c60a815c199d9c0ef36c5b73da68a62b09d1/cc-ldaaeq2neq0kp/master.m3u8?useRelativeUrls=true&skipBeacons=true&declaredCC1Language=en
Hi-YAH!,https://linear-59.frequency.stream/dist/plex/59/hls/master/playlist.m3u8
Toon Goggles,https://stream-us-east-1.getpublica.com/playlist.m3u8?network_id=37
AfreecaTV Billiards,https://newidco-billiardstv-1-eu.xiaomi.wurl.tv/playlist.m3u8
Trace Sports,https://lightning-tracesport-samsungau.amagi.tv/playlist1080p.m3u8
Archive TV,https://stream.ads.ottera.tv/playlist.m3u8?network_id=74
Agro TV,https://agrotv.streamnet.ro/mobile_tv/agrotv.m3u8
Failarmy,https://d89ea9d7a37f40408057298b5ea93acc.mediatailor.us-east-1.amazonaws.com/v1/master/44f73ba4d03e9607dcd9bebdcb8494d86964f1d8/Samsung-in_FailArmy/playlist.m3u8
Fox weather,https://247wlive.foxweather.com/stream/index_1280x720.m3u8
KroneHit TV,https://bitcdn-kronehit.bitmovin.com/v2/hls/chunklist.m3u8
CGTN Documentary,https://english-livetx.cgtn.com/hls/yypdjlctzb_hd.m3u8
CGTN,https://english-livetx.cgtn.com/hls/yypdyyctzb_hd.m3u8
Smurf TV,https://stream.ads.ottera.tv/playlist.m3u8?network_id=6627
韩国KCTV,http://119.77.96.184:1935/chn21/chn21/chunklist_w252131137.m3u8
韩国阿里郎,http://amdlive.ctnd.com.edgesuite.net/arirang_1ch/smil:arirang_1ch.smil/playlist.m3u8
韩国BBS佛教广播,http://bbstv.clouducs.com:1935/bbstv-live/livestream/chunklist_w1403706733.m3u8
朝鲜中央台,http://119.77.96.184:1935/chn05/chn05/chunklist_w644291506.m3u8
Darcizzle,http://30a-tv.com/darcizzle.m3u8
Arirang,http://amdlive-ch01.ctnd.com.edgesuite.net:80/arirang_1ch/smil:arirang_1ch.smil/chunklist_b2256000_sleng.m3u8
CJ onstyle,https://live-ch1.cjonstyle.net/cjmalllive/stream2/playlist.m3u8
CJ onstyle plus,https://live-ch2.cjonstyle.net/cjosplus/live2/playlist.m3u8
EBS1,http://ebsonairios.ebs.co.kr/groundwavetablet500k/tablet500k/playlist.m3u8?zshijd
EBS Kids,http://ebsonairios.ebs.co.kr/ebsutablet500k/_definst_/tablet500k/chunklist_w1965791004.m3u8?zshijd
GS Shop,https://gstv-gsshop.gsshop.com/gsshop_hd/gsshop_hd.stream/playlist.m3u8
KBS Kids,http://mytv.dothome.co.kr/ch/catv/6.php
KBS LIFE,http://mytv.dothome.co.kr/ch/catv/5.php
ONE,http://test.oxxxo.ggff.net/stream/one/playlist.m3u8
Hoy76,https://hoytv-live-stream.hoy.tv/ch76/va2-index.m3u8
Hoy76,https://hoytv-live-stream.hoy.tv/ch76/index-fhd.m3u8
Sky Sport F1,https://32tech0steam0dp01.org/live/UK_SkySportF1FHD/chunks.m3u8



21 Jump Street,https://jmp2.uk/stvp-USBB320000397
ALL ACTION,https://jmp2.uk/stvp-USBB2300001QP
ALLBLK Gems,https://jmp2.uk/stvp-USBD300022FH
Baywatch,https://jmp2.uk/stvp-USBA2000001BR
BBC Drama,https://jmp2.uk/stvp-US3700005GP
BET Pluto TV,https://jmp2.uk/stvp-USBC450000130
Bounce XL,https://jmp2.uk/stvp-USBD300008G1
Brat TV,https://jmp2.uk/stvp-USBC240001823
BYUtv,https://jmp2.uk/stvp-US410000230
Dawson's Creek,https://jmp2.uk/stvp-US4100005NW
Degrassi,https://jmp2.uk/stvp-USBD700010XU
Dove Channel,https://jmp2.uk/stvp-USBD700016JY
Drama Life,https://jmp2.uk/stvp-USAJ26000015Y
Ebony TV by Lionsgate,https://jmp2.uk/stvp-USBD2500012DH
ElectricNOW,https://jmp2.uk/stvp-USBC6000225M
Family Hour TV,https://jmp2.uk/stvp-US4100024YU
Heartland,https://jmp2.uk/stvp-USBB2900003O3
Highway to Heaven,https://jmp2.uk/stvp-USBB19000017U
ION,https://jmp2.uk/stvp-USBD300002TU
ION Plus,https://jmp2.uk/stvp-USBD300003LK
K-Stories by CJ ENM,https://jmp2.uk/stvp-USBB2900001P9
MHz Mysteries,https://jmp2.uk/stvp-USAJ22000130U
Samsung Television Network,https://jmp2.uk/stvp-US300068X7
Shades of Black,https://jmp2.uk/stvp-USBC1000004G8
Stories by AMC,https://jmp2.uk/stvp-USBD2500018X6
TV Land Drama,https://jmp2.uk/stvp-USBB3500002FL
4UV,https://jmp2.uk/stvp-USBD70000412
Backstage,https://jmp2.uk/stvp-USBC10000129R
Biography: The Icons,https://jmp2.uk/stvp-US26000201N
Cheddar News,https://jmp2.uk/stvp-USAJ3504714A
Divorce Court,https://jmp2.uk/stvp-USBD300006A6
Documentary+,https://jmp2.uk/stvp-USAJ3504701A
Dr Phil's MeritTV,https://jmp2.uk/stvp-US70001475
ET,https://jmp2.uk/stvp-USBA3700002JF
FOX SOUL,https://jmp2.uk/stvp-USBA300032J7
Hollywire,https://jmp2.uk/stvp-USBC2400015DO
In Depth with Graham Bensinger,https://jmp2.uk/stvp-US2600024EO
Nosey,https://jmp2.uk/stvp-USAJ34000022E
OUTtv Proud,https://jmp2.uk/stvp-US8000024G
Revry,https://jmp2.uk/stvp-USBA3800003VP
The Bob Ross Channel,https://jmp2.uk/stvp-USBD700012OA
TMZ,https://jmp2.uk/stvp-USBD70000213
TODAY All Day,https://jmp2.uk/stvp-USBB32000251N
USA Today,https://jmp2.uk/stvp-USBB1500001GD
VICE,https://jmp2.uk/stvp-USBB1900006NY
WWE Superstar Central,https://jmp2.uk/stvp-US700005ID
60 Days In by A&E,https://jmp2.uk/stvp-USBD42000073E
ABC 20/20,https://jmp2.uk/stvp-US4800001W5
American Crimes,https://jmp2.uk/stvp-USBD42000250Q
BritBox Mysteries,https://jmp2.uk/stvp-US3700007E4
Cold Case Files,https://jmp2.uk/stvp-USBC390002256
Court TV,https://jmp2.uk/stvp-USBA34000049Z
Crime 24/7,https://jmp2.uk/stvp-USAK3508703A
Crime ThrillHer,https://jmp2.uk/stvp-USBB52000236D
Crime Zone,https://jmp2.uk/stvp-USBB36000040M
Crimes Cults Killers,https://jmp2.uk/stvp-USBB5200022PY
Dateline 24/7,https://jmp2.uk/stvp-USBB5200007BY
Dr. G: Medical Examiner,https://jmp2.uk/stvp-USBB3200004X3
Forensic Files,https://jmp2.uk/stvp-USBB3200017MY
I Survived ,https://jmp2.uk/stvp-USBD1700008H9
ION Mystery,https://jmp2.uk/stvp-USBC24000223S
Law & Crime,https://jmp2.uk/stvp-USAK3508710A
Live PD Presents,https://jmp2.uk/stvp-US160000159
Midsomer Murders,https://jmp2.uk/stvp-USBC24000134A
Murder, She Wrote,https://jmp2.uk/stvp-US1800001D1
Oxygen True Crimes Archive,https://jmp2.uk/stvp-US1900005VB
REELZ Famous & Infamous,https://jmp2.uk/stvp-USBB3200001MG
The First 48,https://jmp2.uk/stvp-US3300011V9
The New Detectives,https://jmp2.uk/stvp-USAJ3504547A
TruBlu,https://jmp2.uk/stvp-US37000036P
Unsolved Mysteries,https://jmp2.uk/stvp-USBB3200018Q6
Witness to Justice,https://jmp2.uk/stvp-US700010XK
World s Most Evil Killers,https://jmp2.uk/stvp-USBC1000002NP
ABC News Live,https://jmp2.uk/stvp-USBC39000171G
BBC News,https://jmp2.uk/stvp-US4000033L
Bloomberg Originals,https://jmp2.uk/stvp-USAJ30000041W
Bloomberg TV+,https://jmp2.uk/stvp-USAJ3400011A8
CBC News,https://jmp2.uk/stvp-USBC4400003OU
CBS News 24/7,https://jmp2.uk/stvp-USBA370000104
CBS News Texas,https://jmp2.uk/stvp-USBD17000129L
Fox 4 Dallas - Fort Worth,https://jmp2.uk/stvp-USBD1200013ET
FOX Weather,https://jmp2.uk/stvp-USBD700003L7
LiveNOW from FOX,https://jmp2.uk/stvp-USBA300024TN
NBC Dallas Fort Worth News,https://jmp2.uk/stvp-USBC15000058Z
NBC News NOW,https://jmp2.uk/stvp-USBB2200014DK
NEWSMAX2,https://jmp2.uk/stvp-USBA300028QU
Real America's Voice,https://jmp2.uk/stvp-USBB1900002KF
Salem News Channel,https://jmp2.uk/stvp-US3700004Y0
Scripps News,https://jmp2.uk/stvp-USBD3000073N
Sky News,https://jmp2.uk/stvp-USBB52000022Q
The First,https://jmp2.uk/stvp-US1000016Q
The Hill,https://jmp2.uk/stvp-US3300008FX
TYT Network,https://jmp2.uk/stvp-USBA30002142
WFAA,https://jmp2.uk/stvp-USBD3500046GS
WN Dallas/Ft Worth,https://jmp2.uk/stvp-USBC1500014UR
Yahoo Finance,https://jmp2.uk/stvp-USAJ4300005PJ
ACC Digital Network,https://jmp2.uk/stvp-USBD25000161U
beIN SPORTS XTRA,https://jmp2.uk/stvp-USAJ4300001Q7
Big 12 Studios,https://jmp2.uk/stvp-US37000017A
Billiard TV,https://jmp2.uk/stvp-USBD12000183X
CBS Sports HQ,https://jmp2.uk/stvp-USBB4800005VO
Combate Global MMA,https://jmp2.uk/stvp-US4600006R8
DP World Tour,https://jmp2.uk/stvp-US4600010KE
DraftKings Network,https://jmp2.uk/stvp-USBD700013BW
ESPN8: The Ocho,https://jmp2.uk/stvp-US34000040T
FanDuel TV Extra,https://jmp2.uk/stvp-US1400012RF
FIFA+,https://jmp2.uk/stvp-USBD12000255B
FOX Sports,https://jmp2.uk/stvp-US2700001QY
fubo Sports Network,https://jmp2.uk/stvp-USAJ2200023Z0
Game & Fish TV,https://jmp2.uk/stvp-US4400001PL
GOLFPASS,https://jmp2.uk/stvp-USBB400000145
MeatEater,https://jmp2.uk/stvp-US21000043S
MLB Channel,https://jmp2.uk/stvp-US1400001WV
MSG SportsZone,https://jmp2.uk/stvp-USBD300021B8
NBC Sports NOW,https://jmp2.uk/stvp-USBD420002446
NESN Nation,https://jmp2.uk/stvp-US300062TG
NFL Channel,https://jmp2.uk/stvp-US2600007WJ
NFL Preseason All Access,https://jmp2.uk/stvp-US2600008FU
One Championship TV,https://jmp2.uk/stvp-US2600006VY
Outdoor America,https://jmp2.uk/stvp-USBD1200020Y4
Outside TV,https://jmp2.uk/stvp-USAJ3504707A
Pac-12 Insider,https://jmp2.uk/stvp-USBA300034DB
PFL,https://jmp2.uk/stvp-US350000231
PGA Tour,https://jmp2.uk/stvp-US400001M2
PickleballTV,https://jmp2.uk/stvp-USBD4200016QR
Pursuit UP,https://jmp2.uk/stvp-USBD17000025J
Roku Sports Channel,https://jmp2.uk/stvp-US4500005Z1
RugbyPass TV,https://jmp2.uk/stvp-US1000004YJ
Samsung Showcase,https://jmp2.uk/stvp-US4700001B4
SportsGrid,https://jmp2.uk/stvp-USBA300031OT
Stadium,https://jmp2.uk/stvp-USAJ3504705A
SURF NOW TV,https://jmp2.uk/stvp-USBB10000058A
T2,https://jmp2.uk/stvp-USBC600001QL
The Jim Rome Show,https://jmp2.uk/stvp-US2900014UU
TNA Wrestling,https://jmp2.uk/stvp-USBB1000001XP
UFC,https://jmp2.uk/stvp-US2900017P2
Unbeaten Sports Channel,https://jmp2.uk/stvp-US1400008DW
Waypoint TV,https://jmp2.uk/stvp-USBB440002055
Women's Sports Network,https://jmp2.uk/stvp-US4100001KP
World Poker Tour,https://jmp2.uk/stvp-USBD1700009P5
ALF,https://jmp2.uk/stvp-US4100023FK
Always Funny Videos,https://jmp2.uk/stvp-USBA1600001XM
Animation+,https://jmp2.uk/stvp-US400002PS
BBC Comedy,https://jmp2.uk/stvp-US4500009VV
Comedy Dynamics,https://jmp2.uk/stvp-USBD7000145C
Conan O'Brien TV,https://jmp2.uk/stvp-USBD120001614
Dry Bar Comedy,https://jmp2.uk/stvp-USAJ30000039U
FailArmy,https://jmp2.uk/stvp-USAJ3504702A
Family Ties,https://jmp2.uk/stvp-USBB3500003D6
GET Comedy,https://jmp2.uk/stvp-US350000563
Hot Ones,https://jmp2.uk/stvp-US2900006IV
Just for Laughs GAGS,https://jmp2.uk/stvp-USBC4400004KK
Laff More,https://jmp2.uk/stvp-US3700002P0
Letterman TV,https://jmp2.uk/stvp-US4000004N1
LOL! Network,https://jmp2.uk/stvp-USBC1300009VM
MrBeast,https://jmp2.uk/stvp-US310000101
Mystery Science Theater 3000,https://jmp2.uk/stvp-US4500004SQ
Mythical 24/7,https://jmp2.uk/stvp-US2900008FP
National Lampoon,https://jmp2.uk/stvp-US1800015K5
Portlandia,https://jmp2.uk/stvp-USBD12000038K
RiffTrax,https://jmp2.uk/stvp-USAJ3504706A
Saved by the Bell,https://jmp2.uk/stvp-US18000096O
SNL Vault,https://jmp2.uk/stvp-US1800012MT
TV Land Sitcoms,https://jmp2.uk/stvp-USBA300019WF
Who's The Boss?,https://jmp2.uk/stvp-US4100003MA
Alfred Hitchcock Presents,https://jmp2.uk/stvp-US1800014CG
Alien Nation by DUST,https://jmp2.uk/stvp-USBC100000630
Ancient Aliens,https://jmp2.uk/stvp-US3300010F5
FARSCAPE,https://jmp2.uk/stvp-US4100022W9
Fear Zone,https://jmp2.uk/stvp-USBC1300012VK
Haunt TV,https://jmp2.uk/stvp-USBC4400006BR
Horror by ALTER,https://jmp2.uk/stvp-USBC100001175
Midnight Pulp,https://jmp2.uk/stvp-USBD700015LK
Mysteries Xplored,https://jmp2.uk/stvp-USBB5200028MM
OuterSphere,https://jmp2.uk/stvp-USBD1200007FE
The Asylum,https://jmp2.uk/stvp-USAJ17000014C
The Curse of Oak Island,https://jmp2.uk/stvp-US300002BE
The UnXplained with William Shatner,https://jmp2.uk/stvp-US700011JL
The Walking Dead Universe,https://jmp2.uk/stvp-USBD1200004NS
Unidentified,https://jmp2.uk/stvp-USBB10000047W
Universal Monsters,https://jmp2.uk/stvp-US1900002QK
All Babies Channel,https://jmp2.uk/stvp-USBD3300019OU
Baby Einstein,https://jmp2.uk/stvp-USBD350002338
Barbie and Friends,https://jmp2.uk/stvp-USBD490000209
Barney and Friends,https://jmp2.uk/stvp-US300001UO
batteryPOP,https://jmp2.uk/stvp-USBD3300012VX
BBC Kids,https://jmp2.uk/stvp-US800003JM
Blippi,https://jmp2.uk/stvp-US9000032J
Bob the Builder,https://jmp2.uk/stvp-USBC4400013R7
Caillou,https://jmp2.uk/stvp-USBD50000048H
ducktv,https://jmp2.uk/stvp-US3400003HI
Fireman Sam,https://jmp2.uk/stvp-USBD42000124T
HappyKids,https://jmp2.uk/stvp-USBC44000072I
Hot Wheels Action,https://jmp2.uk/stvp-US2900013AY
Kartoon Channel!,https://jmp2.uk/stvp-US2900015RO
Kidoodle.TV,https://jmp2.uk/stvp-USAK3508716A
Mattel Jr.,https://jmp2.uk/stvp-US4500002UB
Moonbug,https://jmp2.uk/stvp-USBB11000015Q
My Little Pony,https://jmp2.uk/stvp-US2900011CJ
Nick Pluto TV,https://jmp2.uk/stvp-USBA3000158L
Ninja Kidz,https://jmp2.uk/stvp-US2200007QG
PBS Kids,https://jmp2.uk/stvp-USBC3600013PC
pocket.watch Game-On,https://jmp2.uk/stvp-USBD12000153A
Pok mon,https://jmp2.uk/stvp-US5100003NU
Power Rangers,https://jmp2.uk/stvp-US2900012T8
Rainbow Ruby,https://jmp2.uk/stvp-USBD3300015BY
Rev and Roll,https://jmp2.uk/stvp-USBD3300016AK
Ryan and Friends,https://jmp2.uk/stvp-USBD12000239N
Sensical Jr,https://jmp2.uk/stvp-USBD3300013KV
Sensical Makers,https://jmp2.uk/stvp-USBD3300017XB
Shaun the Sheep,https://jmp2.uk/stvp-US2200006FS
Slugterra,https://jmp2.uk/stvp-USBD33000180S
Sonic The Hedgehog,https://jmp2.uk/stvp-USBD3300020PM
Strawberry Shortcake,https://jmp2.uk/stvp-USBC4400012QS
Teletubbies,https://jmp2.uk/stvp-USBD3500015R5
TG Junior,https://jmp2.uk/stvp-USBB3600001R6
The LEGO Channel,https://jmp2.uk/stvp-USBA2300001S8
Toon Goggles,https://jmp2.uk/stvp-USBB1900004J9
Transformers,https://jmp2.uk/stvp-US29000168D
Yu-Gi-Oh,https://jmp2.uk/stvp-US1000003G8
ZooMoo,https://jmp2.uk/stvp-USBC2400019EF
All Reality We TV,https://jmp2.uk/stvp-USBD12000061R
All Weddings We TV,https://jmp2.uk/stvp-USBD1200005XR
All-Out Reality,https://jmp2.uk/stvp-USBB4400016F9
Bad Girls Club,https://jmp2.uk/stvp-US1800008PZ
Bondi Rescue,https://jmp2.uk/stvp-US2900010UT
Bravo Vault,https://jmp2.uk/stvp-US1800003BG
Bring It!,https://jmp2.uk/stvp-USBD17000040J
Caught on Tape,https://jmp2.uk/stvp-US700007CV
Cheaters,https://jmp2.uk/stvp-USBD3500031F3
Dance Moms,https://jmp2.uk/stvp-USBC3900021HS
DangerTV,https://jmp2.uk/stvp-USAJ3504708A
Dog the Bounty Hunter,https://jmp2.uk/stvp-US900002IH
Duck Dynasty,https://jmp2.uk/stvp-USBC4400002GF
E! Keeping Up,https://jmp2.uk/stvp-US18000133I
Hoarders by A&E,https://jmp2.uk/stvp-USBD4200009Y4
INFAST,https://jmp2.uk/stvp-USBA300022JX
Intervention by A&E,https://jmp2.uk/stvp-USBD3500040WX
Kitchen Nightmares,https://jmp2.uk/stvp-USBA3000042O6
Little Women: LA,https://jmp2.uk/stvp-USBD170000771
Love & Hip Hop,https://jmp2.uk/stvp-USBA300020WC
Matched Married Meet,https://jmp2.uk/stvp-USBC440000193
Mountain Men,https://jmp2.uk/stvp-USBD17000051M
MTV Pluto TV,https://jmp2.uk/stvp-USBA3000093U
Operation Repo,https://jmp2.uk/stvp-USBC6000219D
Perform,https://jmp2.uk/stvp-USBB520002604
Real Housewives Vault,https://jmp2.uk/stvp-US18000059V
RIG TV,https://jmp2.uk/stvp-US4500001DM
Road Renegades,https://jmp2.uk/stvp-US700002ZB
Swamp People,https://jmp2.uk/stvp-USBD2700013UK
Alone By History,https://jmp2.uk/stvp-USBD27000156I
American Ninja Warrior,https://jmp2.uk/stvp-US19000017A
American Pickers by History,https://jmp2.uk/stvp-USBD3500041ZF
Ax Men,https://jmp2.uk/stvp-USBB5200020Z0
Dallas Cowboys Cheer,https://jmp2.uk/stvp-USBA300004TE
Deal Zone,https://jmp2.uk/stvp-USBB52000246M
Fear Factor,https://jmp2.uk/stvp-USBB2300002Q6
Forged In Fire,https://jmp2.uk/stvp-USBD2700014QW
Hell's Kitchen,https://jmp2.uk/stvp-USBB2900002Z7
Ice Road Truckers,https://jmp2.uk/stvp-USBB520002173
Pawn Stars,https://jmp2.uk/stvp-US300003S3
Pluto TV Pixel World,https://jmp2.uk/stvp-USAJ3504531A
Project Runway,https://jmp2.uk/stvp-USBB3500004RC
Storage Wars: LA,https://jmp2.uk/stvp-USBD1700006T2
The Challenge,https://jmp2.uk/stvp-USBB3500001O6
Top Chef Vault,https://jmp2.uk/stvp-US180001143
Wipeout Xtra,https://jmp2.uk/stvp-USBB4400018LR
Xtreme Outdoor Presented by HISTORY,https://jmp2.uk/stvp-USAK3508706A
AMC en Espa ol,https://jmp2.uk/stvp-USBD7000017L
Angelique,https://jmp2.uk/stvp-US2200004HD
Aqu  y Ahora,https://jmp2.uk/stvp-USBD1700015J1
beIN Sports XTRA  ,https://jmp2.uk/stvp-US2700004DX
Canal ViX,https://jmp2.uk/stvp-US2200005Y2
Canela.TV,https://jmp2.uk/stvp-USBC39000080S
Caso Cerrado,https://jmp2.uk/stvp-US1800004S5
CG MMA En Espa ol,https://jmp2.uk/stvp-US4600005ST
Cine de Oro,https://jmp2.uk/stvp-USBD2700005KL
Cine Retro,https://jmp2.uk/stvp-USBD2500022U5
Cine Romantico,https://jmp2.uk/stvp-USBA3800001E0
Como Dice el Dicho,https://jmp2.uk/stvp-USBD2700004ME
Curiosity Animales,https://jmp2.uk/stvp-US2200001IY
Curiosity Explora,https://jmp2.uk/stvp-US22000020U
Curiosity Motores,https://jmp2.uk/stvp-US2200003ZN
Estrella Games,https://jmp2.uk/stvp-USBC24000145I
Estrella News,https://jmp2.uk/stvp-USAJ2200020N4
Estrella TV,https://jmp2.uk/stvp-USBA300040WR
FreeTV Estelar,https://jmp2.uk/stvp-USAJ1700009QJ
Galanes,https://jmp2.uk/stvp-USBD2700002DU
Hallmark en Espa ol,https://jmp2.uk/stvp-US1300001GM
Historia,https://jmp2.uk/stvp-US2600019IC
Las 3 Mar as,https://jmp2.uk/stvp-USBD17000172A
Noticias Telemundo Ahora,https://jmp2.uk/stvp-US3000005RS
Noticias Univision 24/7,https://jmp2.uk/stvp-USBD1700014QU
Novelas Turcas,https://jmp2.uk/stvp-US27000033D
Pequenos Gigantes,https://jmp2.uk/stvp-USBD2700003F3
Rebelde,https://jmp2.uk/stvp-USBD1700018II
Sony One Competencias,https://jmp2.uk/stvp-USAJ3504719A
Sony One Novelas,https://jmp2.uk/stvp-USAJ3000002OC
Telemundo Accion,https://jmp2.uk/stvp-US1800002UQ
Telemundo Al D a,https://jmp2.uk/stvp-USBB3200016HO
Telemundo Texas,https://jmp2.uk/stvp-USBC4400018D0
ViX Grandes Parejas,https://jmp2.uk/stvp-USBC2100012EJ
ViX JaJaJa,https://jmp2.uk/stvp-USBC2100010OS
ViX Novelas de romance,https://jmp2.uk/stvp-USBB44000099N
ViX Villanos de Novela,https://jmp2.uk/stvp-USBC2100011WI
WAPA+,https://jmp2.uk/stvp-US41000060J
Zona TUDN,https://jmp2.uk/stvp-USBD1700016X9
 Qu  Culpa Tiene Fatmag l?,https://jmp2.uk/stvp-US270000298
America's Test Kitchen,https://jmp2.uk/stvp-USBA3800002KI
Antiques Roadshow,https://jmp2.uk/stvp-USBC600018CF
At Home with Family Handyman,https://jmp2.uk/stvp-USBD25000138Y
BBC Food,https://jmp2.uk/stvp-USBC6000108Z
BBC Home & Garden,https://jmp2.uk/stvp-USBC600017FG
Bon App tit,https://jmp2.uk/stvp-USBC44000226R
Emeril Lagasse Channel,https://jmp2.uk/stvp-US4500010B0
Flipping Nation by A&E,https://jmp2.uk/stvp-USBD4200008RS
Gusto TV,https://jmp2.uk/stvp-USAK3508724A
Home Refresh,https://jmp2.uk/stvp-USBC21000142T
Home.Made.Nation,https://jmp2.uk/stvp-USAJ3000006X5
Homeful,https://jmp2.uk/stvp-USBD700022M5
Hungry,https://jmp2.uk/stvp-USAJ2200009C2
Jamie Oliver,https://jmp2.uk/stvp-USBC4400016CL
Journy,https://jmp2.uk/stvp-USBB1000003HL
Localish,https://jmp2.uk/stvp-USBC4400005HY
Million Dollar Dream Home,https://jmp2.uk/stvp-US300067FX
Million Dollar Listing Vault,https://jmp2.uk/stvp-USBB3200024V5
NBC LX Home,https://jmp2.uk/stvp-USBB40000028E
PBS Antiques Roadshow,https://jmp2.uk/stvp-USBD4200017GS
PBS Food,https://jmp2.uk/stvp-US13000081O
PBS Travel,https://jmp2.uk/stvp-US1300005MK
Plated,https://jmp2.uk/stvp-USBC1300008AZ
Tastemade,https://jmp2.uk/stvp-USBD7000189R
Tastemade Home,https://jmp2.uk/stvp-USBC3200022W6
Tastemade Travel,https://jmp2.uk/stvp-USBD700017WC
The Design Network,https://jmp2.uk/stvp-USBD1200022S1
The Martha Stewart Channel,https://jmp2.uk/stvp-US4500011SP
This Old House,https://jmp2.uk/stvp-USBC13000065U
This Old House Makers,https://jmp2.uk/stvp-USBC1300005T6
Tiny House Nation,https://jmp2.uk/stvp-USAJ3400020KC
Anime All day,https://jmp2.uk/stvp-USAJ3504502A
D&D Adventures,https://jmp2.uk/stvp-US3400005I4
FilmRise Anime,https://jmp2.uk/stvp-US3500004M7
It s Anime,https://jmp2.uk/stvp-US11000020V
Naruto,https://jmp2.uk/stvp-US2000014IC
RetroCrush,https://jmp2.uk/stvp-USBC36000073J
Sailor Moon,https://jmp2.uk/stvp-US2000015Z1
Team Liquid,https://jmp2.uk/stvp-US240000434
BBC Earth,https://jmp2.uk/stvp-USBD1700001RW
Clarity 4K,https://jmp2.uk/stvp-USBA3800005NI
Dinos 24/7,https://jmp2.uk/stvp-US3700006XE
Dog Whisperer,https://jmp2.uk/stvp-US3400001FX
History & Warfare Now,https://jmp2.uk/stvp-USBD1200009JI
History 365,https://jmp2.uk/stvp-USBD35000428O
InWonder,https://jmp2.uk/stvp-USBA300023G8
Love Nature 4K,https://jmp2.uk/stvp-USBA3400003IP
Love Pets,https://jmp2.uk/stvp-US300065DB
Lucky Dog,https://jmp2.uk/stvp-USBA3000044BJ
MagellanTV Wildest,https://jmp2.uk/stvp-USAJ340000677
Military Heroes,https://jmp2.uk/stvp-USBC39000204J
Modern Marvels Presented by History,https://jmp2.uk/stvp-USBB5200025DO
PBS Digital Studios,https://jmp2.uk/stvp-USBB800001O7
PBS Genealogy,https://jmp2.uk/stvp-US130000639
PBS Nature,https://jmp2.uk/stvp-US1300007KZ
Rovr Pets,https://jmp2.uk/stvp-USBC2400024FN
Samsung Wild Life,https://jmp2.uk/stvp-USBA3000043LH
TED,https://jmp2.uk/stvp-USBC2100013WI
The Jack Hanna Channel,https://jmp2.uk/stvp-USBC2100009GT
The Pet Collective,https://jmp2.uk/stvp-USAJ3504704A
Universe: Mysteries Solved,https://jmp2.uk/stvp-US900001CX
WeatherSpy,https://jmp2.uk/stvp-USAJ3400014LK
WildEarth,https://jmp2.uk/stvp-US3800007CR
Xplore,https://jmp2.uk/stvp-USBC2100008DP
Beach Bonfire Vibes,https://jmp2.uk/stvp-US14000119Q
Campfire Vibes,https://jmp2.uk/stvp-US1500002I2
Cozy Vibes,https://jmp2.uk/stvp-US2900005NW
Fireplace Vibes,https://jmp2.uk/stvp-USBA3800004EL
Island Vibes,https://jmp2.uk/stvp-US1400007V6
Loupe 4K,https://jmp2.uk/stvp-USBB1000002TK
Luxe Fireplace Vibes,https://jmp2.uk/stvp-US2900004L2
Ocean Vibes,https://jmp2.uk/stvp-US700012OU
Rainy Day Vibes,https://jmp2.uk/stvp-US14000030Y
Stingray Holidayscapes,https://jmp2.uk/stvp-USBD3500038R6
Stingray Naturescape,https://jmp2.uk/stvp-USAK3508705A
Stingray Spa,https://jmp2.uk/stvp-USBD3500013DG
Storm Vibes,https://jmp2.uk/stvp-US1400014N9
Summer Vibes,https://jmp2.uk/stvp-US1400010S0
ZenLIFE by Stingray,https://jmp2.uk/stvp-USBD3500027DS
BUZZR,https://jmp2.uk/stvp-USBD700021WG
Deal or No Deal,https://jmp2.uk/stvp-USBB4400017N3
Game Show Central,https://jmp2.uk/stvp-USAJ3400012FA
Supermarket Sweep,https://jmp2.uk/stvp-USBC44000087O
Wild 'N Out,https://jmp2.uk/stvp-USBA3000100X
Cars,https://jmp2.uk/stvp-USAJ3504545A
Formula 1 Channel,https://jmp2.uk/stvp-US600011Q2
Hagerty,https://jmp2.uk/stvp-USBD4200011W4
MotorTrend FAST TV,https://jmp2.uk/stvp-USBC3600005U9
NASCAR Channel,https://jmp2.uk/stvp-US700021SM
NHRA TV,https://jmp2.uk/stvp-USBC3200019WF
POWERNATION,https://jmp2.uk/stvp-USBD2500017XQ
RACER Select,https://jmp2.uk/stvp-USBD1700019RN
Top Gear,https://jmp2.uk/stvp-USBC2400027NG
Torque,https://jmp2.uk/stvp-USBB5200027Z5
CINEVAULT,https://jmp2.uk/stvp-USAJ30000148W
CINEVAULT: Classics,https://jmp2.uk/stvp-USBB3200015M8
Gravitas Movies,https://jmp2.uk/stvp-USBD700011RE
Hallmark Movies & More,https://jmp2.uk/stvp-USBD270001633
Lifetime Movies Love & Drama,https://jmp2.uk/stvp-US1600002OK
Maverick Black Cinema,https://jmp2.uk/stvp-USAJ3000007MT
Miramax Channel,https://jmp2.uk/stvp-US18000163F
Movie Favorites By Lifetime,https://jmp2.uk/stvp-USBB5200019FO
Movie Hub,https://jmp2.uk/stvp-USBA3000041ZP
Movie Hub Action,https://jmp2.uk/stvp-USBD3500032H0
Movie Hub Romance,https://jmp2.uk/stvp-USBD3500033U0
Movie Hub West,https://jmp2.uk/stvp-USBD3500036HP
MovieSphere,https://jmp2.uk/stvp-USBD17000117B
MyTime Movie Network,https://jmp2.uk/stvp-USBC3900018K6
NEW KMOVIES,https://jmp2.uk/stvp-USAJ30000122O
Paramount Movie Channel,https://jmp2.uk/stvp-USAJ26000054W
Pluto TV Fantastic,https://jmp2.uk/stvp-USBA300017PK
Universal Movies,https://jmp2.uk/stvp-USBB3200030CG
CINEVAULT: Westerns,https://jmp2.uk/stvp-USAK3508709A
Circle,https://jmp2.uk/stvp-USBA300035FV
Death Valley Days,https://jmp2.uk/stvp-US2900007HA
FilmRise Westerns,https://jmp2.uk/stvp-USBB32000196O
get TV,https://jmp2.uk/stvp-USBD1200002PM
Grit Xtra,https://jmp2.uk/stvp-USBC24000213P
Grjngo,https://jmp2.uk/stvp-US44000027B
Lassie,https://jmp2.uk/stvp-US1800010NE
Little House on the Prairie,https://jmp2.uk/stvp-US18000078A
Pluto TV Westerns,https://jmp2.uk/stvp-USBA300005MK
Shout! TV,https://jmp2.uk/stvp-USBD1200021JM
Western Bound,https://jmp2.uk/stvp-USBC3200020QF
Wild West TV,https://jmp2.uk/stvp-US4500003B0
Genie K-Drama,https://jmp2.uk/stvp-US2000012KX
Genie K-Movie,https://jmp2.uk/stvp-US200001137
K-POP by CJ ENM,https://jmp2.uk/stvp-US39000038W
NEW KPOP,https://jmp2.uk/stvp-USAJ3000013FJ
Qello Concerts by Stingray,https://jmp2.uk/stvp-USBD3500024YB
SMTOWN,https://jmp2.uk/stvp-US10000135V
Stingray Classic Rock,https://jmp2.uk/stvp-USBD35000180U
Stingray Classica,https://jmp2.uk/stvp-USBD350002623
Stingray Country Greats,https://jmp2.uk/stvp-US4700005EA
Stingray DJAZZ,https://jmp2.uk/stvp-USBD3500025GS
Stingray Easy Listening,https://jmp2.uk/stvp-USBD3500011J3
Stingray Euro Hits,https://jmp2.uk/stvp-US4700002UF
Stingray Flashback 70s,https://jmp2.uk/stvp-USBD3500008IJ
Stingray Greatest Hits,https://jmp2.uk/stvp-USBD3500022DN
Stingray Hip Hop,https://jmp2.uk/stvp-USBD3500010MT
Stingray Hot Country,https://jmp2.uk/stvp-USBD3300021KV
Stingray Jukebox Oldies,https://jmp2.uk/stvp-US4700006XL
Stingray Movie Music,https://jmp2.uk/stvp-US4700003DP
Stingray Nothin' But 90s,https://jmp2.uk/stvp-USBD35000149S
Stingray Remember the 80s,https://jmp2.uk/stvp-USBD3300022QK
Stingray Romance Latino,https://jmp2.uk/stvp-USBD3500017CE
Stingray Smooth Jazz,https://jmp2.uk/stvp-USBD35000128A
Stingray Soft Hits,https://jmp2.uk/stvp-US4700007GV
Stingray Today's K-Pop,https://jmp2.uk/stvp-USBD3500016NH
Stingray Today's Latin Pop,https://jmp2.uk/stvp-USBD3500009Y3
Vevo '70s,https://jmp2.uk/stvp-USBD300011KQ
Vevo '80s,https://jmp2.uk/stvp-USBD300012YC
Vevo '90s,https://jmp2.uk/stvp-USBD3000133M
Vevo 2010s,https://jmp2.uk/stvp-USBD120002431
Vevo 2K,https://jmp2.uk/stvp-USBB4400015F5
Vevo Country,https://jmp2.uk/stvp-USBC3600001RQ
Vevo Hip-Hop,https://jmp2.uk/stvp-USBC3600002EK
Vevo Latino,https://jmp2.uk/stvp-USBC3600015GF
Vevo Pop,https://jmp2.uk/stvp-USBC3600008WY
Vevo R&B,https://jmp2.uk/stvp-USBC3900009K5
Vevo Rock,https://jmp2.uk/stvp-USBD3000145P
XITE 80s Flashback,https://jmp2.uk/stvp-USBB320000647
XITE 90s Throwback,https://jmp2.uk/stvp-USBB3200007AK
XITE Celebrates,https://jmp2.uk/stvp-USBD350003932
XITE Christian Hits,https://jmp2.uk/stvp-US46000072L
XITE Classic Country,https://jmp2.uk/stvp-USBD3300011UT
XITE Country Today,https://jmp2.uk/stvp-USBD3300006O3
XITE Hits,https://jmp2.uk/stvp-USBD3300004RH
XITE Just Chill,https://jmp2.uk/stvp-USBB2300003JZ
XITE Nuevo Latino,https://jmp2.uk/stvp-USBD3300007PB
XITE R&B Classic Jams,https://jmp2.uk/stvp-USBD330000948
XITE Reggae Vibes,https://jmp2.uk/stvp-US4600008JA
XITE Rock x Metal,https://jmp2.uk/stvp-USBB2300004KV
XITE Siempre Latino,https://jmp2.uk/stvp-USBD3300010L9

等待测试,#genre#

翡翠台,http://r.jdshipin.com/qClQf
翡翠台,http://r.jdshipin.com/qrfbg
翡翠台,http://r.jdshipin.com/62WM7
翡翠台,http://r.jdshipin.com/n90gt
翡翠台,http://r.jdshipin.com/GeWKr
明珠台,http://r.jdshipin.com/ZQ4kN
明珠台,http://r.jdshipin.com/jUx8K
TVB Plus,http://r.jdshipin.com/Nr5jq
TVB Plus,http://r.jdshipin.com/ndGgS
无线新闻,http://r.jdshipin.com/CkuBd
TVB星河,http://r.jdshipin.com/sXuuD
TVB星河,http://r.jdshipin.com/Voac4
华丽翡翠台,http://r.jdshipin.com/thuYX
ViuTV,http://r.jdshipin.com/vSJvl
ViuTV,http://r.jdshipin.com/TcKr2
HOY TV,http://r.jdshipin.com/sFw4S
凤凰中文,http://r.jdshipin.com/cCCzW
凤凰资讯,http://r.jdshipin.com/0Rp07
凤凰香港,http://r.jdshipin.com/yDoTN
凤凰香港,http://r.jdshipin.com/NfC0f
澳视澳门,http://r.jdshipin.com/n2YZI
澳视卫星,http://r.jdshipin.com/QFhCq
广东珠江,http://r.jdshipin.com/sE5vO
广东体育,http://r.jdshipin.com/LiYdg
广州综合,http://r.jdshipin.com/iR6Gq
广州南国都市,http://r.jdshipin.com/nWaZO
广州综合,http://r.jdshipin.com/snhya
海峡卫视,http://r.jdshipin.com/WtYt3
咪咕视频4K,http://r.jdshipin.com/ln4xk
咪咕视频4K-2,http://r.jdshipin.com/Lqdwf

https://php.946985.filegear-sg.me/jacktv.txt
翡翠台,https://hls-pull-wicketpw.speedws.com/live/IcmEedSDSFSFDF354621166.flv
明珠台,https://hls-pull-wicketpw.speedws.com/live/IcmEedSDSFSFDF354621167.flv
无线新闻,https://hls-pull-wicketpw.speedws.com/live/IcmEedSDSFSFDF354621168.flv
TVBPUS,https://hls-pull-wicketpw.speedws.com/live/IcmEedSDSFSFDF354621169.flv
戲曲台,https://hls-pull-wicketpw.speedws.com/live/IcmEedSDSFSFDF354621170.flv
CCTV13,https://hls-pull-wicketpw.speedws.com/live/IcmEedSDSFSFDF354621175.flv
五星体育,https://hls-pull-wicketpw.speedws.com/live/IcmEedSDSFSFDF354621178.flv
深圳卫视4K,https://hls-pull-wicketpw.speedws.com/live/IcmEedSDSFSFDF354621179.flv
深圳财经生活,https://hls-pull-wicketpw.speedws.com/live/IcmEedSDSFSFDF354621180.flv
第一财经,https://hls-pull-wicketpw.speedws.com/live/IcmEedSDSFSFDF354621181.flv
重温经典,https://hls-pull-wicketpw.speedws.com/live/IcmEedSDSFSFDF354621182.flv
龙华电影,https://hls-pull-wicketpw.speedws.com/live/IcmEedSDSFSFDF354621183.flv
龙华经典,https://hls-pull-wicketpw.speedws.com/live/IcmEedSDSFSFDF354621184.flv
龙华卡通,https://hls-pull-wicketpw.speedws.com/live/IcmEedSDSFSFDF354621185.flv
龙华偶像,https://hls-pull-wicketpw.speedws.com/live/IcmEedSDSFSFDF354621186.flv
龙华日韩,https://hls-pull-wicketpw.speedws.com/live/IcmEedSDSFSFDF354621187.flv
龙华戏剧,https://hls-pull-wicketpw.speedws.com/live/IcmEedSDSFSFDF354621188.flv
龙华洋片,https://hls-pull-wicketpw.speedws.com/live/IcmEedSDSFSFDF354621189.flv
TVB1,https://hls-pull-wicketpw.speedws.com/live/IcmEedSDSFSFDF354621190.flv
TVBJ1,https://hls-pull-wicketpw.speedws.com/live/IcmEedSDSFSFDF354621191.flv
TVB亚洲武侠,https://hls-pull-wicketpw.speedws.com/live/IcmEedSDSFSFDF354621192.flv
TVB娱乐新闻台,https://hls-pull-wicketpw.speedws.com/live/IcmEedSDSFSFDF354621193.flv
TVB华丽翡翠台,https://hls-pull-wicketpw.speedws.com/live/IcmEedSDSFSFDF354621194.flv
TVB星河,https://hls-pull-wicketpw.speedws.com/live/IcmEedSDSFSFDF354621195.flv
TVB星河,https://hls-pull-wicketpw.speedws.com/live/IcmEedSDSFSFDF354621196.flv
翡翠剧集台,https://hls-pull-wicketpw.speedws.com/live/IcmEedSDSFSFDF354621197.flv
天映马来西亚,https://hls-pull-wicketpw.speedws.com/live/IcmEedSDSFSFDF354621200.flv
天映经典频道,https://hls-pull-wicketpw.speedws.com/live/IcmEedSDSFSFDF354621201.flv
爱奇艺,https://hls-pull-wicketpw.speedws.com/live/IcmEedSDSFSFDF354621202.flv
八度空间,https://hls-pull-wicketpw.speedws.com/live/IcmEedSDSFSFDF354621203.flv
CH5,https://hls-pull-wicketpw.speedws.com/live/IcmEedSDSFSFDF354621204.flv
CH8,https://hls-pull-wicketpw.speedws.com/live/IcmEedSDSFSFDF354621205.flv
CHU,https://hls-pull-wicketpw.speedws.com/live/IcmEedSDSFSFDF354621206.flv
Astro欢喜台,https://hls-pull-wicketpw.speedws.com/live/IcmEedSDSFSFDF354621207.flv
Astro AOD,https://hls-pull-wicketpw.speedws.com/live/IcmEedSDSFSFDF354621208.flv
Astro AEC,https://hls-pull-wicketpw.speedws.com/live/IcmEedSDSFSFDF354621209.flv
Astro QJ,https://hls-pull-wicketpw.speedws.com/live/IcmEedSDSFSFDF354621210.flv

邵氏动作,http://38.75.136.137:98/gslb/dsdqpub/lbssdz.m3u8?auth=testpub
邵氏喜剧,http://38.75.136.137:98/gslb/dsdqpub/lbssxj.m3u8?auth=testpub
邵氏电影,http://38.75.136.137:98/gslb/dsdqpub/lbssdy.m3u8?auth=testpub
邵氏武侠,http://38.75.136.137:98/gslb/dsdqpub/lbsswx.m3u8?auth=testpub
经典电影重温,https://yylunbo.ottiptv.cc/yy/1382793140
星光怀旧台,http://data.3g.yy.com/live/hls/1354936134/1354936134.m3u8
星光世界台,http://data.3g.yy.com/live/hls/1353422557/1353422557.m3u8
经典影视台,http://huanqiuzhibo.cn/manifest/douyu.php?id=6091425
经典剧场,http://huanqiuzhibo.cn/manifest/douyu.php?id=4246519

無線新聞台,http://mypanel-4k.com:80/me52pjdqa6/dt2t9r16ja/283852 
鳳凰HD,http://mypanel-4k.com:80/me52pjdqa6/dt2t9r16ja/283854 
長城精品,http://mypanel-4k.com:80/me52pjdqa6/dt2t9r16ja/283855 
大灣區衛視,http://mypanel-4k.com:80/me52pjdqa6/dt2t9r16ja/283856 
安徽國際,http://mypanel-4k.com:80/me52pjdqa6/dt2t9r16ja/283858 
TVBe,http://mypanel-4k.com:80/me52pjdqa6/dt2t9r16ja/283859 
海峽衛視,http://mypanel-4k.com:80/me52pjdqa6/dt2t9r16ja/283866 
娛樂新聞台,http://mypanel-4k.com:80/me52pjdqa6/dt2t9r16ja/283867 
鳳凰美洲台,http://mypanel-4k.com:80/me52pjdqa6/dt2t9r16ja/283869 
東方衛視,http://mypanel-4k.com:80/me52pjdqa6/dt2t9r16ja/283871 
江蘇國際,http://mypanel-4k.com:80/me52pjdqa6/dt2t9r16ja/283873 
Tvbs亞洲台,http://mypanel-4k.com:80/me52pjdqa6/dt2t9r16ja/283874 
民視,http://mypanel-4k.com:80/me52pjdqa6/dt2t9r16ja/283888 
三立國際台,http://mypanel-4k.com:80/me52pjdqa6/dt2t9r16ja/283889 
華視新聞台,http://mypanel-4k.com:80/me52pjdqa6/dt2t9r16ja/283890 
台視綜合台,http://mypanel-4k.com:80/me52pjdqa6/dt2t9r16ja/283891 
東森中國台,http://mypanel-4k.com:80/me52pjdqa6/dt2t9r16ja/283892 
東森衛視台,http://mypanel-4k.com:80/me52pjdqa6/dt2t9r16ja/283893 
東森戲劇台,http://mypanel-4k.com:80/me52pjdqa6/dt2t9r16ja/283894 
東森財經台,http://mypanel-4k.com:80/me52pjdqa6/dt2t9r16ja/283895 
東森美洲台,http://mypanel-4k.com:80/me52pjdqa6/dt2t9r16ja/283896 
台視新聞台,http://mypanel-4k.com:80/me52pjdqa6/dt2t9r16ja/283897 
天下衛視台,http://mypanel-4k.com:80/me52pjdqa6/dt2t9r16ja/283898 
新鮮戲劇台,http://mypanel-4k.com:80/me52pjdqa6/dt2t9r16ja/283899 
東森幼幼台,http://mypanel-4k.com:80/me52pjdqa6/dt2t9r16ja/283902 
TVB1,http://mypanel-4k.com:80/me52pjdqa6/dt2t9r16ja/482512 
TVB戲劇,http://mypanel-4k.com:80/me52pjdqa6/dt2t9r16ja/482513 
TVBe,http://mypanel-4k.com:80/me52pjdqa6/dt2t9r16ja/482514 
CCTV4,http://mypanel-4k.com:80/me52pjdqa6/dt2t9r16ja/482527 
蕭山綜合,http://mypanel-4k.com:80/me52pjdqa6/dt2t9r16ja/4825278
NOW英超1台,http://lunar.pm:8080/melodyg/uQnLQnTkRj/117457


凤凰卫视中文台,http://t.061899.xyz/tl/js/js.php?id=fhwszwt
凤凰卫视资讯台,http://t.061899.xyz/tl/js/js.php?id=fhwszxt
凤凰卫视香港台,http://t.061899.xyz/tl/js/js.php?id=fhwsxgt
TVB翡翠台,http://t.061899.xyz/tl/js/js.php?id=tvbfct
TVB无线新闻台,http://t.061899.xyz/tl/js/js.php?id=tvbwxxwt
TVB Plus,http://t.061899.xyz/tl/js/js.php?id=tvbplus
TVB明珠台,http://t.061899.xyz/tl/js/js.php?id=tvbmzt
香港有线新闻台,http://t.061899.xyz/tl/js/js.php?id=xgyxxwt
香港有线18台,http://t.061899.xyz/tl/js/js.php?id=18xgyxt
香港有线18台(备),http://t.061899.xyz/tl/js/js.php?id=18xgyxtb
NOW直播台,http://t.061899.xyz/tl/js/js.php?id=nowzbt
NOW新闻台,http://t.061899.xyz/tl/js/js.php?id=nowxwt
NOW财经台,http://t.061899.xyz/tl/js/js.php?id=nowcjt
ViuTV,http://t.061899.xyz/tl/js/js.php?id=viutv
ViuTV6,http://t.061899.xyz/tl/js/js.php?id=6viutv
HOY国际财经台,http://t.061899.xyz/tl/js/js.php?id=hoygjcjt
HOY资讯台,http://t.061899.xyz/tl/js/js.php?id=hoyzxt
HOY TV,http://t.061899.xyz/tl/js/js.php?id=hoytv
港台电视31,http://t.061899.xyz/tl/js/js.php?id=31gtds
港台电视32,http://t.061899.xyz/tl/js/js.php?id=32gtds
HBO HD,http://t.061899.xyz/tl/js/js.php?id=hbohd
好莱坞电影,http://t.061899.xyz/tl/js/js.php?id=hlwdy
Discovery,http://t.061899.xyz/tl/js/js.php?id=discovery
影迷數位電影台,http://t.061899.xyz/tl/js/js.php?id=ymswdyt
AMC电影台,http://t.061899.xyz/tl/js/js.php?id=amcdyt
靖天电影台,http://t.061899.xyz/tl/js/js.php?id=jtdyt
龙华电影,http://t.061899.xyz/tl/js/js.php?id=lhdy
采昌影剧,http://t.061899.xyz/tl/js/js.php?id=ccyj
民视影剧,http://t.061899.xyz/tl/js/js.php?id=msyj
龙华经典,http://t.061899.xyz/tl/js/js.php?id=lhjd
龙华戏剧,http://t.061899.xyz/tl/js/js.php?id=lhxj
龙华日韩,http://t.061899.xyz/tl/js/js.php?id=lhrh
龙华偶像,http://t.061899.xyz/tl/js/js.php?id=lhox
龙华卡通,http://t.061899.xyz/tl/js/js.php?id=lhkt

凤凰中文,p3p://108.181.32.169:38254/6410229e000655dd98612e41401e3e7d
凤凰资讯,p3p://108.181.32.169:38254/641022be000e5cc69861ad4f5a025336
凤凰香港台,p3p://108.181.32.169:38254/641022da0005d3069862188000a64525
TVB翡翠台,p3p://108.181.32.169:38254/6533f6560002787f2d01338b57197695
TVB翡翠台(b),p3p://108.181.32.169:38254/6533f5c20003762b2cfef1ac322c6404
VB翡翠台(d),p3p://108.181.32.169:38254/655daa1c00083272cfe6541e61d40be0
TVB翡翠台MY,p3p://108.181.32.169:38254/6533f6f8000f2ebd2d03af9d53e46544
无线新闻台,p3p://108.181.32.169:38254/6533fd5600043bdb2d1c8c0729c35d0c
无线新闻台(b),p3p://108.181.32.169:38254/6533f9fb00006d352d0f6f9235041f8d
无线财经台,p3p://108.181.32.169:38254/64100aec000c7bc59804a081537730cb
TVB明珠台Pearl,p3p://108.181.32.169:38254/6533f84d00047c732d08e0ea71ab4e92
TVB星河粤语,p3p://108.181.32.169:38254/641021c50003c5af985dddf037af353c
TVB星河国语,p3p://108.181.32.169:38254/641021e900026b0f985e6a374d7d56bb
TVB功夫台,p3p://108.181.32.169:38254/6411291b0004b01b9c62861646d00929
TVB娱乐新闻台,p3p://108.181.32.169:38254/64102219000c6f74985f28485a5a5799
TVB J2,p3p://108.181.32.169:38254/641021800006a527985cd1244315142d
TVB经典台,p3p://108.181.32.169:38254/6410219e0000704b985d44bd2a501d47
TVB爆谷台(不稳定),p3p://108.181.32.169:38254/641af90c000328bac2b691f11db2274a
TVB星影台(不稳定),p3p://108.181.32.169:38254/641af926000cc2b9c2b6f9f75c8d2b97
电影一台,p3p://108.181.32.169:38254/6410224e00097a01985ff68e53d22e70
VIU TV,p3p://108.181.32.169:38254/641021400008eb86985bd7b90b510a5b
VIU six,p3p://108.181.32.169:38254/6410215d000ad4ca985c497e192b3552
RHK 31,p3p://108.181.32.169:38254/64101f330006ab429853d45f7940453b
RHK 32,p3p://108.181.32.169:38254/641020b00001b8599859a360613572d7
HOY咨询台有线新闻台,p3p://108.181.32.169:38254/6533f8d200067abd2d0ae8f534c10d88
HOY咨询台有线新闻台(b),p3p://108.181.32.169:38254/6427e50e0008e093f53042b347a45e2f
有线体育台,p3p://108.181.32.169:38254/64100a6b000527e19802a6b80be147fa
有线耀才财经,p3p://108.181.32.169:38254/64102268000ecb1f98605d7b0a602bf4
mytv super,p3p://108.181.32.169:38254/6533f044000117a52ce97ce95ac54bb3
有线18台跑马,p3p://108.181.32.169:38254/6533f34d0002237a2cf5584a11195950
CH288跑马,p3p://108.181.32.169:38254/6533f484000c2b3e2cfa19b55cab3b9b
CH289跑马,p3p://108.181.32.169:38254/6533f5040003559d2cfc0b7268db0ab8
NOW财经台,p3p://108.181.32.169:38254/641020d00004bf91985a212731011c3c
NOW直播台,p3p://108.181.32.169:38254/6417e77b0007feb1b6b9f4ca25bc6e04
NOW新闻台,p3p://108.181.32.169:38254/6410254c0006df63986ba60f292a7500
Now体育英超,p3p://108.181.32.169:38254/64b8f92b000089e02be334b114c32320
Now plus,p3p://108.181.32.169:38254/64b8f962000df4a32be40ef90d9f4afd
NOW体育台,p3p://108.181.32.169:38254/6410211d00048968985b4de16d6e5b6a
EPL nsports 英超4keng,p3p://108.181.32.169:38254/64d74cf7000556f0223ed6366e5f689a
EPL nsports 英超1eng,p3p://108.181.32.169:38254/64d74cb1000cc276223dc6ac654a2299
EPL nsports 英超4k1粤语,p3p://108.181.32.169:38254/64d74ca40007202e223d927267473868
EPL nsports 英超 粤语,p3p://108.181.32.169:38254/64d74c1600083555223b68096e79387e
Now体育1 Sports 1,p3p://108.181.32.169:38254/643361f20007b9a9220fabfc3001244e
Now体育2 Sports 2,p3p://108.181.32.169:38254/643362090006b031221005903b883d07
Now体育3 Sports 3,p3p://108.181.32.169:38254/6433621d000d9c3522105573223958e1
Now体育4 Sports 4,p3p://108.181.32.169:38254/6437999f00025f983289265f38ef3722
Now体育5 Sports 5,p3p://108.181.32.169:38254/643799aa000e7bac3289547135e05a80
Now体育6 Sports 6,p3p://108.181.32.169:38254/643799bb00044f193289943e2e5f6ac1
Now体育7 Sports 7,p3p://108.181.32.169:38254/643799ca000a29a43289d0542d57262c
HBO,p3p://108.181.32.169:38254/64137f0b0006a17fa58238155813216c
HBO家庭,p3p://108.181.32.169:38254/64137f3c000d4a86a582f93235111bc5
HBO原创,p3p://108.181.32.169:38254/64137f700008f329a583c3344ddf5dfc
HBO强档,p3p://108.181.32.169:38254/64137f970005246ea5845a9326ce6233
凤凰资讯test,p3p://108.181.32.169:38254/641fd7b400080236d5bc536f5d82159c
Kix HD,p3p://108.181.32.169:38254/6413854d000785b1a59aaa2924fa1aa7
Discovery Channel,p3p://108.181.32.169:38254/641383f300048101a59561c464b07293
TVB黄金翡翠台维修中,p3p://108.181.32.169:38254/64206c63000c3a90d801201c5fe2483a
HOY TV HD(香港开电视)维修中,p3p://108.181.32.169:38254/641022340009a273985f91092cb6113d
TVB粤语片台维修中,p3p://108.181.32.169:38254/643361c7000d4bee220f05703b541d41
TVB华语剧台维修中,p3p://108.181.32.169:38254/643361e10003610a220f68773c0b4c78
TVB戏曲台维修中,p3p://108.181.32.169:38254/64336236000b18a12210b67722665e99
HKS, https://ott-iptv.top/shanxi/hks.php
iQIYI,p3p://108.181.32.169:38254/649672870005e0a5a5062d0e1384610b

央卫测试,#genre#

CCTV-1综合,http://www.96335.top:4566/udp/239.81.0.102:4056
CCTV-2财经,http://www.96335.top:4566/udp/239.81.0.115:4056
CCTV-3综艺,http://www.96335.top:4566/udp/239.81.0.231:4056
CCTV-4中文国际,http://www.96335.top:4566/udp/239.81.0.96:4056
CCTV-5体育,http://www.96335.top:4566/udp/239.81.0.232:4056
CCTV-5+体育赛事,http://www.96335.top:4566/udp/239.81.0.101:4056
CCTV-6电影,http://www.96335.top:4566/udp/239.81.0.233:4056
CCTV-7国防军事,http://www.96335.top:4566/udp/239.81.0.116:4056
CCTV-8电视剧,http://www.96335.top:4566/udp/239.81.0.234:4056
CCTV-9纪录,http://www.96335.top:4566/udp/239.81.0.117:4056
CCTV-10科教,http://www.96335.top:4566/udp/239.81.0.118:4056
CCTV-11戏曲,http://www.96335.top:4566/udp/239.81.0.229:4056
CCTV-12社会与法,http://www.96335.top:4566/udp/239.81.0.119:4056
CCTV-13新闻,http://www.96335.top:4566/udp/239.81.0.206:4056
CCTV-14少儿,http://www.96335.top:4566/udp/239.81.0.120:4056
CCTV-15音乐,http://www.96335.top:4566/udp/239.81.0.230:4056
CCTV-17农业农村,http://www.96335.top:4566/udp/239.81.0.228:4056
北京卫视,http://www.96335.top:4566/udp/239.81.0.109:4056
天津卫视,http://www.96335.top:4566/udp/239.81.0.113:4056
东方卫视,http://www.96335.top:4566/udp/239.81.0.111:4056
浙江卫视,http://www.96335.top:4566/udp/239.81.0.108:4056
安徽卫视,http://www.96335.top:4566/udp/239.81.0.211:4056
江苏卫视,http://www.96335.top:4566/udp/239.81.0.106:4056
山东卫视,http://www.96335.top:4566/udp/239.81.0.114:4056
广东卫视,http://www.96335.top:4566/udp/239.81.0.104:4056
四川卫视,http://www.96335.top:4566/udp/239.81.0.130:4056
深圳卫视,http://www.96335.top:4566/udp/239.81.0.103:4056
湖南卫视,http://www.96335.top:4566/udp/239.81.0.110:4056
湖北卫视,http://www.96335.top:4566/udp/239.81.0.112:4056
河北卫视,http://www.96335.top:4566/udp/239.81.0.94:4056
江西卫视,http://www.96335.top:4566/udp/239.81.0.204:4056
东南卫视,http://www.96335.top:4566/udp/239.81.0.215:4056
贵州卫视,http://www.96335.top:4566/udp/239.81.0.95:4056
辽宁卫视,http://www.96335.top:4566/udp/239.81.0.210:4056
黑龙江卫视,http://www.96335.top:4566/udp/239.81.0.105:4056
甘肃卫视,http://www.96335.top:4566/udp/239.81.0.207:4056
重庆卫视,http://www.96335.top:4566/udp/239.81.0.47:4056
吉林卫视,http://www.96335.top:4566/udp/239.81.0.58:4056
陕西卫视,http://www.96335.top:4566/udp/239.81.0.89:4056
山西卫视,http://www.96335.top:4566/udp/239.81.0.49:4056
河南卫视,http://www.96335.top:4566/udp/239.81.0.44:4056
宁夏卫视,http://www.96335.top:4566/udp/239.81.0.60:4056
内蒙古卫视,http://www.96335.top:4566/udp/239.81.0.54:4056
青海卫视,http://www.96335.top:4566/udp/239.81.0.53:4056
新疆卫视,http://www.96335.top:4566/udp/239.81.0.46:4056
西藏卫视,http://www.96335.top:4566/udp/239.81.0.55:4056
云南卫视,http://www.96335.top:4566/udp/239.81.0.45:4056
海南卫视,http://www.96335.top:4566/udp/239.81.0.48:4056
三沙卫视,http://www.96335.top:4566/udp/239.81.0.242:4056
大湾区卫视,http://www.96335.top:4566/udp/239.81.0.32:4056
厦门卫视,http://www.96335.top:4566/udp/239.81.0.212:4056
兵团卫视,http://www.96335.top:4566/udp/239.81.0.213:4056
山东教育卫视,http://www.96335.top:4566/udp/239.81.0.93:4056
广西卫视,http://www.96335.top:4566/udp/239.81.0.107:4056
广西综艺旅游,http://www.96335.top:4566/udp/239.81.0.214:4056
广西影视频道,http://www.96335.top:4566/udp/239.81.0.250:4056
广西新闻频道,http://www.96335.top:4566/udp/239.81.0.248:4056
广西都市频道,http://www.96335.top:4566/udp/239.81.0.247:4056
广西国际频道,http://www.96335.top:4566/udp/239.81.0.8:4056
广西移动电视,http://www.96335.top:4566/udp/239.81.0.10:4056
南宁新闻综合,http://www.96335.top:4566/udp/239.81.0.241:4056
南宁影视娱乐,http://www.96335.top:4566/udp/239.81.0.128:4056
南宁公共频道,http://www.96335.top:4566/udp/239.81.0.129:4056
南宁文旅生活,http://www.96335.top:4566/udp/239.81.0.127:4056
柳州新闻,http://www.96335.top:4566/udp/239.81.0.134:4056
北海新闻,http://www.96335.top:4566/udp/239.81.0.136:4056
玉林新闻,http://www.96335.top:4566/udp/239.81.0.138:4056
贺州新闻,http://www.96335.top:4566/udp/239.81.0.137:4056
桂林新闻,http://www.96335.top:4566/udp/239.81.0.135:4056
华数爱上4K,http://www.96335.top:4566/udp/239.81.0.123:4056
广西IPTV7,http://www.96335.top:4566/udp/239.81.0.253:4056
广西IPTV8,http://www.96335.top:4566/udp/239.81.0.208:4056
IPTV6电影,http://www.96335.top:4566/udp/239.81.0.100:4056
IPTV12,http://www.96335.top:4566/udp/239.81.0.124:4056
IPTV5体育,http://www.96335.top:4566/udp/239.81.0.12:4056

央视网频,#genre#
CCTV1,http://38.75.136.137:98/gslb/dsdqpub/cctv1hd.m3u8?auth=testpub
CCTV2,http://38.75.136.137:98/gslb/dsdqpub/cctv2hd.m3u8?auth=testpub
CCTV3,http://38.75.136.137:98/gslb/dsdqpub/cctv3hd.m3u8?auth=testpub
CCTV4,http://38.75.136.137:98/gslb/dsdqpub/cctv4hd.m3u8?auth=testpub
CCTV5,http://38.75.136.137:98/gslb/dsdqpub/cctv5hd.m3u8?auth=testpub
CCTV6,http://38.75.136.137:98/gslb/dsdqpub/cctv6hd.m3u8?auth=testpub
CCTV7,http://38.75.136.137:98/gslb/dsdqpub/cctv7hd.m3u8?auth=testpub
CCTV8,http://38.75.136.137:98/gslb/dsdqpub/cctv8hd.m3u8?auth=testpub
CCTV9,http://38.75.136.137:98/gslb/dsdqpub/cctv9hd.m3u8?auth=testpub
CCTV13,http://38.75.136.137:98/gslb/dsdqpub/cctv13hd.m3u8?auth=testpub
邵氏电影,http://38.75.136.137:98/gslb/dsdqpub/lbssdy.m3u8?auth=testpub
邵氏武侠,http://38.75.136.137:98/gslb/dsdqpub/lbsswx.m3u8?auth=testpub
邵氏动作,http://38.75.136.137:98/gslb/dsdqpub/lbssdz.m3u8?auth=testpub
邵氏喜剧,http://38.75.136.137:98/gslb/dsdqpub/lbssxj.m3u8?auth=testpub
广东珠江,http://38.75.136.137:98/gslb/dsdqpub/gdzj.m3u8?auth=testpub
广东新闻,http://38.75.136.137:98/gslb/dsdqpub/gdxw.m3u8?auth=testpub
广东体育,http://38.75.136.137:98/gslb/dsdqpub/gdty.m3u8?auth=testpub

抖音央视,#genre#
🎵CCTV6,https://tv1288.xyz/douyin.php?type=rid&rid=208823316033
🎵CCTV13,https://tv1288.xyz/douyin.php?type=rid&rid=339638082961
🎵CCTV13,https://tv1288.xyz/douyin.php?type=rid&rid=870887192950
🎵CCTV13,https://tv1288.xyz/douyin.php?type=rid&rid=127453393722
🎵CCTV13,https://tv1288.xyz/douyin.php?type=rid&rid=547977714661
🎵CCTV2,https://tv1288.xyz/douyin.php?type=rid&rid=296728101980
🎵CCTV13,https://tv1288.xyz/douyin.php?type=rid&rid=127453393722

广东酒店,#genre#
广东体育高清,http://183.57.249.119:8183/tsfile/live/1000_1.m3u8
广东卫视高清,http://183.57.249.119:8183/tsfile/live/0125_1.m3u8
广东珠江高清,http://183.57.249.119:8183/tsfile/live/1001_1.m3u8
大湾区卫视高清,http://183.57.249.119:8183/tsfile/live/1002_1.m3u8
广东影视高清,http://183.57.249.119:8183/tsfile/live/1004_1.m3u8
CCTV1,http://183.57.249.119:8183/tsfile/live/0001_1.m3u8
CCTV2,http://183.57.249.119:8183/tsfile/live/0002_1.m3u8
CCTV3,http://183.57.249.119:8183/tsfile/live/0003_1.m3u8
CCTV4,http://183.57.249.119:8183/tsfile/live/0004_1.m3u8
CCTV5,http://183.57.249.119:8183/tsfile/live/0005_1.m3u8
CCTV6,http://183.57.249.119:8183/tsfile/live/0006_1.m3u8
CCTV7,http://183.57.249.119:8183/tsfile/live/0007_1.m3u8
CCTV8,http://183.57.249.119:8183/tsfile/live/0008_1.m3u8
CCTV9,http://183.57.249.119:8183/tsfile/live/0009_1.m3u8
CCTV10,http://183.57.249.119:8183/tsfile/live/0010_1.m3u8
CCTV11-戏曲,http://183.57.249.119:8183/tsfile/live/0011_1.m3u8
CCTV12,http://183.57.249.119:8183/tsfile/live/0012_1.m3u8
CCTV13-新闻,http://183.57.249.119:8183/tsfile/live/0013_1.m3u8
CCTV14,http://183.57.249.119:8183/tsfile/live/0014_1.m3u8
CCTV15,http://183.57.249.119:8183/tsfile/live/0015_1.m3u8
CCTV17农业农村,http://183.57.249.119:8183/tsfile/live/0016_1.m3u8
安徽卫视,http://183.57.249.119:8183/tsfile/live/0130_1.m3u8
湖南卫视高清,http://183.57.249.119:8183/tsfile/live/1007_1.m3u8
浙江卫视高清,http://183.57.249.119:8183/tsfile/live/1008_1.m3u8
江苏卫视高清,http://183.57.249.119:8183/tsfile/live/1009_1.m3u8
东方卫视高清,http://183.57.249.119:8183/tsfile/live/1010_1.m3u8
金鹰卡通,http://183.57.249.119:8183/tsfile/live/0123_1.m3u8
卡酷动画,http://183.57.249.119:8183/tsfile/live/1003_1.m3u8
风云足球,http://183.57.249.119:8183/tsfile/live/0120_1.m3u8
世界地理,http://183.57.249.119:8183/tsfile/live/1011_1.m3u8
风云剧场,http://183.57.249.119:8183/tsfile/live/1005_1.m3u8
河南卫视,http://183.57.249.119:8183/tsfile/live/0139_1.m3u8
黑龙江卫视,http://183.57.249.119:8183/tsfile/live/0143_1.m3u8
江西卫视,http://183.57.249.119:8183/tsfile/live/0138_1.m3u8
深圳卫视,http://183.57.249.119:8183/tsfile/live/0126_1.m3u8
湖北卫视,http://183.57.249.119:8183/tsfile/live/0132_1.m3u8
重庆卫视,http://183.57.249.119:8183/tsfile/live/0142_1.m3u8
东森电影,http://183.57.249.119:8183/tsfile/live/1013_1.m3u8

深圳酒店,#genre#

广东卫视,http://183.10.180.56:202/tsfile/live/1032_1.m3u8?key=txiptv&playlive=1&down=1
汕头综合,http://183.10.180.56:202/tsfile/live/1000_1.m3u8?key=txiptv&playlive=1&down=1
汕头经济,http://183.10.180.56:202/tsfile/live/1001_1.m3u8?key=txiptv&playlive=1&down=1
揭阳综合,http://183.10.180.56:202/tsfile/live/1004_1.m3u8?key=txiptv&playlive=1&down=1
揭阳公共,http://183.10.180.56:202/tsfile/live/1141_1.m3u8?key=txiptv&playlive=1&down=1
CCTV1,http://183.10.180.56:202/tsfile/live/1005_1.m3u8?key=txiptv&playlive=1&down=1
CCTV2,http://183.10.180.56:202/tsfile/live/1007_1.m3u8?key=txiptv&playlive=1&down=1
CCTV3,http://183.10.180.56:202/tsfile/live/1009_1.m3u8?key=txiptv&playlive=1&down=1
CCTV4,http://183.10.180.56:202/tsfile/live/1008_1.m3u8?key=txiptv&playlive=1&down=1
CCTV5,http://183.10.180.56:202/tsfile/live/1010_1.m3u8?key=txiptv&playlive=1&down=1
CCTV6,http://183.10.180.56:202/tsfile/live/1026_1.m3u8?key=txiptv&playlive=1&down=1
CCTV7,http://183.10.180.56:202/tsfile/live/1038_1.m3u8?key=txiptv&playlive=1&down=1
CCTV8,http://183.10.180.56:202/tsfile/live/1110_1.m3u8?key=txiptv&playlive=1&down=1
CCTV9,http://183.10.180.56:202/tsfile/live/1124_1.m3u8?key=txiptv&playlive=1&down=1
CCTV10,http://183.10.180.56:202/tsfile/live/1129_1.m3u8?key=txiptv&playlive=1&down=1
CCTV11,http://183.10.180.56:202/tsfile/live/1130_1.m3u8?key=txiptv&playlive=1&down=1
CCTV12,http://183.10.180.56:202/tsfile/live/1011_1.m3u8?key=txiptv&playlive=1&down=1
CCTV13,http://183.10.180.56:202/tsfile/live/1012_1.m3u8?key=txiptv&playlive=1&down=1
CCTV14,http://183.10.180.56:202/tsfile/live/1013_1.m3u8?key=txiptv&playlive=1&down=1
CCTV15,http://183.10.180.56:202/tsfile/live/1040_1.m3u8?key=txiptv&playlive=1&down=1
CCTV16,http://183.10.180.56:202/tsfile/live/1006_1.m3u8?key=txiptv&playlive=1&down=1
CCTV17,http://183.10.180.56:202/tsfile/live/1003_1.m3u8?key=txiptv&playlive=1&down=1
黑龙江卫视,http://183.10.180.56:202/tsfile/live/1014_1.m3u8?key=txiptv&playlive=1&down=1
山东卫视高清,http://183.10.180.56:202/tsfile/live/1015_1.m3u8?key=txiptv&playlive=1&down=1
河北卫视,http://183.10.180.56:202/tsfile/live/1016_1.m3u8?key=txiptv&playlive=1&down=1
河南卫视,http://183.10.180.56:202/tsfile/live/1017_1.m3u8?key=txiptv&playlive=1&down=1
山东教育,http://183.10.180.56:202/tsfile/live/1018_1.m3u8?key=txiptv&playlive=1&down=1
湖北卫视,http://183.10.180.56:202/tsfile/live/1019_1.m3u8?key=txiptv&playlive=1&down=1
吉林卫视,http://183.10.180.56:202/tsfile/live/1020_1.m3u8?key=txiptv&playlive=1&down=1
山西卫视,http://183.10.180.56:202/tsfile/live/1021_1.m3u8?key=txiptv&playlive=1&down=1
江西卫视,http://183.10.180.56:202/tsfile/live/1022_1.m3u8?key=txiptv&playlive=1&down=1
贵州卫视,http://183.10.180.56:202/tsfile/live/1023_1.m3u8?key=txiptv&playlive=1&down=1
宁夏卫视,http://183.10.180.56:202/tsfile/live/1024_1.m3u8?key=txiptv&playlive=1&down=1
内蒙古,http://183.10.180.56:202/tsfile/live/1025_1.m3u8?key=txiptv&playlive=1&down=1
海南卫视,http://183.10.180.56:202/tsfile/live/1027_1.m3u8?key=txiptv&playlive=1&down=1
广西卫视,http://183.10.180.56:202/tsfile/live/1028_1.m3u8?key=txiptv&playlive=1&down=1
四川卫视,http://183.10.180.56:202/tsfile/live/1030_1.m3u8?key=txiptv&playlive=1&down=1
东南卫视,http://183.10.180.56:202/tsfile/live/1031_1.m3u8?key=txiptv&playlive=1&down=1
广东珠江,http://183.10.180.56:202/tsfile/live/1002_1.m3u8?key=txiptv&playlive=1&down=1
广东新闻,http://183.10.180.56:202/tsfile/live/1033_1.m3u8?key=txiptv&playlive=1&down=1
广州影视,http://183.10.180.56:202/tsfile/live/1034_1.m3u8?key=txiptv&playlive=1&down=1
广州综合,http://183.10.180.56:202/tsfile/live/1035_1.m3u8?key=txiptv&playlive=1&down=1
佛山影视,http://183.10.180.56:202/tsfile/live/1036_1.m3u8?key=txiptv&playlive=1&down=1
佛山顺德,http://183.10.180.56:202/tsfile/live/1037_1.m3u8?key=txiptv&playlive=1&down=1
河源综合,http://183.10.180.56:202/tsfile/live/1039_1.m3u8?key=txiptv&playlive=1&down=1
梅州综合,http://183.10.180.56:202/tsfile/live/1041_1.m3u8?key=txiptv&playlive=1&down=1
深圳卫视,http://183.10.180.56:202/tsfile/live/1042_1.m3u8?key=txiptv&playlive=1&down=1
深圳都市,http://183.10.180.56:202/tsfile/live/1043_1.m3u8?key=txiptv&playlive=1&down=1
深圳龙岗频道,http://183.10.180.56:202/tsfile/live/1044_1.m3u8?key=txiptv&playlive=1&down=1
深圳电视剧,http://183.10.180.56:202/tsfile/live/1045_1.m3u8?key=txiptv&playlive=1&down=1
CCTV世界地理,http://183.10.180.56:202/tsfile/live/1046_1.m3u8?key=txiptv&playlive=1&down=1
第一剧场,http://183.10.180.56:202/tsfile/live/1047_1.m3u8?key=txiptv&playlive=1&down=1
怀旧剧场,http://183.10.180.56:202/tsfile/live/1048_1.m3u8?key=txiptv&playlive=1&down=1
风云剧场,http://183.10.180.56:202/tsfile/live/1049_1.m3u8?key=txiptv&playlive=1&down=1
天气预报,http://183.10.180.56:202/tsfile/live/1029_1.m3u8?key=txiptv&playlive=1&down=1

云南电信,#genre#
CCTV1综合,http://tvlist.top/jd/index.php?id=cctv1&qt=183.224.122.114:8014
CCTV2-财经,http://tvlist.top/jd/index.php?id=cctv2&qt=183.224.122.114:8014
CCTV3-综艺,http://tvlist.top/jd/index.php?id=cctv3&qt=183.224.122.114:8014
CCTV4-中文国际,http://tvlist.top/jd/index.php?id=cctv4&qt=183.224.122.114:8014
CCTV5-体育,http://tvlist.top/jd/index.php?id=cctv5&qt=183.224.122.114:8014
CCTV6-电影,http://tvlist.top/jd/index.php?id=cctv6&qt=183.224.122.114:8014
CCTV7-军事农业,http://tvlist.top/jd/index.php?id=cctv7&qt=183.224.122.114:8014
CCTV8-电视剧,http://tvlist.top/jd/index.php?id=cctv8&qt=183.224.122.114:8014
CCTV9-记录,http://tvlist.top/jd/index.php?id=cctv9&qt=183.224.122.114:8014
CCTV10,http://tvlist.top/jd/index.php?id=cctv10&qt=183.224.122.114:8014
CCTV11-戏曲,http://tvlist.top/jd/index.php?id=cctv11&qt=183.224.122.114:8014
CCTV12-社会与法,http://tvlist.top/jd/index.php?id=cctv12&qt=183.224.122.114:8014
CCTV13-新闻,http://tvlist.top/jd/index.php?id=cctv13&qt=183.224.122.114:8014
CCTV14-少儿,http://tvlist.top/jd/index.php?id=cctv14&qt=183.224.122.114:8014
CCTV15-音乐,http://tvlist.top/jd/index.php?id=cctv15&qt=183.224.122.114:8014
CCTV16,http://tvlist.top/jd/index.php?id=cctv16&qt=183.224.122.114:8014
CCTV5+,http://tvlist.top/jd/index.php?id=cctv5p&qt=183.224.122.114:8014
安徽卫视,http://tvlist.top/jd/index.php?id=ahws&qt=183.224.122.114:8014
北京卫视,http://tvlist.top/jd/index.php?id=bjws&qt=183.224.122.114:8014
重庆卫视,http://tvlist.top/jd/index.php?id=cqws&qt=183.224.122.114:8014
东方卫视,http://tvlist.top/jd/index.php?id=dfws&qt=183.224.122.114:8014
东南卫视,http://tvlist.top/jd/index.php?id=dnws&qt=183.224.122.114:8014
甘肃卫视,http://tvlist.top/jd/index.php?id=gsws&qt=183.224.122.114:8014
广西卫视,http://tvlist.top/jd/index.php?id=gxws&qt=183.224.122.114:8014
贵州卫视,http://tvlist.top/jd/index.php?id=gzws&qt=183.224.122.114:8014
河北卫视,http://tvlist.top/jd/index.php?id=hebeiws&qt=183.224.122.114:8014
河南卫视,http://tvlist.top/jd/index.php?id=hnws&qt=183.224.122.114:8014
黑龙江卫视,http://tvlist.top/jd/index.php?id=hljws&qt=183.224.122.114:8014
湖北卫视,http://tvlist.top/jd/index.php?id=hbws&qt=183.224.122.114:8014
湖南卫视,http://tvlist.top/jd/index.php?id=hunanws&qt=183.224.122.114:8014
吉林卫视,http://tvlist.top/jd/index.php?id=jlws&qt=183.224.122.114:8014
江苏卫视,http://tvlist.top/jd/index.php?id=jsws&qt=183.224.122.114:8014
江西卫视,http://tvlist.top/jd/index.php?id=jxws&qt=183.224.122.114:8014
康巴卫视,http://tvlist.top/jd/index.php?id=live4468&qt=183.224.122.114:8014
辽宁卫视,http://tvlist.top/jd/index.php?id=lnws&qt=183.224.122.114:8014
内蒙古卫视,http://tvlist.top/jd/index.php?id=neimenggu&qt=183.224.122.114:8014
宁夏卫视,http://tvlist.top/jd/index.php?id=linxws&qt=183.224.122.114:8014
农林卫视,http://tvlist.top/jd/index.php?id=live3843&qt=183.224.122.114:8014
青海卫视,http://tvlist.top/jd/index.php?id=qhws&qt=183.224.122.114:8014
厦门卫视,http://tvlist.top/jd/index.php?id=xmws&qt=183.224.122.114:8014
山东卫视,http://tvlist.top/jd/index.php?id=sdws&qt=183.224.122.114:8014
山西卫视,http://tvlist.top/jd/index.php?id=sxws&qt=183.224.122.114:8014
陕西卫视,http://tvlist.top/jd/index.php?id=shxws&qt=183.224.122.114:8014
深圳卫视,http://tvlist.top/jd/index.php?id=szws&qt=183.224.122.114:8014
四川卫视,http://tvlist.top/jd/index.php?id=scws&qt=183.224.122.114:8014
天津卫视,http://tvlist.top/jd/index.php?id=tjws&qt=183.224.122.114:8014
西藏卫视,http://tvlist.top/jd/index.php?id=xzws&qt=183.224.122.114:8014
新疆卫视,http://tvlist.top/jd/index.php?id=xjws&qt=183.224.122.114:8014
云南卫视,http://tvlist.top/jd/index.php?id=ynws&qt=183.224.122.114:8014
浙江卫视,http://tvlist.top/jd/index.php?id=zjws&qt=183.224.122.114:8014

网络电台,#genre#
巴登-符腾堡,https://streams.42u.de/BW-lq
萨克森,https://streams.42u.de/SAX-lq
夏日,https://streams.42u.de/egoSUN-lq
冬日,https://streams.42u.de/egoSNOW-lq
轻松酷炫,https://streams.42u.de/egoRAP-lq
摇滚,https://streams.42u.de/egoRIFF-lq
电子音乐,https://streams.42u.de/egoFLASH-lq
充满情感,https://streams.42u.de/egoSOUL-lq
连贯不断,https://streams.42u.de/egoPURE-lq
放松平静,https://streams.42u.de/egoCHILLOUT-lq
充满爵士风,https://streams.42u.de/egoJAZZ-lq
卡夫卡风格,https://streams.42u.de/Kavka-lq
电影感,https://streams.42u.de/Soundtrack-lq
霍夫曼与科尔曼电台,https://streams.42u.de/HK-lq
传奇,https://streams.42u.de/HallOfFame-lq
柔和顺畅,https://streams.42u.de/RNB-lq
广东,https://lhttp.qingting.fm/live/1257/64k.mp3
广东音乐,https://lhttp.qingting.fm/live/1260/64k.mp3
广东2,https://lhttp.qingting.fm/live/1259/64k.mp3
广东汽车,https://lhttp.qingting.fm/live/1262/64k.mp3
广东3,https://lhttp.qingting.fm/live/1264/64k.mp3
香港第三台,https://rthkaudio3-lh.akamaihd.net/i/radio3_1@355866/master.m3u8
亚洲经典,https://lhttp.qingting.fm/live/5021912/64k.mp3
亚洲热歌,https://live.ximalaya.com/radio-first-page-app/live/1908/64.m3u8?transcode=ts
HD音乐,https://lhttp.qingting.fm/live/15318341/64k.mp3
亚洲粤语,https://lhttp.qingting.fm/live/15318569/64k.mp3
亚洲天空,https://lhttp.qingting.fm/live/20071/64k.mp3
亚洲音乐,https://lhttp.qingting.fm/live/5022405/64k.mp3
澳门绿坉,https://fm995.ddns.net/hls1/fm995.m3u8
重庆音乐,https://lhttp.qingting.fm/live/647/64k.mp3
江苏音乐,https://lhttp.qingting.fm/live/4936/64k.mp3
广西音乐,https://lhttp.qingting.fm/live/4875/64k.mp3
陕西音乐,https://lhttp.qingting.fm/live/4873/64k.mp3
河南音乐,https://lhttp.qingting.fm/live/1206/64k.mp3
河南音乐2,https://lhttp.qingting.fm/live/1206/64k.mp3
香港古典音乐,https://rthkradio1-live.akamaized.net/hls/live/2035313/radio1/master.m3u8?sd=10&rebase=on
四川音乐,https://lhttp.qingting.fm/live/1110/64k.mp3
贵州音乐,https://lhttp.qingting.fm/live/20067/64k.mp3
湖北音乐,https://lhttp.qingting.fm/live/1289/64k.mp3
湖南音乐,https://lhttp.qingting.fm/live/4979/64k.mp3
吉林音乐,https://lhttp.qingting.fm/live/1831/64k.mp3
江西音乐,http://lhttp.qingting.fm/live/1802/64k.mp3
山西音乐,https://lhttp.qingting.fm/live/4932/64k.mp3
福建音乐,https://lhttp.qingting.fm/live/4585/64k.mp3
河北音乐,https://lhttp.qingting.fm/live/1649/64k.mp3
浙江音乐,https://lhttp.qingting.fm/live/4866/64k.mp3
CRI环球资讯广播,http://satellitepull.cnr.cn/live/wxhqzx01/playlist.m3u8
CRI华语环球广播,http://sk.cri.cn/hyhq.m3u8
CRI英语环球广播 China Plus Radio,http://sk.cri.cn/am846.m3u8
CRI外语教学广播 China Plus Radio,http://sk.cri.cn/am1008.m3u8
CRI南海之声,http://sk.cri.cn/nhzs.m3u8
CRI轻松调频,http://sk.cri.cn/915.m3u8
CRI粤语国际,http://sk.cri.cn/hxfh.m3u8
CNR中国之声,http://ngcdn001.cnr.cn/live/zgzs/index.m3u8
CNR经济之声,http://ngcdn002.cnr.cn/live/jjzs/index.m3u8
CNR文艺之声,http://audiows010.cnr.cn/live/wyzs192/playlist.m3u8
上海长三角之声,http://satellitepull.cnr.cn/live/wx32dfgbdt/playlist.m3u8
上海第一财经广播,http://satellitepull.cnr.cn/live/wx32dycjgb/playlist.m3u8
湖南旅游广播·PoPoPod播客电台,http://satellitepull.cnr.cn/live/wx32hunlygb/playlist.m3u8
江苏新闻综合广播,http://satellitepull.cnr.cn/live/wx32jsxwzhgb/playlist.m3u8
江苏文艺广播,http://satellitepull.cnr.cn/live/wx32jswygb/playlist.m3u8
江苏财经广播,http://satellitepull.cnr.cn/live/wx32jscjgb/playlist.m3u8
安徽之声,http://satellitepull.cnr.cn/live/wxahxxgb/playlist.m3u8
安徽生活广播·城市之声,http://satellitepull.cnr.cn/live/wxahshgb/playlist.m3u8
安徽经济广播,http://satellitepull.cnr.cn/live/wxahjjgb/playlist.m3u8
安徽交通广播,http://satellitepull.cnr.cn/live/wxahjtgb/playlist.m3u8
安徽旅游广播·高速之声,http://satellitepull.cnr.cn/live/wxahlygb/playlist.m3u8
安徽戏曲广播·动听995,http://satellitepull.cnr.cn/live/wxahxqgb/playlist.m3u8
安徽故事广播,http://satellitepull.cnr.cn/live/wxahxspsgb/playlist.m3u8
湖北之声,http://satellitepull.cnr.cn/live/wx32hubzsgb/playlist.m3u8
楚天交通广播,http://satellitepull.cnr.cn/live/wx32hubctjtgb/playlist.m3u8
福建都市广播·私家车987,http://satellitepull.cnr.cn/live/wx32fjdndsgb/playlist.m3u8
福建东南广播,http://satellitepull.cnr.cn/live/wx32fjdngb/playlist.m3u8
江西都市广播,http://satellitepull.cnr.cn/live/wx32jiangxdsgb/playlist.m3u8
山东交通广播,http://satellitepull.cnr.cn/live/wxsdjtgb/playlist.m3u8
山东体育休闲广播,http://satellitepull.cnr.cn/live/wxsdtyxxgb/playlist.m3u8
山东经济广播,http://satellitepull.cnr.cn/live/wxsdjjgb/playlist.m3u8
山东乡村广播,http://satellitepull.cnr.cn/live/wxsdxcgb/playlist.m3u8
陕西交通广播,http://satellitepull.cnr.cn/live/wxsxxjtgb/playlist.m3u8
陕西经济广播·896汽车调频,http://satellitepull.cnr.cn/live/wxsxxjjgb/playlist.m3u8
陕西都市广播·陕广新闻,http://satellitepull.cnr.cn/live/wxsxxdsgb/playlist.m3u8
陕西农村广播,http://satellitepull.cnr.cn/live/wxsxxncgb/playlist.m3u8
陕西戏曲广播,http://satellitepull.cnr.cn/live/wxsxxxqgb/playlist.m3u8
陕西新闻广播,http://satellitepull.cnr.cn/live/wxsxxxwgb/playlist.m3u8
浙江之声,http://satellitepull.cnr.cn/live/wxzjzs/playlist.m3u8
浙江经济广播,http://satellitepull.cnr.cn/live/wxzjjjgb/playlist.m3u8
浙江交通之声,http://satellitepull.cnr.cn/live/wxzjjtgb/playlist.m3u8
浙江民生资讯广播,http://satellitepull.cnr.cn/live/wxzjmsgb/playlist.m3u8
浙江城市之声,http://satellitepull.cnr.cn/live/wxzjcszs/playlist.m3u8
浙江旅游之声,http://satellitepull.cnr.cn/live/wxzj1045/playlist.m3u8
宁波新闻综合广播,http://ihzlh.linker.cc/ihzlh/zjnb_ts04_920.m3u8
宁波交通广播,http://ihzlh.linker.cc/ihzlh/zjnb_ts01_939.m3u8
宁波经济广播,http://ihzlh.linker.cc/ihzlh/zjnb_ts03_1029.m3u8
四川经济广播,http://satellitepull.cnr.cn/live/wxscjjgb/playlist.m3u8
四川文艺广播,http://satellitepull.cnr.cn/live/wxscwygb/playlist.m3u8
四川旅游生活广播,http://satellitepull.cnr.cn/live/wxsclyshgb/playlist.m3u8
四川交通广播,http://satellitepull.cnr.cn/live/wxscjtgb/playlist.m3u8
四川综合广播四川之声,http://satellitepull.cnr.cn/live/wxsczhgb/playlist.m3u8
四川私家车广播,http://satellitepull.cnr.cn/live/wxsc925/playlist.m3u8
贵州经济广播,http://satellitepull.cnr.cn/live/wx32gzjjgb/playlist.m3u8
贵州旅游广播,http://satellitepull.cnr.cn/live/wx32gzlygb/playlist.m3u8
贵州故事广播,http://satellitepull.cnr.cn/live/wx32gzgsgb/playlist.m3u8
贵州综合广播,http://satellitepull.cnr.cn/live/wx32gzwxwzhgb/playlist.m3u8
延边文艺生活广播,http://satellitepull.cnr.cn/live/wxybwyshgb/playlist.m3u8
辽宁之声,http://satellitepull.cnr.cn/live/wxlnzhgb/playlist.m3u8
辽宁乡村广播,http://satellitepull.cnr.cn/live/wxlnxcgb/playlist.m3u8
辽宁经济广播,http://satellitepull.cnr.cn/live/wxlnjjtb/playlist.m3u8
辽宁交通广播,http://satellitepull.cnr.cn/live/wxlnjtgb/playlist.m3u8
黑龙江都市女性广播,http://satellitepull.cnr.cn/live/wx32hljnxgb/playlist.m3u8
黑龙江高校广播,http://satellitepull.cnr.cn/live/wx32hljgxgb/playlist.m3u8
黑龙江老年少儿广播·爱家调频,http://satellitepull.cnr.cn/live/wx32hljajgb/playlist.m3u8
黑龙江朝鲜语广播,http://satellitepull.cnr.cn/live/wx32hljcygb/playlist.m3u8
内蒙古农村牧区广播绿野之声,http://satellitepull.cnr.cn/live/wx32nmglyzs/playlist.m3u8
内蒙古新闻广播,http://satellitepull.cnr.cn/live/wx32nmghyzhxwgb/playlist.m3u8
内蒙古经济生活广播,http://satellitepull.cnr.cn/live/wx32nmgjjgb/playlist.m3u8
内蒙古评书曲艺广播,http://satellitepull.cnr.cn/live/wx32nmgpsqy/playlist.m3u8
内蒙古蒙语对外广播草原之声,http://satellitepull.cnr.cn/live/wx32nmgdwgb/playlist.m3u8
内蒙古蒙语新闻综合广播,http://satellitepull.cnr.cn/live/wx32nmgmygb/playlist.m3u8
锡林郭勒汉语广播,http://satellitepull.cnr.cn/live/wx32nmgxlglhygb/playlist.m3u8
锡林郭勒蒙语广播,http://satellitepull.cnr.cn/live/wx32nmgxlglmygb/playlist.m3u8
阿拉善汉语广播,http://satellitepull.cnr.cn/live/wx32nmgalshygb/playlist.m3u8
阿拉善蒙语广播,http://satellitepull.cnr.cn/live/wx32nmgalsmygb/playlist.m3u8
呼伦贝尔汉语广播,http://satellitepull.cnr.cn/live/wx32nmghlbehygb/playlist.m3u8
呼伦贝尔蒙语广播,http://satellitepull.cnr.cn/live/wx32nmghlbemygb/playlist.m3u8
新疆私家车广播,http://satellitepull.cnr.cn/live/wxxjsjcgb/playlist.m3u8
甘肃经济广播,http://satellitepull.cnr.cn/live/wxgshhzs/playlist.m3u8
广西教育广播,http://satellitepull.cnr.cn/live/wx32gbjyshgb/playlist.m3u8
广西综合广播,http://satellitepull.cnr.cn/live/wx32gxrmgb/playlist.m3u8
广西北部湾之声,http://satellitepull.cnr.cn/live/wx32gxdwgb/playlist.m3u8
广西交通广播,http://satellitepull.cnr.cn/live/wx32gxjtgb/playlist.m3u8
云南新闻广播,http://satellitepull.cnr.cn/live/wxynxwgb/playlist.m3u8
云南经济广播·私家车电台,http://satellitepull.cnr.cn/live/wxynjjgb/playlist.m3u8
云南交通之声,http://satellitepull.cnr.cn/live/wxynjtgb/playlist.m3u8
云南旅游广播·香格里拉之声,http://satellitepull.cnr.cn/live/wxxgllzs/playlist.m3u8
云南民族广播,http://satellitepull.cnr.cn/live/wxynmzgb/playlist.m3u8
云南国际广播,http://satellitepull.cnr.cn/live/wxynsegb/playlist.m3u8
云南教育广播·知道分子,http://satellitepull.cnr.cn/live/wxynjygb/playlist.m3u8
宁夏经济广播,http://satellitepull.cnr.cn/live/wxnxjjgb/playlist.m3u8
宁夏新闻广播,http://satellitepull.cnr.cn/live/wxnxxwgb/playlist.m3u8
宁夏旅游广播,http://satellitepull.cnr.cn/live/wxnxdsgb/playlist.m3u8
青海新闻综合广播,http://satellitepull.cnr.cn/live/wx32qhwxzhgb/playlist.m3u8
青海经济广播,http://satellitepull.cnr.cn/live/wx32qhjjgb/playlist.m3u8
开州之声,http://183.64.174.171:10124/tlgb.m3u8
NPR·KJZZ,http://kjzz.streamguys1.com/kjzz_aac_high
NPR·WBEZ,http://stream.wbez.org/wbezlinear
NPR·MPR News,http://nis.stream.publicradio.org/nis.mp3
NPR·WOSU,http://wosu.streamguys1.com/NPR_256
NPR·KQED,http://hls.kqed.org/kqed/256/playlist.m3u8
CRI HIT FM,http://satellitepull.cnr.cn/live/wxgjlxyy/playlist.m3u8
CRI HIT FM,http://satellitepull.cnr.cn/live/wxhitfm/playlist.m3u8
陕西音乐广播,http://satellitepull.cnr.cn/live/wxsxxyygb/playlist.m3u8
陕西青少广播·好听1055,http://satellitepull.cnr.cn/live/wxsxxqcgb/playlist.m3u8
山东音乐广播,http://satellitepull.cnr.cn/live/wxsdyygb/playlist.m3u8
山东经典音乐广播,http://satellitepull.cnr.cn/live/wxsdshxxgb/playlist.m3u8
安徽音乐广播,http://satellitepull.cnr.cn/live/wxahyygb/playlist.m3u8
宁波音乐广播,http://ihzlh.linker.cc/ihzlh/zjnb_ts02_986.m3u8
湖南文艺广播·摩登音乐台,http://satellitepull.cnr.cn/live/wx32hunwygb/playlist.m3u8
内蒙古音乐之声,http://satellitepull.cnr.cn/live/wx32nmgyygb/playlist.m3u8
湖北经典音乐广播,http://satellitepull.cnr.cn/live/wx32hubyygb/playlist.m3u8
甘肃青春调频,http://satellitepull.cnr.cn/live/wxgsqcgb/playlist.m3u8
甘肃都市调频,http://satellitepull.cnr.cn/live/wxgsdstb/playlist.m3u8
广西音乐广播,http://satellitepull.cnr.cn/live/wx32gxwygb/playlist.m3u8
广西经济广播·女主播电台,http://satellitepull.cnr.cn/live/wx32gxjjgb/playlist.m3u8
云南音乐广播,http://satellitepull.cnr.cn/live/wxynyygb/playlist.m3u8
四川城市之音,http://satellitepull.cnr.cn/live/wxsccszs/playlist.m3u8
四川岷江音乐,http://satellitepull.cnr.cn/live/wxscmjyyt/playlist.m3u8
楚天音乐广播,http://satellitepull.cnr.cn/live/wx32hubctyygb/playlist.m3u8
江苏音乐广播,http://satellitepull.cnr.cn/live/wx32jsyygb/playlist.m3u8
江苏经典流行音乐广播,http://satellitepull.cnr.cn/live/wx32jsjdlxyy/playlist.m3u8
浙江音乐调频·动听968,http://satellitepull.cnr.cn/live/wxzj968/playlist.m3u8
河北音乐广播,http://satellitepull.cnr.cn/live/wxhebyygb/playlist.m3u8
广东音乐之声,http://satellitepull.cnr.cn/live/wxgdyyzs/playlist.m3u8
深圳飞扬971,http://satellitepull.cnr.cn/live/wxszfy971/playlist.m3u8
深圳生活942,http://satellitepull.cnr.cn/live/wxszsjcgb/playlist.m3u8
海南音乐广播,http://satellitepull.cnr.cn/live/wxhainyygb/playlist.m3u8
贵州音乐广播,http://satellitepull.cnr.cn/live/wx32gzyygb/playlist.m3u8
贵州都市广播,http://satellitepull.cnr.cn/live/wx32gzqcgb/playlist.m3u8
宁夏音乐广播,http://satellitepull.cnr.cn/live/wxnxyygb/playlist.m3u8
重庆音乐广播,http://satellitepull.cnr.cn/live/wxcqyygb/playlist.m3u8
江西音乐广播,http://satellitepull.cnr.cn/live/wx32jiangxyygb/playlist.m3u8
黑龙江音乐广播,http://satellitepull.cnr.cn/live/wx32hljyygb/playlist.m3u8
福建汽车音乐广播,http://satellitepull.cnr.cn/live/wx32fjdnyygb/playlist.m3u8
青岛摩登音乐调频,http://video11.qtv.com.cn/zhibo886/manifest.m3u8
辽宁经典音乐广播,http://satellitepull.cnr.cn/live/wxlnwygb/playlist.m3u8
青海交通音乐广播,http://satellitepull.cnr.cn/live/wx32qhjtyygb/playlist.m3u8
CGTN Radio,http://satellitepull.cnr.cn/live/wxhqzx01/playlist.m3u8
长三角之声,http://satellitepull.cnr.cn/live/wx32dfgbdt/playlist.m3u8
第一财经广播,http://satellitepull.cnr.cn/live/wx32dycjgb/playlist.m3u8
AsiaFM 亚洲经典,http://goldfm.cn:8000/goldfm
AsiaFM 亚洲天空,http://funradio.cn:8000/funradio
北京新闻广播,http://satellitepull.cnr.cn/live/wxbjxwgb/playlist.m3u8
湖北农村广播,http://satellitepull.cnr.cn/live/wx32hubncgb/playlist.m3u8
万州综合广播,http://123.146.162.24:8013/tslslive/L4cvRM0/hls/live_sd.m3u8
万州交通广播,http://123.146.162.24:8013/tslslive/gBEcw39/hls/live_sd.m3u8
四川新闻广播,http://satellitepull.cnr.cn/live/wxsclyshgb/playlist.m3u8
河南农村广播大象资讯台,http://satellitepull.cnr.cn/live/wxhnncgb/playlist.m3u8
北京经典969,http://satellitepull.cnr.cn/live/wxsdyygb/playlist.m3u8
深圳飞扬971,http://satellitepull.cnr.cn/live/wxszfy971/playlist.m3u8
深圳生活942,http://satellitepull.cnr.cn/live/wxszsjcgb/playlist.m3u8
青岛音乐体育广播,http://satellitepull.cnr.cn/live/wxlnwygb/playlist.m3u8
烟台音乐广播,http://live.yantaitv.cn/live/899686f2687848cdbe62b1c27f3b3fc1/111dcc2035384c579cb79a260591a4ea.m3u8
北京新闻,http://wstvcpudali.v.myalicdn.com/wstvcpud/udrmbtv9_1/index.m3u8?adapt=0&BR=audio
北京文艺,http://wstvcpudali.v.myalicdn.com/wstvcpud/udrmbtv2_1/index.m3u8?adapt=0&BR=audio
北京科教,http://wstvcpudali.v.myalicdn.com/wstvcpud/udrmbtv3_1/index.m3u8?adapt=0&BR=audio
北京影视,http://wstvcpudali.v.myalicdn.com/wstvcpud/udrmbtv4_1/index.m3u8?adapt=0&BR=audio
北京财经,http://wstvcpudali.v.myalicdn.com/wstvcpud/udrmbtv5_1/index.m3u8?adapt=0&BR=audio
北京生活,http://wstvcpudali.v.myalicdn.com/wstvcpud/udrmbtv7_1/index.m3u8?adapt=0&BR=audio
第一财经,http://a1live.livecdn.yicai.com/live/radio_tv.m3u8
湖南潇湘之声,http://satellitepull.cnr.cn/live/wx32hunyygb/playlist.m3u8
湖南经济广播,http://satellitepull.cnr.cn/live/wx32hunjjgb/playlist.m3u8
湖南旅游广播·PoPoPod播客电台,http://satellitepull.cnr.cn/live/wx32hunlygb/playlist.m3u8
湖南交通广播,http://satellitepull.cnr.cn/live/wx32hunjtgb/playlist.m3u8
湖南金鹰之声,http://satellitepull.cnr.cn/live/wx32955/playlist.m3u8
湖南综合广播,http://satellitepull.cnr.cn/live/wx32hunxwgb/playlist.m3u8
江苏故事广播,http://satellitepull.cnr.cn/live/wx32jsgsgb/playlist.m3u8
江苏新闻综合广播,http://satellitepull.cnr.cn/live/wx32jsxwzhgb/playlist.m3u8
江苏新闻广播,http://satellitepull.cnr.cn/live/wx32jsxwgb/playlist.m3u8
江苏文艺广播,http://satellitepull.cnr.cn/live/wx32jswygb/playlist.m3u8
江苏金陵之声,http://satellitepull.cnr.cn/live/wx32jsqctp/playlist.m3u8
江苏交通广播,http://satellitepull.cnr.cn/live/wx32jsjtgb/playlist.m3u8
江苏健康广播,http://satellitepull.cnr.cn/live/wx32jsjkgb/playlist.m3u8
安徽之声,http://satellitepull.cnr.cn/live/wxahxxgb/playlist.m3u8
安徽生活广播·城市之声,http://satellitepull.cnr.cn/live/wxahshgb/playlist.m3u8
安徽经济广播,http://satellitepull.cnr.cn/live/wxahjjgb/playlist.m3u8
安徽交通广播,http://satellitepull.cnr.cn/live/wxahjtgb/playlist.m3u8
安徽旅游广播·高速之声,http://satellitepull.cnr.cn/live/wxahlygb/playlist.m3u8
安徽戏曲广播·动听995,http://satellitepull.cnr.cn/live/wxahxqgb/playlist.m3u8
安徽故事广播,http://satellitepull.cnr.cn/live/wxahxspsgb/playlist.m3u8
湖北之声,http://satellitepull.cnr.cn/live/wx32hubzsgb/playlist.m3u8
楚天交通广播,http://satellitepull.cnr.cn/live/wx32hubctjtgb/playlist.m3u8
湖北亲子广播,http://satellitepull.cnr.cn/live/wx32hubfnetgb/playlist.m3u8
湖北生活广播,http://satellitepull.cnr.cn/live/wx32hubczshgb/playlist.m3u8
湖北城市之声,http://satellitepull.cnr.cn/live/wx32hubjtgb/playlist.m3u8
湖北资讯广播,http://satellitepull.cnr.cn/live/wx32hubzxgb/playlist.m3u8
河北文艺广播,http://satellitepull.cnr.cn/live/wxhebwygb/playlist.m3u8
河北综合广播,http://satellitepull.cnr.cn/live/wxhebzhgb/playlist.m3u8
河北交通广播,http://satellitepull.cnr.cn/live/wxhebjtgb/playlist.m3u8
河北经济广播,http://satellitepull.cnr.cn/live/wxhebjjgb/playlist.m3u8
河北生活广播,http://satellitepull.cnr.cn/live/wxhebshgb/playlist.m3u8
福建新闻广播,http://satellitepull.cnr.cn/live/wx32fjxwgb/playlist.m3u8
福建都市广播·私家车987,http://satellitepull.cnr.cn/live/wx32fjdndsgb/playlist.m3u8
福建交通广播,http://satellitepull.cnr.cn/live/wx32fjdnjtgb/playlist.m3u8
福建经济广播,http://satellitepull.cnr.cn/live/wx32fjdnjjgb/playlist.m3u8
福建东南广播,http://satellitepull.cnr.cn/live/wx32fjdngb/playlist.m3u8
江西综合新闻广播,http://satellitepull.cnr.cn/live/wx32jiangxxwgb/playlist.m3u8
江西都市广播,http://satellitepull.cnr.cn/live/wx32jiangxdsgb/playlist.m3u8
江西信息交通广播,http://satellitepull.cnr.cn/live/wx32jiangxjtgb/playlist.m3u8
江西民生广播,http://satellitepull.cnr.cn/live/wx32jiangxmsgb/playlist.m3u8
江西农村广播·绿色985,http://satellitepull.cnr.cn/live/wx32jiangxncgb/playlist.m3u8
山东交通广播,http://satellitepull.cnr.cn/live/wxsdjtgb/playlist.m3u8
山东体育休闲广播,http://satellitepull.cnr.cn/live/wxsdtyxxgb/playlist.m3u8
山东经济广播,http://satellitepull.cnr.cn/live/wxsdjjgb/playlist.m3u8
山东乡村广播,http://satellitepull.cnr.cn/live/wxsdxcgb/playlist.m3u8
陕西交通广播,http://satellitepull.cnr.cn/live/wxsxxjtgb/playlist.m3u8
陕西经济广播·896汽车调频,http://satellitepull.cnr.cn/live/wxsxxjjgb/playlist.m3u8
陕西都市广播·陕广新闻,http://satellitepull.cnr.cn/live/wxsxxdsgb/playlist.m3u8
陕西农村广播,http://satellitepull.cnr.cn/live/wxsxxncgb/playlist.m3u8
陕西戏曲广播,http://satellitepull.cnr.cn/live/wxsxxxqgb/playlist.m3u8
陕西新闻广播,http://satellitepull.cnr.cn/live/wxsxxxwgb/playlist.m3u8
浙江之声,http://satellitepull.cnr.cn/live/wxzjzs/playlist.m3u8
浙江经济广播,http://satellitepull.cnr.cn/live/wxzjjjgb/playlist.m3u8
浙江交通之声,http://satellitepull.cnr.cn/live/wxzjjtgb/playlist.m3u8
浙江民生资讯广播,http://satellitepull.cnr.cn/live/wxzjmsgb/playlist.m3u8
浙江城市之声,http://satellitepull.cnr.cn/live/wxzjcszs/playlist.m3u8
浙江旅游之声,http://satellitepull.cnr.cn/live/wxzj1045/playlist.m3u8
重庆都市广播·私家车938,http://satellitepull.cnr.cn/live/wxcqdsgb/playlist.m3u8
广东新闻广播,http://satellitepull.cnr.cn/live/wxgdxwgb/playlist.m3u8
广东股市广播,http://satellitepull.cnr.cn/live/wxgdgsgb/playlist.m3u8
广东文体广播,http://satellitepull.cnr.cn/live/wxgdwtgb/playlist.m3u8
广东城市之声,http://satellitepull.cnr.cn/live/wxgdcszs/playlist.m3u8
广东南粤之声,http://satellitepull.cnr.cn/live/wxnyzs/playlist.m3u8
珠江经济台,http://satellitepull.cnr.cn/live/wxgdzjjjt/playlist.m3u8
南方生活广播,http://satellitepull.cnr.cn/live/wxgdnfshgb/playlist.m3u8
羊城交通广播,http://satellitepull.cnr.cn/live/wxgdycjtt/playlist.m3u8
深圳交通广播,http://satellitepull.cnr.cn/live/wxszjjpl/playlist.m3u8
海南新闻广播,http://satellitepull.cnr.cn/live/wxhainxwgb/playlist.m3u8
海南交通广播,http://satellitepull.cnr.cn/live/wxhainjtgb/playlist.m3u8
四川经济广播,http://satellitepull.cnr.cn/live/wxscjjgb/playlist.m3u8
四川文艺广播,http://satellitepull.cnr.cn/live/wxscwygb/playlist.m3u8
四川交通广播,http://satellitepull.cnr.cn/live/wxscjtgb/playlist.m3u8
四川综合广播四川之声,http://satellitepull.cnr.cn/live/wxsczhgb/playlist.m3u8
四川私家车广播,http://satellitepull.cnr.cn/live/wxsc925/playlist.m3u8
贵州经济广播,http://satellitepull.cnr.cn/live/wx32gzjjgb/playlist.m3u8
贵州旅游广播,http://satellitepull.cnr.cn/live/wx32gzlygb/playlist.m3u8
贵州故事广播,http://satellitepull.cnr.cn/live/wx32gzgsgb/playlist.m3u8
贵州综合广播,http://satellitepull.cnr.cn/live/wx32gzwxwzhgb/playlist.m3u8
河南新闻广播,http://satellitepull.cnr.cn/live/wxhnxwgb/playlist.m3u8
河南经济广播,http://satellitepull.cnr.cn/live/wxhnjjgb/playlist.m3u8
河南戏曲广播,http://satellitepull.cnr.cn/live/wxhnxqgb/playlist.m3u8
河南教育广播,http://satellitepull.cnr.cn/live/wxhnlygb/playlist.m3u8
河南信息广播,http://satellitepull.cnr.cn/live/wxhnxxgb/playlist.m3u8
吉林新闻综合广播,http://satellitepull.cnr.cn/live/wxjlxwzhgb/playlist.m3u8
吉林交通广播,http://satellitepull.cnr.cn/live/wxjljtgb/playlist.m3u8
吉林乡村广播,http://satellitepull.cnr.cn/live/wxjlxcgb/playlist.m3u8
延边新闻广播,http://satellitepull.cnr.cn/live/wxybxwgb/playlist.m3u8
辽宁之声,http://satellitepull.cnr.cn/live/wxlnzhgb/playlist.m3u8
辽宁乡村广播,http://satellitepull.cnr.cn/live/wxlnxcgb/playlist.m3u8
辽宁经济广播,http://satellitepull.cnr.cn/live/wxlnjjtb/playlist.m3u8
辽宁交通广播,http://satellitepull.cnr.cn/live/wxlnjtgb/playlist.m3u8
黑龙江新闻广播,http://satellitepull.cnr.cn/live/wx32hljxwgb/playlist.m3u8
黑龙江交通广播,http://satellitepull.cnr.cn/live/wx32hljjtgb/playlist.m3u8
黑龙江都市女性广播,http://satellitepull.cnr.cn/live/wx32hljnxgb/playlist.m3u8
黑龙江高校广播,http://satellitepull.cnr.cn/live/wx32hljgxgb/playlist.m3u8
黑龙江老年少儿广播·爱家调频,http://satellitepull.cnr.cn/live/wx32hljajgb/playlist.m3u8
黑龙江乡村广播,http://satellitepull.cnr.cn/live/wx32hljxcgb/playlist.m3u8
黑龙江朝鲜语广播,http://satellitepull.cnr.cn/live/wx32hljcygb/playlist.m3u8
内蒙古农村牧区广播绿野之声,http://satellitepull.cnr.cn/live/wx32nmglyzs/playlist.m3u8
内蒙古新闻广播,http://satellitepull.cnr.cn/live/wx32nmghyzhxwgb/playlist.m3u8
内蒙古经济生活广播,http://satellitepull.cnr.cn/live/wx32nmgjjgb/playlist.m3u8
内蒙古评书曲艺广播,http://satellitepull.cnr.cn/live/wx32nmgpsqy/playlist.m3u8
内蒙古蒙语对外广播草原之声,http://satellitepull.cnr.cn/live/wx32nmgdwgb/playlist.m3u8
内蒙古蒙语新闻综合广播,http://satellitepull.cnr.cn/live/wx32nmgmygb/playlist.m3u8
锡林郭勒汉语广播,http://satellitepull.cnr.cn/live/wx32nmgxlglhygb/playlist.m3u8
锡林郭勒蒙语广播,http://satellitepull.cnr.cn/live/wx32nmgxlglmygb/playlist.m3u8
阿拉善汉语广播,http://satellitepull.cnr.cn/live/wx32nmgalshygb/playlist.m3u8
阿拉善蒙语广播,http://satellitepull.cnr.cn/live/wx32nmgalsmygb/playlist.m3u8
呼伦贝尔汉语广播,http://satellitepull.cnr.cn/live/wx32nmghlbehygb/playlist.m3u8
呼伦贝尔蒙语广播,http://satellitepull.cnr.cn/live/wx32nmghlbemygb/playlist.m3u8
新疆新闻广播,http://satellitepull.cnr.cn/live/wxxjxwgb/playlist.m3u8
新疆交通广播,http://satellitepull.cnr.cn/live/wxxjjtgb/playlist.m3u8
新疆私家车广播,http://satellitepull.cnr.cn/live/wxxjsjcgb/playlist.m3u8
新疆绿色广播,http://satellitepull.cnr.cn/live/wxxjlsgb/playlist.m3u8
西藏都市生活广播,http://satellitepull.cnr.cn/live/wxxzdsshgb/playlist.m3u8
西藏对外交通广播,http://satellitepull.cnr.cn/live/wxxzdwjtgb/playlist.m3u8
西藏汉语广播,http://satellitepull.cnr.cn/live/wxxzhygb/playlist.m3u8
西藏藏语广播,http://satellitepull.cnr.cn/live/wxxzzygb/playlist.m3u8
广西教育广播,http://satellitepull.cnr.cn/live/wx32gbjyshgb/playlist.m3u8
广西综合广播,http://satellitepull.cnr.cn/live/wx32gxrmgb/playlist.m3u8
广西北部湾之声,http://satellitepull.cnr.cn/live/wx32gxdwgb/playlist.m3u8
广西交通广播,http://satellitepull.cnr.cn/live/wx32gxjtgb/playlist.m3u8
云南新闻广播,http://satellitepull.cnr.cn/live/wxynxwgb/playlist.m3u8
云南经济广播·私家车电台,http://satellitepull.cnr.cn/live/wxynjjgb/playlist.m3u8
云南交通之声,http://satellitepull.cnr.cn/live/wxynjtgb/playlist.m3u8
云南旅游广播·香格里拉之声,http://satellitepull.cnr.cn/live/wxxgllzs/playlist.m3u8
云南民族广播,http://satellitepull.cnr.cn/live/wxynmzgb/playlist.m3u8
云南国际广播,http://satellitepull.cnr.cn/live/wxynsegb/playlist.m3u8
云南教育广播·知道分子,http://satellitepull.cnr.cn/live/wxynjygb/playlist.m3u8
宁夏经济广播,http://satellitepull.cnr.cn/live/wxnxjjgb/playlist.m3u8
宁夏旅游广播,http://satellitepull.cnr.cn/live/wxnxdsgb/playlist.m3u8
青海新闻综合广播,http://satellitepull.cnr.cn/live/wx32qhwxzhgb/playlist.m3u8
青海经济广播,http://satellitepull.cnr.cn/live/wx32qhjjgb/playlist.m3u8
安徽音乐广播,http://satellitepull.cnr.cn/live/wxahyygb/playlist.m3u8
陕西青少广播·好听1055,http://satellitepull.cnr.cn/live/wxsxxqcgb/playlist.m3u8
山东经典音乐广播,http://satellitepull.cnr.cn/live/wxsdshxxgb/playlist.m3u8
湖南文艺广播·摩登音乐台,http://satellitepull.cnr.cn/live/wx32hunwygb/playlist.m3u8
CRI HIT FM,http://satellitepull.cnr.cn/live/wxgjlxyy/playlist.m3u8
CRI HIT FM,http://satellitepull.cnr.cn/live/wxhitfm/playlist.m3u8
江西音乐广播,http://satellitepull.cnr.cn/live/wx32jiangxyygb/playlist.m3u8
内蒙古音乐之声,http://satellitepull.cnr.cn/live/wx32nmgyygb/playlist.m3u8
湖北经典音乐广播,http://satellitepull.cnr.cn/live/wx32hubyygb/playlist.m3u8
广西音乐广播,http://satellitepull.cnr.cn/live/wx32gxwygb/playlist.m3u8
广西经济广播·女主播电台,http://satellitepull.cnr.cn/live/wx32gxjjgb/playlist.m3u8
云南音乐广播,http://satellitepull.cnr.cn/live/wxynyygb/playlist.m3u8
四川城市之音,http://satellitepull.cnr.cn/live/wxsccszs/playlist.m3u8
四川岷江音乐,http://satellitepull.cnr.cn/live/wxscmjyyt/playlist.m3u8
楚天音乐广播,http://satellitepull.cnr.cn/live/wx32hubctyygb/playlist.m3u8
江苏音乐广播,http://satellitepull.cnr.cn/live/wx32jsyygb/playlist.m3u8
江苏经典流行音乐广播,http://satellitepull.cnr.cn/live/wx32jsjdlxyy/playlist.m3u8
浙江音乐调频·动听968,http://satellitepull.cnr.cn/live/wxzj968/playlist.m3u8
河北音乐广播,http://satellitepull.cnr.cn/live/wxhebyygb/playlist.m3u8
海南音乐广播,http://satellitepull.cnr.cn/live/wxhainyygb/playlist.m3u8
贵州音乐广播,http://satellitepull.cnr.cn/live/wx32gzyygb/playlist.m3u8
宁夏音乐广播,http://satellitepull.cnr.cn/live/wxnxyygb/playlist.m3u8
黑龙江音乐广播,http://satellitepull.cnr.cn/live/wx32hljyygb/playlist.m3u8
福建汽车音乐广播,http://satellitepull.cnr.cn/live/wx32fjdnyygb/playlist.m3u8
青海交通音乐广播,http://satellitepull.cnr.cn/live/wx32qhjtyygb/playlist.m3u8

海外频道,#genre#
SportsGrid,https://sportsgrid-tribal.amagi.tv/hls/amagi_hls_data_sportstri-sportsgrid-sportstribal/CDN/playlist.m3u8
BLEAV Football,https://139cdd2c07204547aa4c184866d2d662.mediatailor.us-west-2.amazonaws.com/v1/master/ba62fe743df0fe93366eba3a257d792884136c7f/Linear-493-BLEAV-FOOTBALL-SPORTSTRIBALTV/mt/sportstribaltv/493/hls/master/playlist.m3u8
Sports Connect,https://d1jl8oqlli7412.cloudfront.net/v1/master/9d062541f2ff39b5c0f48b743c6411d25f62fc25/SportsStudio-Passthrough-SportsConnect/index.m3u8
MTRSPT1,https://cdn-uw2-prod.tsv2.amagi.tv/linear/amg02873-kravemedia-mtrspt1-sportstribal/playlist.m3u8
RPM Motorsport,https://d1phlc8te2m7db.cloudfront.net/v1/master/9d062541f2ff39b5c0f48b743c6411d25f62fc25/RPM-SportsTribal/playlist.m3u8
United Fight Alliance,https://9ab4bcc639c845d2b682105f4e9afbf8.mediatailor.us-east-1.amazonaws.com/v1/master/44f73ba4d03e9607dcd9bebdcb8494d86964f1d8/SportsTribal-eu_UnitedFightAlliance/playlist.m3u8
FIGHT NETWORK,https://amg00966-amg00966c10-amgplt0201.playout.now3.amagi.tv/playlist/amg00966-amg00966c10-amgplt0201/playlist.m3u8
MVMT Culture,https://d15g7z5n3epv7t.cloudfront.net/v1/master/9d062541f2ff39b5c0f48b743c6411d25f62fc25/TheGrapplingNetwork-SportsTribal/236.m3u8
Harlem Globetrotters,https://32d0f0785a2a46d28117199f63ad73ea.mediatailor.us-east-1.amazonaws.com/v1/master/44f73ba4d03e9607dcd9bebdcb8494d86964f1d8/SportsTribal-eu_TheHarlemGlobeTrotters/playlist.m3u8
Cricket Gold,https://d1nj4u39ja4cn0.cloudfront.net/v1/master/9d062541f2ff39b5c0f48b743c6411d25f62fc25/FLS-MuxIP-CricketGold/418.m3u8
Lacrosse Channel,https://e9f5db0f59d6470c81af59545905e4e5.mediatailor.us-west-2.amazonaws.com/v1/master/9d062541f2ff39b5c0f48b743c6411d25f62fc25/SportsTribal-LacrosseChannel/LSN_SCTE.m3u8
Racquet,https://b01bd331ff0249b5a62e52ff0cd4104a.mediatailor.us-west-2.amazonaws.com/v1/master/ba62fe743df0fe93366eba3a257d792884136c7f/LINEAR-627-COURT-SPORTS-NETWORK-SPORTSTRIBALTV/mt/sportstribaltv/627/hls/master/playlist.m3u8
Action & Extreme,https://76eb25c25d284d038e4a785c7c982f9d.mediatailor.us-west-2.amazonaws.com/v1/master/ba62fe743df0fe93366eba3a257d792884136c7f/LINEAR-957-WORB-LATAM-ES-FAST-FREELIVESPORTS/957/freelivesports/hls/master/playlist.m3u8
GoPro,https://3a1b4d927c02473b806350cc162d271f.mediatailor.us-west-2.amazonaws.com/v1/master/ba62fe743df0fe93366eba3a257d792884136c7f/LINEAR-891-GOPRO-FREELIVESPORTS/mt/freelivesports/891/hls/master/playlist.m3u8
InTrouble,https://cdn-uw2-prod.tsv2.amagi.tv/linear/amg00861-terninternation-introuble-sportstribal/playlist.m3u8
World of Freesports,https://cdn-uw2-prod.tsv2.amagi.tv/linear/amg01866-mainstreammedia-freesportsinc-sportstribal/playlist.m3u8
FUEL TV,https://cdn-uw2-prod.tsv2.amagi.tv/linear/amg01074-fueltv-fueltvemeaen-sportstribal/playlist.m3u8
Poker,https://d39azd0vpxfn6x.cloudfront.net/v1/master/9d062541f2ff39b5c0f48b743c6411d25f62fc25/SportsTribal-MuxIP-WPTLive/406.m3u8
PokerGO,https://ea14c91ee2fb4faea1f381e9c9e51173.mediatailor.us-west-2.amazonaws.com/v1/master/ba62fe743df0fe93366eba3a257d792884136c7f/LINEAR-426-POKERGO-SPORTSTRIBALTV/mt/sportstribaltv/426/hls/master/playlist.m3u8
Poker Night In America,https://linear-1068.frequency.stream/dist/freelivesports/1068/hls/master/playlist.m3u8
Kozoom,https://cdn-uw2-prod.tsv2.amagi.tv/linear/amg01743-sportstribal-kozoom-sportstribal/playlist.m3u8
Outdoors,https://3100d8a6ad764beb9da3c6ebf285ba1b.mediatailor.us-west-2.amazonaws.com/v1/master/ba62fe743df0fe93366eba3a257d792884136c7f/LINEAR-600-OUTDOORAMERICA-FREELIVESPORTS/mt/freelivesports/600/hls/master/playlist.m3u8
Wired2Fish,https://b0530716d58747539cefbb49fbcf833c.mediatailor.us-west-2.amazonaws.com/v1/master/ba62fe743df0fe93366eba3a257d792884136c7f/LINEAR-80-WIRED2FISH-SPORTSTRIBALTV/mt/sportstribaltv/80/hls/master/playlist.m3u8
Pursuit UP,https://fca567973f1544d3b177a416690efb86.mediatailor.us-west-2.amazonaws.com/v1/master/ba62fe743df0fe93366eba3a257d792884136c7f/LINEAR-205-PURSUIT-CHANNEL-SPORTSTRIBALTV/mt/sportstribaltv/205/hls/master/playlist.m3u8
H20 TV,https://1261a78709344810a5b834d397509879.mediatailor.us-west-2.amazonaws.com/v1/master/ba62fe743df0fe93366eba3a257d792884136c7f/LINEAR-738-H2OTV-SPORTSTRIBALTV/mt/sportstribaltv/738/hls/master/playlist.m3u8
Skull Bound TV,https://f570dedd03914e34a94fa4d318deddb5.mediatailor.us-west-2.amazonaws.com/v1/master/2d2d0d97b0e548f025b2598a69b55bf30337aa0e/npp_796/4QT2WMPRUUVGQ48G9KYQ/hls3/now
Strongman Champions League,https://0864a05b1ca54a4e8fe73805bf810fa4.mediatailor.us-east-1.amazonaws.com/v1/master/04fd913bb278d8775298c26fdca9d9841f37601f/SportsTribal-gb_StrongmanChampionsLeague/playlist.m3u8
Choppertown,https://7d8dc76d676946ec8d372d4ed7b22333.mediatailor.us-west-2.amazonaws.com/v1/master/ba62fe743df0fe93366eba3a257d792884136c7f/LINEAR-11-CHOPPERTOWN-SPORTSTRIBAL/mt/sportstribaltv/11/hls/master/playlist.m3u8
The Boat Show,https://b74b2c1067794724b288f2e6996c2dad.mediatailor.us-east-1.amazonaws.com/v1/master/44f73ba4d03e9607dcd9bebdcb8494d86964f1d8/SportsTribal-eu_TheBoatShow/playlist.m3u8
Equestrian,https://hncfree-sportstribal.amagi.tv/hls/amagi_hls_data_sportstri-hncfree-sportstribal/CDN/playlist.m3u8
GCTV,https://cdn-uw2-prod.tsv2.amagi.tv/linear/amg00585-sportstribaltv-gctv-sportstribal/playlist.m3u8
MORE U,https://114933112aa649148b22f46d7798c6ce.mediatailor.us-east-1.amazonaws.com/v1/master/44f73ba4d03e9607dcd9bebdcb8494d86964f1d8/SportsTribal-eu_MoreU/playlist.m3u8
Entertainment,https://tracetv-tracesportstar-sportstribal.amagi.tv/hls/amagi_hls_data_tracetvAA-trace-sportstars-sportstribal/CDN/playlist.m3u8
American Stories Network,https://linear-1016.frequency.stream/dist/freelivesports/1016/hls/master/playlist.m3u8
Greatest Sports Legends & Laughs,https://3db084d1dd6f49ecbf809a40d8a446b2.mediatailor.us-east-1.amazonaws.com/v1/master/44f73ba4d03e9607dcd9bebdcb8494d86964f1d8/SportsTribal-eu_GreatestSportsLegendsandLaughs/playlist.m3u8
Documentary+,https://a38d899367d24b1197db60dedfa80262.mediatailor.us-west-2.amazonaws.com/v1/master/ba62fe743df0fe93366eba3a257d792884136c7f/LINEAR-887-DOCUMENTARYINTERNATIONAL-FREELIVESPORTS/mt/freelivesports/887/hls/master/playlist.m3u8
Drone TV,https://a480c1a918694b47b63f7ba07a0f1dc2.mediatailor.us-east-1.amazonaws.com/v1/master/44f73ba4d03e9607dcd9bebdcb8494d86964f1d8/SportsTribal-eu_DroneTV/playlist.m3u8

直播中国,#genre#
中央电视塔东,https://gcalic.v.myalicdn.com/gc/ztd_1/index.m3u8
中央电视塔南,https://gcalic.v.myalicdn.com/gc/ztn_1/index.m3u8
丽江古城万古楼遥望玉龙雪山,https://gcalic.v.myalicdn.com/gc/ljgcwglytylxs_1/index.m3u8
丽江古城大水车,https://gcalic.v.myalicdn.com/gc/ljgcdsc_1/index.m3u8
丽江古城大研花巷观景,https://gcalic.v.myalicdn.com/gc/ljgcdyhxgjt_1/index.m3u8
乌镇全景,https://gcalic.v.myalicdn.com/gc/zjwzblt_1/index.m3u8
乌镇蓝印花布,https://gcalic.v.myalicdn.com/gc/zjwzlyhb_1/index.m3u8
乌镇西市河,https://gcalic.v.myalicdn.com/gc/zjwzbblh_1/index.m3u8
乌镇龙形田,https://gcalic.v.myalicdn.com/gc/zjwzlxt_1/index.m3u8
乐山大佛全景,https://gcalic.v.myalicdn.com/gc/lsdfgfl_1/index.m3u8
云南丽江冰川,https://gcalic.v.myalicdn.com/gc/hkylxs05_1/index.m3u8
云南丽江印象实景,https://gcalic.v.myalicdn.com/gc/hkylxs01_1/index.m3u8
云南丽江玉龙雪山,https://gcalic.v.myalicdn.com/gc/ylxs11_1/index.m3u8
云南丽江玉龙雪山草甸,https://gcalic.v.myalicdn.com/gc/hkylxs06_1/index.m3u8
云南丽江蓝月谷,https://gcalic.v.myalicdn.com/gc/ylxs12_1/index.m3u8
云南大理崇圣寺三塔中景,https://gcalic.v.myalicdn.com/gc/dlst03_1/index.m3u8
云南大理崇圣寺三塔远景,https://gcalic.v.myalicdn.com/gc/dlst01_1/index.m3u8
云南白沙远眺玉龙雪山,https://gcalic.v.myalicdn.com/gc/hkylxs03_1/index.m3u8
五彩池,https://gcalic.v.myalicdn.com/gc/hlwcc_1/index.m3u8
八里沟风景区天界山玻璃栈道,https://gcalic.v.myalicdn.com/gc/blg03_1/index.m3u8
八里沟风景区桃花湾瀑布,https://gcalic.v.myalicdn.com/gc/blg05_1/index.m3u8
六盘山红军长征景区,https://gcalic.v.myalicdn.com/gc/lpsgmjng01_1/index.m3u8
南京玄武湖公园,https://gcalic.v.myalicdn.com/gc/xwh01_1/index.m3u8
厦门鼓浪屿,https://gcalic.v.myalicdn.com/gc/gly01_1/index.m3u8
四川四姑娘山隆珠措,https://gcalic.v.myalicdn.com/gc/sgns02_1/index.m3u8
四川峨眉山云海日出,https://gcalic.v.myalicdn.com/gc/emsarm_1/index.m3u8
四川峨眉山普贤菩萨铜像,https://gcalic.v.myalicdn.com/gc/emspxps_1/index.m3u8
四川峨眉山远眺万佛顶,https://gcalic.v.myalicdn.com/gc/emswfs_1/index.m3u8
四川峨眉山远眺贡嘎雪山,https://gcalic.v.myalicdn.com/gc/emsyh_1/index.m3u8
天涯石,https://gcalic.v.myalicdn.com/gc/tyhjtys_1/index.m3u8
安徽池州九华山风景区九华山,https://gcalic.v.myalicdn.com/gc/jhs05_1/index.m3u8
安徽黟县芦村远眺,https://gcalic.v.myalicdn.com/gc/yxlcyt_1/index.m3u8
安徽黟县西递牌坊,https://gcalic.v.myalicdn.com/gc/yxxdpf_1/index.m3u8
广西桂林漓江景区,https://gcalic.v.myalicdn.com/gc/gllj01_1/index.m3u8
广西玉林大容山莲花山顶,https://gcalic.v.myalicdn.com/gc/drs01_1/index.m3u8
张掖七彩丹霞,https://gcalic.v.myalicdn.com/gc/zyqcdx01_1/index.m3u8
恒山悬空寺全景,https://gcalic.v.myalicdn.com/gc/hsxksqj_1/index.m3u8
新疆天山,http://gctxyc.liveplay.myqcloud.com/gc/xjtcdhsz_1/index.m3u8
普陀山,https://gcalic.v.myalicdn.com/gc/pts01_1/index.m3u8
月牙泉,https://gcalic.v.myalicdn.com/gc/dhyyqsm_1/index.m3u8
望乡台,https://gcalic.v.myalicdn.com/gc/hlwxt_1/index.m3u8
江苏南京牛首山,https://gcalic.v.myalicdn.com/gc/nss01_1/index.m3u8
江苏徐州云龙湖风景区云龙山观景台西,https://gcalic.v.myalicdn.com/gc/ylh04_1/index.m3u8
泰山主峰,https://gcalic.v.myalicdn.com/gc/taishan01_1/index.m3u8
泰山十八盘,https://gcalic.v.myalicdn.com/gc/taishan05_1/index.m3u8
泰山南天门,https://gcalic.v.myalicdn.com/gc/hkts07_1/index.m3u8
泰山大观峰,https://gcalic.v.myalicdn.com/gc/taishan03_1/index.m3u8
泰山太平岭,https://gcalic.v.myalicdn.com/gc/hkts09_1/index.m3u8
泰山望人松,https://gcalic.v.myalicdn.com/gc/taishan02_1/index.m3u8
泰山玉皇顶,https://gcalic.v.myalicdn.com/gc/taishan06_1/index.m3u8
泰山白云亭悬崖,https://gcalic.v.myalicdn.com/gc/hkts02_1/index.m3u8
泰山碧霞祠,https://gcalic.v.myalicdn.com/gc/hkts03_1/index.m3u8
浙江舟山东极岛,https://gcalic.v.myalicdn.com/gc/djd01_1/index.m3u8
湖南张家界天门山西线玻璃栈道,https://gcalic.v.myalicdn.com/gc/tms05_1/index.m3u8
湖南张家界宝峰湖,https://gcalic.v.myalicdn.com/gc/zjjbfh_1/index.m3u8
湖南张家界御笔峰,https://gcalic.v.myalicdn.com/gc/zjjybf_1/index.m3u8
湖南张家界水绕四门,https://gcalic.v.myalicdn.com/gc/zjjsrsm_1/index.m3u8
狮子山鸟瞰丽江古城,https://gcalic.v.myalicdn.com/gc/ljgcszsnkgc_1/index.m3u8
福建武夷山玉女峰,https://gcalic.v.myalicdn.com/gc/wysynf_1/index.m3u8
福建漳州醉美沙滩翡翠湾,https://gcalic.v.myalicdn.com/gc/fcw03_1/index.m3u8
贵州省兴义市万峰林,https://gcalic.v.myalicdn.com/gc/xywfl_1/index.m3u8
都江堰鱼嘴,https://gcalic.v.myalicdn.com/gc/djyqyl1_1/index.m3u8
陕西洋县国宝朱鹮02,https://gcalic.v.myalicdn.com/gc/zh02_1/index.m3u8
雪乡大石碑,https://gcalic.v.myalicdn.com/gc/mdjxxdsb_1/index.m3u8
雪乡梦幻家园,https://gcalic.v.myalicdn.com/gc/mdjxxmhjyxj_1/index.m3u8
青岛崂山八水河,https://gcalic.v.myalicdn.com/gc/qdls02_1/index.m3u8
青岛崂山双福,https://gcalic.v.myalicdn.com/gc/qdls03_1/index.m3u8
鸣沙山,https://gcalic.v.myalicdn.com/gc/dhyyqst_1/index.m3u8
黄山,https://gcalic.v.myalicdn.com/gc/ahhs01_1/index.m3u8
黄山始信新道,https://gcalic.v.myalicdn.com/gc/hsyg_1/index.m3u8
黄山排云亭,https://gcalic.v.myalicdn.com/gc/hspyt_1/index.m3u8
黄山飞来石,https://gcalic.v.myalicdn.com/gc/hsptgy_1/index.m3u8
黄果树六角亭瀑布,https://gcalic.v.myalicdn.com/gc/hgsspzxdpb_1/index.m3u8
黄花城水长城01,https://gcalic.v.myalicdn.com/gc/wgw01_1/index.m3u8
黄花城水长城02,http://gctxyc.liveplay.myqcloud.com/gc/wgw02_1/index.m3u8
黄花城水长城03,https://gcalic.v.myalicdn.com/gc/wgw03_1/index.m3u8
黄龙,https://gcalic.v.myalicdn.com/gc/hlzycc_1/index.m3u8


轮播线路,#genre#
没有共产党就没有新中国,https://res.mq-link.com:4438/webapi/filestore/29c94d7dc5eb7b679c1abe4ac9927905258e014e.mp4?type=video&docid=50ea69&name=%E6%B2%A1%E6%9C%89%E5%85%B1%E4%BA%A7%E5%85%9A%E5%B0%B1%E6%B2%A1%E6%9C%89%E6%96%B0%E4%B8%AD%E5%9B%BD.mp4
义勇軍进行曲,https://res.mq-link.com:4438/webapi/filestore/a0e982bdd91a3fe2021714aa842d246d6051b28e.mp4?type=video&docid=750fff&name=%E4%B9%89%E5%8B%87%E5%86%9B%E8%BF%9B%E8%A1%8C%E6%9B%B2.mp4
社会主义好,https://res.mq-link.com:4438/webapi/filestore/a7b2316f72bed6d626ecc01328faa83c85756c45.mp4?type=video&docid=88bf27&name=%E7%A4%BE%E4%BC%9A%E4%B8%BB%E4%B9%89%E5%A5%BD.mp4
歌唱祖国,https://res.mq-link.com:4438/webapi/filestore/7c60661e08014bcc51cf7f395622c52309c0037a.mp4?type=video&docid=af123c&name=%E6%AD%8C%E5%94%B1%E7%A5%96%E5%9B%BD.mp4
我们走在大路上,https://res.mq-link.com:4438/webapi/filestore/1da7c0cd431c9219abc0fe7ad79196522315ad14.mp4?type=video&docid=fd68b3&name=%E6%88%91%E4%BB%AC%E8%B5%B0%E5%9C%A8%E5%A4%A7%E8%B7%AF%E4%B8%8A.mp4
爱的传说邰正宵,https://vd2.bdstatic.com/mda-refjgvx7nhrha8js/cae_h264/1747403357338896764/mda-refjgvx7nhrha8js.mp4
《我想有个家》1潘美辰,https://txmov2.a.kwimgs.com/upic/2025/11/18/22/BMjAyNTExMTgyMjQ3MTVfNjQ4ODU0MTg5XzE4MDIyODg1MjMzNF8yXzM=_b_Bb5d41a2406bf7df789775bba73557ae8.mp4
《我想有个家》2潘美辰,https://txmov2.a.kwimgs.com/upic/2025/11/18/22/BMjAyNTExMTgyMjUzNDFfNjQ4ODU0MTg5XzE4MDIyOTI2MTc3OF8yXzM=_b_B3bc4fd4526dc0eb2eab3ed7e8605446f.mp4
王菲-执迷不悔,http://vodcdn.video.taobao.com/oss/ali-video/15bf7da88b44048edaabe73d6b17c00b/video.m3u8
我的好兄弟,https://sns-video-default.xhscdn.com/stream/1/110/258/01e8c171e907fbe0010370019933a69c19_258.mp4

每日经济,http://swiftplay.hxkjmedia.com/tv/spbW.m3u8
长江烟花秀,https://video.cjyun.org/fs/record/20250912/3b3/ts/index.m3u8
变形金刚_4K,https://vd3.bdstatic.com/mda-nd6k8tnavw6sj0a5/uhd/cae_h264_delogo/1649341416749683469/mda-nd6k8tnavw6sj0a5.mp4

🎈9月3号阅兵回放,https://vip.dytt-cine.com/20250903/54616_ce842c8a/index.m3u8
🎈9月3号阅兵回放,https://vvip.high26-playback.com/20250903/20785_ad349260/index.m3u8
🎈9月3号阅兵回放,https://vd3.bdstatic.com/mda-ri283wyxe135szm5/576p/h264/1756880513304056354/mda-ri283wyxe135szm5.mp4
🎈9月3号阅兵回放,https://vd3.bdstatic.com/mda-ri2b90is4f6p4shy/cae_h264/1756888200825139529/mda-ri2b90is4f6p4shy.mp4
2019年国庆70周年阅兵,https://vodcnd11.rsfcxq.com/20250902/BM9AcAeq/index.m3u8
2015年抗战70周年阅兵,https://vodcnd11.rsfcxq.com/20250902/tLKkH9fN/index.m3u8
2009年国庆60周年阅兵,https://vodcnd11.rsfcxq.com/20250902/VPoOzOa4/index.m3u8
1999年国庆50周年阅兵,https://vodcnd11.rsfcxq.com/20250902/nmbxS9bN/index.m3u8
1984年国庆35周年阅兵,https://vodcnd11.rsfcxq.com/20250902/zc4ZGGYY/index.m3u8
阅兵装备详解,https://sns-video-default.xhscdn.com/stream/79/110/258/01e8bc3d97bc5b9e4f037001991f54f4f9_258.mp4
朝鲜视角阅兵,https://sns-video-default.xhscdn.com/stream/79/110/258/01e8be81aabc2e7a4f03700199282ce8e4_258.mp4

1949阅兵,https://vip.dytt-luck.com/20250923/24454_0af03ed6/index.m3u8
1950年阅兵新中国第一个国庆节阅兵,https://vip.dytt-luck.com/20250923/24455_b290a635/index.m3u8
1951年国庆大阅兵,https://vip.dytt-luck.com/20250923/24456_a2d336f8/index.m3u8
1952年国庆大阅兵,https://vip.dytt-luck.com/20250923/24457_f1ce00c0/index.m3u8
1953年国庆大阅兵,https://vip.dytt-luck.com/20250923/24458_a6796dbc/index.m3u8
1954年建国五周年国防部长彭德怀阅兵,https://vip.dytt-luck.com/20250923/24459_6320267b/index.m3u8
1955阅兵,https://vip.dytt-luck.com/20250923/24460_d6139184/index.m3u8
1956年国庆大阅兵,https://vip.dytt-luck.com/20250923/24461_f5733e3a/index.m3u8
1957年国庆大阅兵,https://vip.dytt-luck.com/20250923/24462_50299aa5/index.m3u8
1958年国庆9周年大阅兵,https://vip.dytt-luck.com/20250923/24463_eee75242/index.m3u8
1959庆祝建国十周年,https://vip.dytt-luck.com/20250923/24465_8d7c30cf/index.m3u8
1980年解放军演习,https://vip.dytt-luck.com/20250923/24464_ce169541/index.m3u8
1981年华北军事演习及阅兵式邓小平亲自到场观看,https://vip.dytt-luck.com/20250923/24467_6b3a8f76/index.m3u8
1984年邓小平大阅兵,https://vip.dytt-luck.com/20250923/24468_73a3d9df/index.m3u8
1999八一电影制片厂《世纪大阅兵》,https://vip.dytt-luck.com/20250923/24469_cd53dd33/index.m3u8
1999国庆阅兵,https://vip.dytt-luck.com/20250923/24470_37b47bc2/index.m3u8
2009《盛世大阅兵》,https://vip.dytt-luck.com/20250923/24471_07246f1a/index.m3u8
2009中国海上大阅兵,https://vip.dytt-luck.com/20250923/24472_cd9015a6/index.m3u8
2015中国抗日战争暨世界反法西斯战争胜利70周年阅兵,https://vip.dytt-luck.com/20250923/24466_0608bbe8/index.m3u8
2017建军90周年朱日和阅兵,https://vip.dytt-luck.com/20250923/24473_d0241607/index.m3u8
2019国庆70周年大阅兵.群众游行,https://vip.dytt-luck.com/20250923/24474_4184dfd0/index.m3u8

朝鲜劳动党成立80周年阅兵第01集,https://vip.dytt-kan.com/20251013/8033_fc5b3186/index.m3u8
朝鲜劳动党成立80周年阅兵第02集,https://vip.dytt-kan.com/20251013/8034_cc4af25f/index.m3u8
朝鲜劳动党成立80周年阅兵第03集,https://vip.dytt-kan.com/20251013/8035_a2b8a85a/index.m3u8
朝鲜劳动党成立80周年阅兵第04集,https://vip.dytt-kan.com/20251013/8036_750263db/index.m3u8

UFC格斗之夜②,https://txmov2.a.yximgs.com/bs3/video-hls/5189554226836202631_hlsb.m3u8?pkey=AAXSV7JAeO9odQjnMgyNIfPEebdRZsIbqDtZjPmCcngq2T3CpRqckqi4KWLMTP6c530T9vGf4V4Bhg9Zcy5rxoPU7dgU_WZCVRaBoyDNV2K2QZ93qPGe-Jav6ZOTDAYZP1k
UFC格斗①,https://txmov2.a.yximgs.com/mediacloud/acfun/acfun_video/8983d8c926edf403-e8bfe3f01cfa00a46eca126706bd7b1f-hls_1080p_h264_60_1.m3u8?pkey=ABBRbnXG8ub6M73LmC58Re5OToo6A8Ri64I86UPefcv6zytj5GaOBBp3auY1VHFouDRJDOfdcxTYd4Bhj8JAXIandAsR8MtUE6DC_7sLWZiknVnPOLLfTu1EAnm63boreF3g1S8IOU7iMlJArIveLlkEk9853uCGrvwqh2RmZgTwlu2Yy5M91OBRyQXXhSIBkkDANqVrKoTRsIW8Dt7P8eFS5TIWU8_nOEmGccAUJ9ky3ncc9WxMz9L9jpZamYmLfN0&safety_id=AALufSf0OHCmkfb0zHi92cpK
泰之战①,https://txmov2.a.yximgs.com/bs3/video-hls/5232338420747548479_hlsb.m3u8?pkey=AAUR7Wp4cKw3MEaOyv0EwH0kj1gOlii1ZrT8SUp9YTncOWbLEHJbYU-x-Yhtke7HqUQ6yr6Pbju4qJrcU5aaMmCaVrtTQFSkIPT20ZtqAdq3HfUJDPL1s0y8u3JSO6prRNg
武林风③,https://txmov2.a.yximgs.com/bs3/video-hls/5230931045761004318_hlsb.m3u8?pkey=AAVTKbr7pJ8xZ2oLnj2D_utkZtu68l5j3B0HGCAmoJda5-fVEzVWFCNOZ43xQmWN7DnRDPTHVhz1k8eE8OGAiVQKjvdjPlnqL9fJAHubPbSJ-If0h8PaVqVNfRZANTTZbQs

CityFM城市音乐台（24小时）,https://lhttp.qingting.fm/live/20500153/64k.mp3
清晨音乐台,https://lhttp.qingting.fm/live/4915/64k.mp3
怀集音乐之声,https://lhttp.qingting.fm/live/4804/64k.mp3
动听音乐台,https://lhttp.qingting.fm/live/5022107/64k.mp3
星河音乐,https://lhttp.qingting.fm/live/20210755/64k.mp3
80后音乐台,https://lhttp.qingting.fm/live/20207761/64k.mp3
90后潮流音悦台,https://lhttp.qingting.fm/live/20207760/64k.mp3
AsiaFM亚洲热歌台,https://lhttp.qingting.fm/live/20500208/64k.mp3
AsiaFM亚洲天空台,https://lhttp.qingting.fm/live/20071/64k.mp3
AsiaFM亚洲经典台,https://lhttp.qingting.fm/live/5021912/64k.mp3
云梦音乐台,https://lhttp.qingting.fm/live/20500187/64k.mp3


重温经典,http://php.jdshipin.com/PLTV/iptv.php?id=cwjd#http://php.jdshipin.com:8880/TVOD/iptv.php?id=cwjd
重温经典,https://php.946985.xyz/iptv/jacktv.php?id=3oiena
重温经典,https://gdcucc.v1.mk/gdcucc/cwjd.m3u8
重温经典,http://m.061899.xyz/mg/cwjd
峨眉电影,http://8.138.250.123:8888/edge-cache02.live3.omd.sc96655.com/live/emdy4k_8000.m3u8
搜狐剧场,https://hdl-vip-ws.qf.56.com/live/lc_11730.flv
五星体育,https://gdcucc.v1.mk/gdcucc/wxty.m3u8
1905电影网,http://xxwx.yoesun.com/xxw/1905电影网.php?id=1905#http://php.jdshipin.com:8880/1905.php?id=1905dy#http://php.jdshipin.com:8880/1905.php?id=1905dy2
1905电影网,http://xxwx.yoesun.com/xxw/1905电影网.php?id=1905电影网.php?id=1905



汶川,http://live.iwcmt.cn:90/live/zhxw.m3u8
文化影视,http://live.shaoxing.com.cn/video/s10001-sxtv3/index.m3u8?zzhed
钱江,http://ali-m-l.cztv.com/channels/lantian/channel002/1080p.m3u8
6,http://ali-m-l.cztv.com/channels/lantian/channel006/1080p.m3u8
JC乡村频道,http://live.jinchuanrmt.com:90/live/jcxc.m3u8
淇县电视台,http://tvpull.dxhmt.cn:9081/tv/10622-1.m3u8
襄城电视台,http://tvpull.dxhmt.cn:9081/tv/11025-1.m3u8
淅川广播电视台,http://tvpull.dxhmt.cn:9081/tv/11326-1.m3u8
延津电视台,http://tvpull.dxhmt.cn:9081/tv/10726-1.m3u8
壶关电视台,http://zmjp3jin.live.sxmty.com/live/hls/268fe96f955d496db37fb10bb887cda9/fc196029d289449ea524a94a95379a0d.m3u8?zshanxd
七星关电视台,https://p8.vzan.com:443/slowlive/147077707554082780/live.m3u8
萧山电视台,https://l.cztvcloud.com/channels/lantian/SXxiaoshan2/720p.m3u8
AYXTV,http://tvpull.dxhmt.cn:9081/tv/10522-1.m3u8
XXTV,http://tvpull.dxhmt.cn:9081/tv/10621-1.m3u8
什邡,http://live.sfrmt.com:85/live/zhpd.m3u8
PVA,http://video.epaper.pybtv.cn:8080/live/rtmp_live_demo.flv
LQTV,http://l.cztvcloud.com/channels/lantian/SXlongquan1/720p.m3u8
青田电视台,http://l.cztvcloud.com/channels/lantian/SXqingtian1/720p.m3u8
SYTV,http://l.cztvcloud.com/channels/lantian/SXsongyang1/720p.m3u8
云,http://l.cztvcloud.com/channels/lantian/SXyunhe1/720p.m3u8
天祝,https://play.kankanlive.com/live/1656487214793905.m3u8
快乐垂钓,http://8.138.7.223/tv/mgtv.php?id=218
普洱TV,https://zhibo.puerw.cn/puer/c752b300-602c-4083-8c5e-f6bb97b58f2d.m3u8

象视界,http://1.94.31.214/php/hntv.php?id=xsj